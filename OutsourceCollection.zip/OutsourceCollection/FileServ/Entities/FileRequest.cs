﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Entities
{
    public class FileRequest
    {
        public string Id { get; set; }
        public string RequestFrom { get; set; }
        public string RequestContract { get; set; }
        public DateTime RequestDateTime { get; set; }
        public RequestStatus Status { get; set; }
        public bool ForceExcute { get; set; }
        public string RequestStamp { get; set; }
    }

    public enum RequestStatus
    {
        Waitting = 10,
        Validating = 15,
        ValidatedSucessful = 16,
        ValidatedFailed = 17,
        Downloading = 20,
        Downloaded = 30,
        Packaging = 40,
        Packaged = 50,
        UploadingToShareFile = 60,
        UploadedToShareFile = 70,
        Replying = 80,
        Done = 90
    }
}

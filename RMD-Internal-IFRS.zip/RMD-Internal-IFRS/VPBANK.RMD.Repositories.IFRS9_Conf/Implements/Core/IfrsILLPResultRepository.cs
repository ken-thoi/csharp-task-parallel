﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Core
{
    public class IfrsILLPResultRepository : QueryRepository<IFRS9_ConfContext, IfrsILLPResult>, IIfrsILLPResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public IfrsILLPResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, IfrsILLPResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<IfrsILLPResult> FindAllILLPsByCustomerIdAndBusinessDate(string customerId, DateTime businessDate)
        {
            try
            {
                var queryExec = string.IsNullOrEmpty(customerId) || customerId.Equals("NULL", StringComparison.CurrentCultureIgnoreCase)
                    ? $"exec Core.Get_IFRS_ILLP_CustomerList '{businessDate.ToString(DefFormats.DATE_FORMAT)}', {"NULL"}"
                    : $"exec Core.Get_IFRS_ILLP_CustomerList '{businessDate.ToString(DefFormats.DATE_FORMAT)}', '{customerId}'";
                return QueryableRepository.QueryableSql(queryExec).AsEnumerable().ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Obsolete]
        public async Task<int> ConsolidateAdjustByBusinessDate(DateTime businessDate)
        {
            try
            {
                var queryExec = businessDate == null || businessDate == DateTime.MinValue
                    ? $"exec Tech.calculate_ILLP_Customer {null}"
                    : $"exec Tech.calculate_ILLP_Customer '{businessDate.ToString(DefFormats.DATE_FORMAT)}'";
                return await _context.Database.ExecuteSqlCommandAsync(queryExec);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

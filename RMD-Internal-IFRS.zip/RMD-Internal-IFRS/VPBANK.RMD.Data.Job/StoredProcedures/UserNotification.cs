﻿using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.StoredProcedures
{
    public class UserNotification : QueryObjectResult
    {
    }
}

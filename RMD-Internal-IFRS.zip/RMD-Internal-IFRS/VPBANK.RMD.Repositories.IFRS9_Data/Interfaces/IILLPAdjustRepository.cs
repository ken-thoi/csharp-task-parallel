﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Interfaces
{
    public interface IILLPAdjustRepository : IRepository<IFRS9_DataContext, ILLPAdjust, int>
    {
        List<ILLPAdjust> FindILLPAdjustByCustomerId(ILLPAdjust iLLPAdjust);
    }
}

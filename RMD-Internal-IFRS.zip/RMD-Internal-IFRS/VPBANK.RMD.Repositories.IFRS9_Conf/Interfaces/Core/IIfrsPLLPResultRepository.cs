﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core
{
    public interface IIfrsPLLPResultRepository : IQueryRepository<IFRS9_ConfContext, IfrsPLLPResult>
    {
        List<IfrsPLLPResult> FindAllContractByCustomerId(string customerId, DateTime businessDate);
    }
}

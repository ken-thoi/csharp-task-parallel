﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech
{
    [Table("Conf_LGD", Schema = "Tech")]
    public class ConfLgd : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Qtrr_Segment { get; set; }
        public string Product_Group { get; set; }
        public int Mob { get; set; }
        public decimal Lgd { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }
}

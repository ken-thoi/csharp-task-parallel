﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.WO;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.WO
{
    public class WrittenOffFileUploadResultRepository : QueryRepository<IFRS9_ConfContext, WrittenOffFileUploadResult>, IWrittenOffFileUploadResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public WrittenOffFileUploadResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, WrittenOffFileUploadResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<WrittenOffFileUploadResult> FindAllWrittenOffFileUploads(DateTime businessDate, int flowExecutionId, int taskExecutionId)
        {
            try
            {
                var queryExec = $"exec core.Get_Written_Off_File_Upload '{businessDate.ToString(DefFormats.DATE_FORMAT)}', {flowExecutionId}, {taskExecutionId}";
                return QueryableRepository.QueryableSql(queryExec).AsEnumerable().ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> CalculationWrittenOff(DateTime businessDate)
        {
            try
            {
                var queryExec = businessDate == null || businessDate == DateTime.MinValue || businessDate == DateTime.MaxValue
                    ? $"exec Tech.calculate_ILLP_Customer {null}"
                    : $"exec Tech.calculate_ILLP_Customer '{businessDate.ToString(DefFormats.DATE_FORMAT)}'";
                return await _context.Database.ExecuteSqlCommandAsync(queryExec);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
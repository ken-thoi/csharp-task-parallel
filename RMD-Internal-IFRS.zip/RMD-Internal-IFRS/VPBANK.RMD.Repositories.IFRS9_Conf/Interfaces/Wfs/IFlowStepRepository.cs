﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs
{
    public interface IFlowStepRepository : IRepository<IFRS9_ConfContext, FlowStep, int>
    {
        public List<FlowStep> FindAllByFlowId(int flowId);
        public Task<int> DeleteFlowStepByFlowId(int flowId);
    }
}

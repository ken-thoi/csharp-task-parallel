﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.AppEngines
{
    [Table("Engine_Batch_Log", Schema = "App")]
    public class EngineBatchLog : EntityBase<decimal>
    {
        [Key]
        public override decimal Pk_Id { get; set; }

        public decimal FK_Batch_ID { get; set; }

        public DateTime Business_Date { get; set; }

        public string Approach { get; set; }

        public string Entity_Code { get; set; }

        public string Scenario_ID { get; set; }

        public string Version_ID { get; set; }

        public string Batch_Status { get; set; }

        public int? SPID { get; set; }

        public int? Total_Engine { get; set; }

        public int? Number_Failed { get; set; }

        public int? Number_Success { get; set; }

        public DateTime? Start_Time { get; set; }

        public DateTime? End_Time { get; set; }

        public string failed_reason { get; set; }

        public string Executor { get; set; }
    }
}

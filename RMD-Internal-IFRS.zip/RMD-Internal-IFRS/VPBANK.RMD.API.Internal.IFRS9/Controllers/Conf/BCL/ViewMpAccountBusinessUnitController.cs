﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Serilog;
using System.Net;
using System;
using System.Linq;
using System.Collections.Generic;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.Collection.Views;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Utils.Common.Extensions;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.API.Common.Helpers.Errors;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Utils.Common.Helpers;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.BCL;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Conf.Views.BCL;
using System.Dynamic;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.BCL
{
    public class ViewMpAccountBusinessUnitController : QueryController<IFRS9_ConfContext, ViewMpAccountBusinessUnit, int>
    {
        private readonly RequestHandler _requestHandler;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IRequestObjectService _reqService;
        private readonly IApproveStatusRepository _reqStatusRepository;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IMpAccountBusinessUnitService _service;

        public ViewMpAccountBusinessUnitController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, ViewMpAccountBusinessUnit, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, ViewMpAccountBusinessUnit, int> genericRepository,

            RequestHandler requestHandler,
            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusRepository reqStatusRepository,
            IApproveStatusService appStaService,
            IMpAccountBusinessUnitService service) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;
            _reqRepository = reqRepository;
            _reqService = requestService;
            _reqStatusRepository = reqStatusRepository;
            _reqStatusService = appStaService;
            _service = service;
        }

        /// <summary>
        /// Get all usernames not be grant Business Unit (selected_item)
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<List<SelectedItem>> FindAllUsersNonBusinessUnit()
        {
            try
            {
                return Ok(_service.FindAllUsersNonBusinessUnit());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Create new or update request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly created or updated request</returns>
        [HttpPost, HttpPut]
        public async virtual Task<ActionResult<RequestObject>> Req([NotNull][FromBody] DataReq<ViewMpAccountBusinessUnitRequestable> req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || !req.Entity.Any())
                    return BadRequest(ModelState);

                _unitOfWork.BeginTransaction();

                // insert data
                var currentDate = DateTime.Now;
                var data = new RequestObject
                {
                    Pk_Id = req.Id,
                    Username = GetUserPayload().Username,
                    Payload = req.Entity.JsonSerialize(),
                    Payload_Clazz = typeof(ViewCollectionEmail).ToString(),
                    Comment = req.Comment,
                    Params = null,
                    Type = RequestEvents.END_POINT,
                    End_Point = GetFullUri().Replace(RequestSegment.SEGMENT_LAST_SEND_REQ, string.Empty),
                    Created_Dt = currentDate,
                    Approve_Uri_Api = _configuration.GetSection($"{nameof(AppSettings.Properties)}:{nameof(Properties.API_BASE)}").Value
                };
                var result = await _reqService.InsertOrUpdateAsync(data, RequestStatus.PENDING, RequestStep.PENDING, GetUserPayload().Username, currentDate);

                // save changed & commit
                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.Commit();

                // send noti
                var routerKey = Request.Path.Value.Replace(RequestSegment.SEGMENT_LAST_SEND_REQ, string.Empty);
                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                SendNotifications(ActionTypes.REQUEST, typeof(ViewCollectionEmail).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.PENDING, routerKey, subscribers, new ExpandoObject());

                // results
                return CreatedAtAction(nameof(Req), result);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Approve existed request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly approved request</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Apr([NotNull][FromRoute] int reqId, [NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || reqId == 0)
                    return BadRequest(ModelState);

                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                var entities = req.Payload.JsonDeSerialize<List<ViewMpAccountBusinessUnitRequestable>>();
                if (entities == null || entities.Count == 0)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                if (req.Type.ToUpper().Equals(RequestEvents.END_POINT, StringComparison.CurrentCultureIgnoreCase))
                {
                    var adds = new List<ViewMpAccountBusinessUnitRequestable>();
                    var updates = new List<ViewMpAccountBusinessUnitRequestable>();
                    var deletes = new List<ViewMpAccountBusinessUnitRequestable>();
                    foreach (var item in entities)
                    {
                        if (item.ReqActionType.Equals(ActionTypes.INSERT.ToDescription(), StringComparison.CurrentCultureIgnoreCase))
                            adds.Add(item);
                        else if (item.ReqActionType.Equals(ActionTypes.UPDATE.ToDescription(), StringComparison.CurrentCultureIgnoreCase) && item.ReqObjectType.Equals(ReqObjectTypes.NEW, StringComparison.CurrentCultureIgnoreCase))
                            updates.Add(item);
                        else if (item.ReqActionType.Equals(ActionTypes.DELETE.ToDescription(), StringComparison.CurrentCultureIgnoreCase))
                            deletes.Add(item);
                    }

                    _unitOfWork.BeginTransaction();

                    // insert data
                    if (adds.Any())
                        await _service.InsertListAsync(adds);
                    if (updates.Any())
                        await _service.UpdateListAsync(updates);
                    if (deletes.Any())
                        await _service.DeleteListAsync(deletes);

                    // req object & req status
                    req.Comment = approveStatusReq.Comment;
                    var result = await _reqService.InsertOrUpdateAsync(req, RequestStatus.APPROVED, RequestStep.APPROVED, GetUserPayload().Username, DateTime.Now);

                    // save changed & commit
                    await _unitOfWork.SaveChangesAsync();
                    _unitOfWork.Commit();

                    // send noti
                    var routerKey = req.End_Point.Replace(GetBaseUri(), string.Empty);
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.APPROVAL, typeof(ViewCollectionEmail).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.APPROVED, routerKey, subscribers, new ExpandoObject());

                    // results
                    return CreatedAtAction(nameof(Apr), req);
                }
                throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.EM204);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Validate for entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] ViewMpAccountBusinessUnitRequestable entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest();
                var results = _service.Validate(entity);
                if (results.Any())
                    return BadRequest(results);

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

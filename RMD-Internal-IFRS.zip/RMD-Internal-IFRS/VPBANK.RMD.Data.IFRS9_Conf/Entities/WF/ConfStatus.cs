﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Conf_Status", Schema = "WF")]
    public class ConfStatus : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Status_Type { get; set; }

        public string Status_Code { get; set; }

        public string Status_Name { get; set; }

        public string Description { get; set; }

        public bool Is_Deleted { get; set; }
    }
}

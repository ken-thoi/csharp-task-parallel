﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr
{
    [Table("Requests", Schema = "Apr")]
    public class Requests : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Request_Details { get; set; }
        public string Obj_Class { get; set; }
        public string Req_Type { get; set; }
        public string Uri_Base_Approve { get; set; }
        public string End_Point { get; set; }
        public string Created_By { get; set; }
        public DateTime Created_Time { get; set; }
    }
}

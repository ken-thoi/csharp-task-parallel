﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Serilog;
using System.Net;
using System;
using System.Linq;
using System.Collections.Generic;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Data.Collection.Views;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Services.Collection.Interfaces;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Utils.Common.Extensions;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Helpers.Errors;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Utils.Common.Helpers;
using VPBANK.RMD.Utils.Common.Datas;

namespace VPBANK.RMD.API.Internal.Controllers.Collection
{
    public class CollectionOutsourceEmailController : QueryController<CollectionContext, ViewCollectionEmail, int>
    {
        private readonly RequestHandler _requestHandler;
        private readonly ICollectionOutsourceEmailService _service;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IRequestObjectService _reqService;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IApproveStatusRepository _reqStatusRepository;

        public CollectionOutsourceEmailController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<CollectionContext> unitOfWork,
            ITrackableRepository<CollectionContext, ViewCollectionEmail, int> trackableRepository,
            IGenericRepository<CollectionContext, ViewCollectionEmail, int> genericRepository,

            RequestHandler requestHandler,
            ICollectionOutsourceEmailService service,
            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;
            _service = service;
            _reqRepository = reqRepository;
            _reqService = requestService;
            _reqStatusService = appStaService;
            _reqStatusRepository = reqStatusRepository;
        }

        /// <summary>
        /// Create new record.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="entity"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        public virtual async Task<ActionResult<ViewCollectionEmail>> Create([FromBody] ViewCollectionEmailDto entity)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                // insert data
                await _service.InsertAsync(entity);

                // results
                return CreatedAtAction(nameof(Create), new { pk_Id = entity.Pk_Id }, entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Update exists record.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="pk_Id"></param>
        /// <param name="entity"></param>
        /// <returns>A newly updated object</returns>
        /// <response code="200">Returns OK</response>
        /// <response code="400">If the item is null</response>
        /// <response code="404">The item is not found</response>
        [HttpPut(template: "{pk_Id}")]
        public virtual async Task<ActionResult<ViewCollectionEmail>> Update([FromRoute] int pk_Id, [FromBody] ViewCollectionEmailDto entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                if (!await _genericRepository.ExistsAsync(pk_Id))
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.EM002);

                await _service.UpdateAsync(entity);
                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Delete record.
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpDelete(template: "{pk_Id}")]
        public virtual async Task<IActionResult> Delete([FromRoute] int pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (!await _genericRepository.ExistsAsync(pk_Id))
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.EM002);

                await _service.DeleteAsync(pk_Id);
                return Ok();
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Create new or update request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly created or updated request</returns>
        [HttpPost, HttpPut]
        public async virtual Task<ActionResult<RequestObject>> Req([NotNull][FromBody] DataReq<ViewCollectionEmailDto> req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || !req.Entity.Any())
                    return BadRequest(ModelState);

                // insert data
                var currentDate = DateTime.Now;
                var data = new RequestObject
                {
                    Pk_Id = req.Id,
                    Username = GetUserPayload().Username,
                    Payload = req.Entity.JsonSerialize(),
                    Payload_Clazz = typeof(ViewCollectionEmail).ToString(),
                    Comment = req.Comment,
                    Params = null,
                    Type = RequestEvents.END_POINT,
                    End_Point = GetFullUri().Replace(RequestSegment.SEGMENT_LAST_SEND_REQ, string.Empty),
                    Created_Dt = currentDate,
                    Approve_Uri_Api = _configuration.GetSection(nameof(AppSettings.API_BASE)).Value
                };
                var result = await _reqService.InsertOrUpdateAsync(data, RequestStatus.PENDING, RequestStep.PENDING, GetUserPayload().Username, currentDate);

                // send noti
                var routerKey = Request.Path.Value.Replace(RequestSegment.SEGMENT_LAST_SEND_REQ, string.Empty);
                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                SendNotifications(ActionTypes.REQUEST, typeof(ViewCollectionEmail).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.PENDING, routerKey, subscribers);

                // results
                return CreatedAtAction(nameof(Req), result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Approve existed request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly approved request</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Apr([NotNull][FromRoute] int reqId, [NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || reqId == 0)
                    return BadRequest(ModelState);

                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                var entities = req.Payload.JsonDeSerialize<List<ViewCollectionEmailDto>>();
                if (entities == null || entities.Count == 0)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                if (req.Type.ToUpper().Equals(RequestEvents.END_POINT, StringComparison.CurrentCultureIgnoreCase))
                {
                    var adds = new List<ViewCollectionEmailDto>();
                    var updates = new List<ViewCollectionEmailDto>();
                    var deletes = new List<ViewCollectionEmailDto>();
                    foreach (var item in entities)
                    {
                        if (item.ReqActionType.Equals(ActionTypes.INSERT.ToDescription(), StringComparison.CurrentCultureIgnoreCase))
                            adds.Add(item);
                        else if (item.ReqActionType.Equals(ActionTypes.UPDATE.ToDescription(), StringComparison.CurrentCultureIgnoreCase) && item.ReqObjectType.Equals(ReqObjectTypes.NEW, StringComparison.CurrentCultureIgnoreCase))
                            updates.Add(item);
                        else if (item.ReqActionType.Equals(ActionTypes.DELETE.ToDescription(), StringComparison.CurrentCultureIgnoreCase))
                            deletes.Add(item);
                    }

                    // insert data
                    if (adds.Count > 0)
                        await _service.InsertListAsync(adds);
                    if (updates.Count > 0)
                        await _service.UpdateListAsync(updates);
                    if (deletes.Count > 0)
                        await _service.DeleteListAsync(deletes.Select(c => c.Pk_Id.Value).ToList());

                    // req object & req status
                    req.Comment = approveStatusReq.Comment;
                    var result = await _reqService.InsertOrUpdateAsync(req, RequestStatus.APPROVED, RequestStep.APPROVED, GetUserPayload().Username, DateTime.Now);

                    // send noti
                    var routerKey = req.End_Point.Replace(GetBaseUri(), string.Empty);
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.APPROVAL, typeof(ViewCollectionEmail).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.APPROVED, routerKey, subscribers);

                    // results
                    return CreatedAtAction(nameof(Apr), req);
                }
                throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.EM204);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Validate for entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] ViewCollectionEmailDto entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest();
                var results = _service.Validate(entity);
                if (results.Any())
                    return BadRequest(results);

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
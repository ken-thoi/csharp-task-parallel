﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Entities
{
    public class CustomerDocument
    {
        public int Id { get; set; }
        public int FK_Source { get; set; }
        public string CustomerName { get; set; }
        public string ContractNumber { get; set; }
        public string FilePackageName { get; set; }
        public string DocumentID { get; set; }
        public CustomerDocumentStatus Status { get; set; }
        public bool NeedReExcuted { get; set; }
        public DateTime ExcutedAt { get; set; }
        public int Priority { get; set; }
    }


    public enum CustomerDocumentStatus
    {
        Waitting = 10,
        Downloading = 20,
        Downloaded = 30,
        NotFoundAnyFile = 35,
        Packaging = 40,
        Packaged = 50,
        UploadingToShareFile = 60,
        UploadedToShareFile = 70,
        Replying = 80,
        Done = 90
    }
}

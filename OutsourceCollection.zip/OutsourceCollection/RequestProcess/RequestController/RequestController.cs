﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequestProcess.RequestController
{
    public static class RequestController
    {
        public static void GetRequest()
        {
            //get email list

        }
    }
}

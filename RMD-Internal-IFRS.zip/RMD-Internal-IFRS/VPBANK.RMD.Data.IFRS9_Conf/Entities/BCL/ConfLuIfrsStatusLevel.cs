﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_LU_IFRS_Status_Level", Schema = "BCL")]
    public class ConfLuIfrsStatusLevel : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Level_Oder { get; set; }
        public string Level_Display { get; set; }
        public string Status_Level_Description { get; set; }
    }
}

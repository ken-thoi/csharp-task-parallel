﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.BCL
{
    [Table("View_MP_Validation_Right", Schema = "BCL")]
    public class ViewMpValidationRight : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Business_Unit_Id { get; set; }
        public int Fk_Lu_Validation_Id { get; set; }
        public string Fk_Lu_Manual_File_Id { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Validation_Rule { get; set; }
        public string Validation_Description { get; set; }
        public string Validation_Source { get; set; }
        public string Fk_Validation_Type_Name { get; set; }
        public string Assign_Validation_Group { get; set; }
    }

    public class ViewMpValidationRightRequestable : Requestable
    {
        public int Fk_Business_Unit_Id { get; set; }
        public int Fk_Lu_Validation_Id { get; set; }
        public string Fk_Lu_Manual_File_Id { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Validation_Rule { get; set; }
        public string Validation_Description { get; set; }
        public string Validation_Source { get; set; }
        public string Fk_Validation_Type_Name { get; set; }
        public string Assign_Validation_Group { get; set; }
    }
}

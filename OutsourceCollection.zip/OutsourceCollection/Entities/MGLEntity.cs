﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class MGLEntity
    {
        public string SID { get; set; }
        public string Folder { get; set; }
        public string FileName { get; set; }
        public string Cif { get; set; }
        public string Os_Company { get; set; }
        public string Customer_Name { get; set; }
        public string Legal_ID { get; set; }
        public string Business_Date { get; set; }
        public string Contract_No { get; set; }
        public string Product_Group { get; set; }
        public string Duno_Goc { get; set; }
        public string Duno_Lai { get; set; }
        public string Current_No_Ovd_Days { get; set; }
        public string MGL_Flag { get; set; }
        public string So_tien_xin_dong { get; set; }
        public string Thoi_han_thanh_toan { get; set; }
        public string Branch_code { get; set; }
        public string Log_time { get; set; }

    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs
{
    public interface IFlowStepExecutionRepository : IRepository<IFRS9_ConfContext, FlowStepExecution, int>
    {
        public List<FlowStepExecution> FindAllByFlowExecutionId(int flowExecutionId);
        public List<FlowStepExecution> FindAllByFkCurrentTaskStepId(int fkCurrentTaskStepId);
        public List<FlowStepExecution> FindAllByFkCurrentTaskStepIdAndFkFlowExecutionId(int fkCurrentTaskStepId, int fkFlowExecutionId);
        public List<FlowStepExecution> FindAllByFkNextTaskStepIdAndFkFlowExecutionId(int fkNextTaskStepId, int fkFlowExecutionId);
        public Task<int> DeleteFlowStepExecutionByFlowId(int flowExecutionId);
    }
}

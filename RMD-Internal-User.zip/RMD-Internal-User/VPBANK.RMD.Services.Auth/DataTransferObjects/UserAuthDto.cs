﻿using System.ComponentModel.DataAnnotations;

namespace VPBANK.RMD.Services.Auth.DataTransferObjects
{
    public class UserAuthDto
    {
        [Required]
        public string Username { get; set; }
    }

    public class RefreshTokenDto
    {
        [Required]
        public string Username { get; set; }
    }

    public class RevokeTokenDto
    {
        public string Token { get; set; }
    }
}

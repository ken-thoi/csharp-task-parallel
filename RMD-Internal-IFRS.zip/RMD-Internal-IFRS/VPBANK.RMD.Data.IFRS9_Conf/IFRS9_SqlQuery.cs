﻿namespace VPBANK.RMD.Data.IFRS9_Conf
{
    public static class IFRS9_SqlQuery_Define
    {
        public static readonly string get_Table_IFRS_Validation = "EXECUTE IFRS9_Conf.dbo.get_Table_IFRS_Validation @Business_Date";
    }
}

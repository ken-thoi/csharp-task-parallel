﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using System.Net;
using Serilog;
using System.Threading.Tasks;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.Data.Auth.Entities.Views;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Services.Auth.DataTransferObjects;
using VPBANK.RMD.Utils.Common.Helpers.Paging;

namespace VPBANK.RMD.API.Auth.Controllers
{
    public class RoleController : QueryController<AuthContext, ViewUserRole, int>
    {
        protected readonly RequestHandler _requestHandler;
        protected readonly IUserRepository _userRepository;
        protected readonly IRoleService _roleService;

        public RoleController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<AuthContext> unitOfWork,
            ITrackableRepository<AuthContext, ViewUserRole, int> trackableRepository,
            IGenericRepository<AuthContext, ViewUserRole, int> genericRepository,

            RequestHandler requestHandler,
            IUserRepository userRepository,
            IRoleService roleService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;

            _userRepository = userRepository;
            _roleService = roleService;
        }

        /// <summary>
        /// Get all data roles
        /// </summary>
        /// <returns>List selected items (SelectedItem)</returns>
        [HttpGet]
        public IActionResult GuiDataRoles()
        {
            return Ok(_roleService.GuiDataRoles());
        }

        /// <summary>
        /// Save user with data role, func role, component role
        /// </summary>
        /// <param name="entity"></param>
        /// <returns>object UserRoleMappingDto</returns>
        [HttpPost]
        public virtual ActionResult<UserRoleMappingDto> SaveUserRoles([Required][NotNull][FromBody] UserRoleMappingDto entity)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                // insert data
                _roleService.Save(entity);

                // results
                return CreatedAtAction(nameof(SaveUserRoles), new { entity.Username }, entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Delete all roles by username
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual IActionResult DeleteUserRoles([Required][NotNull][FromBody] UserAuthDto entity)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                // insert data
                _roleService.DeleteRoleByUsername(entity.Username);

                // results
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Delete func role by username
        /// </summary>
        /// <param name="funcRole"></param>
        /// <returns></returns>
        [HttpDelete(template: "{funcRole}")]
        public virtual IActionResult DeleteFuncRole([Required][NotNull][FromRoute] string funcRole)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                _roleService.DeleteFunctionRole(funcRole);

                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Delete component role (set IsDeleted = true)
        /// </summary>
        /// <param name="compRole"></param>
        /// <returns></returns>
        [HttpDelete(template: "{compRole}")]
        public virtual IActionResult DeleteCompRole([Required][NotNull][FromRoute] string compRole)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                _roleService.DeleteComponentRole(compRole);

                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public override async Task<ActionResult<PaginatedContentResults<ViewUserRole>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                paginatedParams.FilterExpression = string.IsNullOrEmpty(paginatedParams.FilterExpression)
                        ? string.Empty
                        : $"{ConvertColumnNameToJsonFilter(paginatedParams.FilterExpression, true)}";

                if (paginatedParams.SortingParams != null && paginatedParams.SortingParams.Any())
                    foreach (var item in paginatedParams.SortingParams)
                        item.ColumnName = ConvertColumnNameToJsonFilter(item.ColumnName, false);

                if (paginatedParams.FilterParams != null && paginatedParams.FilterParams.Any())
                    foreach (var item in paginatedParams.FilterParams)
                        item.ColumnName = ConvertColumnNameToJsonFilter(item.ColumnName, false);

                return await base.Query(paginatedParams);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        private string ConvertColumnNameToJsonFilter(string jsonField, bool isfilterExpression)
        {
            var field = jsonField;
            if (isfilterExpression)
            {
                field = jsonField.Replace("id", "Pk_Id").Replace("superRole", "Super_Role").Replace("dataRole", "Data_Role")
                    .Replace("functionRole", "Function_Role").Replace("componentRole", "Component_Role").Replace("fkDataRole", "Data_Role");
            }
            else
            {
                switch (jsonField.ToLower())
                {
                    case "id":
                        field = "Pk_Id";
                        break;
                    case "superrole":
                        field = "Super_Role";
                        break;
                    case "datarole":
                        field = "Data_Role";
                        break;
                    case "functionrole":
                        field = "Function_Role";
                        break;
                    case "componentrole":
                        field = "Component_Role";
                        break;
                    case "fkdatarole":
                        field = "Data_Role";
                        break;
                }
            }
            return field;
        }

    }
}
﻿namespace VPBANK.RMD.API.Core
{
    public static class Globals
    {
    }
}

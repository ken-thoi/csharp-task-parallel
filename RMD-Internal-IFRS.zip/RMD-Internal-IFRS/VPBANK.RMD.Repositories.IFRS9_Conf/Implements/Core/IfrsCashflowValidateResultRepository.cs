﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Core
{
    public class IfrsCashflowValidateResultRepository : QueryRepository<IFRS9_ConfContext, IfrsCashflowValidateResult>, IIfrsCashflowValidateResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public IfrsCashflowValidateResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, IfrsCashflowValidateResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<IfrsCashflowValidateResult> ExecPopulateIllpCashflow(string customerId, int taskExecutionId)
        {
            try
            {
                var queryExec = $"exec tech.populate_ILLP_CF {taskExecutionId}, '{customerId}'";
                return QueryableRepository.QueryableSql(queryExec).AsEnumerable().ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

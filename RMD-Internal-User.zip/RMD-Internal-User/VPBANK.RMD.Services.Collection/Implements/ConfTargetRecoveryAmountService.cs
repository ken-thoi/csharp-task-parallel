﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Services.Collection.Interfaces;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Shared;

namespace VPBANK.RMD.Services.Collection.Implements
{
    public class ConfTargetRecoveryAmountService : IConfTargetRecoveryAmountService
    {
        private readonly IUnitOfWork<CollectionContext> _unitOfWork;
        private readonly IGenericRepository<CollectionContext, ConfTargetRecoveryAmount, int> _genConfTargetRecoveryAmountRepository;
        public ConfTargetRecoveryAmountService(IUnitOfWork<CollectionContext> unitOfWork,
            IGenericRepository<CollectionContext, ConfTargetRecoveryAmount, int> genConfTargetRecoveryAmountRepository)
        {
            _unitOfWork = unitOfWork;
            _genConfTargetRecoveryAmountRepository = genConfTargetRecoveryAmountRepository;
        }

        public IList<FieldValidateResponse> Validate(ConfTargetRecoveryAmountDto entity)
        {
            var results = new List<FieldValidateResponse>();
            try
            {
                if (string.IsNullOrEmpty(entity.Target_Month))
                    results.Add(new FieldValidateResponse
                    {
                        Error = string.Format(ErrorMessages.EM001, nameof(entity.Target_Month)),
                        Field = nameof(entity.Target_Month),
                        Description = string.Format(ErrorMessages.EM001, nameof(entity.Target_Month))
                    });
                if (string.IsNullOrEmpty(entity.Target_Year))
                    results.Add(new FieldValidateResponse
                    {
                        Error = string.Format(ErrorMessages.EM001, nameof(entity.Target_Year)),
                        Field = nameof(entity.Target_Month),
                        Description = string.Format(ErrorMessages.EM001, nameof(entity.Target_Year))
                    });
                if (entity.End_Date.HasValue && entity.End_Date.Value.Date < entity.Start_Date.Date)
                    results.Add(new FieldValidateResponse
                    {
                        Error = string.Format(ErrorMessages.EM019, "Effective To", "Effective From"),
                        Field = nameof(entity.End_Date),
                        Description = string.Format(ErrorMessages.EM019, "Effective To", "Effective From")
                    });
            }
            catch (Exception ex)
            {
                results.Add(new FieldValidateResponse
                {
                    Error = ex.Message,
                    Field = Constants.BUSSINESS_EXCEPTION,
                    Description = ex.Message
                });
            }
            return results;
        }
    }
}

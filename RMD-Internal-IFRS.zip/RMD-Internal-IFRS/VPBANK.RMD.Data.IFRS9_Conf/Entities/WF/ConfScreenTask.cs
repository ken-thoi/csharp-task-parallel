﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Conf_Task_Type", Schema = "WF")]
    public class ConfTaskType : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Task_Type_Code { get; set; }

        public string Task_Type_Name { get; set; }

        public string Task_Type_Description { get; set; }

        public bool Is_Deleted { get; set; }
    }
}

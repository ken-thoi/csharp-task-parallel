﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class Body_Data
    {
        public int Id { get; set; }
        public int MessageID { get; set; }
        public string Body { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.BCL;
using VPBANK.RMD.Services.Auth.Interfaces;
using System;
using Serilog;
using VPBANK.RMD.API.Common.Middlewares;
using System.Net;
using VPBANK.RMD.Utils.Common;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using VPBANK.RMD.API.Common.Helpers.Errors;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Conf.Views.BCL;


namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.BCL
{
    public class ViewMpValidationRightController : QueryController<IFRS9_ConfContext, ViewMpValidationRight, int>
    {
        private readonly RequestHandler _requestHandler;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IRequestObjectService _reqService;
        private readonly IApproveStatusRepository _reqStatusRepository;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IConfMpValidationRightService _service;

        public ViewMpValidationRightController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, ViewMpValidationRight, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, ViewMpValidationRight, int> genericRepository,

            RequestHandler requestHandler,
            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusRepository reqStatusRepository,
            IApproveStatusService appStaService,
            IConfMpValidationRightService service) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;
            _reqRepository = reqRepository;
            _reqService = requestService;
            _reqStatusRepository = reqStatusRepository;
            _reqStatusService = appStaService;
            _service = service;
        }

        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] ViewMpValidationRightRequestable entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest();
                var results = _service.Validate(entity);
                if (results.Any())
                    return BadRequest(results);

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

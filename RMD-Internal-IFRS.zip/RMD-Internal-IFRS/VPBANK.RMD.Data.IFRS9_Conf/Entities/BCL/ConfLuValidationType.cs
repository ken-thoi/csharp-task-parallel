﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_LU_Validation_Type", Schema = "BCL")]
    public class ConfLuValidationType : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Type_Code { get; set; }
        public string Type_Name { get; set; }
        public string Type_Desc { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

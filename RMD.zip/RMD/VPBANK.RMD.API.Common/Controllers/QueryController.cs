﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;
using TrackableEntities.Common.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Common.Controllers
{
    public abstract class QueryController<TContext, TEntity, TKey> : ManualController<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntity<TKey>
        where TKey : IEquatable<TKey>
    {
        public QueryController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<TContext> unitOfWork,
            ITrackableRepository<TContext, TEntity, TKey> trackableRepository,
            IGenericRepository<TContext, TEntity, TKey> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// List all records.
        /// </summary>
        /// <returns>IEnumerable</returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<TEntity>> All()
        {
            try
            {
                //var webrootFolder = _env.WebRootPath;
                var results = _genericRepository.Queryable().AsEnumerable();
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find object by key.
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns>Object</returns>
        [HttpGet(template: "{pk_Id}")]
        public virtual async Task<ActionResult<TEntity>> FindById([Required][NotNull][FromRoute] TKey pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var entity = await _genericRepository.FindAsync(pk_Id);
                if (entity == null)
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.EM001);

                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Check existed object
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{pk_Id}")]
        public virtual async Task<bool> Exists([Required][NotNull][FromRoute] TKey pk_Id)
        {
            return await _genericRepository.ExistsAsync(pk_Id);
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public virtual async Task<ActionResult<PaginatedContentResults<TEntity>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                // All data
                var total = _genericRepository.CountDataPaginated(paginatedParams);
                var data = _genericRepository.QueryDataPaginated(paginatedParams);
                dynamic result = await SqlQueryDataAsync(total, data, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_LU_Business_Unit", Schema = "BCL")]
    public class ConfLuBusinessUnit : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Business_Unit_Code { get; set; }
        public string Business_Unit_Name { get; set; }
        public string Describle { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class FilePackageController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private static object _lockGetFilePackage = new object();

        public static void FilePackageProcess()
        {
            logger.Info("=== Start Run File Package Process ===");
            List<Task> listWorkingTask = new List<Task>();
            while (true)
            {
                try
                {
                    if (listWorkingTask.Count < GetMaximunProcess)
                    {
                        lock (listWorkingTask)
                        {
                            var filePackage = GetFilePackageToProcess;
                            if (filePackage != null)
                            {
                                logger.Info("Before Start: Curent running package task: " + listWorkingTask.Count);
                                var task = Task.Factory.StartNew(() =>
                                {
                                    PackingFile(filePackage);
                                });
                                task.ContinueWith(t =>
                                {
                                    lock (listWorkingTask)
                                    {
                                        listWorkingTask.Remove(task);
                                        logger.Info("After Run: Curent running package task: " + listWorkingTask.Count);
                                    }
                                });
                                listWorkingTask.Add(task);
                            }
                            else
                                Thread.Sleep(1000);
                        }
                    }
                    else
                    {
                        logger.Info("File Package Process is running max process allow, waiting for 10 seconds");
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                    Thread.Sleep(5000);
                }
            }
        }

        public static void CheckCurrentRunning()
        {
            logger.Info("------ START: Check Current Thread ------");
            var list = GetCurrentPacking();
            if (list.Count > 0)
            {
                string error = "- Can not start run because other thread are running, please kill other thread and reset all Status in [FileServ].[FilePackage] to 10 (waiting) or null to continued";
                logger.Error(error);
                throw new Exception(error);
            }
            logger.Info("- System ready to run");
            logger.Info("------ END: Check Current Thread ------");
        }

        private static List<FilePackage> GetCurrentPacking()
        {
            List<FilePackage> lstDocunment = new List<FilePackage>();
            string command = "[FileServ].[FilePackage_Get_Current_Running]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command);
            foreach (DataRow dr in dt.Rows)
            {
                lstDocunment.Add(Utils.UtilFunction.CreateItemFromRow<FilePackage>(dr));
            }
            return lstDocunment;
        }

        private static void PackingFile(FilePackage filePackage)
        {
            logger.Info($"--Start packing file packageId: {filePackage.Id}");
            int count = 5;
            while (count > 0)
            {
                try
                {
                    var custDoc = CustDocController.GetCustomerDocByDocID(filePackage.FK_Customer);
                    var listFileDownload = FileDownloadController.GetListFileDownloadedByCustId(filePackage.FK_Customer);
                    List<FileInfo> listFile = new List<FileInfo>();
                    List<string> listEntryName = new List<string>();
                    foreach (var file in listFileDownload)
                    {
                        var fileInfo = new FileInfo(Path.Combine(GetStorageFolder, file.Destination));
                        if (fileInfo.Exists)
                        {
                            listFile.Add(fileInfo);
                            listEntryName.Add(file.Destination);
                        }
                        else
                        {
                            file.Status = FileStatus.NotFoundOnPacking;
                            FileDownloadController.UpdateFileDownload(file);
                        }
                    }

                    var zipPath = Path.Combine(GetPackageFolder, custDoc.FilePackageName + ".zip");
                    if (File.Exists(zipPath))
                        File.Delete(zipPath);

                    CreateZipFile(listFile, listEntryName, zipPath);
                    filePackage.Status = FilePackageStatus.PackingCompleted;
                    UpdateFilePackage(filePackage);

                    try
                    {
                        Utils.UtilFunction.isValidateZip(zipPath);
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                        count--;
                        filePackage.Status = FilePackageStatus.VerifiedFailed;
                        UpdateFilePackage(filePackage);
                        break;
                    }

                    filePackage.Status = FilePackageStatus.Verified;
                    UpdateFilePackage(filePackage);

                    filePackage.MD5Checksum = Utils.UtilFunction.CalculateMD5FromFile(zipPath);
                    filePackage.Destination = zipPath.Replace(GetPackageFolder, string.Empty);
                    if (filePackage.Destination.StartsWith("\\"))
                        filePackage.Destination = filePackage.Destination.Substring(1);
                    filePackage.Status = FilePackageStatus.Done;
                    filePackage.Size = (new FileInfo(zipPath)).Length;
                    UpdateFilePackage(filePackage);
                    break;
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                    count--;
                }
            }
        }

        private static void CreateZipFile(List<FileInfo> files, List<string> entriesName, string archiveName)
        {
            using (var stream = File.OpenWrite(archiveName))
            using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Create))
            {
                for (int i = 0; i < files.Count(); i++)
                {
                    archive.CreateEntryFromFile(files[i].FullName, entriesName[i], CompressionLevel.Optimal);
                }
            }
        }

        public static string GetPackageFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "PACKAGE");
            }
        }

        private static int GetMaximunProcess
        {
            get
            {
                return Convert.ToInt32(SysVarController.GetSystemValue("PROCESS_CONTROL", "PACKING_MAXIMUM_THREAD"));
            }
        }

        private static string GetStorageFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "STORAGE");
            }
        }

        public static FilePackage GetFilePackageToProcess
        {
            get
            {
                lock (_lockGetFilePackage)
                {
                    string command = "[FileServ].[FilePackage_SEL]";
                    DataTable dt = new DataTable();
                    Utils.SqlHelper.Fill(dt, command);
                    if (dt.Rows.Count == 0)
                        return null;
                    else
                        return Utils.UtilFunction.CreateItemFromRow<FilePackage>(dt.Rows[0]);
                }
            }
        }

        public static void UpdateFilePackage(FilePackage filePackage)
        {
            string command = "[FileServ].[FilePackage_UDP]";
            List<SqlParameter> listParam = new List<SqlParameter>();
            listParam.Add(new SqlParameter("@pv_Id", filePackage.Id));
            listParam.Add(new SqlParameter("@pv_FK_Customer", filePackage.FK_Customer));
            listParam.Add(new SqlParameter("@pv_Destination", filePackage.Destination));
            listParam.Add(new SqlParameter("@pv_ProcessTime", DateTime.Now));
            listParam.Add(new SqlParameter("@pv_Status", filePackage.Status));
            listParam.Add(new SqlParameter("@pv_Size", filePackage.Size));
            listParam.Add(new SqlParameter("@pv_MD5Checksum", filePackage.MD5Checksum));
            Utils.SqlHelper.ExecuteNonQuery(command, listParam.ToArray());
        }

    }
}

﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace VPBANK.RMD.Services.Auth.DataTransferObjects
{
    public class UserRoleMappingDto
    {
        [JsonPropertyName("username")]
        [JsonProperty("username", NullValueHandling = NullValueHandling.Ignore)]
        public string Username { get; set; }

        [JsonPropertyName("fkDataRole")]
        [JsonProperty("fkDataRole", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> FkDataRole { get; set; }

        [JsonPropertyName("fkBusinessUnitRole")]
        [JsonProperty("fkBusinessUnitRole", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> FkBusinessUnitRole { get; set; }

        [JsonPropertyName("functionRole")]
        [JsonProperty("functionRole", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> FunctionRole { get; set; }

        [JsonPropertyName("componentRole")]
        [JsonProperty("componentRole", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ComponentRole { get; set; }
    }
}

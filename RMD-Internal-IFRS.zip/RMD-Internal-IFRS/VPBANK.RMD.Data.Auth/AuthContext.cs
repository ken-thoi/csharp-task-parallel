﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.Data.Auth.Entities.Views;

namespace VPBANK.RMD.Data.Auth
{
    public class AuthContext : DbContext
    {
        //private IHttpContextAccessor _httpContextAccessor;

        public AuthContext(DbContextOptions<AuthContext> options) : base(options)
        {
            //ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        //public AuthContext(DbContextOptions<AuthContext> options, IHttpContextAccessor httpContextAccessor) : base(options)
        //{
        //    this._httpContextAccessor = httpContextAccessor;
        //}

        // POCO
        public DbSet<ComponentUserRole> ComponentUserRoles { get; set; }
        public DbSet<DataPermission> DataPermissions { get; set; }
        public DbSet<DataPermissionEngine> DataPermissionEngines { get; set; }
        public DbSet<DataPermissionEntity> DataPermissionEntities { get; set; }
        public DbSet<DataRole> DataRoles { get; set; }
        public DbSet<DataRolePermission> DataRolePermissions { get; set; }
        public DbSet<DataUserRole> DataUserRoles { get; set; }
        public DbSet<FunctionUserRole> FunctionUserRoles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserArchived> UserArchiveds { get; set; }

        // VIEW
        public DbSet<ViewUserRole> ViewUserRoles { get; set; }

        // DbQuery<T> is for Stored Procedure
        public DbQuery<User> UserQueries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ComponentUserRole>().ToTable("Component_User_Role", "Core");
            modelBuilder.Entity<ComponentUserRole>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<DataPermission>().ToTable("Data_Permission", "Core");
            modelBuilder.Entity<DataPermission>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<DataPermissionEngine>().ToTable("Data_Permission_Engine", "Core");
            modelBuilder.Entity<DataPermissionEngine>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<DataPermissionEntity>().ToTable("Data_Permission_Entity", "Core");
            modelBuilder.Entity<DataPermissionEntity>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<DataRole>().ToTable("Data_Role", "Core");
            modelBuilder.Entity<DataRole>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<DataRolePermission>().ToTable("Data_Role_Permission", "Core");
            modelBuilder.Entity<DataRolePermission>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<DataUserRole>().ToTable("Data_User_Role", "Core");
            modelBuilder.Entity<DataUserRole>().HasKey(item => new { item.Username, item.Fk_Role_Id });

            modelBuilder.Entity<FunctionUserRole>().ToTable("Function_User_Role", "Core");
            modelBuilder.Entity<FunctionUserRole>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<User>().ToTable("User", "Core");
            modelBuilder.Entity<User>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<UserArchived>().ToTable("User_Archived", "Core");

            modelBuilder.Entity<ViewUserRole>().ToView("View_User_Role", "Core");
            modelBuilder.Entity<ViewUserRole>().HasKey(item => new { item.Pk_Id });

            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            //var now = DateTime.Now;

            //// Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            //var entries = ChangeTracker
            //    .Entries()
            //    .Where(e => e.Entity is Auditable && (e.State == EntityState.Added || e.State == EntityState.Modified));

            //// For each entity we will set the Audit properties
            //if (entries != null)
            //    foreach (var entityEntry in entries)
            //    {
            //        // If the entity state is Added let's set the CreatedAt and CreatedBy properties
            //        if (entityEntry.State == EntityState.Added)
            //        {
            //            ((Auditable)entityEntry.Entity).CreatedAt = now;
            //            ((Auditable)entityEntry.Entity).CreatedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "MyApp";
            //        }
            //        else
            //        {
            //            // If the state is Modified then we don't want to modify the CreatedAt and CreatedBy properties so we set their state as IsModified to false
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedAt).IsModified = false;
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedBy).IsModified = false;
            //        }

            //    // In any case we always want to set the properties ModifiedAt and ModifiedBy
            //    ((Auditable)entityEntry.Entity).ModifiedAt = now;
            //        ((Auditable)entityEntry.Entity).ModifiedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "MyApp";
            //    }

            // After we set all the needed properties we call the base implementation of SaveChanges to actually save our entities in the database
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            //var now = DateTime.Now;

            //// Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            //var entries = ChangeTracker
            //    .Entries()
            //    .Where(e => e.Entity is Auditable && (e.State == EntityState.Added || e.State == EntityState.Modified));

            //// For each entity we will set the Audit properties
            //if (entries != null)
            //    foreach (var entityEntry in entries)
            //    {
            //        // If the entity state is Added let's set the CreatedAt and CreatedBy properties
            //        if (entityEntry.State == EntityState.Added)
            //        {
            //            ((Auditable)entityEntry.Entity).CreatedAt = now;
            //            ((Auditable)entityEntry.Entity).CreatedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "VBP_MRD_Administrator";
            //        }
            //        else
            //        {
            //            // If the state is Modified then we don't want to modify the CreatedAt and CreatedBy properties so we set their state as IsModified to false
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedAt).IsModified = false;
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedBy).IsModified = false;
            //        }

            //    // In any case we always want to set the properties ModifiedAt and ModifiedBy
            //    ((Auditable)entityEntry.Entity).ModifiedAt = now;
            //        ((Auditable)entityEntry.Entity).ModifiedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "VBP_MRD_Administrator";
            //    }

            // After we set all the needed properties we call the base implementation of SaveChangesAsync to actually save our entities in the database
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}

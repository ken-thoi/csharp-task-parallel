﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class FileSharedController
    {
        public static void RemoveSharedFile()
        {
            SysVarController.LoadSysVar();
            string command = "[FileServ].[FileSharedRemoveList_GetListRemove]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command);
            var SharedFolder = FileRequestController.GetSharepointFolder;
            foreach(DataRow dr in dt.Rows)
            {
                int Id = Convert.ToInt32(dr["Id"]);
                Console.WriteLine($"Start Process Delete File: " + Id);
                try
                {
                    string dateShareFolder = Convert.ToDateTime(dr["SharedTime"]).ToString("yyyy-MM-dd");
                    string yearShared = Convert.ToDateTime(dr["SharedTime"]).ToString("yyyy");
                    string quater =  "Q" + (Convert.ToDateTime(dr["SharedTime"]).Month + 2) / 3;
                    string file = Path.Combine(SharedFolder, yearShared, yearShared + "-" + quater, Convert.ToString(dr["OSCompany"]), dateShareFolder, Convert.ToString(dr["Destination"]));
                    if(File.Exists(file))
                    {
                        int countFailed = 10;
                        while(countFailed > 0)
                        {
                            try
                            {
                                File.Delete(file);
                                UpdateRemoveSharedFileStatus(Id, "1", string.Empty);
                                break;
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                                System.Threading.Thread.Sleep(2000);
                                countFailed--;
                                if (countFailed == 0)
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    UpdateRemoveSharedFileStatus(Id, "0", ex.ToString());
                    Console.WriteLine(ex.ToString());
                }
            }
        }

        public static void UpdateRemoveSharedFileStatus(int Id, string IsDeleted, string MsgLog)
        {
            string command = @"UPDATE [FileServ].[FileSharedRemoveList]
                            SET [IsDeleted] = @IsDeleted,[MsgLog] = @MsgLog
                            WHERE Id = @Id";
            List<SqlParameter> listprams = new List<SqlParameter>();
            listprams.Add(new SqlParameter("@Id", Utils.UtilFunction.CheckDBValueNull(Id)));
            listprams.Add(new SqlParameter("@IsDeleted", Utils.UtilFunction.CheckDBValueNull(IsDeleted)));
            listprams.Add(new SqlParameter("@MsgLog", Utils.UtilFunction.CheckDBValueNull(MsgLog)));
            Utils.SqlHelper.ExecuteNonQuery(command, listprams.ToArray(), false);
        }
    }
}

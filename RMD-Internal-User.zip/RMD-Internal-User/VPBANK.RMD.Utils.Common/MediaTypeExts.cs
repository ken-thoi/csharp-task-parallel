﻿namespace VPBANK.RMD.Utils.Common
{
    //
    // Summary:
    //     Specifies the media type information for an email message attachment.
    public static class MediaTypeExts
    {
        //
        // Summary:
        //     Specifies the kind of application data in an email message attachment.
        public static class Application
        {
            //
            // Summary:
            //     Specifies that the Excel, Csv... data is not interpreted.
            public const string OfficeDocument = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
    }
}

﻿namespace VPBANK.RMD.EFCore.Entities
{
    public abstract class QueryObjectResult : IQueryObjectResult
    {
    }

    public interface IQueryObjectResult
    {
    }
}

﻿using Microsoft.Extensions.Caching.Distributed;
using Serilog;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Core
{
    public class CustomerResultRepository : QueryRepository<IFRS9_ConfContext, CustomerResult>, ICustomerResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public CustomerResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, CustomerResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public CustomerResult FindByCustomerId(string customerId)
        {
            try
            {
                return QueryableRepository.QueryableSql($"exec Core.Get_Customer_Name '{customerId}'").AsEnumerable().ToList().FirstOrDefault();
            }
            catch (System.Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }
    }
}

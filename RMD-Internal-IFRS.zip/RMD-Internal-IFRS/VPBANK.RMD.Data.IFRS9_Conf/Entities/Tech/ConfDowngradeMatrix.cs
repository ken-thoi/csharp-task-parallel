﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech
{
    [Table("Conf_Downgrade_Matrix", Schema = "Tech")]
    public class ConfDowngradeMatrix : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Model_Segment { get; set; }
        public string Notch_Level_Ini_Range { get; set; }
        public string Downgrade_Notch { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }
}

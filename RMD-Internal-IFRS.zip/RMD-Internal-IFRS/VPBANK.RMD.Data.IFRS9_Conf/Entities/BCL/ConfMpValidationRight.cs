﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_MP_Validation_Right", Schema = "BCL")]
    public class ConfMpValidationRight : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int Fk_Business_Unit_Id { get; set; }

        public int Fk_Lu_Validation_Id { get; set; }

        public string Fk_Lu_Manual_File_Id { get; set; }

        public DateTime Start_Date { get; set; }

        public DateTime? End_Date { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl
{
    [Table("Conf_Glo_MP_General_Ledger_Kplus", Schema = "BCL")]
    public class ConfGloMpGeneralLedgerKplus : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string System_Code { get; set; }
        public decimal Gl { get; set; }
        public string Tablename { get; set; }
        public string Gl_Name { get; set; }
        public string Gl_Name_Loc_Lang { get; set; }
        public string Source_Table { get; set; }
        public string Filter { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

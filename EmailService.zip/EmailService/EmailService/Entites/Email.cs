﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class Email
    {
        public long Id { get; set; }
        public long uid { get; set; }
        public int MessageID { get; set; }
        public int FK_IMAP_Rule_Id { get; set; }
    }
}

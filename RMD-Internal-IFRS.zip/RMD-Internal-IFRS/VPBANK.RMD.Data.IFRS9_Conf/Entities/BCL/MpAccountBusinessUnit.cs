﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_MP_Account_Business_Unit", Schema = "BCL")]
    public class ConfMpAccountBusinessUnit : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Business_Unit_Id { get; set; }
        public string Username { get; set; }
        public string Status { get; set; }
    }
}

﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class ILLPAdjustRepository : Repository<IFRS9_DataContext, ILLPAdjust, int>, IILLPAdjustRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public ILLPAdjustRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, ILLPAdjust, int> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<ILLPAdjust> FindILLPAdjustByCustomerId(ILLPAdjust iLLPAdjust)
        {
            try
            {
                return TrackableRepository
                       .QueryableFromSqlRaw($"SELECT c.* FROM Core.ILLP_Adjust AS c WHERE c.Customer_Id = '{iLLPAdjust.Customer_Id}' AND c.Business_Date = '{iLLPAdjust.Business_Date.ToString(DefFormats.DATE_FORMAT)}' AND c.List_Flag = '{iLLPAdjust.List_Flag}'")
                       .AsEnumerable()
                       .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

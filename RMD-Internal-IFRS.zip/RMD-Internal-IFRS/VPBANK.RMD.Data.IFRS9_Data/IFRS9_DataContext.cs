﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore.Entities.SchemaInfos;

namespace VPBANK.RMD.Data.IFRS9_Data
{
    public partial class IFRS9_DataContext : DbContext
    {
        private IHttpContextAccessor _httpContextAccessor;

        public IFRS9_DataContext(DbContextOptions<IFRS9_DataContext> options, IHttpContextAccessor httpContextAccessor) : base(options)
        {
            this._httpContextAccessor = httpContextAccessor;
        }

        // DbQuery<T> is for Stored Procedure
        public virtual DbQuery<TableInfo> TableInfos { get; set; }
        public virtual DbQuery<ColumnInfo> ColumnInfos { get; set; }

        // Entities
        public virtual DbSet<StagingAdjust> StagingAdjusts { get; set; }
        public virtual DbSet<ILLPAdjust> IllpAdjusts { get; set; }
        public virtual DbSet<PLLPCustomer> PLLPCustomers { get; set; }
        public virtual DbSet<ILLPCashflowAdjustSummary> ILLPCashflowAdjustSummarys { get; set; }
        public virtual DbSet<ILLPCashflowAdjustDetail> ILLPCashflowAdjustDetails { get; set; }
        public virtual DbSet<RawIllpCf> RawIllpCfs { get; set; }

        // Views
        public virtual DbQuery<ViewIfrsILLPCashflow> ViewIfrsILLPCashflowResults { get; set; }
        public virtual DbQuery<ViewIfrsInitContract> ViewIfrsInitContracts { get; set; }
        public virtual DbQuery<ViewIfrsPLLPResult> ViewIfrsPLLPs { get; set; }
        public virtual DbQuery<ViewIfrsILLPResult> ViewIfrsILLPs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<StagingAdjust>().ToTable("Staging_Adjust", "Core");
            modelBuilder.Entity<StagingAdjust>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ILLPAdjust>().ToTable("ILLP_Adjust", "Core");
            modelBuilder.Entity<ILLPAdjust>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<PLLPCustomer>().ToTable("PLLP_Customer", "Core");
            modelBuilder.Entity<PLLPCustomer>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ILLPCashflowAdjustSummary>().ToTable("ILLP_CF_Adjust_Summary", "Core");
            modelBuilder.Entity<ILLPCashflowAdjustSummary>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ILLPCashflowAdjustDetail>().ToTable("ILLP_CF_Adjust_Detail", "Core");
            modelBuilder.Entity<ILLPCashflowAdjustDetail>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<RawIllpCf>().ToTable("Raw_ILLP_CF", "Core");
            modelBuilder.Entity<RawIllpCf>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ViewIfrsILLPCashflow>().ToView("view_ILLP_CF", "Core");
            modelBuilder.Entity<ViewIfrsILLPCashflow>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ViewIfrsInitContract>().ToView("view_IFRS_INIT_Contract", "Core");
            modelBuilder.Entity<ViewIfrsInitContract>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ViewIfrsPLLPResult>().ToView("view_IFRS_PLLP_ECL", "Core");
            modelBuilder.Entity<ViewIfrsPLLPResult>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ViewIfrsILLPResult>().ToView("view_IFRS_ILLP_ECL", "Core");
            modelBuilder.Entity<ViewIfrsILLPResult>().HasKey(item => new { item.Pk_Id });

            // finish
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            var now = DateTime.Now;
            var username = this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "VBP_MRD_Administrator";

            // Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            // For each entity we will set the Audit properties
            if (entries != null && entries.Any())
            {
                foreach (var entry in entries)
                {
                    try
                    {
                        var createdBy = entry.CurrentValues[nameof(Auditable.Created_By)];
                        var createdTime = entry.CurrentValues[nameof(Auditable.Created_Time)];

                        // If the entity state is Added let's set the CreatedTime and CreatedBy properties
                        if (entry.State == EntityState.Added)
                        {
                            entry.CurrentValues[nameof(Auditable.Created_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Created_Time)] = now;
                        }

                        var updatedBy = entry.CurrentValues[nameof(Auditable.Updated_By)];
                        var updatedTime = entry.CurrentValues[nameof(Auditable.Updated_Time)];

                        // In any case we always want to set the properties UpdatedTime and ModifiedBy
                        if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                        {
                            entry.CurrentValues[nameof(Auditable.Updated_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Updated_Time)] = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Warning("ENTRY NOT IS AUDITABLE");
                        Log.Warning(ex.Message);
                        Log.Warning(ex.StackTrace);
                    }
                }
            }

            // After we set all the needed properties we call the base implementation of SaveChanges to actually save our entities in the database
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var now = DateTime.Now;
            var username = this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "VBP_MRD_Administrator";

            // Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            // For each entity we will set the Audit properties
            if (entries != null && entries.Any())
            {
                foreach (var entry in entries)
                {
                    try
                    {
                        var createdBy = entry.CurrentValues[nameof(Auditable.Created_By)];
                        var createdTime = entry.CurrentValues[nameof(Auditable.Created_Time)];

                        // If the entity state is Added let's set the CreatedTime and CreatedBy properties
                        if (entry.State == EntityState.Added)
                        {
                            entry.CurrentValues[nameof(Auditable.Created_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Created_Time)] = now;
                        }

                        var updatedBy = entry.CurrentValues[nameof(Auditable.Updated_By)];
                        var updatedTime = entry.CurrentValues[nameof(Auditable.Updated_Time)];

                        // In any case we always want to set the properties UpdatedTime and ModifiedBy
                        if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                        {
                            entry.CurrentValues[nameof(Auditable.Updated_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Updated_Time)] = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Warning("ENTRY NOT IS AUDITABLE");
                        Log.Warning(ex.Message);
                        Log.Warning(ex.StackTrace);
                    }
                }
            }

            // After we set all the needed properties we call the base implementation of SaveChangesAsync to actually save our entities in the database
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Conf_MP_IFRS_MODEL_SEGMENT_GROUP", Schema = "Core")]
    public class ConfMpModelSegmentGroup : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Model_Segment { get; set; }
        public string Model_Definition { get; set; }
        public string Model_Segment_Group { get; set; }
        public DateTime? Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Serilog;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.IFRS9_Conf.DataTransferObjects.Wfs;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Wfs;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Utils.Common.Shared;


namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Wfs
{
    public class FlowController : TrackingController<IFRS9_ConfContext, Flow, int>
    {
        private readonly IFlowService _flowService;
        private readonly IFlowStepService _flowStepService;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;

        public FlowController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, Flow, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, Flow, int> genericRepository,

            IFlowService defWorkFlowService,
            IFlowStepService flowStepService,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _flowService = defWorkFlowService;
            _flowStepService = flowStepService;
            _genFlowExecutionRepository = genFlowExecutionRepository;
        }

        /// <summary>
        /// Get Gui
        /// </summary>
        /// <param name="hasAll"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{hasAll:bool?}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiWorkFlow([AllowNull][FromRoute] bool? hasAll)
        {
            try
            {
                return Ok(_flowService.GetFlowGuiComboBox(hasAll));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get for dropdownlist
        /// </summary>
        /// <param name="flowId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{flowId}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuilFlowComboBox([AllowNull][FromRoute] int flowId)
        {
            try
            {
                return Ok(_flowStepService.GetFlowGuilComboBox(false));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get Flow_Flow_Step details
        /// </summary>
        /// <param name="flowId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{flowId}")]
        public virtual ActionResult<FlowTaskStepsDto> FindDetailsByFlowId([AllowNull][FromRoute] int flowId)
        {
            try
            {
                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                return Ok(_flowStepService.FindAllDetailsByFlowId(flowId, user, GetBusinessUnitDataRolesFromHeader()));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Create new record.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        public virtual async Task<ActionResult<FlowTaskStepsDto>> CreateFlowDetails([FromBody] FlowTaskStepsDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null || data.FlowSteps == null || !data.FlowSteps.Any())
                    return BadRequest(ModelState);

                // validate flow name
                var msg = _flowService.ValidateFlowName(data.Flow);
                if (!string.IsNullOrEmpty(msg))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                // validate, only save
                msg = _flowService.ValidateSave(data.FlowSteps);
                if (!string.IsNullOrEmpty(msg))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                // insert data
                await _flowStepService.SaveAsync(data, GetUserPayloadFromHeader().Username);

                // results
                return CreatedAtAction(nameof(Create), new { pk_Id = data.Flow.Pk_Id }, data);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Update exists record.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="pk_Id"></param>
        /// <param name="data"></param>
        /// <returns>A newly updated object</returns>
        /// <response code="200">Returns OK</response>
        /// <response code="400">If the item is null</response>
        /// <response code="404">The item is not found</response>
        [HttpPut(template: "{pk_Id}")]
        public virtual async Task<ActionResult<FlowTaskStepsDto>> UpdateFlowDetails([FromRoute] int pk_Id, [FromBody] FlowTaskStepsDto data)
        {
            try
            {
                if (!ModelState.IsValid || data == null || data.FlowSteps == null || !data.FlowSteps.Any())
                    return BadRequest(ModelState);

                if (!await _genericRepository.ExistsAsync(pk_Id))
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.EM002);

                // check flow is executing
                var hasFlowExecuting = _genFlowExecutionRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(x => x.Fk_Flow_Id == data.Flow.Pk_Id && x.Flow_Execution_Status.Equals(Workflow_Status_Code.EXECUTING, StringComparison.CurrentCultureIgnoreCase))
                    .Any();
                if (hasFlowExecuting && !data.Flow.Is_Actived)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM010);

                // validate flow name
                var msg = _flowService.ValidateFlowName(data.Flow);
                if (!string.IsNullOrEmpty(msg))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                // validate, only save
                msg = _flowService.ValidateSave(data.FlowSteps);
                if (!string.IsNullOrEmpty(msg))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                // update data
                await _flowStepService.SaveAsync(data, GetUserPayloadFromHeader().Username);
                return Ok(data);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Delete record.
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpDelete(template: "{pk_Id}")]
        public virtual async Task<IActionResult> DeleteFlowDetails([FromRoute] int pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var flow = _genericRepository.Find(pk_Id);
                if (flow == null)
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.EM002);

                // validate
                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                var msg = _flowService.ValidateDelete(pk_Id, user, GetBusinessUnitDataRolesFromHeader());
                if (!string.IsNullOrEmpty(msg))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                // delete
                await _flowStepService.DeleteAsync(pk_Id, GetUserPayloadFromHeader().Username);
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs
{
    public interface IFlowExecutionRepository : IRepository<IFRS9_ConfContext, FlowExecution, int>
    {
        public List<FlowExecution> FindAllByFlowIdAndBusinessDateAndFlowExecutionStatus(int flowId, DateTime businessDate, string flowStatus);
    }
}

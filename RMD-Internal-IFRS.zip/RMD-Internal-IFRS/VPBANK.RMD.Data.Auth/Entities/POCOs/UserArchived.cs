﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.Utils.Common.Expressions;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Serializable]
    [Table("User_Archived", Schema = "Core")]
    public class UserArchived : EntityBase<int>
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(name: "PK_Id")]
        [JsonPropertyName("id")]
        [JsonProperty("id")]
        public override int Pk_Id { get; set; }

        [Column(name: "Username")]
        [JsonPropertyName("username")]
        [JsonProperty("username")]
        public string Username { get; set; }

        [Column(name: "Display_Name")]
        [JsonPropertyName("displayName")]
        [JsonProperty("displayName")]
        public string Display_Name { get; set; }

        [Column(name: "Password")]
        [JsonPropertyName("password")]
        [JsonProperty("password")]
        public string Password { get; set; }

        [Column(name: "Super_Role")]
        [JsonPropertyName("superRole")]
        [JsonProperty("superRole")]
        public string Super_Role { get; set; }

        [Column(name: "Type")]
        [JsonPropertyName("type")]
        [JsonProperty("type")]
        public string Type { get; set; }

        [Column(name: "Status")]
        [JsonPropertyName("status")]
        [JsonProperty("status")]
        public string Status { get; set; }

        [Column(name: "Is_Deleted")]
        [JsonPropertyName("isDeleted")]
        [JsonProperty("isDeleted")]
        public bool Is_Deleted { get; set; }

        [Column(name: "Created_Date")]
        [JsonPropertyName("createdDate")]
        [JsonProperty("createdDate")]
        public DateTime? Created_Date { get; set; }

        [Column(name: "Create_User")]
        [JsonPropertyName("createUser")]
        [JsonProperty("createUser")]
        public string Create_User { get; set; }

        [Column(name: "Modified_Date")]
        [JsonPropertyName("modifiedDate")]
        [JsonProperty("modifiedDate")]
        public DateTime? Modified_Date { get; set; }

        [Column(name: "Modified_By")]
        [JsonPropertyName("modifiedBy")]
        [JsonProperty("modifiedBy")]
        public string Modified_By { get; set; }

        [Column(name: "Email")]
        [Display(Name = "Email")]
        [JsonPropertyName("email")]
        [JsonProperty("email")]
        [RegularExpression(RegularExpressions.EMAIL, ErrorMessage = "Please enter a valid email address.")]
        public string Email { get; set; }

        [Column(name: "Phone")]
        [Display(Name = "Phone")]
        [JsonPropertyName("phone")]
        [JsonProperty("phone")]
        [RegularExpression(RegularExpressions.PHONE_NUMBER, ErrorMessage = "Please enter a valid email address.")]
        public string Phone { get; set; }

        [Column(name: "Last_Login")]
        [JsonPropertyName("lastLogin")]
        [JsonProperty("lastLogin")]
        public DateTime? Last_Login { get; set; }
    }
}

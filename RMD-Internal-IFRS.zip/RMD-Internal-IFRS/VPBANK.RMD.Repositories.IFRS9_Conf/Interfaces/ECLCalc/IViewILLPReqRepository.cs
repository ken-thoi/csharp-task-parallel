﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Views.WF;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.ECLCalc
{
    public interface IViewILLPReqRepository : IRepository<IFRS9_ConfContext, ViewIfrsILLPReq, long>
    {
        public List<ViewIfrsILLPReq> FindAllByCustomerAndReqStatus(int fk_Flow_Execution_Id, int fk_Task_Execution_Id, string customer_Id, DateTime business_Date, string request_Status);
    }
}
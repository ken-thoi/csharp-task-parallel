﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Core;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.Data.IFRS9_Conf.Views.BCL;
using VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations;
using VPBANK.RMD.Data.IFRS9_Conf.Views.WF;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore.Entities.SchemaInfos;
using Task = VPBANK.RMD.Data.IFRS9_Conf.Entities.WF.Task;

namespace VPBANK.RMD.Data.IFRS9_Conf
{
    public partial class IFRS9_ConfContext : DbContext
    {
        private IHttpContextAccessor _httpContextAccessor;

        public IFRS9_ConfContext(DbContextOptions<IFRS9_ConfContext> options, IHttpContextAccessor httpContextAccessor) : base(options)
        {
            this._httpContextAccessor = httpContextAccessor;
        }

        #region DbQuery<T> is for Stored Procedure

        public virtual DbQuery<TableInfo> TableInfos { get; set; }
        public virtual DbQuery<ColumnInfo> ColumnInfos { get; set; }

        // store procedure
        public virtual DbQuery<CustomerResult> CustomerResults { get; set; }
        public virtual DbQuery<CustomerInitContractResult> CustomerInitContractResults { get; set; }
        public virtual DbQuery<IfrsStagingResult> IfrsStagingResults { get; set; }
        public virtual DbQuery<IfrsPLLPResult> IfrsPLLPResults { get; set; }
        public virtual DbQuery<IfrsILLPResult> IfrsILLPResults { get; set; }
        public virtual DbQuery<IfrsCashflowValidateResult> IfrsCashflowValidateResults { get; set; }
        public virtual DbQuery<IfrsEclResult> IfrsEclPLLPResults { get; set; }

        #endregion

        #region Apr

        public virtual DbSet<Requests> Requests { get; set; }
        public virtual DbSet<RequestsFile> RequestsFiles { get; set; }
        public virtual DbSet<RequestsProcess> RequestsProcesses { get; set; }

        public virtual DbQuery<ViewIfrsStagingReq> ViewIfrsStagingReqs { get; set; }
        public virtual DbQuery<ViewIfrsILLPReq> ViewIfrsILLPReqs { get; set; }

        #endregion

        #region WF

        public virtual DbSet<ConfStatus> ConfStatus { get; set; }
        public virtual DbSet<ConfTaskType> ConfTaskTypes { get; set; }
        public virtual DbSet<ConfScreenTask> ConfScreenTasks { get; set; }

        public virtual DbSet<Flow> Flows { get; set; }
        public virtual DbSet<FlowExecution> FlowExecutions { get; set; }
        public virtual DbSet<FlowStep> FlowSteps { get; set; }
        public virtual DbSet<FlowStepExecution> FlowStepExecutions { get; set; }
        public virtual DbSet<Task> Tasks { get; set; }

        public virtual DbSet<ConfLuValidation> ConfLuValidations { get; set; }
        public virtual DbSet<ConfMpValidationRight> ConfMpValidationRights { get; set; }
        public virtual DbSet<ConfLuValidationType> ConfLuValidationTypes { get; set; }
        public virtual DbQuery<ViewTaskConfiguration> ViewTaskConfigurations { get; set; }
        public virtual DbQuery<ViewTaskMonitoring> ViewTaskMonitorings { get; set; }

        public virtual DbQuery<ViewFlowConfiguration> ViewFlowConfigurations { get; set; }
        public virtual DbQuery<ViewFlowMonitoring> ViewFlowMonitorings { get; set; }

        #endregion

        #region BCL

        public virtual DbSet<ConfLuBusinessUnit> ConfLuBusinessUnits { get; set; }
        public virtual DbSet<ConfLuIfrsStage> ConfLuIfrsStages { get; set; }
        public virtual DbSet<ConfLuIfrsStatusLevel> ConfLuIfrsStatusLevels { get; set; }
        public virtual DbSet<ConfMpAccountBusinessUnit> ConfMpAccountBusinessUnits { get; set; }
        public virtual DbQuery<ViewMpAccountBusinessUnit> ViewMpAccountBusinessUnits { get; set; }

        public virtual DbSet<ConfLuManualUpload> ConfLuManualUploads { get; set; }
        public virtual DbSet<ConfMpUploadRight> ConfLuUploadRights { get; set; }

        public virtual DbSet<ConfMpCashflowRight> ConfMpCashflowRights { get; set; }
        public virtual DbQuery<ViewMpValidationRight> ViewMpValidationRights { get; set; }

        public virtual DbQuery<ViewIfrsDataValidationResult> ViewIfrsDataValidationResults { get; set; }

        public virtual DbQuery<ViewIfrsDataInitialResult> ViewIfrsDataInitialResults { get; set; }
        public virtual DbQuery<ViewWebCoreRequestDetail> ViewWebCoreRequestDetails { get; set; }


        public virtual DbSet<ConfMpGlIfrs> ConfMpGlIfrses { get; set; }
        public virtual DbSet<ConfMpDefaultFlag> ConfMpDefaultFlags { get; set; }
        public virtual DbSet<ConfMpPdltIfrs> ConfMpPdltIfrses { get; set; }
        public virtual DbSet<ConfMpGroupSegment> MpGroupSegments { get; set; }
        public virtual DbSet<ConfMpModelSegmentGroup> MpModelSegmentGroups { get; set; }
        public virtual DbSet<ConfMpQtrrSegment> MpQtrrSegments { get; set; }
        public virtual DbSet<ConfMpSectorGroup> MpSectorGroups { get; set; }

        #endregion

        #region TECH

        public virtual DbSet<ConfParam> ConfParams { get; set; }
        public virtual DbSet<ConfExposureType> ConfExposureTypes { get; set; }
        public virtual DbSet<ConfCcf> ConfCcfs { get; set; }
        public virtual DbSet<ConfRatingRanking> ConfRatingRankings { get; set; }
        public virtual DbSet<ConfDowngradeMatrix> ConfDowngradeMatrixs { get; set; }
        public virtual DbSet<ConfLgd> ConfLgds { get; set; }

        #endregion

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region Apr

            //Requests
            modelBuilder.Entity<Requests>().ToTable("Requests", "Apr");
            modelBuilder.Entity<Requests>().HasKey(item => new { item.Pk_Id });

            //RequestsFile
            modelBuilder.Entity<RequestsFile>().ToTable("Requests_File", "Apr");
            modelBuilder.Entity<RequestsFile>().HasKey(item => new { item.Pk_Id });

            //RequestsProcess
            modelBuilder.Entity<RequestsProcess>().ToTable("Requests_Process", "Apr");
            modelBuilder.Entity<RequestsProcess>().HasKey(item => new { item.Pk_Id });


            modelBuilder.Query<ViewIfrsStagingReq>().ToView("View_IFRS_Staging_Req", "Apr");
            modelBuilder.Query<ViewIfrsILLPReq>().ToView("View_IFRS_ILLP_Req", "Apr");

            #endregion

            #region WF

            //Conf_Status
            modelBuilder.Entity<ConfStatus>().ToTable("Conf_Status", "WF");
            modelBuilder.Entity<ConfStatus>().HasKey(item => new { item.Pk_Id });

            //Conf_Screen_Task
            modelBuilder.Entity<ConfScreenTask>().ToTable("Conf_Screen_Task", "WF");
            modelBuilder.Entity<ConfScreenTask>().HasKey(item => new { item.Pk_Id });

            //Conf_Task_Type
            modelBuilder.Entity<ConfTaskType>().ToTable("Conf_Task_Type", "WF");
            modelBuilder.Entity<ConfTaskType>().HasKey(item => new { item.Pk_Id });

            //Flow
            modelBuilder.Entity<Flow>().ToTable("Flow", "WF");
            modelBuilder.Entity<Flow>().HasKey(item => new { item.Pk_Id });

            //Flow_Execution
            modelBuilder.Entity<FlowExecution>().ToTable("Flow_Execution", "WF");
            modelBuilder.Entity<FlowExecution>().HasKey(item => new { item.Pk_Id });

            //FlowStep
            modelBuilder.Entity<FlowStep>().ToTable("Flow_Step", "WF");
            modelBuilder.Entity<FlowStep>().HasKey(item => new { item.Pk_Id });

            //Flow_Step_Execution
            modelBuilder.Entity<FlowStepExecution>().ToTable("Flow_Step_Execution", "WF");
            modelBuilder.Entity<FlowStepExecution>().HasKey(item => new { item.Pk_Id });

            //Task
            modelBuilder.Entity<Task>().ToTable("Task", "WF");
            modelBuilder.Entity<Entities.WF.Task>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Query<ViewTaskConfiguration>().ToView("View_Task_Configuration", "WF");
            modelBuilder.Query<ViewTaskMonitoring>().ToView("View_Task_Monitoring", "WF");
            modelBuilder.Query<ViewFlowConfiguration>().ToView("View_Flow_Configuration", "WF");
            modelBuilder.Query<ViewFlowMonitoring>().ToView("View_Flow_Monitoring", "WF");

            #endregion

            #region BCL

            modelBuilder.Entity<ConfLuBusinessUnit>().ToTable("Conf_LU_Business_Unit", "BCL");
            modelBuilder.Entity<ConfLuBusinessUnit>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfLuIfrsStage>().ToTable("Conf_LU_IFRS_Stage", "BCL");
            modelBuilder.Entity<ConfLuIfrsStage>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfLuIfrsStatusLevel>().ToTable("Conf_LU_IFRS_Status_Level", "BCL");
            modelBuilder.Entity<ConfLuIfrsStatusLevel>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfMpAccountBusinessUnit>().ToTable("Conf_MP_Account_Business_Unit", "BCL");
            modelBuilder.Entity<ConfMpAccountBusinessUnit>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Query<ViewMpAccountBusinessUnit>().ToView("View_MP_Account_Business_Unit", "BCL");
            //modelBuilder.Query<ViewMpAccountBusinessUnit>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfLuManualUpload>().ToTable("Conf_LU_Manual_Upload", "BCL");
            modelBuilder.Entity<ConfLuManualUpload>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfMpUploadRight>().ToTable("Conf_MP_Upload_Right", "BCL");
            modelBuilder.Entity<ConfMpUploadRight>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfLuValidation>().ToTable("Conf_LU_Validation", "BCL");
            modelBuilder.Entity<ConfLuValidation>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfMpValidationRight>().ToTable("Conf_MP_Validation_Right", "BCL");
            modelBuilder.Entity<ConfMpValidationRight>().HasKey(item => new { item.Pk_Id });

            //Conf_MP_Cashflow_Right
            modelBuilder.Entity<ConfMpCashflowRight>().ToTable("Conf_MP_Cashflow_Right", "BCL");
            modelBuilder.Entity<ConfMpCashflowRight>().HasKey(item => new { item.Pk_Id });
            modelBuilder.Query<ViewMpValidationRight>().ToView("View_MP_Validation_Right", "BCL");

            modelBuilder.Entity<ConfLuValidationType>().ToTable("Conf_LU_Validation_Type", "BCL");
            modelBuilder.Entity<ConfLuValidationType>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Query<ViewIfrsDataValidationResult>().ToView("View_Ifrs_Data_Validation_Result", "BCL");

            modelBuilder.Query<ViewIfrsDataInitialResult>().ToView("View_Ifrs_Data_Initial_Result", "BCL");

            modelBuilder.Query<ViewWebCoreRequestDetail>().ToView("View_Web_Core_Request_Detail", "BCL");

            // Conf_MP_GL_Ifrs
            modelBuilder.Entity<ConfMpGlIfrs>().ToTable("Conf_MP_GL_Ifrs", "BCL");
            modelBuilder.Entity<ConfMpGlIfrs>().HasKey(item => new { item.Pk_Id });

            //CONF_MP_IFRS_DEFAULT_FLAG
            modelBuilder.Entity<ConfMpDefaultFlag>().ToTable("Conf_MP_IFRS_DEFAULT_FLAG", "BCL");
            modelBuilder.Entity<ConfMpDefaultFlag>().HasKey(item => new { item.Pk_Id });

            //Conf_MP_PDLT_IFRS
            modelBuilder.Entity<ConfMpPdltIfrs>().ToTable("Conf_MP_PDLT_IFRS", "BCL");
            modelBuilder.Entity<ConfMpPdltIfrs>().HasKey(item => new { item.Pk_Id });

            //Conf_MP_IFRS_GROUP_SEGMENT
            modelBuilder.Entity<ConfMpGroupSegment>().ToTable("Conf_MP_IFRS_GROUP_SEGMENT", "BCL");
            modelBuilder.Entity<ConfMpGroupSegment>().HasKey(item => new { item.Pk_Id });

            //Conf_MP_IFRS_MODEL_SEGMENT_GROUP
            modelBuilder.Entity<ConfMpModelSegmentGroup>().ToTable("Conf_MP_IFRS_MODEL_SEGMENT_GROUP", "BCL");
            modelBuilder.Entity<ConfMpModelSegmentGroup>().HasKey(item => new { item.Pk_Id });

            //Mp_Qtrr_Segment
            modelBuilder.Entity<ConfMpQtrrSegment>().ToTable("Conf_MP_IFRS_Qtrr_Segment", "BCL");
            modelBuilder.Entity<ConfMpQtrrSegment>().HasKey(item => new { item.Pk_Id });

            //Mp_Qtrr_Segment
            modelBuilder.Entity<ConfMpSectorGroup>().ToTable("Conf_MP_IFRS_Sector_Group", "BCL");
            modelBuilder.Entity<ConfMpSectorGroup>().HasKey(item => new { item.Pk_Id });

            #endregion

            #region TECH

            modelBuilder.Entity<ConfParam>().ToTable("Conf_Param", "Tech");
            modelBuilder.Entity<ConfParam>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfExposureType>().ToTable("Conf_Exposure_Type", "Tech");
            modelBuilder.Entity<ConfExposureType>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfCcf>().ToTable("Conf_CCF", "Tech");
            modelBuilder.Entity<ConfCcf>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfRatingRanking>().ToTable("Conf_Rating_Ranking", "Tech");
            modelBuilder.Entity<ConfRatingRanking>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfDowngradeMatrix>().ToTable("Conf_Downgrade_Matrix", "Tech");
            modelBuilder.Entity<ConfDowngradeMatrix>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfLgd>().ToTable("Conf_LGD", "Tech");
            modelBuilder.Entity<ConfLgd>().HasKey(item => new { item.Pk_Id });


            #endregion

            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            var now = DateTime.Now;
            var username = this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "VBP_MRD_Administrator";

            // Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            // For each entity we will set the Audit properties
            if (entries != null && entries.Any())
            {
                foreach (var entry in entries)
                {
                    try
                    {
                        var createdBy = entry.CurrentValues[nameof(Auditable.Created_By)];
                        var createdTime = entry.CurrentValues[nameof(Auditable.Created_Time)];

                        // If the entity state is Added let's set the CreatedTime and CreatedBy properties
                        if (entry.State == EntityState.Added)
                        {
                            entry.CurrentValues[nameof(Auditable.Created_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Created_Time)] = now;
                        }

                        var updatedBy = entry.CurrentValues[nameof(Auditable.Updated_By)];
                        var updatedTime = entry.CurrentValues[nameof(Auditable.Updated_Time)];

                        // In any case we always want to set the properties UpdatedTime and ModifiedBy
                        if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                        {
                            entry.CurrentValues[nameof(Auditable.Updated_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Updated_Time)] = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Warning("ENTRY NOT IS AUDITABLE");
                        Log.Warning(ex.Message);
                        Log.Warning(ex.StackTrace);
                    }
                }
            }

            // After we set all the needed properties we call the base implementation of SaveChanges to actually save our entities in the database
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var now = DateTime.Now;
            var username = this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "VBP_MRD_Administrator";

            // Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            // For each entity we will set the Audit properties
            if (entries != null && entries.Any())
            {
                foreach (var entry in entries)
                {
                    try
                    {
                        var createdBy = entry.CurrentValues[nameof(Auditable.Created_By)];
                        var createdTime = entry.CurrentValues[nameof(Auditable.Created_Time)];

                        // If the entity state is Added let's set the CreatedTime and CreatedBy properties
                        if (entry.State == EntityState.Added)
                        {
                            entry.CurrentValues[nameof(Auditable.Created_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Created_Time)] = now;
                        }

                        var updatedBy = entry.CurrentValues[nameof(Auditable.Updated_By)];
                        var updatedTime = entry.CurrentValues[nameof(Auditable.Updated_Time)];

                        // In any case we always want to set the properties UpdatedTime and ModifiedBy
                        if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                        {
                            entry.CurrentValues[nameof(Auditable.Updated_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Updated_Time)] = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Warning("ENTRY NOT IS AUDITABLE");
                        Log.Warning(ex.Message);
                        Log.Warning(ex.StackTrace);
                    }
                }
            }

            // After we set all the needed properties we call the base implementation of SaveChangesAsync to actually save our entities in the database
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}

﻿namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public class SelectedItem
    {
        public object Key { get; set; }
        public string Val { get; set; }
    }
}

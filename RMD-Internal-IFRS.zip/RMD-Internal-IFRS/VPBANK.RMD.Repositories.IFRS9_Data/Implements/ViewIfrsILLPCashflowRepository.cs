﻿using Microsoft.Extensions.Caching.Distributed;
using Serilog;
using System;
using System.Linq;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using System.Collections.Generic;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class ViewIfrsILLPCashflowRepository : Repository<IFRS9_DataContext, ViewIfrsILLPCashflow, long>, IViewIfrsILLPCashflowRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public ViewIfrsILLPCashflowRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, ViewIfrsILLPCashflow, long> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<ViewIfrsILLPCashflow> FindAllByBusinessDate(DateTime businessDate)
        {
            try
            {
                return TrackableRepository
                           .QueryableFromSqlRaw($"SELECT c.* FROM Core.view_ILLP_CF AS c WHERE c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'")
                           .AsEnumerable()
                           .ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }

        public ViewIfrsILLPCashflow FindILLPCashflowByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                return TrackableRepository
                           .QueryableFromSqlRaw($"SELECT c.* FROM Core.view_ILLP_CF AS c WHERE c.Customer_Id = '{customerId}' AND c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'")
                           .AsEnumerable()
                           .FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }
    }
}

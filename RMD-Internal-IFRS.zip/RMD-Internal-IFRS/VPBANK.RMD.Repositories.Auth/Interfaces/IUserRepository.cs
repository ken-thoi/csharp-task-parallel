﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.Auth.Interfaces
{
    public interface IUserRepository : IRepository<AuthContext, User, int>
    {
        Task<IEnumerable<User>> FindAllAsync();
        User FindByUserNameAndIsDeleted(string username, bool isDeleted);
        User FindByIdAndIsDeleted(int pk_Id, bool isDeleted);
        Task<User> FindByUserNameAndIsDeletedAsync(string username);
        Task<User> FindByUserNameAndIsDeletedAsync(string username, bool isDeleted);
        Task<User> FindByUserNameAndIsDeletedAndStatusAsync(string username, bool isDeleted, string status);
        IEnumerable<User> FindAllByQuery(bool? isDeleted);
        IEnumerable<User> FindAllNonRole();
        IEnumerable<User> FindAllActived();
    }
}

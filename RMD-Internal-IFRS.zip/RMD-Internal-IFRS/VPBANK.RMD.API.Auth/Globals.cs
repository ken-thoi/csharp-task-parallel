﻿namespace VPBANK.RMD.API.Auth
{
    public static class Globals
    {
    }
}

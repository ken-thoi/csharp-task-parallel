﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core
{
    public class IfrsILLPResult : QueryObjectResult
    {
        public DateTime? Business_Date { get; set; }
        public string Flow_Name { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public decimal? Total_Amount_Lcy { get; set; }
        public decimal? Amount_Lcy { get; set; }
        public decimal? Accrual_39_Lcy { get; set; }
        public decimal? Fee_3970_Lcy { get; set; }
        public decimal? Accrual_94_Lcy { get; set; }
        public decimal? Off_Balance_Amt { get; set; }
        public string Stage { get; set; }
        public string Stage_Flag { get; set; }
        public string List_Flag { get; set; }
        public string Rst_Flag { get; set; }
        public string Downgrade_Flag { get; set; }
        public string Qtrr_Segment { get; set; }
        public int? No_Ovd_Day { get; set; }
        public decimal? Total_Unused_Limit { get; set; }
    }
}

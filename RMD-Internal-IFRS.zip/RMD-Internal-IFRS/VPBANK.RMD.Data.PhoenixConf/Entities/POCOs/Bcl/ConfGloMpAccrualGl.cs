﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl
{
    [Table("Conf_Glo_MP_Accrual_GL", Schema = "BCL")]
    public class ConfGloMpAccrualGl : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public decimal Gl_Accruals { get; set; }
        public decimal Gl_Principal { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

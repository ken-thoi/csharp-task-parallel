﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Utils.Common.Shared;

namespace VPBANK.RMD.Repositories.Auth.Implements
{
    public class UserRepository : Repository<AuthContext, User, int>, IUserRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly ILogger<User> _logger;
        protected readonly AuthContext _authContext;

        public UserRepository(IDistributedCache distributedCache, ILogger<User> logger, ITrackableRepository<AuthContext, User, int> trackableRepository,
            AuthContext authContext) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _logger = logger;
            _authContext = authContext;
        }

        public async Task<IEnumerable<User>> FindAllAsync()
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users;
        }

        public User FindByIdAndIsDeleted(int pk_Id, bool isDeleted)
        {
            return TrackableRepository
                .Queryable()
                .AsEnumerable()
                .SingleOrDefault(c => c.Pk_Id == pk_Id && Convert.ToBoolean(c.Is_Deleted) == isDeleted);
        }

        public User FindByUserNameAndIsDeleted(string username, bool isDeleted)
        {
            return TrackableRepository
                .Queryable()
                .AsEnumerable()
                .SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) && c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase) && Convert.ToBoolean(c.Is_Deleted) == isDeleted);
        }

        public async Task<User> FindByUserNameAndIsDeletedAsync(string username)
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users.SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) && c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase) &&
                                              !string.IsNullOrEmpty(c.Status) && c.Status.Equals(UserStatusConstant.ACTIVE, StringComparison.CurrentCultureIgnoreCase));
        }

        public async Task<User> FindByUserNameAndIsDeletedAsync(string username, bool isDeleted)
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users.SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) && c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase) &&
                                              !string.IsNullOrEmpty(c.Status) && c.Status.Equals(UserStatusConstant.ACTIVE, StringComparison.CurrentCultureIgnoreCase) &&
                                              !c.Is_Deleted);
        }

        public async Task<User> FindByUserNameAndIsDeletedAndStatusAsync(string username, bool isDeleted, string status)
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users.SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) && c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase) &&
                                              !string.IsNullOrEmpty(c.Status) && c.Status.Equals(status, StringComparison.CurrentCultureIgnoreCase) &&
                                              !c.Is_Deleted);
        }

        public IEnumerable<User> FindAllByQuery(bool? isDeleted)
        {
            var isDeletedParam = new SqlParameter("@IsDeleted", isDeleted);
            return _authContext.UserQueries.FromSqlRaw("EXEC core.Get_Users @IsDeleted = @IsDeleted", isDeletedParam).AsEnumerable();
        }

        public IEnumerable<User> FindAllNonRole()
        {
            var query = "SELECT * FROM core.[User] WHERE Username NOT IN (SELECT username FROM core.View_User_Role) AND Is_Deleted = 0";
            return _authContext.UserQueries.FromSqlRaw(query).AsEnumerable();
        }
    }
}

﻿using EmailService.Entites;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Controller
{
    public class EmailController
    {
        public static void InsertOrUpdateEmail(Email data)
        {
            string command = "[dbo].[Email_INS]";
            List<SqlParameter> lstParma = new List<SqlParameter>();
            lstParma.Add(new SqlParameter("@pv_MessageID", data.MessageID));
            lstParma.Add(new SqlParameter("@pv_uid", data.uid));
            lstParma.Add(new SqlParameter("@pv_FK_IMAP_Rule_Id", data.FK_IMAP_Rule_Id));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParma.ToArray());
        }
    }
}

﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class CustDocController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void RunCustDocColldrivection()
        {
            
        }

        public static void RunIDLECustDocCollection()
        {
            var task1 = Task.Factory.StartNew(() => {
                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "RunIDLECustDocCollection_ODFEDoc")))
                {
                    CheckCurrentRunning(1);
                    ODFEDocController.RunIDLEDownload();
                }
            });

            var task2 = Task.Factory.StartNew(() => {
                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "RunIDLECustDocCollection_LOSDoc")))
                {
                    CheckCurrentRunning(2);
                    LOSDocController.RunIDLEDownload();
                }
            });
            
            Task.WaitAll(task1, task2);
        }
        
        public static void CheckCurrentRunning(int FK_Source)
        {
            logger.Info("------ START: Check Current Thread ------");
            var list = GetCurrentDownloading(FK_Source);
            if(list.Count > 0)
            {
                string error = "- Can not start run because other thread are running, please kill other thread and reset all Status in [FileServ].[CustomerDocument] to 10 (waiting) or null to continued";
                logger.Error(error);
                throw new Exception(error);
            }
            logger.Info("- System ready to run");
            logger.Info("------ END: Check Current Thread ------");
        }

        public static void CleanCurrentTempFolder()
        {
            logger.Info("------ START: Clean Current TempFolder ------");
            try
            {
                if(Directory.Exists(CurrentTempDownloadFolder))
                    Directory.Delete(CurrentTempDownloadFolder, true);
                logger.Info("------ END: Clean Current TempFolder ------");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public static void CleanCurrentCacheFolder()
        {
            logger.Info("------ START: Clean Current CacheFolder ------");
            try
            {
                Directory.Delete(CurrentTempCacheFolder, true);
                logger.Info("------ END: Clean Current CacheFolder ------");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public static string CurrentTempDownloadFolder
        {
            get
            {
                return Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "TEMP_DOWNLOAD"));
            }
        }

        public static string CurrentTempCacheFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "CACHE");
            }
        }

        private static List<CustomerDocument> GetCurrentDownloading(int FK_Source)
        {
            List<CustomerDocument> lstDocunment = new List<CustomerDocument>();
            string command = "[FileServ].[CustomerDocument_Check_Curent_Running]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FK_Source", FK_Source) });
            foreach (DataRow dr in dt.Rows)
            {
                lstDocunment.Add(Utils.UtilFunction.CreateItemFromRow<CustomerDocument>(dr));
            }
            return lstDocunment;
        }

        public static CustomerDocument GetCustomerDocByDocID(int id)
        {
            string command = "[FileServ].[CustomerDocument_Get_By_Id]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_Id", id) } );
            return Utils.UtilFunction.CreateItemFromRow<CustomerDocument>(dt.Rows[0]);
        }

        public static void UpdateCustDocStatus(CustomerDocument custDoc)
        {
            string command = "[FileServ].[CustomerDocument_Update_Status]";
            List<SqlParameter> lstParam = new List<SqlParameter>();
            lstParam.Add(new SqlParameter("@pv_Id", custDoc.Id));
            lstParam.Add(new SqlParameter("@pv_Priority", custDoc.Priority));
            lstParam.Add(new SqlParameter("@pv_Status", custDoc.Status));
            lstParam.Add(new SqlParameter("@pv_CreatedBy", Utils.UtilFunction.CheckDBValueNull(custDoc.CreatedBy)));
            lstParam.Add(new SqlParameter("@pv_UpdatedBy", Utils.UtilFunction.CheckDBValueNull(custDoc.UpdatedBy)));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParam.ToArray());
        }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using System.Net.Http;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.Bcl;
using Microsoft.AspNetCore.Mvc;
using VPBANK.RMD.API.Common.Helpers.Errors;
using System.Collections.Generic;
using System.Linq;
using System;
using Serilog;
using VPBANK.RMD.API.Common.Middlewares;
using System.Net;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.Bcl
{
    public class ConfGloMpSwiftCodeController : ProcessController<PhoenixConfContext, ConfGloMpSwiftCode, int>
    {
        private readonly IConfGloMpSwiftCodeService _confGloMpSwiftCodeService;
        public ConfGloMpSwiftCodeController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, ConfGloMpSwiftCode, int> trackableRepository,
            IGenericRepository<PhoenixConfContext, ConfGloMpSwiftCode, int> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository,

            IConfGloMpSwiftCodeService confGloMpSwiftCodeService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
            _confGloMpSwiftCodeService = confGloMpSwiftCodeService;
        }

        /// <summary>
        /// Validate data input by add, edit
        /// </summary>
        /// <param name="entity"></param>
        /// <returns>List error: field, error message</returns>
        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] ConfGloMpSwiftCodeRequestable entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null || string.IsNullOrEmpty(entity.Customer_Id) || string.IsNullOrEmpty(entity.Swift_Code) || entity.Start_Date == null)
                    return BadRequest();
                var results = _confGloMpSwiftCodeService.Validate(entity);
                if (results.Any())
                    return BadRequest(results);
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

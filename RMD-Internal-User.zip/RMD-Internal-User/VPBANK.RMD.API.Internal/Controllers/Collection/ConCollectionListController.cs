﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using System;
using System.Net;
using Serilog;
using System.Data;
using System.IO;
using Newtonsoft.Json;
using System.Net.Mime;
using AutoMapper;
using System.Collections.Generic;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Settings.Sections;
using VPBANK.RMD.Utils.Common.Remote.FTP;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.ExcelUtils;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Services.Collection.Interfaces;
using VPBANK.RMD.Utils.Common.Datas;

namespace VPBANK.RMD.API.Internal.Controllers.Collection
{
    public class ConCollectionListController : TrackingController<CollectionContext, ConCollectionListDaily, long>
    {
        private readonly IConCollectionListService _service;

        public ConCollectionListController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<CollectionContext> unitOfWork,
            ITrackableRepository<CollectionContext, ConCollectionListDaily, long> trackableRepository,
            IGenericRepository<CollectionContext, ConCollectionListDaily, long> genericRepository,

            IConCollectionListService ConCollectionListService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
            _service = ConCollectionListService;
        }

        /// <summary>
        /// Valid data file import by Excel(.xlsx, .xls)
        /// </summary>
        /// <param name="file">file input: excel stream</param>
        /// <returns>
        /// If file error return: Row error and error message by row
        /// If file not error return: string empty
        /// </returns>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Octet)]
        public IActionResult ValidateExcelFile([FromBody] byte[] file)
        {
            try
            {
                Stream stream = new MemoryStream(file);
                var data = ExcelHelper.ReadDataTableFromStream(stream, true);
                var errors = _service.ValidateExcelFileImport(data);
                var resultErrors = JsonConvert.SerializeObject(errors);
                Log.Information($"Con_Collection_List validate results: {resultErrors}");
                return Ok(resultErrors);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Valid data file import by dat file(.dat)
        /// </summary>
        /// <param name="file">file input: dat file by stream</param>
        /// <returns>
        /// If file error return: Row error and error message by row
        /// If file not error return: string empty
        /// </returns>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Octet)]
        public IActionResult ValidateDatFile([FromBody] byte[] file)
        {
            try
            {
                var content = System.Text.Encoding.UTF8.GetString(file);
                var errors = _service.ValidateDatFileImport(content);
                var resultErrors = JsonConvert.SerializeObject(errors);
                Log.Information($"Con_Collection_List_Daily validate results: {resultErrors}");
                return Ok(resultErrors);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Valid file import by FTP upload (File excel)
        /// </summary>
        /// <param name="fileUpload">Object file send request</param>
        /// <returns>
        /// If data file error return: The file contains the error message in the first column of the file
        /// </returns>
        [HttpPost]
        public IActionResult ValidateFileImport([FromBody] FileUploadReq fileUpload)
        {
            var setting = FtpInfoSetting.GetFtpSetting(_configuration);
            var remote = new FtpRemoteFileSystem(setting);
            remote.Connect();
            remote.SetRootAsWorkingDirectory();
            var localPath = $"{Constants.WWWROOT}\\{fileUpload.Path}\\{fileUpload.Filename}";
            var remotePath = $"{fileUpload.Path}\\{fileUpload.Filename}";

            try
            {
                remote.DownloadFile(localPath, remotePath);
                var data = ExcelHelper.ReadDataTableFromExcelPath(localPath, true);
                var errors = _service.ValidateExcelFileImport(data);

                if (errors != null && errors.Count > 0)
                {
                    ExcelHelper.AppendingErrors(localPath, errors, 10);

                    var fileInfo = new FileInfo(localPath);
                    var bytes = System.IO.File.ReadAllBytes(fileInfo.FullName);

                    HttpContext.Response.ContentType = MediaTypeExts.Application.OfficeDocument;
                    HttpContext.Response.Headers.Add(ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE, ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE_VAL);

                    var fileContentResult = new FileContentResult(bytes, MediaTypeExts.Application.OfficeDocument)
                    {
                        FileDownloadName = fileInfo.Name
                    };
                    return fileContentResult;
                }

                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                bool isConnected = remote.IsConnected();
                Log.Information($"FTP connect status: {isConnected}");
                remote.Disconnect();
                remote.Dispose();
            }
        }

        /// <summary>
        /// Valid data file import by FTP upload (File excel)
        /// </summary>
        /// <param name="fileUpload">Object file send request</param>
        /// <returns>
        /// If data error return: Row error and error message by row
        /// </returns>
        [HttpPost]
        public IActionResult ValidateDataFileImport([FromBody] FileUploadReq fileUpload)
        {
            var setting = FtpInfoSetting.GetFtpSetting(_configuration);
            var remote = new FtpRemoteFileSystem(setting);
            remote.Connect();
            remote.SetRootAsWorkingDirectory();
            var localPath = $"{Constants.WWWROOT}\\{fileUpload.Path}\\{fileUpload.Filename}";
            var remotePath = $"{fileUpload.Path}\\{fileUpload.Filename}";

            try
            {
                remote.DownloadFile(localPath, remotePath);
                var data = ExcelHelper.ReadDataTableFromExcelPath(localPath, true);
                var errors = _service.ValidateExcelFileImport(data);

                if (errors != null && errors.Count > 0)
                    return Ok(JsonConvert.SerializeObject(errors));

                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                bool isConnected = remote.IsConnected();
                Log.Information($"FTP connect status: {isConnected}");
                remote.Disconnect();
                remote.Dispose();
            }
        }

        /// <summary>
        /// Read data file import and save to DB
        /// </summary>
        /// <param name="fileUploads">List file upload</param>
        /// <returns></returns>
        /// <response code="201">Returns OK</response>
        [HttpPost]
        public IActionResult DataImport([FromBody] List<FileUploadReq> fileUploads)
        {
            var setting = FtpInfoSetting.GetFtpSetting(_configuration);
            var remote = new FtpRemoteFileSystem(setting);
            remote.Connect();
            remote.SetRootAsWorkingDirectory();

            _unitOfWork.BeginTransaction();
            try
            {
                var dataTables = new List<DataTable>();
                foreach (var fileUpload in fileUploads)
                {
                    var localPath = $"{Constants.WWWROOT}\\{fileUpload.Path}\\{fileUpload.Filename}";
                    var remotePath = $"{fileUpload.Path}\\{fileUpload.Filename}";

                    remote.DownloadFile(localPath, remotePath);
                    var dataTable = ExcelHelper.ReadDataTableFromExcelPath(localPath, true);
                    if (dataTable != null && dataTable.Rows.Count > 0)
                        dataTables.Add(dataTable);
                }

                _service.DataImport(dataTables);
                _unitOfWork.SaveChanges();
                return StatusCode(200);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                _unitOfWork.Commit();
                bool isConnected = remote.IsConnected();
                Log.Information($"FTP connect status: {isConnected}");
                remote.Disconnect();
                remote.Dispose();
            }
        }
    }
}
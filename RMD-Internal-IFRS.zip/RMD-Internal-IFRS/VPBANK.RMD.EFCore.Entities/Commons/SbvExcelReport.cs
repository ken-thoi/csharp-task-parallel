﻿using System;

namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public class SbvExcelReport
    {
        public string   rptReport { get; set; }
        public DateTime businessDate { get; set; }
        public string   entityCode { get; set; }
        public string   approach { get; set; }
        public string   scenarioId { get; set; }
        public string   versionId { get; set; }
        public string   additionalParams { get; set; }
    }
}

﻿using FileServ.Controller;
using System;

namespace FileServ
{
    class Program
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        static void Main(string[] args)
        {
            CollectionController.StartCollectionSystem();

            while (true)
            {
                Console.WriteLine("Type 'Exit' to quit program");
                var Exit = Console.ReadLine();
                if("Exit".Equals(Exit))
                {
                    break;
                }
            }
        }
    }
}

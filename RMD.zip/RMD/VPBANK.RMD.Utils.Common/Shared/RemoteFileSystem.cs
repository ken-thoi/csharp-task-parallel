﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public class RemoteFileSystem
    {
        public const string FTP = "FTP";
        public const string SFTP = "SFTP";
    }
}

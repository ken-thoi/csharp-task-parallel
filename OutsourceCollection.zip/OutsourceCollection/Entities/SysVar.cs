﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class SysVar
    {
        public string Id { get; set; }
        public string GName { get; set; }
        public string VarName { get; set; }
        public string VarValue { get; set; }
        public string VarDesc { get; set; }
    }
}

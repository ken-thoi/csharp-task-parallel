﻿using Microsoft.EntityFrameworkCore.Design;

namespace VPBANK.RMD.Data.Core
{
    public class CoreContextFactory : IDesignTimeDbContextFactory<CoreContext>
    {
        public CoreContext CreateDbContext(string[] args)
        {
            //var optionsBuilder = new DbContextOptionsBuilder<CoreContext>();
            //optionsBuilder.UseSqlServer("Server=10.37.16.226\\dev; Database=Core; User ID=dev_user; Password=12345a@");
            //return new PhoenixConfContext(optionsBuilder.Options);
            return null;
        }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech
{
    [Table("Conf_CCF", Schema = "Tech")]
    public class ConfCcf : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Priority { get; set; }
        public string Gl_Filter { get; set; }
        public string Exposure_Type { get; set; }
        public string Cont_Ori_Mat_Range { get; set; }
        public decimal Ccf { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }
}

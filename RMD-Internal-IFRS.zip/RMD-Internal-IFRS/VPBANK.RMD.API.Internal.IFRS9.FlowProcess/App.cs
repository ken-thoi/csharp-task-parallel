﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Dynamic;
using System.Linq;
using System.Net.Mime;
using System.Threading;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf.Views.WF;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.AppEngines;
using VPBANK.RMD.Data.PhoenixConf.SqlParams;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.DataValidations;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Repositories.PhoenixData.Interfaces.Core;
using VPBANK.RMD.Services.IFRS9_Conf.DataTransferObjects.Wfs;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Helpers;
using VPBANK.RMD.Utils.Common.Shared;

namespace VPBANK.RMD.API.Internal.IFRS9.FlowProcess
{
    public class App
    {
        //var _services = new ServiceCollection();
        //var serviceProvider = _services.BuildServiceProvider();

        private readonly IConfigurationRoot _configuration;
        private readonly ILogger<App> _logger;

        private readonly IUnitOfWork<IFRS9_ConfContext> _unitOfWork;
        private readonly IGenericRepository<IFRS9_ConfContext, Task, int> _genTaskRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, Flow, int> _genFlowRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStep, int> _genFlowStepRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ViewTaskConfiguration, int> _genViewTaskConfigurationRepository;

        private readonly IBatchEngineRepository _batchEngineRepository;
        private readonly IGenericRepository<PhoenixConfContext, EngineBatchLog, decimal> _genEngineBatchLogRepository;

        private readonly INotificationService _notificationService;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> _mpAccountBusinessUnitRepository;
        private readonly IViewIfrsValidationRepository _ifrsValidationRepository;
        private readonly IViewIfrsDataValidationResultRepository _ifrsDataValidationResultRepository;
        private readonly IViewIfrsDataInitialResultRepository _ifrsDataInitialResultRepository;

        public App(IConfigurationRoot config, ILoggerFactory loggerFactory,
            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            IGenericRepository<IFRS9_ConfContext, Task, int> genTaskRepository,
            IGenericRepository<IFRS9_ConfContext, Flow, int> genFlowRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStep, int> genFlowStepRepository,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, ViewTaskConfiguration, int> genTaskConfigurationRepository,

            IBatchEngineRepository batchEngineRepository,
            IGenericRepository<PhoenixConfContext, EngineBatchLog, decimal> genEngineBatchLogRepository,

            INotificationService notificationService,
            IGenericRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> mpAccountBusinessUnitRepository,
            IViewIfrsValidationRepository ifrsValidationRepository,
            IViewIfrsDataValidationResultRepository ifrsDataValidationResultRepository,
            IViewIfrsDataInitialResultRepository ifrsDataInitialResultRepository)
        {
            _configuration = config;
            _logger = loggerFactory.CreateLogger<App>();

            _unitOfWork = unitOfWork;
            _genTaskRepository = genTaskRepository;
            _genFlowRepository = genFlowRepository;
            _genFlowStepRepository = genFlowStepRepository;
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;
            _genViewTaskConfigurationRepository = genTaskConfigurationRepository;

            _batchEngineRepository = batchEngineRepository;
            _genEngineBatchLogRepository = genEngineBatchLogRepository;

            _notificationService = notificationService;
            _mpAccountBusinessUnitRepository = mpAccountBusinessUnitRepository;
            _ifrsValidationRepository = ifrsValidationRepository;
            _ifrsDataValidationResultRepository = ifrsDataValidationResultRepository;
            _ifrsDataInitialResultRepository = ifrsDataInitialResultRepository;
        }

        public void Run(string[] args)
        {
            _logger.LogInformation(JsonConvert.SerializeObject(args, Formatting.Indented));
            _logger.LogInformation("Hello, from flow_task running");
        }

        public async System.Threading.Tasks.Task RunAsync(string[] args)
        {
            try
            {
                if (args == null || !args.Any() || args.Count() != 3)
                {
                    Console.WriteLine("Job started.");
                    Console.ReadKey();
                }

                _logger.LogInformation(JsonConvert.SerializeObject(args, Formatting.Indented));

                var flowExecutionId = int.Parse(args[0]);
                var username = args[1];
                var token = args[2];

                var flowExecution = await _genFlowExecutionRepository.FindAsync(flowExecutionId);
                switch (flowExecution.Fk_Flow_Id)
                {
                    case 1:
                        await RunDataValidationAsync(flowExecution, username, token);
                        break;
                    case 2:
                        await EclCalculationAsync(flowExecution, username, token);
                        break;
                    default:
                        throw KeyNotFoundException();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        async System.Threading.Tasks.Task RunDataValidationAsync(FlowExecution flowExecution, string username, string token)
        {
            try
            {
                _unitOfWork.BeginTransaction();

                var flowExecution_Current = flowExecution;

                var flowStepExec_CallIfrs_Init = new FlowStepExecution();
                var step_Data_Validation = new FlowStepExecution();
                var step_Init_Data = new FlowStepExecution();

                var task_CallIfrs_Init = new Task();
                var task_Data_Validation = new Task();
                var task_Init_Data = new Task();

                var batchEngineExecutionDto = new BatchEngineExecutionDto();
                var adjustSystemExecutionDto = new AdjustSystemExecutionDto();
                var executionDate = DateTime.Now;

                // flow_Step_Executions list for all Tasks include this flow
                var flowStepExecutions_All = _genFlowStepExecutionRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Fk_Flow_Execution_Id == flowExecution.Pk_Id)
                    .ToList();
                if (flowStepExecutions_All == null || !flowStepExecutions_All.Any()) 
                {
                    _unitOfWork.Commit();
                    return; 
                }

                #region Auto invoke [Call IFFRS_INIT] task

                // Is_First_Task current
                flowStepExec_CallIfrs_Init = flowStepExecutions_All.Single(x => x.Is_First_Task);
                if (flowStepExec_CallIfrs_Init == null)
                {
                    _unitOfWork.Commit();
                    return;
                }

                // Task for step_CallIfrs_Init
                task_CallIfrs_Init = _genTaskRepository.Find(flowStepExec_CallIfrs_Init.Fk_Current_Task_Step_Id);
                if (task_CallIfrs_Init == null || task_CallIfrs_Init.Is_Deleted)
                {
                    _unitOfWork.Commit();
                    return;
                }

                // if READY_TO_EXECUTE/EXECUTING status
                if (task_CallIfrs_Init.Linked_Job_Id.HasValue &&
                    (flowStepExec_CallIfrs_Init.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase) ||
                     flowStepExec_CallIfrs_Init.Task_Status.Equals(Workflow_Status_Code.EXECUTING, StringComparison.CurrentCultureIgnoreCase)))
                {
                    // call job IFRS_INIT
                    var isFlowEnded = await InvokeJobIfrsInit(flowExecution, flowStepExec_CallIfrs_Init, task_CallIfrs_Init, token, executionDate, username);
                    if (isFlowEnded)
                    {
                        // Noti
                        SendNoti_DataInit(flowExecution, token, username);
                        return;
                    }
                }

                #endregion

                #region Auto check data_validation

                step_Data_Validation = _genFlowStepExecutionRepository
                    .Queryable()
                    .SingleOrDefault(x => x.Fk_Flow_Execution_Id == flowExecution.Pk_Id &&
                                          x.Fk_Current_Task_Step_Id == flowStepExec_CallIfrs_Init.Fk_Next_Task_Step_Id.Value);
                if (step_Data_Validation == null) return;

                task_Data_Validation = _genTaskRepository.Find(step_Data_Validation.Fk_Current_Task_Step_Id);
                if (task_Data_Validation == null || task_Data_Validation.Is_Deleted) return;

                if (task_Data_Validation.Linked_Job_Id.HasValue && step_Data_Validation.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                {
                    // call job IFRS_STAG
                    var isFlowEnded = await InvokeJobIfrsStag(flowExecution, step_Data_Validation, task_Data_Validation, token, executionDate, username);
                    if (isFlowEnded)
                    {
                        // Noti
                        SendNoti_DataValidation(flowExecution, token, username);
                        return;
                    }
                }

                #endregion

                #region Auto check data_init task

                step_Init_Data = _genFlowStepExecutionRepository
                    .Queryable()
                    .SingleOrDefault(x => x.Fk_Flow_Execution_Id == flowExecution.Pk_Id &&
                                          x.Fk_Current_Task_Step_Id == step_Data_Validation.Fk_Next_Task_Step_Id.Value);
                if (step_Init_Data == null) return;

                task_Init_Data = _genTaskRepository.Find(step_Data_Validation.Fk_Current_Task_Step_Id);
                if (task_Init_Data == null || task_Init_Data.Is_Deleted) return;

                if (step_Init_Data.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase) && task_Init_Data.Linked_Job_Id.HasValue)
                {
                    // call job IFRS_INIT
                    var isFlowEnded = await InvokeJobIfrsInit(flowExecution, flowStepExec_CallIfrs_Init, task_CallIfrs_Init, token, executionDate, username);
                    if (isFlowEnded)
                    {
                        // Noti
                        SendNoti_DataInit(flowExecution, token, username);
                        return;
                    }

                    // Re-Invoke RunAsync Flow
                    await RunDataValidationAsync(flowExecution, username, token);
                }

                #endregion

                _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                throw ex;
            }
        }

        async System.Threading.Tasks.Task<bool> InvokeJobIfrsInit(FlowExecution flowExecution, FlowStepExecution step_CallIfrs_Init, Task task_CallIfrs_Init, string token, DateTime executionDate, string username)
        {
            try
            {
                //var batchEngineExecutionDto = new BatchEngineExecutionDto
                //{
                //    id = task_CallIfrs_Init.Linked_Job_Id.Value,
                //    businessDate = flowExecution.Business_Date,
                //    approach = string.Empty,
                //    entityCode = task_CallIfrs_Init.Entity_Code,
                //    scenarioId = task_CallIfrs_Init.Scenario_Id,
                //    versionId = task_CallIfrs_Init.Version_Id,

                //    taskExecutionId = task_CallIfrs_Init.Pk_Id
                //};

                //var uri_call_ifrs_init = string.Format($"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_EXECUTION_JOB}", task_CallIfrs_Init.Linked_Job_Id.Value);
                //Log.Information($"Call: {uri_call_ifrs_init}, Batch_Job_Id: {task_CallIfrs_Init.Linked_Job_Id.Value}");
                //Log.Information($"Batch_Engine_Execution param: {JsonConvert.SerializeObject(batchEngineExecutionDto, Formatting.Indented)}");

                //// run call batch_job
                //// get batch_log
                //var batchLogStatus = APIHelper.PostAsString(uri_call_ifrs_init, token, JsonConvert.SerializeObject(batchEngineExecutionDto), MediaTypeNames.Application.Json, API_METHODS.POST);

                // update flow_step_1 to executing
                step_CallIfrs_Init.Task_Status = Workflow_Status_Code.EXECUTING;
                _genFlowStepExecutionRepository.Update(step_CallIfrs_Init);
                await _unitOfWork.SaveChangesAsync();

                // Call
                var batchEngineExecution = new BatchEngineExecutionParam
                {
                    Batch_Id = task_CallIfrs_Init.Linked_Job_Id.Value,
                    Business_Date = flowExecution.Business_Date,
                    Approach = string.Empty,
                    Entity_Code = task_CallIfrs_Init.Entity_Code,
                    Scenario_Id = task_CallIfrs_Init.Scenario_Id,
                    Version_Id = task_CallIfrs_Init.Version_Id
                };
                var batchJobLogId = _batchEngineRepository.BatchJobEnginesExecution(batchEngineExecution);
                var engineBatchLog = _genEngineBatchLogRepository.Find(batchJobLogId);

                // Job_Status = COMPELTED/FAILED
                if (engineBatchLog.Batch_Status.Equals(Workflow_Status_Code.COMPELTED, StringComparison.CurrentCultureIgnoreCase) || engineBatchLog.Batch_Status.Equals(Workflow_Status_Code.FAILED, StringComparison.CurrentCultureIgnoreCase))
                {
                    // CallIfrs_Init
                    step_CallIfrs_Init.Task_Status = engineBatchLog.Batch_Status;
                    step_CallIfrs_Init.End_Time = executionDate;
                    _genFlowStepExecutionRepository.Update(step_CallIfrs_Init);
                    _unitOfWork.SaveChanges(true);

                    // END: update flowExecution if FAILED
                    if (step_CallIfrs_Init.Task_Status.Equals(Workflow_Status_Code.FAILED, StringComparison.CurrentCultureIgnoreCase))
                    {
                        // FlowExecution
                        flowExecution.Flow_Execution_Status = Workflow_Status_Code.FAILED;
                        flowExecution.End_Time = executionDate;
                        _genFlowExecutionRepository.Update(flowExecution);
                        await _unitOfWork.SaveChangesAsync();
                        return true;
                    }

                    // get next task (Data_Validation)
                    if (step_CallIfrs_Init.Task_Status.Equals(Workflow_Status_Code.COMPELTED, StringComparison.CurrentCultureIgnoreCase) &&
                        step_CallIfrs_Init.Fk_Next_Task_Step_Id.HasValue)
                    {
                        var step_Data_Validation = _genFlowStepExecutionRepository
                            .Queryable()
                            .SingleOrDefault(x => x.Fk_Flow_Execution_Id == flowExecution.Pk_Id &&
                                                  x.Fk_Current_Task_Step_Id == step_CallIfrs_Init.Fk_Next_Task_Step_Id.Value);

                        if (step_Data_Validation != null)
                        {
                            step_Data_Validation.Task_Status = Workflow_Status_Code.READY_TO_EXECUTE;
                            step_Data_Validation.Start_Time = executionDate;
                            step_Data_Validation.End_Time = null;
                            step_Data_Validation.Executor_By = username;
                            _genFlowStepExecutionRepository.Update(step_Data_Validation);
                            await _unitOfWork.SaveChangesAsync();
                        }
                    }
                }

                _unitOfWork.Commit();
                return false;
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                throw ex;
            }
        }

        private async System.Threading.Tasks.Task<bool> InvokeJobIfrsStag(FlowExecution flowExecution, FlowStepExecution step_Data_Validation, Task task_Data_Validation, string token, DateTime executionDate, string username)
        {
            // get data_validation failed or success
            var dataValidatationFailed = _ifrsDataValidationResultRepository.FindAllByBusinessDate(flowExecution.Business_Date).ToList();

            // 
            var step_Init_Data = new FlowStepExecution();
            var task_Init_Data = new Task();

            // Priority: 1
            // Exist (Number of fail validation records > 0) for Validation Type='Manual File'
            // Target -> Validation Failed with Manual
            var existedNumberOfFailed = dataValidatationFailed.Where(x => x.Type_Name.Equals(DATA_VALIDATION_TYPES.Manual_File.ToDescription()) && x.Fail_Record > 0).Any();
            if (existedNumberOfFailed)
            {
                // Current (Data_Validation)
                step_Data_Validation.Task_Status = Workflow_Status_Code.VALIDATION_FAILDED_MANUAL_FILE;
                step_Data_Validation.End_Time = executionDate;
                _genFlowStepExecutionRepository.Update(step_Data_Validation);
                await _unitOfWork.SaveChangesAsync();

                // Next (Data_Init)
                if (step_Data_Validation.Fk_Next_Task_Step_Id.HasValue)
                {
                    step_Init_Data = _genFlowStepExecutionRepository
                        .Queryable()
                        .Where(x => x.Fk_Flow_Execution_Id == flowExecution.Pk_Id &&
                                    x.Fk_Current_Task_Step_Id == step_Data_Validation.Fk_Next_Task_Step_Id.Value &&
                                    !x.Is_First_Task)
                        .SingleOrDefault();

                    // END: Update Data_Init to READY_TO_EXECUTE
                    if (step_Init_Data != null)
                    {
                        step_Init_Data.Task_Status = Workflow_Status_Code.READY_TO_EXECUTE;
                        step_Init_Data.Start_Time = executionDate;
                        step_Init_Data.End_Time = null;
                        step_Init_Data.Executor_By = username;
                        _genFlowStepExecutionRepository.Update(step_Init_Data);
                        await _unitOfWork.SaveChangesAsync();
                        return true;
                    }
                }
            }

            // Priority: 2
            // Exist (Number of fail validation records > 0)
            existedNumberOfFailed = dataValidatationFailed.Where(x => x.Type_Name.Equals(DATA_VALIDATION_TYPES.Data_Model.ToDescription()) && x.Fail_Record > 0).Any();
            if (existedNumberOfFailed)
            {
                // Current (Data_Validation)
                step_Data_Validation.Task_Status = Workflow_Status_Code.VALIDATION_FAILDED;
                step_Data_Validation.End_Time = executionDate;
                _genFlowStepExecutionRepository.Update(step_Data_Validation);
                await _unitOfWork.SaveChangesAsync();

                // END:
                flowExecution.Flow_Execution_Status = Workflow_Status_Code.VALIDATION_FAILDED;
                flowExecution.End_Time = executionDate;
                _genFlowExecutionRepository.Update(flowExecution);
                await _unitOfWork.SaveChangesAsync();
                return true;
            }

            // Priority: 3
            // All (Number of fail validation records = 0)
            existedNumberOfFailed = dataValidatationFailed.Where(x => x.Fail_Record != 0).Any();
            if (!existedNumberOfFailed)
            {
                // Current (Data_Validation)
                step_Data_Validation.Task_Status = Workflow_Status_Code.EXECUTING;
                _genFlowStepExecutionRepository.Update(step_Data_Validation);
                await _unitOfWork.SaveChangesAsync();

                #region // get task, call Job IFRS_STAG

                //// Call
                //var batchEngineExecution = new BatchEngineExecutionParam
                //{
                //    Batch_Id = task_Data_Validation.Linked_Job_Id.Value,
                //    Business_Date = flowExecution.Business_Date,
                //    Approach = string.Empty,
                //    Entity_Code = task_Data_Validation.Entity_Code,
                //    Scenario_Id = task_Data_Validation.Scenario_Id,
                //    Version_Id = task_Data_Validation.Version_Id
                //};
                //var batchLogId = await _batchEngineRepository.BatchJobEnginesExecution(batchEngineExecution);
                //var engineBatchLog = _genEngineBatchLogRepository.Find(batchLogId);

                var batchEngineExecutionDto = new BatchEngineExecutionDto
                {
                    batchJobInitId = task_Data_Validation.Linked_Job_Id.Value,
                    batchJobStagId = 0,
                    batchJobIfrsPllpId = 0,
                    businessDate = flowExecution.Business_Date,
                    approach = string.Empty,
                    entityCode = task_Data_Validation.Entity_Code,
                    scenarioId = task_Data_Validation.Scenario_Id,
                    versionId = task_Data_Validation.Version_Id,

                    flowId = 0,
                    flowStepExecutionInitId = task_Data_Validation.Pk_Id,
                    flowStepExecutionStagId = 0,
                    flowStepExecutionStagLstId = 0
                };

                var uri_call_ifrs_init = string.Format($"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_EXECUTION_BATCH_JOB}", task_Data_Validation.Linked_Job_Id);
                Log.Information($"Call: {uri_call_ifrs_init}, Batch_Job_Id: {task_Data_Validation.Linked_Job_Id}");
                Log.Information($"Batch_Engine_Execution param: {JsonConvert.SerializeObject(batchEngineExecutionDto, Formatting.Indented)}");

                // run call batch_job
                var result = APIHelper.PostAsString(uri_call_ifrs_init, token, JsonConvert.SerializeObject(batchEngineExecutionDto), MediaTypeNames.Application.Json, API_METHODS.POST);

                // get batch_log
                var batchLogStatus = JsonConvert.DeserializeObject<string>(result);

                #endregion

                // Current (Data_Validation)
                step_Data_Validation.Task_Status = batchLogStatus;
                step_Data_Validation.End_Time = executionDate;
                _genFlowStepExecutionRepository.Update(step_Data_Validation);
                await _unitOfWork.SaveChangesAsync();

                // END flow:
                flowExecution.Flow_Execution_Status = batchLogStatus;
                flowExecution.End_Time = executionDate;
                _genFlowExecutionRepository.Update(flowExecution);
                await _unitOfWork.SaveChangesAsync();
            }
            return false;
        }

        private async System.Threading.Tasks.Task EclCalculationAsync(FlowExecution flowExecution, string username, string token)
        {
            var flow = await _genFlowExecutionRepository.FindAsync(flowExecution.Pk_Id);
        }

        private Exception KeyNotFoundException()
        {
            throw new NotImplementedException();
        }

        private void SendNoti_DataValidation(FlowExecution flowExecution, string token, string username)
        {
            #region Send notification

            try
            {
                var dataValidationFaileds = _ifrsDataValidationResultRepository
                    .FindAllByBusinessDate(flowExecution.Business_Date)
                    .Where(x => x.Fail_Record > 0)
                    .ToList();

                if (dataValidationFaileds == null || !dataValidationFaileds.Any()) return;

                foreach (var dataValidationFailed in dataValidationFaileds)
                {
                    dynamic other = new ExpandoObject();
                    other.Object_Target = dataValidationFailed.Validation_Rule;
                    other.Ifrs_Noti_Type = IFRS_MSG_TYPES.DATA_VALIDATION;

                    //// get subscribers (all user in Business_Unit)
                    //var subscribers = _mpAccountBusinessUnitRepository
                    //    .Queryable()
                    //    .Where(x => dataValidationFailed.Fk_Business_Unit_Id.HasValue && x.Fk_Business_Unit_Id == dataValidationFailed.Fk_Business_Unit_Id.Value)
                    //    .Select(c => c.Username)
                    //    .Distinct()
                    //    .ToList();
                    //// send noti
                    //var notification = _notificationService.BuildNotiPayload(ActionTypes.IFRS_STAGING, nameof(FlowExecution), RequestStatus.IFRS_AUTO, RequestSegment.END_POINT_IFRS_SEND_AUTO, subscribers, username, new ExpandoObject());

                    //// send msg to j_api
                    //var api_1 = _configuration[$"{nameof(AppSettings.Properties)}:{nameof(Properties.API1)}"];
                    //var api_1_endpoint = string.Format($"{api_1}{RequestSegment.NOTIFICATION_SEND_MSG}");
                    //APIHelper.Post(api_1_endpoint, token, JsonConvert.SerializeObject(notification), MediaTypeNames.Application.Json, API_METHODS.POST);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
            }

            #endregion
        }

        private void SendNoti_DataInit(FlowExecution flowExecution, string token, string username)
        {
            #region Send notification

            try
            {
                var dataValidationFaileds = _ifrsDataValidationResultRepository
                    .FindAllByBusinessDate(flowExecution.Business_Date)
                    .Where(x => x.Fail_Record.HasValue && x.Fail_Record.Value > 0)
                    .ToList();

                var dataInitNotApproveds = _ifrsDataInitialResultRepository
                    .FindAllByBusinessDate(flowExecution.Business_Date)
                    .ToList();

                if (dataValidationFaileds == null || !dataValidationFaileds.Any() || dataInitNotApproveds == null || !dataInitNotApproveds.Any()) return;

                var resultFaileds = from val in dataValidationFaileds
                                    join init in dataInitNotApproveds on val.Validation_Rule equals init.Validation_Rule
                                    select new { init.File_Name, val.Validation_Rule, val.Fail_Record, init.Fk_Business_Unit_Id1 };

                if (resultFaileds == null || !resultFaileds.Any()) return;

                foreach (var fileFailed in resultFaileds)
                {
                    dynamic other = new ExpandoObject();
                    other.Object_Target = fileFailed.File_Name;
                    other.Ifrs_Noti_Type = IFRS_MSG_TYPES.DATA_INITIAL;

                    // get subscribers (all user in Business_Unit)
                    var subscribers = new List<string>();
                    if (string.IsNullOrEmpty(fileFailed.Fk_Business_Unit_Id1)) continue;
                    var fkInputers = fileFailed.Fk_Business_Unit_Id1.Split(SpecificSystems.SEMICOLON).ToList();
                    foreach (var fk_Business_Unit_Id in fkInputers)
                    {
                        subscribers.AddRange(_mpAccountBusinessUnitRepository
                            .Queryable()
                            .Where(x => x.Fk_Business_Unit_Id == int.Parse(fk_Business_Unit_Id))
                            .Select(c => c.Username)
                            .ToList());
                    }

                    if (subscribers.Any())
                    {
                        //// send noti
                        //var notification = _notificationService.BuildNotiPayload(ActionTypes.IFRS_STAGING, nameof(FlowExecution), RequestStatus.IFRS_AUTO, RequestSegment.END_POINT_IFRS_SEND_AUTO, subscribers.Distinct().ToList(), username, other);

                        //// send msg to j_api
                        //var api_1 = _configuration[$"{nameof(AppSettings.Properties)}:{nameof(Properties.API1)}"];
                        //var api_1_endpoint = string.Format($"{api_1}{RequestSegment.NOTIFICATION_SEND_MSG}");
                        //APIHelper.Post(api_1_endpoint, token, JsonConvert.SerializeObject(notification), MediaTypeNames.Application.Json, API_METHODS.POST);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
            }

            #endregion
        }
    }
}

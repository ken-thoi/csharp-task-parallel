﻿namespace VPBANK.RMD.Data.Core
{
    public static class Core_SqlQuery_Define
    {
    }
}

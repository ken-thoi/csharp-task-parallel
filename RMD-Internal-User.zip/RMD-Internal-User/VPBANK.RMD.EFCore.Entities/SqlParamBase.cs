﻿namespace VPBANK.RMD.EFCore.Entities
{
    public abstract class SqlParamBase : ISqlParamBase
    {
    }

    public interface ISqlParamBase
    {
    }
}

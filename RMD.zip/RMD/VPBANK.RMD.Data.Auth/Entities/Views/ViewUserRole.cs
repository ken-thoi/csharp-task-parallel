﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.Views
{
    [Table("View_User_Role", Schema = "Core")]
    public class ViewUserRole : BaseEntity<long>
    {
        [Key]
        public override long Pk_Id { get; set; }

        public string Username { get; set; }

        public string Super_Role { get; set; }

        public string Fk_Data_Role { get; set; }

        public string Data_Role { get; set; }

        public string Function_Role { get; set; }

        public string Component_Role { get; set; }
    }
}

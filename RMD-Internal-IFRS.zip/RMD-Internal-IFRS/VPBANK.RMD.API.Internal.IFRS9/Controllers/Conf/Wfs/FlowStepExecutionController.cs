﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf.Views.WF;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.AppEngines;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Services.IFRS9_Conf.DataTransferObjects.Wfs;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Wfs;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Notification.Publisher;
using Task = VPBANK.RMD.Data.IFRS9_Conf.Entities.WF.Task;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Wfs
{
    public class FlowStepExecutionController : TrackingController<IFRS9_ConfContext, FlowStepExecution, int>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, Task, int> _genTaskRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ViewTaskMonitoring, int> _viewTaskMonitoringRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _flowStepExecutionRepository;
        private readonly IFlowStepExecutionService _flowStepExecutionService;
        private readonly IGenericRepository<PhoenixConfContext, EngineBatchLog, decimal> _genEngineBatchLogRepository;

        public FlowStepExecutionController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, FlowStepExecution, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, Task, int> genTaskRepository,
            IGenericRepository<IFRS9_ConfContext, ViewTaskMonitoring, int> viewTaskMonitoringRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> flowStepExecutionRepository,
            IFlowStepExecutionService flowStepExecutionService,
            IGenericRepository<PhoenixConfContext, EngineBatchLog, decimal> genEngineBatchLogRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genTaskRepository = genTaskRepository;
            _viewTaskMonitoringRepository = viewTaskMonitoringRepository;
            _flowStepExecutionRepository = flowStepExecutionRepository;
            _flowStepExecutionService = flowStepExecutionService;
            _genEngineBatchLogRepository = genEngineBatchLogRepository;
        }

        /// <summary>
        /// Get all flow_step_executions by fk_Flow_Execution_Id
        /// </summary>
        /// <param name="fk_Flow_Execution_Id">0: Get All</param>
        /// <returns></returns>
        [HttpGet]
        [Route("{fk_Flow_Execution_Id}")]
        public virtual ActionResult<IEnumerable<ViewTaskMonitoring>> FindAllByFlowExecutionId([AllowNull][FromRoute] int fk_Flow_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Flow_Execution_Id == 0)
                    return BadRequest(ModelState);

                var results = _viewTaskMonitoringRepository
                    .Queryable()
                    .Where(c => c.Fk_Flow_Execution_Id == fk_Flow_Execution_Id)
                    .OrderBy(x => x.Task_Level)
                    .ThenBy(x => x.Start_Date)
                    .ThenBy(x => x.End_Date)
                    .ToList();
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get all flow_executions by fk_Flow_Execution_Id for gui_ui
        /// </summary>
        /// <param name="fk_Flow_Execution_Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{fk_Flow_Execution_Id}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiFindAllExecutions([AllowNull][FromRoute] int fk_Flow_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Flow_Execution_Id == 0)
                    return BadRequest(ModelState);

                var results = _viewTaskMonitoringRepository
                    .Queryable()
                    .Where(c => c.Fk_Flow_Execution_Id == fk_Flow_Execution_Id)
                    .Select(c => new SelectedItem
                    {
                        Key = fk_Flow_Execution_Id,
                        Val = c.Flow_Name
                    })
                    .Distinct()
                    .ToList();
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get all flow_step_executions by execution_id for gui_ui
        /// </summary>
        /// <param name="fk_Flow_Execution_Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{fk_Flow_Execution_Id}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiFindAllTaskExecutions([AllowNull][FromRoute] int fk_Flow_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Flow_Execution_Id == 0)
                    return BadRequest(ModelState);

                var results = _viewTaskMonitoringRepository
                    .Queryable()
                    .Where(c => c.Fk_Flow_Execution_Id == fk_Flow_Execution_Id)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Pk_Id,
                        Val = c.Task_Name
                    })
                    .Distinct()
                    .ToList();
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Check avaiable action in task by task_execution_id
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{fk_Task_Execution_Id}")]
        public virtual async Task<ActionResult> CheckTaskExecutionAvaiableUpd([AllowNull][FromRoute] int fk_Task_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0)
                    return BadRequest(ModelState);

                var result = await _flowStepExecutionRepository.FindAsync(fk_Task_Execution_Id);
                if (result != null && (result.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase) || result.Task_Status.Equals(Workflow_Status_Code.REJECTED, StringComparison.CurrentCultureIgnoreCase)))
                    return Ok(result);

                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Execute and adjust task_step_execution flow.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="taskActionTypeId">TERMINATED: 2, PAUSE: 5, RESUME: 6</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        [Route("{taskActionTypeId}")]
        public virtual async Task<IActionResult> TaskAdjustAsync([FromRoute] int taskActionTypeId, [FromBody] TaskStepExecutionDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                #region action on results

                var username = GetUserPayloadFromHeader().Username;
                var results = await _flowStepExecutionService.TaskAdjustAsync(taskActionTypeId, data, username, GetToken());
                var errMsg = results.Item1;
                var flowStepExecution = results.Item2;
                var batchEngineExecution = results.Item3;
                var adjustSystemExecution = results.Item4;

                // error
                if (!string.IsNullOrEmpty(errMsg))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), errMsg);

                #endregion

                #region call job from API_1

                try
                {
                    var task = _genTaskRepository.Find(flowStepExecution.Fk_Current_Task_Step_Id);
                    if ((taskActionTypeId == Convert.ToInt32(Action_Type_Enum.TERMINATE) || taskActionTypeId == Convert.ToInt32(Action_Type_Enum.PAUSE) || taskActionTypeId == Convert.ToInt32(Action_Type_Enum.RESUME)) &&
                        flowStepExecution != null && task != null && task.Linked_Job_Id.HasValue)
                    {
                        var flowStepExecutions = _genericRepository
                            .Queryable()
                            .AsEnumerable()
                            .Where(x => x.Fk_Flow_Execution_Id == flowStepExecution.Fk_Flow_Execution_Id && x.Fk_Current_Task_Step_Id == flowStepExecution.Fk_Current_Task_Step_Id)
                            .ToList();
                        foreach (var item in flowStepExecutions)
                        {
                            if (item.Fk_Engine_Batch_Log_Id.HasValue)
                            {
                                var currentStatus = string.Empty;
                                if (taskActionTypeId == Convert.ToInt32(Action_Type_Enum.RESUME))
                                {
                                    currentStatus = Workflow_Status_Code.PAUSED;
                                }
                                else
                                {
                                    currentStatus = Workflow_Status_Code.EXECUTING;
                                }

                                adjustSystemExecution.id = Convert.ToInt32(item.Fk_Engine_Batch_Log_Id.Value);
                                adjustSystemExecution.taskExecutionId = item.Pk_Id;
                                adjustSystemExecution.batchStatus = currentStatus;
                                adjustSystemExecution.actionOriginId = task.Action_Origin_Id ?? Convert.ToInt32(PROCESS_MONITORINGS_ACTION_ORIGIN.ENGINE_JOB);
                                var api_1_adjust = string.Format($"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_ADJUST_SYS_EXEC_BATCH_JOB}", taskActionTypeId);
                                Log.Information($"Call API1_adjust Batch, Job: {api_1_adjust}");
                                Log.Information($"Job_Id: {task.Linked_Job_Id}");
                                Log.Information($"Batch_Engine_Execution adjust: {JsonConvert.SerializeObject(adjustSystemExecution, Formatting.Indented)}");
                                APIHelper.Post(api_1_adjust, GetToken(), JsonConvert.SerializeObject(adjustSystemExecution), MediaTypeNames.Application.Json, API_METHODS.POST);
                                break;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    Log.Error(ex.StackTrace);
                    Log.Error(ex.InnerException?.Message);
                }

                #endregion

                // results
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

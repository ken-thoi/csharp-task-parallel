﻿using System;
using System.Collections.Generic;

namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public class IfrsDataReq<T> where T : class
    {
        public int? Request_Id { get; set; }

        public int Fk_Flow_Execution_Id { get; set; }

        public int Fk_Task_Execution_Id { get; set; }

        public DateTime Business_Date { get; set; }

        public string Customer_Id { get; set; }

        public string Comments { get; set; }

        public int? Request_Action { get; set; }

        public List<T> Entities { get; set; }
    }

    public class IfrsDataApr
    {
        public int Request_Id { get; set; }

        public int Fk_Flow_Execution_Id { get; set; }

        public int Fk_Task_Execution_Id { get; set; }

        public DateTime Business_Date { get; set; }

        public string Customer_Id { get; set; }

        public string Request_Status { get; set; }

        public string Note_Approval { get; set; }
    }
}

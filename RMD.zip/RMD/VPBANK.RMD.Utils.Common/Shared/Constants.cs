﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class Constants
    {
        public const string WWWROOT = "wwwroot";
        public const string PATH_BASE = "PATH_BASE";

        public const string CHARS_ALL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        public const string YES = "Y";
        public const string NO = "N";
        public const string BUSSINESS_EXCEPTION = "BUSSINESS_EXCEPTION";
    }

    public static class DAT_TAG_FILE_EX
    {
        public const int COLN_START_LINE_VALIDATE = 4;
    }
}

﻿namespace VPBANK.RMD.Repositories.PhoenixData
{
    public class PhoenixDataSqlQuery
    {
    }
}

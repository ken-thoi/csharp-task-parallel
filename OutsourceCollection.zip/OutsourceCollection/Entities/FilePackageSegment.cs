﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class FilePackageSegment
    {
        public long Id { get; set; }
        public int FK_FilePackage_Id { get; set; }
        public string Destination { get; set; }
        public long Size { get; set; }
        public string MD5Checksum { get; set; }
    }
}

﻿namespace VPBANK.RMD.Services.Auth.Interfaces
{
    public interface IViewUserRoleService
    {
    }
}

﻿using Microsoft.Extensions.Caching.Distributed;
using Serilog;
using System;
using System.Linq;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class PLLPCustomerRepository : Repository<IFRS9_DataContext, PLLPCustomer, decimal>, IPLLPCustomerRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public PLLPCustomerRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, PLLPCustomer, decimal> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public PLLPCustomer FindPLLPCustomerByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                return TrackableRepository
                       .QueryableFromSqlRaw($"SELECT c.* FROM Core.PLLP_Customer AS c WHERE c.Customer_Id = '{customerId}' AND c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'")
                       .AsEnumerable()
                       .FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }
    }
}

﻿using VPBANK.RMD.Data.Collection.SqlParams;

namespace VPBANK.RMD.Services.Collection.DataTransferObjects.Reports
{
    public class CollectionRepayReportReq : CollectionRepayReportParam
    {
    }
}

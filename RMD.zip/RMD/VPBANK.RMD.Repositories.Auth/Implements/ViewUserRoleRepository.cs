﻿using VPBANK.RMD.Repositories.Auth.Interfaces;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.Views;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.Auth.Implements
{
    public class ViewUserRoleRepository : Repository<AuthContext, ViewUserRole, long>, IViewUserRoleRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly ILogger<ViewUserRole> _logger;
        protected readonly AuthContext _authContext;

        public ViewUserRoleRepository(IDistributedCache distributedCache, ILogger<ViewUserRole> logger, ITrackableRepository<AuthContext, ViewUserRole, long> trackableRepository,
            AuthContext authContext) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _logger = logger;
            _authContext = authContext;
        }

        public async Task<IEnumerable<ViewUserRole>> FindAllAsync()
        {
            var results = await TrackableRepository.Query().SelectAsync();
            return results;
        }

        public ViewUserRole FindByUserName(string username)
        {
            return TrackableRepository
                   .Queryable()
                   .AsEnumerable()
                   .SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) && c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase));
        }

        public async Task<ViewUserRole> FindByUserNameAsync(string username)
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users.SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) && c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase));
        }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System.Linq;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.BCL;
using VPBANK.RMD.Data.IFRS9_Conf.Views.WF;
using System.Collections.Generic;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Wfs
{
    public class ViewTaskMonitoringController : QueryController<IFRS9_ConfContext, ViewTaskMonitoring, int>
    {
        private readonly RequestHandler _requestHandler;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IRequestObjectService _reqService;
        private readonly IApproveStatusRepository _reqStatusRepository;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IMpAccountBusinessUnitService _service;

        public ViewTaskMonitoringController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, ViewTaskMonitoring, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, ViewTaskMonitoring, int> genericRepository,

            RequestHandler requestHandler,
            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusRepository reqStatusRepository,
            IApproveStatusService appStaService,
            IMpAccountBusinessUnitService service) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;
            _reqRepository = reqRepository;
            _reqService = requestService;
            _reqStatusRepository = reqStatusRepository;
            _reqStatusService = appStaService;
            _service = service;
        }

        /// <summary>
        /// Get task monitoring object by task_execution_id
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <returns>ViewTaskMonitoring object</returns>
        [HttpGet(template: "{fk_Task_Execution_Id}")]
        public ActionResult<ViewTaskMonitoring> FindByTaskExecutionId([Required][NotNull][FromRoute] int fk_Task_Execution_Id)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0)
                    return BadRequest();

                // result
                var result = _genericRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(x => x.Pk_Id == fk_Task_Execution_Id)
                    .FirstOrDefault();
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public override async Task<ActionResult<PaginatedContentResults<ViewTaskMonitoring>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                if (paginatedParams == null || paginatedParams.SortingParams == null)
                    paginatedParams = new PaginatedInputModel { SortingParams = new List<SortingUtility.SortingParams>() };
                paginatedParams.SortingParams.Add(new SortingUtility.SortingParams { ColumnName = COLUMNS_NAME.TASK_LEVEL, SortOrder = Enums.SortOrders.Asc });

                return await base.Query(paginatedParams);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

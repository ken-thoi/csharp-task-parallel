﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Conf_MP_IFRS_Sector_Group", Schema = "BCL")]
    public class ConfMpSectorGroup : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public decimal Sector { get; set; }
        public string Sector_Group { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

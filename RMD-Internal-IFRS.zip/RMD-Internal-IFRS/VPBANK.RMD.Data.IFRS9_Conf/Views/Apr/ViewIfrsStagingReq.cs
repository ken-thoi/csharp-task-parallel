﻿using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.WF
{
    [Table("View_IFRS_Staging_Req", Schema = "Apr")]
    public class ViewIfrsStagingReq : EntityBase<long>
    {
        [Key]
        public override long Pk_Id { get; set; }
        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Business_Date { get; set; }

        public string Flow_Name { get; set; }
        public int Request_Id { get; set; }

        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }

        public string Request_Details { get; set; }
        public string Stage_Adjust
        {
            get
            {
                try
                {
                    var requestDetails = JsonConvert.DeserializeObject<List<dynamic>>(Request_Details);
                    var obj = requestDetails != null && requestDetails.Count == 1 ? requestDetails.FirstOrDefault() : null;
                    return obj != null ? obj.Stage_Adjust : string.Empty;
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    return string.Empty;
                }
            }
        }
        public string Request_Status { get; set; }

        public string Note_Adjust { get; set; }
        public string Requestor { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? Request_Date { get; set; }

        public string Note_Approval { get; set; }
        public string Approver { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? Approved_Date { get; set; }
    }
}

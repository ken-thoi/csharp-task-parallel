﻿namespace VPBANK.RMD.Utils.Common.Assemblies
{
    public class DefAssemblies
    {
        public const string VBP_RMD_Data_Auth = "VPBANK.RMD.Data.Auth";
        public const string VBP_RMD_Data_PhoenixConf = "VPBANK.RMD.Data.PhoenixConf";
        public const string VBP_RMD_Data_PhoenixData = "VPBANK.RMD.Data.PhoenixData";
        public const string VBP_RMD_Data_Collection = "VPBANK.RMD.Data.Collection";
        public const string VBP_RMD_Data_IFRS9Conf = "VPBANK.RMD.Data.IFRS9Conf";
        public const string VBP_RMD_Data_IFRS9Data = "VPBANK.RMD.Data.IFRS9Data";
    }
}

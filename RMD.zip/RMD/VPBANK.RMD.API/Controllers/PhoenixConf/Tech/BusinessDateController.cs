﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Serilog;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.Tech;
using VPBANK.RMD.Data.PhoenixConf.Functions;

namespace VPBANK.RMD.API.Controllers.PhoenixConf.Tech
{
    [Authorize]
    public class BusinessDateController : BaseController
    {
        private readonly IAvaiableDateRepository _repository;

        public BusinessDateController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IAvaiableDateRepository repository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository)
        {
            _repository = repository;
        }

        [HttpGet(template: "{segment}")]
        public virtual ActionResult<IEnumerable<AvaiableDate>> GetCollectionAvaiableDate([FromRoute] string segment)
        {
            try
            {
                return Ok(_repository.FindCollectionAvaiDatesBySegment(segment).ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}
﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using System.Net.Http;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Tech;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.Tech
{
    public class ConfCfAssumptionController : ProcessController<PhoenixConfContext, ConfCfAssumption, decimal>
    {
        public ConfCfAssumptionController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, ConfCfAssumption, decimal> trackableRepository,
            IGenericRepository<PhoenixConfContext, ConfCfAssumption, decimal> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
        }
    }
}

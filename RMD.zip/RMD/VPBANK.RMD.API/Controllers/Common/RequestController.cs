﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using Serilog;
using System.Net;
using Newtonsoft.Json;
using AutoMapper;
using System.Net.Mime;
using System.Linq;
using System.Diagnostics.CodeAnalysis;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.API.Common.Helpers.Errors;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.API.Settings.Sections;

namespace VPBANK.RMD.API.Controllers.Common
{
    [Authorize]
    public class RequestController : BaseController
    {
        private readonly IUnitOfWork<PhoenixConfContext> _unitOfWork;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IApproveStatusRepository _reqStatusRepository;
        private readonly IApproveStatusService _reqStatusService;

        public RequestController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            IRequestObjectRepository repository,
            IApproveStatusRepository appStatusRepository,
            IApproveStatusService appStatusService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository)
        {
            _unitOfWork = unitOfWork;
            _reqRepository = repository;
            _reqStatusRepository = appStatusRepository;
            _reqStatusService = appStatusService;
        }

        /// <summary>
        /// Approve existing req for table data.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly approve request table data</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Approve([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // insert data
                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.SE011);

                var reqStatus = _reqStatusService.FindAllByFkRequestIdAndStatus(reqId, RequestStatus.APPROVED);
                if (reqStatus == null || reqStatus.Count > 0)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.SE011);

                if (req.Approve_Uri_Api.Equals(ApiKeys.API1, StringComparison.CurrentCultureIgnoreCase) ||
                   (req.Approve_Uri_Api.Equals(ApiKeys.API2, StringComparison.CurrentCultureIgnoreCase) && req.Type.Equals(RequestEvents.MANUAL_FILE)))
                {
                    #region API1 or manual_file

                    try
                    {
                        var jApproveEndPoint = string.Format($"{_configuration[nameof(AppSettings.ApiUri_Jav)]}{RequestSegment.END_POINT_APPROVE_REQ}", req.Pk_Id);
                        Log.Information($"Call API1_Approve: {jApproveEndPoint}");
                        Log.Information($"Req_Id: {req.Pk_Id}");
                        Log.Information($"ApproveStatusReq: {JsonConvert.SerializeObject(approveStatusReq, Formatting.Indented)}");
                        APIHelper.Post(jApproveEndPoint, GetToken(), JsonConvert.SerializeObject(approveStatusReq), MediaTypeNames.Application.Json, API_METHODS.POST);
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex.Message);
                        Log.Error(ex.StackTrace);
                        Log.Error(ex.InnerException?.Message);
                        if (ex is HttpErrorException)
                            throw;
                        else
                            throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
                    }
                    return Ok(req);

                    #endregion
                }
                else if (req.Approve_Uri_Api.Equals(ApiKeys.API2, StringComparison.CurrentCultureIgnoreCase) &&
                        (req.Type.Equals(RequestEvents.DB_SAVE) || req.Type.Equals(RequestEvents.DB_SAVE_EXTENTION)))
                {
                    #region API2 and (db_save || db_save_extention)

                    approveStatusReq.Id = 0;
                    approveStatusReq.Approver = GetUserPayload().Username;
                    approveStatusReq.End = true;
                    approveStatusReq.Status = RequestStatus.APPROVED;
                    approveStatusReq.Step = (int)RequestStep.APPROVED;
                    var result = HttpClientHelper.PostAsync($"{req.End_Point}/apr/{reqId}", GetToken(), approveStatusReq, MediaTypeNames.Application.Json);
                    var data = JsonConvert.DeserializeObject<BusinessException>(result, JsonSetting.ConfigFormat);
                    if (!string.IsNullOrEmpty(data?.Message))
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), data.Message);

                    return Ok(req);

                    #endregion
                }
                else
                {
                    #region Other cases

                    #endregion
                }

                return BadRequest(ModelState);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                var sqlException = _memoryCache.Get<string>(string.Format(CacheKeys.SqlExceptionCache, GetUserPayload().Username));
                if (!string.IsNullOrEmpty(sqlException))
                {
                    _memoryCache.Remove(string.Format(CacheKeys.SqlExceptionCache, GetUserPayload().Username));
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), sqlException);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessages.SE013);
            }
            finally
            {
            }
        }

        /// <summary>
        /// Cancel existing request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly cancel request</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Cancel([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // insert data
                _unitOfWork.BeginTransaction();
                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.SE011);

                var reqStatus = _reqStatusRepository.FindAllByFkRequestIdAndStatus(reqId, RequestStatus.APPROVED);
                if (reqStatus != null && reqStatus.Count > 0)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.SE011);

                // req status
                _reqStatusService.Insert(reqId, RequestStatus.CANCEL, RequestStep.CANCEL, $"{RequestStatus.CANCEL} by {GetUserPayload().Username}", GetUserPayload().Username);

                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(req.End_Point).Select(c => c.Username).Distinct().ToList();

                // results
                await _unitOfWork.SaveChangesAsync();

                // Send notification
                SendNotifications(ActionTypes.CANCEL, req.Payload_Clazz.Split(SpecificSystems.DOT).Last(), RequestStatus.CANCEL, req.End_Point, subscribers);

                _unitOfWork.Commit();
                return Ok(req);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Reject existing request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly reject request</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Reject([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // insert data
                _unitOfWork.BeginTransaction();
                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.SE011);

                var reqStatus = _reqStatusRepository.FindAllByFkRequestIdAndStatus(reqId, RequestStatus.APPROVED);
                if (reqStatus != null && reqStatus.Count > 0)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.SE011);

                // req status
                _reqStatusService.Insert(reqId, RequestStatus.REJECT, RequestStep.REJECT, $"{RequestStatus.REJECT} by {GetUserPayload().Username}", GetUserPayload().Username);

                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(req.End_Point).Select(c => c.Username).Distinct().ToList();

                // results
                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.Commit();

                // Send notification
                SendNotifications(ActionTypes.REJECT, req.Payload_Clazz.Split(SpecificSystems.DOT).Last(), RequestStatus.REJECT, req.End_Point, subscribers);

                return Ok(req);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Delete existing request.
        /// </summary>
        [HttpDelete(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Delete([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // insert data
                _unitOfWork.BeginTransaction();
                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.SE011);

                var reqStatus = _reqStatusRepository.FindAllByFkRequestIdAndStatus(reqId, RequestStatus.APPROVED);
                if (reqStatus != null && reqStatus.Count > 0)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessages.SE011);

                // req status
                _reqStatusService.Insert(reqId, RequestStatus.DELETED, RequestStep.DELETED, $"{RequestStatus.DELETED} by {GetUserPayload().Username}", GetUserPayload().Username);

                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(req.End_Point).Select(c => c.Username).Distinct().ToList();

                // results
                await _unitOfWork.SaveChangesAsync();

                // Send notification
                SendNotifications(ActionTypes.DELETE, req.Payload_Clazz.Split(SpecificSystems.DOT).Last(), RequestStatus.DELETED, req.End_Point, subscribers);

                _unitOfWork.Commit();
                return Ok(req);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}
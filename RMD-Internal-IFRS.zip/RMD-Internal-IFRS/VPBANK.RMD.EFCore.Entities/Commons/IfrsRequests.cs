﻿using System;
using System.ComponentModel.DataAnnotations;

namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public class IfrsRequests
    {
        public int? Pk_Id { get; set; }
        public int Flow_Execution_Id { get; set; }
        public int Task_Execution_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        [MaxLength]
        public byte[] Request_Details { get; set; }
        public string Obj_Class { get; set; }
        public string Req_Type { get; set; }
        public string Uri_Base_Approve { get; set; }
        public string End_Point { get; set; }
        public string Created_By { get; set; }
        public DateTime Created_Time { get; set; }
    }
}

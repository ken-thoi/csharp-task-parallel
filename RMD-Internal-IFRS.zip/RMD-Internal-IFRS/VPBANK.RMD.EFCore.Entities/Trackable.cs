﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;
using TrackableEntities.Common.Core;

namespace VPBANK.RMD.EFCore.Entities
{
    public abstract class Trackable : ITrackable, IMergeable
    {
        [NotMapped]
        [JsonIgnore]
        public TrackingState TrackingState { get; set; } = TrackingState.Unchanged;

        [NotMapped]
        [JsonIgnore]
        public ICollection<string> ModifiedProperties { get; set; } = new List<string>();

        [NotMapped]
        [JsonIgnore]
        public Guid EntityIdentifier { get; set; } = Guid.NewGuid();
    }
}

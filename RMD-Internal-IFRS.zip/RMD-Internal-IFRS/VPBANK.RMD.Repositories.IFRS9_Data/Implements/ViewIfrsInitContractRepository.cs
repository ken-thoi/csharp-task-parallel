﻿using Microsoft.Extensions.Caching.Distributed;
using Serilog;
using System;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class ViewIfrsInitContractRepository : Repository<IFRS9_DataContext, ViewIfrsInitContract, long>, IViewIfrsInitContractRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public ViewIfrsInitContractRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, ViewIfrsInitContract, long> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public ViewIfrsInitContract FindILLPCustomerListByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                return TrackableRepository
                           .QueryableFromSqlRaw($"SELECT c.* FROM Core.view_IFRS_INIT_Contract AS c WHERE c.Customer_Id = '{customerId}' AND c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'")
                           .AsEnumerable()
                           .FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }
    }
}

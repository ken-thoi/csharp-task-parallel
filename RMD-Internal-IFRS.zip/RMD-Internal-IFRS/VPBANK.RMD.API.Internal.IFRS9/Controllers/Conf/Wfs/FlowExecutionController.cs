﻿using System.Net.Http;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net;
using System;
using Serilog;
using System.Linq;
using Newtonsoft.Json;
using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.IFRS9_Conf.DataTransferObjects.Wfs;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Wfs;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Wfs
{
    public class FlowExecutionController : TrackingController<IFRS9_ConfContext, FlowExecution, int>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> _genTaskRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;
        private readonly IFlowService _flowService;
        private readonly IFlowExecutionRepository _flowExecutionRepository;
        private readonly IFlowStepExecutionService _flowStepExecutionService;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> _mpAccountBusinessUnitRepository;

        public FlowExecutionController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, FlowExecution, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> genTaskRepository,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,
            IFlowService flowService,
            IFlowExecutionRepository flowExecutionRepository,
            IFlowStepExecutionService flowStepExecutionService,
            IGenericRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> mpAccountBusinessUnitRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genTaskRepository = genTaskRepository;
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;
            _flowService = flowService;
            _flowExecutionRepository = flowExecutionRepository;
            _flowStepExecutionService = flowStepExecutionService;
            _mpAccountBusinessUnitRepository = mpAccountBusinessUnitRepository;
        }

        /// <summary>
        /// Execute flow_1 (Data_Validation).
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="flowActionTypeId">Execute (1) | Resume (6) | Continue (20) | Finish (21)</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost(template: "{flowActionTypeId}")]
        public virtual async Task<ActionResult<FlowExecution>> FlowExecutionProcess([FromRoute] int flowActionTypeId, [FromBody] FlowExecutionDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                // execution flow
                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                var results = await _flowStepExecutionService.FlowExecutionProcessAsync(flowActionTypeId, data, user, GetBusinessUnitDataRolesFromHeader(), GetToken());
                var msg = results.Item1;
                var flowExecution = results.Item2;

                // error, invalid
                if (!string.IsNullOrEmpty(msg) || flowExecution == null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                #region call job

                var flowStepExecutions = _genFlowStepExecutionRepository
                    .Queryable()
                    .Where(x => x.Fk_Flow_Execution_Id == flowExecution.Pk_Id)
                    .ToList();

                if (flowExecution != null && flowExecution.Flow_Execution_Status.Equals(Workflow_Status_Code.EXECUTING, StringComparison.CurrentCultureIgnoreCase) && 
                    flowStepExecutions != null && flowStepExecutions.Any())
                {
                    // Call_Init (flow_1), Staging (flow_2)
                    var flowStepExec_Ifrs_First = flowStepExecutions.Where(x => x.Is_First_Task).FirstOrDefault();
                    var flowStepExec_Ifrs_Stag = flowStepExecutions.Where(x => !string.IsNullOrEmpty(x.Task_Status_Condition) && x.Task_Status_Condition.Equals(Workflow_Status_Code.COMPELTED, StringComparison.CurrentCultureIgnoreCase) &&
                                                                               x.Is_End_Task).FirstOrDefault();
                    var flowStepExec_Ifrs_Pllp = flowStepExecutions.Where(x => x.Fk_Current_Task_Step_Id == flowStepExec_Ifrs_First.Fk_Next_Task_Step_Id).FirstOrDefault();

                    if (flowStepExec_Ifrs_First != null && flowStepExec_Ifrs_Stag != null && flowStepExec_Ifrs_Pllp != null)
                    {
                        var task_Ifrs_First = _genTaskRepository.Find(flowStepExec_Ifrs_First.Fk_Current_Task_Step_Id);
                        var task_CallIfrs_Stag = _genTaskRepository.Find(flowStepExec_Ifrs_Stag.Fk_Current_Task_Step_Id);
                        var task_CallIfrs_Pllp = _genTaskRepository.Find(flowStepExec_Ifrs_Pllp.Fk_Current_Task_Step_Id);

                        var batchEngineExecutionDto = new BatchEngineExecutionDto
                        {
                            batchJobInitId = task_Ifrs_First.Linked_Job_Id ?? 0,
                            batchJobStagId = task_CallIfrs_Stag.Linked_Job_Id ?? 0,
                            batchJobIfrsPllpId = task_CallIfrs_Pllp.Linked_Job_Id ?? 0,
                            businessDate = flowExecution.Business_Date.AddHours(-7),
                            approach = "SBV",
                            entityCode = task_Ifrs_First.Entity_Code,
                            scenarioId = task_Ifrs_First.Scenario_Id,
                            versionId = task_Ifrs_First.Version_Id,

                            flowId = flowExecution.Fk_Flow_Id,
                            flowStepExecutionInitId = flowStepExec_Ifrs_First.Pk_Id,
                            flowStepExecutionStagId = flowStepExec_Ifrs_Stag.Pk_Id,
                            flowStepExecutionStagLstId = flowStepExec_Ifrs_Pllp.Pk_Id
                        };

                        var linked_BatchJobId = 0;
                        if (task_Ifrs_First.Linked_Job_Id.HasValue) linked_BatchJobId = task_Ifrs_First.Linked_Job_Id.Value;
                        else if (task_CallIfrs_Stag.Linked_Job_Id.HasValue) linked_BatchJobId = task_CallIfrs_Stag.Linked_Job_Id.Value;
                        else if (task_CallIfrs_Pllp.Linked_Job_Id.HasValue) linked_BatchJobId = task_CallIfrs_Pllp.Linked_Job_Id.Value;
                        else { Console.WriteLine(string.Empty); }

                        if (linked_BatchJobId > 0)
                        {
                            var uri_call_ifrs_to_job = string.Format($"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_EXECUTION_BATCH_JOB}", linked_BatchJobId);
                            Log.Information($"Call: {uri_call_ifrs_to_job}, Batch_Job_Id: {linked_BatchJobId}");
                            Log.Information($"Batch_Engine_Execution param: {JsonConvert.SerializeObject(batchEngineExecutionDto, Formatting.Indented)}");

                            // run call batch_job
                            APIHelper.PostAsString(uri_call_ifrs_to_job, GetToken(), JsonConvert.SerializeObject(batchEngineExecutionDto), MediaTypeNames.Application.Json, API_METHODS.POST);
                        }
                    }
                }

                #endregion

                // results
                return CreatedAtAction(nameof(FlowExecutionProcess), new { flowExecution.Pk_Id }, flowExecution);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Finish flow_2 (ECL_Calculation) on staging task. (only finish staging action)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="flowActionTypeId">Finish (21)</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        [HttpPost(template: "{flowActionTypeId}")]
        public virtual async Task<ActionResult<FlowExecution>> EclCalculationFinish([FromRoute] int flowActionTypeId, [FromBody] FlowExecutionEclCalcDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                // If task status <> 'Ready to Execute', click on this button=> Error message
                var flowStepExecution = _genFlowStepExecutionRepository.Find(data.Fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase) ||
                    flowStepExecution.Task_Status.Equals(Workflow_Status_Code.REJECTED, StringComparison.CurrentCultureIgnoreCase))
                {
                    // execution flow
                    var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                    var results = await _flowStepExecutionService.FlowEclCalculationFinishTaskStaging(flowActionTypeId, data, user, GetBusinessUnitDataRolesFromHeader(), GetToken());
                    var msg = results.Item1;
                    var flowExecution = results.Item2;

                    // error, invalid
                    if (!string.IsNullOrEmpty(msg) || flowExecution == null)
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                    #region call job

                    var staging_FlowTaskExecution = flowStepExecution;

                    if (flowExecution != null && flowExecution.Flow_Execution_Status.Equals(Workflow_Status_Code.EXECUTING, StringComparison.CurrentCultureIgnoreCase) && 
                        staging_FlowTaskExecution != null && staging_FlowTaskExecution.Fk_Next_Task_Step_Id.HasValue)
                    {
                        var task_CallIfrs_Pllp = _genTaskRepository.Find(staging_FlowTaskExecution.Fk_Next_Task_Step_Id.Value);

                        if (task_CallIfrs_Pllp != null)
                        {
                            var batchEngineExecutionDto = new BatchEngineExecutionDto
                            {
                                batchJobInitId = 0,
                                batchJobStagId = 0,
                                batchJobIfrsPllpId = task_CallIfrs_Pllp.Linked_Job_Id ?? 0,
                                businessDate = flowExecution.Business_Date.AddHours(-7),
                                approach = "SBV",
                                entityCode = task_CallIfrs_Pllp.Entity_Code,
                                scenarioId = task_CallIfrs_Pllp.Scenario_Id,
                                versionId = task_CallIfrs_Pllp.Version_Id,

                                flowId = flowExecution.Fk_Flow_Id,
                                flowStepExecutionInitId = 0,
                                flowStepExecutionStagId = 0,
                                flowStepExecutionStagLstId = staging_FlowTaskExecution.Pk_Id
                            };

                            if (batchEngineExecutionDto.batchJobIfrsPllpId != 0)
                            {
                                var uri_call_ifrs_to_job = string.Format($"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_EXECUTION_BATCH_JOB}", batchEngineExecutionDto.batchJobIfrsPllpId);
                                Log.Information($"Call: {uri_call_ifrs_to_job}, Batch_Job_Id: {batchEngineExecutionDto.batchJobIfrsPllpId}");
                                Log.Information($"Batch_Engine_Execution param: {JsonConvert.SerializeObject(batchEngineExecutionDto, Formatting.Indented)}");

                                // run call batch_job
                                APIHelper.PostAsString(uri_call_ifrs_to_job, GetToken(), JsonConvert.SerializeObject(batchEngineExecutionDto), MediaTypeNames.Application.Json, API_METHODS.POST);
                            }
                        }
                    }

                    #endregion

                    // results
                    return CreatedAtAction(nameof(EclCalculationFinish), new { flowExecution.Pk_Id }, flowExecution);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Finish flow_2 (ECL_Calculation) on edit task. (only finish task edit)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="flowActionTypeId">Finish (21)</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        [HttpPost(template: "{flowActionTypeId}")]
        public virtual async Task<ActionResult<FlowExecution>> EclCalculationFinishTaskEdit([FromRoute] int flowActionTypeId, [FromBody] FlowExecutionEclCalcDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                // If task status <> 'Ready to Execute', click on this button=> Error message
                var flowStepExecution = _genFlowStepExecutionRepository.Find(data.Fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase) ||
                    flowStepExecution.Task_Status.Equals(Workflow_Status_Code.REJECTED, StringComparison.CurrentCultureIgnoreCase))
                {
                    // execution flow
                    var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                    var results = await _flowStepExecutionService.FlowEclCalculationFinishTaskCustomerList(flowActionTypeId, data, user, GetBusinessUnitDataRolesFromHeader(), GetToken());
                    var msg = results.Item1;
                    var flowExecution = results.Item2;

                    // error, invalid
                    if (!string.IsNullOrEmpty(msg) || flowExecution == null)
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                    // results
                    return CreatedAtAction(nameof(EclCalculationFinishTaskEdit), new { flowExecution.Pk_Id }, flowExecution);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Finish flow_2 (ECL_Calculation) on Cashflow task. (only finish task ILLP Cashflow)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="flowActionTypeId">Finish (21)</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        [HttpPost(template: "{flowActionTypeId}")]
        public virtual async Task<ActionResult<FlowExecution>> EclCalculationFinishTaskCashflow([FromRoute] int flowActionTypeId, [FromBody] FlowExecutionEclCalcDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                // If task status <> 'Ready to Execute', click on this button=> Error message
                var flowStepExecution = _genFlowStepExecutionRepository.Find(data.Fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                {
                    // execution flow
                    var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                    var results = await _flowStepExecutionService.EclCalculationFinishTaskCashflow(flowActionTypeId, data, user, GetBusinessUnitDataRolesFromHeader(), GetToken());
                    var msg = results.Item1;
                    var flowExecution = results.Item2;

                    // error, invalid
                    if (!string.IsNullOrEmpty(msg) || flowExecution == null)
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                    // results
                    return CreatedAtAction(nameof(EclCalculationFinishTaskCashflow), new { flowExecution.Pk_Id }, flowExecution);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Finish flow_2 (ECL_Calculation) on ECL result task. (only finish task ECL result)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="flowActionTypeId">Finish (21)</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        [HttpPost(template: "{flowActionTypeId}")]
        public virtual async Task<ActionResult<FlowExecution>> EclCalculationFinishTaskEclResult([FromRoute] int flowActionTypeId, [FromBody] FlowExecutionEclCalcDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                // If task status <> 'Ready to Execute', click on this button=> Error message
                var flowStepExecution = _genFlowStepExecutionRepository.Find(data.Fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase) ||
                    flowStepExecution.Task_Status.Equals(Workflow_Status_Code.REJECTED, StringComparison.CurrentCultureIgnoreCase))
                {
                    // execution flow
                    var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                    var results = await _flowStepExecutionService.EclCalculationFinishTaskEclResult(flowActionTypeId, data, user, GetBusinessUnitDataRolesFromHeader(), GetToken());
                    var msg = results.Item1;
                    var flowExecution = results.Item2;

                    // error, invalid
                    if (!string.IsNullOrEmpty(msg) || flowExecution == null)
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                    // results
                    return CreatedAtAction(nameof(EclCalculationFinishTaskEclResult), new { flowExecution.Pk_Id }, flowExecution);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Back to CF flow_2 (ECL_Calculation) on ECL result task. (only back task ECL result)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="flowActionTypeId">Back (10)</param>
        /// <param name="data"></param>
        /// <returns>A newly created object</returns>
        [HttpPost(template: "{flowActionTypeId}")]
        public virtual async Task<ActionResult<FlowExecution>> EclCalculationBackTaskEclResult([FromRoute] int flowActionTypeId, [FromBody] FlowExecutionEclCalcDto data)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || data == null)
                    return BadRequest(ModelState);

                // If task status <> 'Ready to Execute', click on this button=> Error message
                var flowStepExecution = _genFlowStepExecutionRepository.Find(data.Fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                {
                    // execution flow
                    var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                    var results = await _flowStepExecutionService.EclCalculationBackTaskEclResult(flowActionTypeId, data, user, GetBusinessUnitDataRolesFromHeader(), GetToken());
                    var msg = results.Item1;
                    var flowExecution = results.Item2;

                    // error, invalid
                    if (!string.IsNullOrEmpty(msg) || flowExecution == null)
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                    // results
                    return CreatedAtAction(nameof(EclCalculationBackTaskEclResult), new { flowExecution.Pk_Id }, flowExecution);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_LU_Validation", Schema = "BCL")]
    public class ConfLuValidation : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Validation_Type_Id { get; set; }
        public string Validation_Rule { get; set; }
        public string Validation_Source { get; set; }
        public string Validation_Description { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

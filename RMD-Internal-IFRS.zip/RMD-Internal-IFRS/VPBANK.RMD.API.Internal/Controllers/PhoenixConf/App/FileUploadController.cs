﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using Serilog;
using System.Net;
using System.Collections.Generic;
using AutoMapper;
using Newtonsoft.Json;
using System.Net.Mime;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.API.Settings.Sections;
using VPBANK.RMD.Utils.Common.Remote.FTP;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Services.Auth.Interfaces;
using System.Dynamic;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.App
{
    [Authorize]
    public class FileUploadController : BaseController
    {
        private readonly RequestHandler _requestHandler;
        private readonly IUnitOfWork<PhoenixConfContext> _unitOfWork;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IFTPConfigRepository _ftpConfigRepository;

        public FileUploadController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            RequestHandler requestHandler,
            IUnitOfWork<PhoenixConfContext> unitOfWork,
            IRequestObjectRepository reqRepository,
            IApproveStatusService reqStatusService,
            IFTPConfigRepository ftpConfigRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService)
        {
            _requestHandler = requestHandler;
            _unitOfWork = unitOfWork;
            _reqRepository = reqRepository;
            _reqStatusService = reqStatusService;
            _ftpConfigRepository = ftpConfigRepository;
        }

        /// <summary>
        /// Create new or updated request for upload files.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="fileUpload"></param>
        /// <returns>A newly created or updated request upload files</returns>
        [HttpPost, HttpPut]
        public virtual async Task<IActionResult> SendReq([Required][NotNull][FromBody] DataReq<FileUploadReq> fileUpload)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fileUpload == null || fileUpload.Entity == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.SE011);

                // insert data
                _unitOfWork.BeginTransaction();
                var req = new RequestObject
                {
                    Pk_Id = fileUpload.Id,
                    Username = GetUserPayload().Username,
                    Payload = null,
                    Payload_Clazz = RequestSegment.FILE_UPLOAD_CLASS,                                                               //Payload_Clazz = typeof(FileUploadReq).FullName?.ToString(),
                    Type = RequestEvents.MANUAL_FILE,
                    End_Point = $"{_configuration[$"{nameof(AppSettings.Properties)}:{nameof(Properties.API1)}"]}{RequestSegment.END_POINT_APPROVE_FILE_UPLOAD}",        //End_Point = Request.GetDisplayUrl(),
                    Comment = fileUpload.Comment,
                    Created_Dt = DateTime.Now,
                    Approve_Uri_Api = nameof(Properties.API1)
                };
                _reqRepository.Insert(req);
                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.Commit();

                // results
                return Ok(req);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Update existing request for upload files.
        /// Update PAYLOAD for request object from API 1
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="fileUpload"></param>
        /// <returns>A newly created request upload files</returns>
        [AllowAnonymous]
        [HttpPut(template: "{reqId}")]
        public virtual async Task<IActionResult> UpdReq([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] DataReq<FileUploadReq> fileUpload)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (fileUpload.Id == 0 || reqId != fileUpload.Id || fileUpload == null || fileUpload.Entity == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.SE011);

                // insert data
                _unitOfWork.BeginTransaction();
                var result = await _reqRepository.FindAsync(fileUpload.Id);
                if (result == null)
                {
                    _unitOfWork.Rollback();
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.SE011);
                }

                // get payload from api java
                var data = _mapper.Map<IEnumerable<FileUploadReq>, List<FileUploadInfo>>(fileUpload.Entity);
                var payload = APIHelper.Post($"{_configuration[$"{nameof(AppSettings.Properties)}:{nameof(Properties.API1)}"]}{RequestSegment.PAYLOAD_SERIALIZE}", GetToken(), JsonConvert.SerializeObject(data), MediaTypeNames.Application.Json, API_METHODS.POST);

                // update data
                result.Payload = payload;
                _reqRepository.Update(result);

                // req status
                _reqStatusService.Insert(result.Pk_Id, RequestStatus.PENDING, RequestStep.PENDING, fileUpload.Comment, GetUserPayload().Username);

                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(RequestSegment.END_POINT_APPROVE_FILE_UPLOAD).Select(c => c.Username).Distinct().ToList();
                // send noti
                SendNotifications(ActionTypes.UPLOAD, nameof(FileUploadReq), RequestStatus.PENDING, RequestSegment.END_POINT_APPROVE_FILE_UPLOAD, subscribers, new ExpandoObject());

                // results
                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.Commit();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Approve existing files upload request.
        /// Transfer file using FTP service
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly approve request upload files</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> AprReq([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            // get source remote
            var setting = FtpInfoSetting.GetFtpSetting(_configuration);
            var srcRemote = new FtpRemoteFileSystem(setting);
            srcRemote.Connect();
            srcRemote.SetRootAsWorkingDirectory();

            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // insert data
                _unitOfWork.BeginTransaction();
                var req = await _reqRepository.FindAsync(reqId);
                if (req == null)
                    throw new HttpErrorException(HttpStatusCode.NotFound, nameof(HttpStatusCode.NotFound), ErrorMessages.SE011);

                // get list files, detech from java api
                var uri = string.Format($"{_configuration[$"{nameof(AppSettings.Properties)}:{nameof(Properties.API1)}"]}{RequestSegment.PAYLOAD_DESERIALIZE}", reqId);
                var infoFiles = JsonConvert.DeserializeObject<List<FileUploadInfo>>(APIHelper.Get(uri, GetToken()));

                foreach (var info in infoFiles)
                {
                    var localPath = $"{Constants.WWWROOT}\\{info.path}\\{info.filename}";
                    var remotePath = $"{info.path}\\{info.filename}";
                    srcRemote.DownloadFile(localPath, remotePath);

                    FtpRemoteFileSystem tagRemote = null;
                    try
                    {
                        var systemCode = info.targetServer;
                        var reqPath = info.path;

                        var ftpConfigTarget = _ftpConfigRepository.FindByTargetServer(systemCode);
                        if (ftpConfigTarget == null)
                            throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000));

                        // new connect
                        setting.Host = ftpConfigTarget.Ftp_Address;
                        //setting.Port = ftpConfigTarget.Port;
                        setting.Username = ftpConfigTarget.Ftp_User;
                        setting.Password = ftpConfigTarget.Ftp_Password;
                        setting.Username = ftpConfigTarget.Ftp_User;
                        tagRemote = new FtpRemoteFileSystem(setting);

                        tagRemote.Connect();
                        tagRemote.SetRootAsWorkingDirectory();

                        // remote new target server file
                        var remotePathTarget = $"{ftpConfigTarget.Upload_Folder}\\{info.filename}";
                        tagRemote.UploadFile(localPath, remotePathTarget);
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex.Message);
                        Log.Error(ex.StackTrace);
                        tagRemote.Disconnect();
                        tagRemote.Dispose();
                        continue;
                    }
                }

                // req status
                _reqStatusService.Insert(req.Pk_Id, RequestStatus.APPROVED, RequestStep.APPROVED, null, GetUserPayload().Username);

                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(RequestSegment.END_POINT_APPROVE_FILE_UPLOAD).Select(c => c.Username).Distinct().ToList();
                // send noti
                SendNotifications(ActionTypes.UPLOAD, nameof(FileUploadInfo), RequestStatus.APPROVED, RequestSegment.END_POINT_APPROVE_FILE_UPLOAD, subscribers, new ExpandoObject());

                // results
                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.Commit();
                return Ok(req);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
                srcRemote.Disconnect();
                srcRemote.Dispose();
            }
        }
    }
}
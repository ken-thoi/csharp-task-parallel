﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Core
{
    public class IfrsPLLPResultRepository : QueryRepository<IFRS9_ConfContext, IfrsPLLPResult>, IIfrsPLLPResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public IfrsPLLPResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, IfrsPLLPResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<IfrsPLLPResult> FindAllContractByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                return QueryableRepository
                    .QueryableSql($"exec Core.Get_IFRS_PLLP_Detail '{businessDate.ToString(DefFormats.DATE_FORMAT)}', '{customerId}'")
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

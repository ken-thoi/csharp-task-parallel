﻿using VPBANK.RMD.API.Common.Middlewares;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using AutoMapper;
using System.Net.Http;
using System.Threading.Tasks;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Tech;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using Microsoft.EntityFrameworkCore.Internal;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.Tech
{
    public class ConfFilCeController : TrackingController<PhoenixConfContext, ConfFilCe, decimal>
    {
        public ConfFilCeController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, ConfFilCe, decimal> trackableRepository,
            IGenericRepository<PhoenixConfContext, ConfFilCe, decimal> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// Get all data by table name.
        /// </summary>
        /// <remarks>
        /// Here is a sample overight method generic controller.
        /// </remarks>
        /// <param name="table"></param>
        /// <returns></returns>
        [HttpGet("{table}")]
        public virtual async Task<ActionResult<IEnumerable<ConfFilCe>>> FindByTable([FromRoute] string table)
        {
            try
            {
                var entities = await _genericRepository
                    .Query()
                    .Where(c => c.Table_Name.Equals(table, StringComparison.CurrentCultureIgnoreCase))
                    .SelectAsync();

                if (!entities.AsEnumerable().Any())
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                return Ok(entities);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

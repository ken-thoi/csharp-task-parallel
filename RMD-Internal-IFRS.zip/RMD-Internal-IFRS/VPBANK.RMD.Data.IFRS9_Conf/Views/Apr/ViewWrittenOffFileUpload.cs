﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.WF
{
    [Table("View_Written_Off_File_Upload", Schema = "Apr")]
    public class ViewWrittenOffFileUpload : EntityBase<long>
    {
        [Key]
        public override long Pk_Id { get; set; }

        public string File_Convention_Name { get; set; }
        public string Flow_Name { get; set; }

        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }
        public int Fk_Written_Off_File_Id { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Business_Date { get; set; }
        public string Uploaded_File_Name { get; set; }
        public string Latest_Upload_By { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime Latest_Upload_Date { get; set; }

        public string Status { get; set; }
        public string Calculator { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime Start_Date { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? End_Date { get; set; }
    }
}

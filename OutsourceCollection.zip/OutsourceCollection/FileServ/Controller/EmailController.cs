﻿using Entities;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace FileServ.Controller
{
    public static class EmailController
    {
        public static void SendEmail(Email_Queue email)
        {
            string procedureName = "[FileServ].[Email_Queue_INS]";
            List<SqlParameter> listParam = new List<SqlParameter>();
            listParam.Add(new SqlParameter("@pv_From_Mail", email.From_Mail));
            listParam.Add(new SqlParameter("@pv_Mail_To", email.Mail_To));
            listParam.Add(new SqlParameter("@pv_OriginMessageID", email.OriginMessageID));
            listParam.Add(new SqlParameter("@pv_Mail_CC", Utils.UtilFunction.CheckDBValueNull(email.Mail_CC)));
            listParam.Add(new SqlParameter("@pv_Mail_BCC", Utils.UtilFunction.CheckDBValueNull(email.Mail_BCC)));
            listParam.Add(new SqlParameter("@pv_Subject", email.Subject));
            listParam.Add(new SqlParameter("@pv_Content", email.Content));
            Utils.SqlHelper.ExecuteNonQuery(procedureName, listParam.ToArray());
        }

    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core
{
    [Table("IFRS_Contract_WO", Schema = "Core")]
    public class IfrsContractWo : EntityBase<long>
    {
        [Key]
        public override long Pk_Id { get; set; }
        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Qtrr_Segment { get; set; }
        public string Product_Group { get; set; }
        public string Contract_No { get; set; }
        public string Company { get; set; }
        public string Gl { get; set; }

        public decimal Amount_Lcy { get; set; }
        public string Wo_Type { get; set; }
        public DateTime Created_Time { get; set; }
    }
}
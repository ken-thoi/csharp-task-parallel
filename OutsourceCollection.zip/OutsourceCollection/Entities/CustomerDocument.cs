﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class CustomerDocument
    {
        public int Id { get; set; }
        public int FK_Source { get; set; }
        public string CustomerName { get; set; }
        public string ContractNumber { get; set; }
        public string FilePackageName { get; set; }
        public string DocumentID { get; set; }
        public CustomerDocumentStatus Status { get; set; }
        public bool NeedReExcuted { get; set; }
        public bool IgnoreErrorFile { get; set; } = false;
        public DateTime ExcutedAt { get; set; }
        public int Priority { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDatetime { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDatetime { get; set; }
    }


    public enum CustomerDocumentStatus
    {
        Waitting = 10,
        Downloading = 20,
        SearchDocumentError = 22,
        DownloadingError = 25,
        Downloaded = 30,
        NotFoundAnyFile = 35,
        FileUploadCustom = 40
    }
}

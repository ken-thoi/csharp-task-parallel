﻿using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.Services.Auth.Implements
{
    public class ViewUserRoleService : IViewUserRoleService
    {
        private readonly IUnitOfWork<AuthContext> _unitOfWork;
        private readonly IViewUserRoleRepository _viewUserRoleRepository;

        public ViewUserRoleService(IUnitOfWork<AuthContext> unitOfWork, IViewUserRoleRepository viewUserRoleRepository)
        {
            _unitOfWork = unitOfWork;
            _viewUserRoleRepository = viewUserRoleRepository;
        }
    }
}

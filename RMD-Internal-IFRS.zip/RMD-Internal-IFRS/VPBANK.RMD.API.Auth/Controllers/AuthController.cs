﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using AutoMapper;
using Serilog;
using System.Net;
using System.Net.Http;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Security.Claims;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Extensions;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Security.SRAJose;
using VPBANK.RMD.API.Settings.Sections;
using VPBANK.RMD.Utils.Security.Models;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.DataTransferObjects;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.BCL;

namespace VPBANK.RMD.API.Auth.Controllers
{
    public class AuthController : BaseController
    {
        private readonly IUserRepository _userRepository;
        private readonly IViewUserRoleRepository _viewUserRoleRepository;
        private readonly IMpAccountBusinessUnitRepository _mpAccountBusinessUnitRepository;

        public AuthController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUserRepository userRepository,
            IViewUserRoleRepository viewUserRoleRepository,

            IMpAccountBusinessUnitRepository mpAccountBusinessUnitRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService)
        {
            this._userRepository = userRepository;
            this._viewUserRoleRepository = viewUserRoleRepository;

            this._mpAccountBusinessUnitRepository = mpAccountBusinessUnitRepository;
        }

        #region JWT - Jose SRA

        /// <summary>
        /// Build token when login
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Token([FromBody] UserAuthDto model)
        {
            try
            {
                // check valid
                if (!ModelState.IsValid || model == null || string.IsNullOrEmpty(model.Username))
                    throw new HttpErrorException(HttpStatusCode.Unauthorized, nameof(HttpStatusCode.Unauthorized), ErrorMessages.SE402);

                var user = await _userRepository.FindByUserNameAndIsDeletedAndStatusAsync(model.Username, false, UserStatusConstant.ACTIVE);
                if (user != null && !string.IsNullOrEmpty(user.Username))
                {
                    var userRole = await _viewUserRoleRepository.FindByUserNameAsync(user.Username);
                    var payload = new UserPayload
                    {
                        Id = user.Pk_Id,
                        Username = user.Username,
                        Email = user.Email,
                        DefaultRole = userRole == null || string.IsNullOrEmpty(userRole.Data_Role) ? string.Empty : userRole.Data_Role,
                        DataRole = userRole == null || string.IsNullOrEmpty(userRole.Data_Role) ? string.Empty : userRole.Data_Role,
                        FunctionRole = userRole == null || string.IsNullOrEmpty(userRole.Function_Role) ? string.Empty : userRole.Function_Role,
                        ComponentRole = userRole == null || string.IsNullOrEmpty(userRole.Component_Role) ? string.Empty : userRole.Component_Role,
                        Status = user.Status
                    };

                    #region Business_Unit

                    var businessUserRoles = _mpAccountBusinessUnitRepository.FindAllByUsernameAndStatus(user.Username, UserStatusDetailsConstant.ACTIVE);
                    if (businessUserRoles != null && businessUserRoles.Any())
                    {
                        var buIds = businessUserRoles.Select(c => $"{BUSINESS_UNIT_CODES.BUSINESS_UNIT_EXTENTION}{c.Fk_Business_Unit_Id}").ToList();
                        var businessRoles = string.Join(SpecificSystems.SEMICOLON, buIds.ToArray());

                        if (!string.IsNullOrEmpty(businessRoles))
                        {
                            if (!string.IsNullOrEmpty(payload.DefaultRole))
                                payload.DefaultRole += (SpecificSystems.SEMICOLON + businessRoles);
                            if (!string.IsNullOrEmpty(payload.DataRole))
                                payload.DataRole += (SpecificSystems.SEMICOLON + businessRoles);
                        }
                    }

                    #endregion

                    #region Log_info

                    Log.Information($"JWT_Payload: {JsonConvert.SerializeObject(payload, Formatting.Indented)}");

                    #endregion

                    _userService.UpdateLastLoginByUserName(user.Username);
                    SessionHelper.Set(HttpContext.Session, SESSION_KEYS.USER_PAYLOAD, payload);

                    var jwtConfig = JWTSetting.GetJwtSection(_configuration);
                    Log.Information($"JWT_Config: {JsonConvert.SerializeObject(jwtConfig, Formatting.Indented)}");
                    var privateKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtConfig.PrivateKey);
                    Log.Information($"JWT_Key_Path: {privateKeyPath}");
                    var privateKey = System.IO.File.ReadAllText(privateKeyPath);
                    Log.Information($"Private_Key: {privateKey}");

                    var jwtToken = new JwtSraTokenBuilder()
                        .AddSubject(jwtConfig.Subject)
                        .AddIssuer(jwtConfig.Issuer)
                        .AddAudience(jwtConfig.Audience)
                        .AddExpiry(jwtConfig.ExpirationInMins)
                        .AddNotBefore(jwtConfig.NotBeforeInSeconds)
                        .AddClaims(new List<Claim>())
                        .Build();
                    Log.Information($"Jwt_Sra_Token_Builder: {JsonConvert.SerializeObject(jwtToken, Formatting.Indented)}");

                    // create new token
                    var token = TokenProducer.Token(payload, privateKey, jwtToken);

                    // set token into cookie
                    SetTokenCookie(jwtConfig.JwtTokenCookie, token);

                    // results
                    return Ok(new
                    {
                        username = model.Username,
                        token,
                        expires = DateTime.Now.AddMinutes(jwtConfig.ExpirationInMins)
                    });
                }

                throw new HttpErrorException(HttpStatusCode.Unauthorized, nameof(HttpStatusCode.Unauthorized), ErrorMessages.SE402);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw new HttpErrorException(HttpStatusCode.Unauthorized, nameof(HttpStatusCode.Unauthorized), ErrorMessages.SE402);
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Refresh token if expiry
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> RefreshToken()
        {
            var user = await _userRepository.FindAsync(1);
            return Ok(user);
        }

        /// <summary>
        /// Revoke token when refresh
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize]
        public IActionResult RevokeToken([FromBody] RevokeTokenDto model)
        {
            // accept token from request body or cookie
            var token = model.Token ?? Request.Cookies["refreshToken"];

            if (token != null)
                return NotFound(new { message = "Token not found" });

            return Ok(new { message = "Token revoked" });
        }

        #endregion

        #region helper methods

        private void SetTokenCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            };
            Response.Cookies.Append("refreshToken", token, cookieOptions);
        }

        #endregion
    }
}
﻿using AutoMapper;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using System;

namespace VPBANK.RMD.API.Common.Helpers.Mapping
{
    public class ModelMappingProfile : Profile
    {
        /// <summary>
        /// Create automap mapping profiles
        /// </summary>
        public ModelMappingProfile()
        {
            // Add as many of these lines as you need to map your objects
            CreateMap<FileUploadInfo, FileUploadReq>()
                .ForMember(dest => dest.Filename, opts => opts.MapFrom(src => src.filename))
                .ForMember(dest => dest.Path, opts => opts.MapFrom(src => src.path))
                .ForMember(dest => dest.HostInfo, opts => opts.MapFrom(src => src.hostInfo))
                .ForMember(dest => dest.FileType, opts => opts.MapFrom(src => src.fileType))
                .ForMember(dest => dest.TargetServer, opts => opts.MapFrom(src => src.targetServer))
                .ForMember(dest => dest.DocumentType, opts => opts.Ignore());
            CreateMap<FileUploadReq, FileUploadInfo>()
                .ForMember(dest => dest.filename, opts => opts.MapFrom(src => src.Filename))
                .ForMember(dest => dest.path, opts => opts.MapFrom(src => src.Path))
                .ForMember(dest => dest.hostInfo, opts => opts.MapFrom(src => src.HostInfo))
                .ForMember(dest => dest.fileType, opts => opts.MapFrom(src => src.FileType))
                .ForMember(dest => dest.targetServer, opts => opts.MapFrom(src => src.TargetServer))
                .ForMember(dest => dest.size, opts => opts.Ignore())
                .ForMember(dest => dest.updateDt, opts => opts.Ignore());

            CreateMap<User, UserArchived>()
                .ForMember(dest => dest.Pk_Id, opts => opts.MapFrom(src => src.Pk_Id))
                .ForMember(dest => dest.Username, opts => opts.MapFrom(src => src.Username))
                .ForMember(dest => dest.Display_Name, opts => opts.MapFrom(src => src.Display_Name))
                .ForMember(dest => dest.Password, opts => opts.MapFrom(src => src.Password))
                .ForMember(dest => dest.Super_Role, opts => opts.MapFrom(src => src.Super_Role))
                .ForMember(dest => dest.Type, opts => opts.MapFrom(src => src.Type))
                .ForMember(dest => dest.Status, opts => opts.MapFrom(src => src.Status))
                .ForMember(dest => dest.Is_Deleted, opts => opts.MapFrom(src => src.Is_Deleted))
                .ForMember(dest => dest.Created_Date, opts => opts.MapFrom(src => src.Created_Date))
                .ForMember(dest => dest.Create_User, opts => opts.MapFrom(src => src.Create_User))
                .ForMember(dest => dest.Modified_By, opts => opts.MapFrom(src => src.Modified_By))
                .ForMember(dest => dest.Email, opts => opts.MapFrom(src => src.Email))
                .ForMember(dest => dest.Phone, opts => opts.MapFrom(src => src.Phone))
                .ForMember(dest => dest.Last_Login, opts => opts.MapFrom(src => src.Last_Login))
                .ForMember(dest => dest.Modified_Date, opts => opts.Ignore());

            //CreateMap<AnswerSetViewModel, AnswerSet>()
            //    .ForMember(dest => dest.Date, opts => opts.MapFrom(src => src.DateAnswersSubmitted))
            //    .ForMember(dest => dest.Id, opts => opts.MapFrom(src => src.AnswerSetId))
            //    .ForMember(dest => dest.Answers, opts => opts.MapFrom(src => src.AnswerSetAnswers))
            //    .ForMember(dest => dest.IsActive, opts => opts.Ignore());
            //CreateMap<AnswerSet, AnswerSetViewModel>()
            //    .ForMember(dest => dest.DateAnswersSubmitted, opts => opts.MapFrom(src => src.Date))
            //    .ForMember(dest => dest.AnswerSetId, opts => opts.MapFrom(src => src.Id))
            //    .ForMember(dest => dest.AnswerSetAnswers, opts => opts.MapFrom(src => src.Answers));

            //CreateMissingTypeMaps = true;
        }
    }
}

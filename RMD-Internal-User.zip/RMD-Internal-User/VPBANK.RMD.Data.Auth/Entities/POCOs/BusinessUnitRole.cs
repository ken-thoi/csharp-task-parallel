﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("Data_Business_Unit", Schema = "Core")]
    public class BusinessUnitRole : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }
    }
}

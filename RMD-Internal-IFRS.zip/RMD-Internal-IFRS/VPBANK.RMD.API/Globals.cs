﻿namespace VPBANK.RMD.API
{
    public static class Globals
    {
    }
}

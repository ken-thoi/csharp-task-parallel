﻿using System.Collections.Generic;

namespace VPBANK.RMD.Services.Auth.DataContracts
{
    public class UserRoleMappingDto
    {
        public string Username { get; set; }
        public List<int> FkDataRole { get; set; }
        public List<string> FunctionRole { get; set; }
        public List<string> ComponentRole { get; set; }
    }
}

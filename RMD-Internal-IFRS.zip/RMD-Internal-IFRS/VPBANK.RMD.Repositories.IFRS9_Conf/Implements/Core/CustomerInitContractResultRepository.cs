﻿using Microsoft.Extensions.Caching.Distributed;
using Serilog;
using System;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Core
{
    public class CustomerInitContractResultRepository : QueryRepository<IFRS9_ConfContext, CustomerInitContractResult>, ICustomerInitContractResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public CustomerInitContractResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, CustomerInitContractResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public CustomerInitContractResult FindCustomerInitContractResultByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                var query = $"exec Core.Get_Customer_INIT_Contract '{customerId}', '{businessDate.ToString(DefFormats.DATE_FORMAT)}'";
                return QueryableRepository.QueryableSql(query).AsEnumerable().ToList().FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Mp_Sector_group", Schema = "Core")]
    public class MpSectorGroup : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public decimal Sector { get; set; }
        public string Sector_Group { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

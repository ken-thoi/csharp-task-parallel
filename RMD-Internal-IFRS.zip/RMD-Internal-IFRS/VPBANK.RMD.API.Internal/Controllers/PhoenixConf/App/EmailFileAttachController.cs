﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using VPBANK.RMD.EFCore.Entities.Commons;
using System;
using Serilog;
using VPBANK.RMD.API.Common.Middlewares;
using System.Net;
using VPBANK.RMD.Utils.Common;
using System.Linq;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Services.Auth.Interfaces;


namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.App
{
    public class EmailFileAttachController : ProcessController<PhoenixConfContext, EmailFileAttach, int>
    {
        public EmailFileAttachController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, EmailFileAttach, int> trackableRepository,
            IGenericRepository<PhoenixConfContext, EmailFileAttach, int> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiGroupCode()
        {
            try
            {
                var results = new List<SelectedItem>
                {
                    new SelectedItem
                    {
                        Key = "Collection",
                        Val = "Collection"
                    }
                };

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiFileType()
        {
            try
            {
                var results = new List<SelectedItem>
                {
                    new SelectedItem
                    {
                        Key = "xlsx",
                        Val = "xlsx"
                    }
                };

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiDataSourceType()
        {
            try
            {
                var results = new List<SelectedItem>
                {
                    new SelectedItem
                    {
                        Key = "SYSTEM_REPORT",
                        Val = "SYSTEM_REPORT"
                    }
                };

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiReportType()
        {
            try
            {
                var results = _genericRepository
                    .Queryable()
                    .AsEnumerable()
                    .Select(c => new SelectedItem
                    {
                        Key = c.Pk_Id,
                        Val = c.File_Name
                    })
                    .Distinct()
                    .ToList();

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpGet("{emailAttachIds}")]
        public async virtual Task<ActionResult<IEnumerable<CallbackObjectRes>>> FindReportTypesById([NotNull][FromRoute] string emailAttachIds)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || string.IsNullOrEmpty(emailAttachIds))
                    return BadRequest(ModelState);

                var results = string.Empty;
                var ids = emailAttachIds.Split(SpecificSystems.SEMICOLON);
                foreach (var id in ids)
                {
                    var emailTempt = await _genericRepository.FindAsync(Convert.ToInt32(id));
                    if (emailTempt == null)
                        throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);
                    if (string.IsNullOrEmpty(results))
                        results = emailTempt.File_Name;
                    else if (!string.IsNullOrEmpty(emailTempt.File_Name))
                        results = results + SpecificSystems.SEMICOLON + emailTempt.File_Name;
                }

                return Ok(new List<CallbackObjectRes> { new CallbackObjectRes { controlId = "collection_Email_File_Attach_Name", value = results } });
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}
﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Mp_Group_Segment", Schema = "Core")]
    public class MpGroupSegment : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Group_Segment { get; set; }
        public string Qtrr_Segment { get; set; }
        public DateTime? Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

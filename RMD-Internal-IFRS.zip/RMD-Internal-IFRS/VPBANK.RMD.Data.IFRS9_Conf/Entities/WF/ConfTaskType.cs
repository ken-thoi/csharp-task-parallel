﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Conf_Screen_Task", Schema = "WF")]
    public class ConfScreenTask : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Screen_Code { get; set; }

        public string Screen_Name { get; set; }

        public string Description { get; set; }

        public bool Is_Deleted { get; set; }
    }
}

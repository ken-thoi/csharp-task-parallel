﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class DocumentTypeController
    {
        private static Dictionary<int, Dictionary<string, DocumentType>> DictDocumentType = new Dictionary<int, Dictionary<string, DocumentType>>();
        public static Dictionary<int, Dictionary<int, DocumentType>> DictDocumentTypeById = new Dictionary<int, Dictionary<int, DocumentType>>();
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void LoadDocumentType()
        {
            logger.Info("------ START: Loading Document Type ------");
            string command = "[FileServ].[DocumentType_SEL]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command);
            foreach (DataRow dr in dt.Rows)
            {
                var item = Utils.UtilFunction.CreateItemFromRow<DocumentType>(dr);
                if(DictDocumentType.ContainsKey(item.FK_Source_Id))
                {
                    DictDocumentType[item.FK_Source_Id].Add(item.DocumentName, item);
                }
                else
                {
                    Dictionary<string, DocumentType> tmp = new Dictionary<string, DocumentType>();
                    tmp.Add(item.DocumentName, item);
                    DictDocumentType.Add(item.FK_Source_Id, tmp);
                }

                if (DictDocumentTypeById.ContainsKey(item.FK_Source_Id))
                {
                    DictDocumentTypeById[item.FK_Source_Id].Add(item.Id, item);
                }
                else
                {
                    Dictionary<int, DocumentType> tmp = new Dictionary<int, DocumentType>();
                    tmp.Add(item.Id, item);
                    DictDocumentTypeById.Add(item.FK_Source_Id, tmp);
                }
            }
            logger.Info("------ END: Loading Document Type ------");
        }

        public static DocumentType GetDocumentType(DocumentType docType)
        {
            docType.DocumentName = docType.DocumentName.Trim();
            if (DictDocumentType.ContainsKey(docType.FK_Source_Id) && DictDocumentType[docType.FK_Source_Id].ContainsKey(docType.DocumentName))
            {
                return DictDocumentType[docType.FK_Source_Id][docType.DocumentName];
            }
            else
            {
                docType.AllowToDownload = true;
                var item = DocumentTypeINS(docType);
                if (DictDocumentType.ContainsKey(item.FK_Source_Id))
                {
                    DictDocumentType[item.FK_Source_Id].Add(item.DocumentName, item);
                }
                else
                {
                    Dictionary<string, DocumentType> tmp1 = new Dictionary<string, DocumentType>();
                    tmp1.Add(item.DocumentName, item);
                    DictDocumentType.Add(item.FK_Source_Id, tmp1);
                }

                if (DictDocumentTypeById.ContainsKey(item.FK_Source_Id))
                {
                    DictDocumentTypeById[item.FK_Source_Id].Add(item.Id, item);
                }
                else
                {
                    Dictionary<int, DocumentType> tmp1 = new Dictionary<int, DocumentType>();
                    tmp1.Add(item.Id, item);
                    DictDocumentTypeById.Add(item.FK_Source_Id, tmp1);
                }
                return item;
            }
        }

        private static DocumentType DocumentTypeINS(DocumentType docType)
        {
            string command = "[FileServ].[DocumentType_INS]";
            List<SqlParameter> lstParam = new List<SqlParameter>();
            lstParam.Add(new SqlParameter("@pv_FK_Source_Id", docType.FK_Source_Id));
            lstParam.Add(new SqlParameter("@pv_DocumentName", docType.DocumentName));
            lstParam.Add(new SqlParameter("@pv_DocumentDesc", Utils.UtilFunction.CheckDBValueNull(docType.DocumentDesc)));
            lstParam.Add(new SqlParameter("@pv_AllowToDownload", docType.AllowToDownload));
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, lstParam.ToArray());
            return Utils.UtilFunction.CreateItemFromRow<DocumentType>(dt.Rows[0]);
        }
    }
}

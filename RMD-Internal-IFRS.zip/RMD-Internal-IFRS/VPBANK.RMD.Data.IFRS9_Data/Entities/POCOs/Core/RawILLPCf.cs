﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core
{
    [Table("Raw_ILLP_CF", Schema = "Core")]
    public class RawIllpCf : EntityBase<decimal>
    {
        [Key]
        public override decimal Pk_Id { get; set; }
        public int Fk_Task_Exec_Id { get; set; }
        public string Customer_Id { get; set; }
        [MaxLength]
        public string Json_Data { get; set; }
    }
}
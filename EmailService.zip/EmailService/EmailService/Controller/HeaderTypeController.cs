﻿using EmailService.Entites;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EmailService.Controller
{
    public static class HeaderTypeController
    {
        private static Dictionary<string, int> HearderMap = new Dictionary<string, int>();
        public static void LoadHeaderType()
        {
            string command = "[dbo].[Header_Type_SEL]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command);
            foreach(DataRow dr in dt.Rows)
            {
                var hdt = Utils.UtilFunction.CreateItemFromRow<Header_Type>(dr);
                HearderMap.Add(hdt.HeaderName, hdt.Id);
            }
        }

        public static int GetHeaderId(string headerName)
        {
            headerName = headerName.Trim();
            if (string.IsNullOrEmpty(headerName))
                throw new ArgumentException("headerName can not be empty"); 

            if (HearderMap.ContainsKey(headerName))
                return HearderMap[headerName];
            else
            {
                List<SqlParameter> listParam = new List<SqlParameter>();
                var id = Convert.ToInt32(Utils.SqlHelper.ExecuteScalar("[dbo].[Header_Type_INS]", new SqlParameter[] { new SqlParameter("@pv_HeaderName", headerName) }));
                HearderMap.Add(headerName, id);
                return id;
            }
        }
    }
}

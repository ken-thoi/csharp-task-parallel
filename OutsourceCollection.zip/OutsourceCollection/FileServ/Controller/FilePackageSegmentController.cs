﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class FilePackageSegmentController
    {
        public static void InsertFilePackageSegment(List<FilePackageSegment> listFilePackageSegment)
        {
            DataTable dt = Utils.UtilFunction.ToDataTable(listFilePackageSegment);
            dt.TableName = "[FileServ].[FilePackageSegment]";
            Utils.SqlHelper.ExcuteBulkInsert(dt);
        }

        public static void DeleteFilePackageSegment(int FK_FilePackage_Id)
        {
            Utils.SqlHelper.ExecuteNonQuery("[FileServ].[FilePackageSegment_DEL]", new SqlParameter[] { new SqlParameter("@pv_FK_FilePackage_Id", FK_FilePackage_Id) });
        }

        public static List<FilePackageSegment> SelectFilePackageSegment(int FK_FilePackage_Id)
        {
            List<FilePackageSegment> list = new List<FilePackageSegment>();
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, "[FileServ].[FilePackageSegment_SEL]", new SqlParameter[] { new SqlParameter("@pv_FK_FilePackage_Id", FK_FilePackage_Id) });
            foreach(DataRow dr in dt.Rows)
            {
                list.Add(Utils.UtilFunction.CreateItemFromRow<FilePackageSegment>(dr));
            }

            return list;
        }
    }
}

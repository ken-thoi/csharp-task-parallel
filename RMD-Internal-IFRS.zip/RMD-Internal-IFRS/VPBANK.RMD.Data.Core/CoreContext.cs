﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore.Entities.SchemaInfos;

namespace VPBANK.RMD.Data.Core
{
    public partial class CoreContext : DbContext
    {
        private IHttpContextAccessor _httpContextAccessor;

        public CoreContext(DbContextOptions<CoreContext> options, IHttpContextAccessor httpContextAccessor) : base(options)
        {
            this._httpContextAccessor = httpContextAccessor;
        }

        #region DbQuery<T> is for Stored Procedure

        public DbQuery<TableInfo> TableInfos { get; set; }
        public DbQuery<ColumnInfo> ColumnInfos { get; set; }

        #endregion

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            var now = DateTime.Now;
            var username = this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "VBP_MRD_Administrator";

            // Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            // For each entity we will set the Audit properties
            if (entries != null && entries.Any())
            {
                foreach (var entry in entries)
                {
                    try
                    {
                        var createdBy = entry.CurrentValues[nameof(Auditable.Created_By)];
                        var createdTime = entry.CurrentValues[nameof(Auditable.Created_Time)];

                        // If the entity state is Added let's set the CreatedTime and CreatedBy properties
                        if (entry.State == EntityState.Added)
                        {
                            entry.CurrentValues[nameof(Auditable.Created_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Created_Time)] = now;
                        }

                        var updatedBy = entry.CurrentValues[nameof(Auditable.Updated_By)];
                        var updatedTime = entry.CurrentValues[nameof(Auditable.Updated_Time)];

                        // In any case we always want to set the properties UpdatedTime and ModifiedBy
                        if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                        {
                            entry.CurrentValues[nameof(Auditable.Updated_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Updated_Time)] = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Warning("ENTRY NOT IS AUDITABLE");
                        Log.Warning(ex.Message);
                        Log.Warning(ex.StackTrace);
                    }
                }
            }

            // After we set all the needed properties we call the base implementation of SaveChanges to actually save our entities in the database
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var now = DateTime.Now;
            var username = this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "VBP_MRD_Administrator";

            // Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            // For each entity we will set the Audit properties
            if (entries != null && entries.Any())
            {
                foreach (var entry in entries)
                {
                    try
                    {
                        var createdBy = entry.CurrentValues[nameof(Auditable.Created_By)];
                        var createdTime = entry.CurrentValues[nameof(Auditable.Created_Time)];

                        // If the entity state is Added let's set the CreatedTime and CreatedBy properties
                        if (entry.State == EntityState.Added)
                        {
                            entry.CurrentValues[nameof(Auditable.Created_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Created_Time)] = now;
                        }

                        var updatedBy = entry.CurrentValues[nameof(Auditable.Updated_By)];
                        var updatedTime = entry.CurrentValues[nameof(Auditable.Updated_Time)];

                        // In any case we always want to set the properties UpdatedTime and ModifiedBy
                        if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                        {
                            entry.CurrentValues[nameof(Auditable.Updated_By)] = username;
                            entry.CurrentValues[nameof(Auditable.Updated_Time)] = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Warning("ENTRY NOT IS AUDITABLE");
                        Log.Warning(ex.Message);
                        Log.Warning(ex.StackTrace);
                    }
                }
            }

            // After we set all the needed properties we call the base implementation of SaveChangesAsync to actually save our entities in the database
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}

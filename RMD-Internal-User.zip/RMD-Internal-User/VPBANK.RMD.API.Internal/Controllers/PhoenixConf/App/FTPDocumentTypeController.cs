﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using Microsoft.AspNetCore.Mvc;
using VPBANK.RMD.EFCore.Entities.Commons;
using System.Collections.Generic;
using VPBANK.RMD.API.Common.Middlewares;
using System.Net;
using VPBANK.RMD.Utils.Common;
using Serilog;
using System;
using VPBANK.RMD.API.Common.Controllers;
using System.Linq;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using AutoMapper;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.App
{
    public class FTPDocumentTypeController : GenericController<PhoenixConfContext, FTPDocumentType, int>
    {
        public FTPDocumentTypeController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, FTPDocumentType, int> trackableRepository,
            IGenericRepository<PhoenixConfContext, FTPDocumentType, int> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        [HttpGet("{sourceSystem}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> FindBySourceSystem([Required][NotNull][FromRoute] string sourceSystem)
        {
            try
            {
                var entities = _genericRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => !string.IsNullOrEmpty(sourceSystem) && c.Source_System.Equals(sourceSystem, StringComparison.CurrentCultureIgnoreCase) && c.Is_Active)
                    .ToList();

                if (entities == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                var result = new List<SelectedItem>();
                foreach (var item in entities)
                    result.Add(new SelectedItem { Key = item.Doc_Key, Val = item.Doc_Val });

                return Ok(result.OrderBy(c => c.Key).ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
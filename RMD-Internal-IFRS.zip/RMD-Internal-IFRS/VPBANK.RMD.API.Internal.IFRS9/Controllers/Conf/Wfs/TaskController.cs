﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Serilog;
using TrackableEntities.Common.Core;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Common.Helpers.Errors;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Wfs;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Notification.Publisher;
using Task = VPBANK.RMD.Data.IFRS9_Conf.Entities.WF.Task;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Wfs
{
    public class TaskController : TrackingController<IFRS9_ConfContext, Task, int>
    {
        private readonly ITaskService _taskService;

        public TaskController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            ITaskService taskService,
            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, Task, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, Task, int> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _taskService = taskService;
        }

        /// <summary>
        /// Get Task to drop_box
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetTaskDropdownBox()
        {
            try
            {
                return Ok(_taskService.GetTasksDropdownBox(false));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public override async Task<ActionResult<PaginatedContentResults<Task>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                return await base.Query(paginatedParams);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Create new record.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="entity"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        public override async Task<ActionResult<Task>> Create([Required][NotNull][FromBody] Task entity)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                // set tracking state
                entity.TrackingState = TrackingState.Added;
                if (IFRS9_TASK_TYPE.TASK_JOB.Equals(entity.Task_Type, StringComparison.CurrentCultureIgnoreCase) && entity.Linked_Job_Id.HasValue)
                    entity.Action_Origin_Id = Convert.ToInt32(PROCESS_MONITORINGS_ACTION_ORIGIN.ENGINE_JOB);
                else
                    entity.Action_Origin_Id = null;

                // results
                return await base.Create(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Update exists record.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="pk_Id"></param>
        /// <param name="entity"></param>
        /// <returns>A newly updated object</returns>
        /// <response code="200">Returns OK</response>
        /// <response code="400">If the item is null</response>
        /// <response code="404">The item is not found</response>
        [HttpPut(template: "{pk_Id}")]
        public override async Task<ActionResult<Task>> Update([Required][NotNull][FromRoute] int pk_Id, [Required][NotNull][FromBody] Task entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null || entity.Pk_Id == 0)
                    return BadRequest(ModelState);

                // set tracking state
                entity.TrackingState = TrackingState.Modified;
                if (IFRS9_TASK_TYPE.TASK_JOB.Equals(entity.Task_Type, StringComparison.CurrentCultureIgnoreCase) && entity.Linked_Job_Id.HasValue)
                    entity.Action_Origin_Id = Convert.ToInt32(PROCESS_MONITORINGS_ACTION_ORIGIN.ENGINE_JOB);
                else
                    entity.Action_Origin_Id = null;

                // save
                _genericRepository.Update(entity);
                var result = await _unitOfWork.SaveChangesAsync();
                if (result == 0)
                    return BadRequest();

                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Delete task, update is_deleted = true
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpDelete(template: "{pk_Id}")]
        public override async Task<IActionResult> Delete([Required][NotNull][FromRoute] int pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (!await _genericRepository.ExistsAsync(pk_Id))
                    return NotFound();

                var task = _genericRepository.Find(pk_Id);
                if (task == null)
                    return NotFound();

                // check task in flow active or executing
                var results = _taskService.Validate(task);
                if (!string.IsNullOrEmpty(results.Item1))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), results.Item1);

                // delete
                task.Is_Deleted = true;
                _genericRepository.Update(task);
                _unitOfWork.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Validate for entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] TaskRequestable entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest();

                var results = _taskService.Validate(entity);
                if (results.Any())
                    return BadRequest(results);

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

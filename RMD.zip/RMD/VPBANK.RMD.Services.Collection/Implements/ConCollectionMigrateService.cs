﻿using VPBANK.RMD.Services.Collection.Interfaces;

namespace VPBANK.RMD.Services.Collection.Implements
{
    public class ConCollectionMigrateService : IConCollectionMigrateService
    {
        public ConCollectionMigrateService()
        {
        }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using VPBANK.RMD.EFCore.Entities.Commons;
using System.Collections.Generic;
using System.Net;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Common.Middlewares;
using System;
using Serilog;
using System.Linq;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using System.Web;
using VPBANK.RMD.API.Common.Helpers.Errors;
using VPBANK.RMD.Data.Collection.Views;
using VPBANK.RMD.Data.Collection;

namespace VPBANK.RMD.API.Controllers.PhoenixConf.App
{
    public class EmailTemptController : BaseReqController<PhoenixConfContext, EmailTempt, int>
    {
        private readonly IGenericRepository<CollectionContext, ViewCollectionEmail, int> _collectEmailRepository;

        public EmailTemptController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, EmailTempt, int> trackableRepository,
            IGenericRepository<PhoenixConfContext, EmailTempt, int> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository,

            IGenericRepository<CollectionContext, ViewCollectionEmail, int> collectEmailRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
            _collectEmailRepository = collectEmailRepository;
        }

        /// <summary>
        /// Find content email by group code
        /// </summary>
        /// <param name="groupCode"></param>
        /// <returns></returns>
        [HttpGet("{groupCode}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> FindByGroupCode([Required][NotNull][FromRoute] string groupCode)
        {
            try
            {
                var entities = _genericRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Group_Code.Equals(groupCode, StringComparison.CurrentCultureIgnoreCase))
                    .ToList();

                if (entities == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                var results = new List<SelectedItem>();
                foreach (var item in entities)
                {
                    results.Add(new SelectedItem
                    {
                        Key = item.Pk_Id,
                        Val = item.Email_Tempt_Name
                    });
                }

                return Ok(results.OrderBy(c => c.Key).ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find content email by name
        /// </summary>
        /// <param name="emailTemptId"></param>
        /// <returns></returns>
        [HttpGet("{emailTemptId}")]
        public async virtual Task<ActionResult<IEnumerable<CallbackObjectRes>>> FindContentEmail([NotNull][FromRoute] int emailTemptId)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || emailTemptId == 0)
                    return BadRequest(ModelState);

                var emailTempt = await _genericRepository.FindAsync(emailTemptId);
                if (emailTempt == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                var contentEncode = HttpUtility.JavaScriptStringEncode(emailTempt.Content_Html, false);
                return Ok(new List<CallbackObjectRes> { new CallbackObjectRes { controlId = "email_Tempt_Content", value = contentEncode } });
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Validate
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] EmailTemptDto entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null || string.IsNullOrEmpty(entity.Group_Code))
                    return BadRequest();

                var colleOutEmail = _collectEmailRepository
                    .Queryable()
                    .FirstOrDefault(m => m.Fk_Email_Tempt_Id == entity.Pk_Id);

                if (colleOutEmail != null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessages.EM142);
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
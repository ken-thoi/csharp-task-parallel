﻿namespace VPBANK.RMD.Utils.AuditLog.Models
{
    public static class AuditElasticSearchs
    {
        public const string FIELD_TIMESTAMP = "timestamp";
        public const string FIELD_RECEIVER_TIME = "recvTime";
        public const string FIELD_RECEIVER = "receiver";
    }
}

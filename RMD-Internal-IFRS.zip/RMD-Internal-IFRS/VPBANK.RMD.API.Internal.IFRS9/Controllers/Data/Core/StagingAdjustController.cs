﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using Serilog;
using System.Net;
using System.Linq;
using System.Dynamic;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Services.IFRS9_Data.DataTransferObjects;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Data.Core
{
    public class StagingAdjustController : QueryController<IFRS9_DataContext, StagingAdjust, int>
    {
        private readonly IStagingAdjustService _stagingAdjustService;
        private readonly IIfrsStagingResultRepository _ifrsStagingResultRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;

        public StagingAdjustController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_DataContext> unitOfWork,
            ITrackableRepository<IFRS9_DataContext, StagingAdjust, int> trackableRepository,
            IGenericRepository<IFRS9_DataContext, StagingAdjust, int> genericRepository,

            IStagingAdjustService stagingAdjustService,
            IIfrsStagingResultRepository ifrsStagingResultRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _stagingAdjustService = stagingAdjustService;
            _ifrsStagingResultRepository = ifrsStagingResultRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;
        }

        /// <summary>
        /// Find all Staging by customer_id, business_date
        /// </summary>
        /// <param name="dataStagingDto"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<List<IfrsStagingResult>> FindAllStagingByCustomerId([NotNull][FromBody] StagingResultDto dataStagingDto)
        {
            try
            {
                if (!ModelState.IsValid || dataStagingDto == null || string.IsNullOrEmpty(dataStagingDto.Customer_Id) || dataStagingDto.Business_Date == null)
                    return BadRequest();

                var results = _ifrsStagingResultRepository.FindAllContractStagingByCustomerId(dataStagingDto.Customer_Id, dataStagingDto.Business_Date).ToList();

                return results;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Create new or update request.
        /// Send request (Request_action = 6)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly created or updated request</returns>
        [HttpPost]
        public async virtual Task<ActionResult<Requests>> Req([NotNull][FromBody] IfrsDataReq<StagingAdjust> req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || !req.Entities.Any())
                    return BadRequest(ModelState);

                var results = await _stagingAdjustService.SaveAsync(req, GetUserPayloadFromHeader().Username);
                var msg = results.Item1;
                var request = results.Item2;

                // error, invalid
                if (!string.IsNullOrEmpty(msg) || request == null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                try
                {
                    // send noti
                    var routerKey = "/api/vbp-rmd/v1.0/ifrs-staging-req";
                    // other data
                    dynamic other = new ExpandoObject();
                    other.Customer_Id = req.Customer_Id;
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.IFRS_STAGING, typeof(StagingAdjust).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.PENDING, routerKey, subscribers, other);
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    Log.Error(ex.StackTrace);
                    Log.Error(ex.InnerException?.Message);
                }

                // results
                return CreatedAtAction(nameof(Req), request);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Approve/Reject existed request.
        /// Approve (Request_action = 7)
        /// Reject (Request_action = 9)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly approved/rejected request</returns>
        [HttpPost]
        public async virtual Task<ActionResult<Requests>> Apr([NotNull][FromBody] IfrsDataApr req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || req.Request_Id == 0)
                    return BadRequest(ModelState);

                var data = new IfrsDataReq<StagingAdjust>
                {
                    Request_Id = req.Request_Id,
                    Fk_Flow_Execution_Id = req.Fk_Flow_Execution_Id,
                    Fk_Task_Execution_Id = req.Fk_Task_Execution_Id,
                    Business_Date = req.Business_Date,
                    Customer_Id = req.Customer_Id,
                    Request_Action = req.Request_Status.Equals(IfrsRequestStatus.APPROVED, StringComparison.CurrentCultureIgnoreCase) ? (int)ActionTypes.APPROVAL : (int)ActionTypes.REJECT,
                    Comments = req.Note_Approval
                };

                var results = await _stagingAdjustService.SaveAsync(data, GetUserPayloadFromHeader().Username);
                var msg = results.Item1;
                var request = results.Item2;

                // error, invalid
                if (!string.IsNullOrEmpty(msg) || request == null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                try
                {
                    // send noti
                    var routerKey = "/api/vbp-rmd/v1.0/ifrs-staging-req";
                    // other data
                    dynamic other = new ExpandoObject();
                    other.Customer_Id = req.Customer_Id;
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.IFRS_STAGING, typeof(StagingAdjust).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.APPROVED, routerKey, subscribers, other);
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    Log.Error(ex.StackTrace);
                    Log.Error(ex.InnerException?.Message);
                }

                // results
                return CreatedAtAction(nameof(Apr), request);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Validate
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <returns></returns>
        [HttpGet("{fk_Task_Execution_Id}")]
        public virtual IActionResult Validate([FromRoute] int fk_Task_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // check task completed
                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (taskExecution == null || taskExecution.Task_Status.Equals(Workflow_Status_Code.COMPELTED, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // results
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

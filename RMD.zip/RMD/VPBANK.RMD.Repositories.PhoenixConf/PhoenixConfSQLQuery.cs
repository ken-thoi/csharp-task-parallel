﻿namespace VPBANK.RMD.Repositories.PhoenixConf
{
    public static class PhoenixConfSQLQuery
    {
        public static readonly string EXEC_Collection_Send_Email = "EXECUTE Phoenix_Conf.tech.Collection_Send_Email @Business_Date, @in_Segment, @in_Os_Company";
    }
}

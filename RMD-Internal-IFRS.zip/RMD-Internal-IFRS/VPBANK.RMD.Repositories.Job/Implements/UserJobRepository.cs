﻿using System.Threading.Tasks;
using System;
using Serilog;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.Repositories.Job.Interfaces;
using VPBANK.RMD.Data.Job.Entities.POCOs;
using VPBANK.RMD.Data.Job;

namespace VPBANK.RMD.Repositories.Job.Implements
{
    public class UserJobRepository : Repository<JobContext, UserJob, decimal>, IUserJobRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly ILogger<UserJobRepository> _logger;
        protected readonly JobContext _context;

        public UserJobRepository(IDistributedCache distributedCache, ILogger<UserJobRepository> logger, ITrackableRepository<JobContext, UserJob, decimal> trackableRepository,
            JobContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _logger = logger;
            _context = context;
        }

        [Obsolete]
        public int SendNotifications(string routingKey, string messageType, List<string> receivers, string message)
        {
            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();

            try
            {
                Parallel.ForEach(receivers, receiver =>
                {
                    _context.Database.ExecuteSqlCommand($"EXEC App.Send_Notifi_By_Users '{routingKey}', '{messageType}', '{receiver}', '{message}'");
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            watch.Stop();

            Log.Information($"Execution time:{watch.ElapsedMilliseconds} milliseconds");
            return receivers.Count;
        }
    }
}

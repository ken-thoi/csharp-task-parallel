﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.Utils.Common.Expressions;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("User", Schema = "Core")]
    public class User : BaseEntity<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Username { get; set; }

        public string Display_Name { get; set; }

        public string Password { get; set; }

        public string Super_Role { get; set; }

        public string Type { get; set; }

        public string Status { get; set; }

        public string Is_Deleted { get; set; }

        public DateTime? Created_Date { get; set; }

        public string Create_User { get; set; }

        public DateTime? Modified_Date { get; set; }

        public string Modified_By { get; set; }

        [Display(Name = "Email")]
        [RegularExpression(RegularExpressions.EMAIL, ErrorMessage = "Please enter a valid email address.")]
        public string Email { get; set; }

        [Display(Name = "Phone")]
        [RegularExpression(RegularExpressions.PHONE_NUMBER, ErrorMessage = "Please enter a valid email address.")]
        public string Phone { get; set; }

        public DateTime? Last_Login { get; set; }
    }
}

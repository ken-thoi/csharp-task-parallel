﻿using System.Collections.Generic;
using VPBANK.RMD.Data.Job;
using VPBANK.RMD.Data.Job.Entities.POCOs;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.Job.Interfaces
{
    public interface IUserJobRepository : IRepository<JobContext, UserJob, decimal>
    {
        int SendNotifications(string routingKey, string messageType, List<string> receivers, string message);
    }
}

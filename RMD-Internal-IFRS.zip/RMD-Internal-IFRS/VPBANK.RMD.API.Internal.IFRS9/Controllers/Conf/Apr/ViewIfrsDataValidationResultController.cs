﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using Serilog;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Net;
using System.Linq;
using Newtonsoft.Json;
using System.Net.Mime;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.BCL;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.Data.IFRS9_Conf.Views.BCL;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Apr
{
    public class ViewIfrsDataValidationResultController : QueryController<IFRS9_ConfContext, ViewIfrsDataValidationResult, int>
    {
        private readonly RequestHandler _requestHandler;
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IRequestObjectService _reqService;
        private readonly IApproveStatusRepository _reqStatusRepository;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IMpAccountBusinessUnitService _service;

        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genericFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ViewMpValidationRight, int> _genericViewMpValidationRightRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfLuBusinessUnit, int> _genericConfLuBusinessUnitRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> _genericConfMpAccountBusinessUnitRepository;

        private readonly IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> _genTaskRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;

        private readonly IGenericRepository<PhoenixConfContext, ConfGloConfiguration, decimal> _genConfGloConfigurationRepository;

        public ViewIfrsDataValidationResultController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, ViewIfrsDataValidationResult, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, ViewIfrsDataValidationResult, int> genericRepository,

            RequestHandler requestHandler,
            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusRepository reqStatusRepository,
            IApproveStatusService appStaService,
            IMpAccountBusinessUnitService service,

            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genericFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, ViewMpValidationRight, int> genericViewMpValidationRightRepository,
            IGenericRepository<IFRS9_ConfContext, ConfLuBusinessUnit, int> genericConfLuBusinessUnitRepository,
            IGenericRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> genericConfMpAccountBusinessUnitRepository,

            IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> genTaskRepository,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,
            IGenericRepository<PhoenixConfContext, ConfGloConfiguration, decimal> genConfGloConfigurationRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;
            _reqRepository = reqRepository;
            _reqService = requestService;
            _reqStatusRepository = reqStatusRepository;
            _reqStatusService = appStaService;
            _service = service;

            _genericFlowExecutionRepository = genericFlowExecutionRepository;
            _genericViewMpValidationRightRepository = genericViewMpValidationRightRepository;
            _genericConfLuBusinessUnitRepository = genericConfLuBusinessUnitRepository;
            _genericConfMpAccountBusinessUnitRepository = genericConfMpAccountBusinessUnitRepository;

            _genTaskRepository = genTaskRepository;
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;

            _genConfGloConfigurationRepository = genConfGloConfigurationRepository;
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// </summary>
        /// <param name="fk_Flow_Execution_Id"></param>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost(template: "{fk_Flow_Execution_Id}")]
        public async Task<ActionResult<PaginatedContentResults<ViewIfrsDataValidationResult>>> QueryByFlowExecutionId([Required][NotNull][FromRoute] int fk_Flow_Execution_Id, [Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid || fk_Flow_Execution_Id == 0)
                    return BadRequest();

                var flowExecution = _genericFlowExecutionRepository.Find(fk_Flow_Execution_Id);
                if (flowExecution == null)
                    return NotFound();

                var query = $"Business_Date = '{flowExecution.Business_Date.ToString(DefFormats.DATE_FORMAT)}'";
                if (paginatedParams == null || string.IsNullOrEmpty(paginatedParams.FilterExpression))
                    paginatedParams.FilterExpression = query;
                else
                    paginatedParams.FilterExpression = $"{paginatedParams.FilterExpression} AND {query}";

                var results = BuildResults(paginatedParams);
                var total = results.Item1;
                var data = results.Item2;

                // get from conf_mapping_table
                var rules = _genericViewMpValidationRightRepository.Queryable().ToList();
                total = rules.Count;

                var res = new List<ViewIfrsDataValidationResult>();
                foreach (var rule in rules)
                {
                    var ruleFailed = data.Where(x => x.Validation_Rule.Equals(rule.Validation_Rule, StringComparison.CurrentCultureIgnoreCase)).SingleOrDefault();

                    res.Add(new ViewIfrsDataValidationResult
                    {
                        Pk_Id = rule.Pk_Id,
                        Flow_Name = ruleFailed == null ? "Data Validation" : ruleFailed.Flow_Name,
                        Fk_Business_Unit_Id = rule.Fk_Business_Unit_Id,
                        Fk_Lu_Validation_Id = rule.Fk_Lu_Validation_Id,
                        Fk_Lu_Upload_Id = rule.Fk_Lu_Manual_File_Id,
                        Start_Date = rule.Start_Date,
                        End_Date = rule.End_Date,

                        Validation_Rule = rule.Validation_Rule,

                        Validation_Source = rule.Validation_Source,
                        Validation_Description = rule.Validation_Description,
                        Business_Date = flowExecution.Business_Date,
                        Assign_Validation_Group = rule.Assign_Validation_Group,
                        Fail_Record = ruleFailed == null ? 0 : ruleFailed.Fail_Record,
                        Type_Name = rule.Fk_Validation_Type_Name
                    });
                }

                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                var buAsigneds = _userService.FindAllBusinessUnitIdByUsername(user.Username, UserStatusDetailsConstant.ACTIVE);
                if (user.Super_Role.Equals(UserPermissionConstant.NORMAL) && buAsigneds != null && buAsigneds.Any())
                {
                    res = res.Where(x => x.Fk_Business_Unit_Id.HasValue && buAsigneds.Contains(x.Fk_Business_Unit_Id.Value)).ToList();
                    total = res.Count();
                }

                // result
                dynamic result = await QueryDataAsync(total, res, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Download file Validation rules results by Excel(.xlsx, .xls)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="validation_Rule"></param>
        /// <param name="fail_Record"></param>
        /// <returns></returns>
        [HttpGet(template: "{fk_Task_Execution_Id}/validation-rule/{validation_Rule}/fail-records/{fail_Record}")]
        public async Task<IActionResult> DownloadValidationRuleResult([FromRoute] int fk_Task_Execution_Id, [FromRoute] string validation_Rule, [FromRoute] int fail_Record)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(validation_Rule))
                    return BadRequest();

                if (fail_Record == 0)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), "Number failed records cannot zero.");

                // check limit max row excel
                var gloCOnf = _genConfGloConfigurationRepository
                    .Queryable()
                    .Where(x => !string.IsNullOrEmpty(x.Param_Name) && x.Param_Name.Equals("Excel_Exp_Maximum_Limit"))
                    .SingleOrDefault();

                var excelExpMaxLimit = gloCOnf == null ? 1000 : Convert.ToInt32(gloCOnf.Param_Value);
                if (fail_Record > excelExpMaxLimit)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM0270);

                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);
                var task = await _genTaskRepository.FindAsync(taskExecution.Fk_Current_Task_Step_Id);

                //if (!taskExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE))
                //    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM027);

                var sbvExcelReport = new SbvExcelReport
                {
                    rptReport = "IFRS_VALD",
                    businessDate = flowExecution.Business_Date,
                    entityCode = task.Entity_Code,
                    approach = "SBV",
                    scenarioId = task.Scenario_Id,
                    versionId = task.Version_Id,
                    additionalParams = $"Field^\"{validation_Rule}\""
                };

                var api_1_report = $"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_SBV_REPORT}";
                Log.Information($"Call API1_adjust Batch, Job: {api_1_report}");
                Log.Information($"Batch_Engine_Execution adjust: {JsonConvert.SerializeObject(sbvExcelReport, Formatting.Indented)}");
                var results = APIHelper.PostAsString(api_1_report, GetToken(), JsonConvert.SerializeObject(sbvExcelReport), MediaTypeNames.Application.Json, API_METHODS.POST);
                Dictionary<string, List<dynamic>> data = JsonConvert.DeserializeObject<Dictionary<string, List<dynamic>>>(results);

                // recheck limit max row excel
                foreach (var item in data)
                    if (item.Value.Count > excelExpMaxLimit)
                        throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM0270);

                HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, $"{validation_Rule}_{flowExecution.Business_Date:yyyyMMdd}.xlsx");

                return Ok(data);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.AppEngines
{
    [Table("Engines", Schema = "App")]
    public class Engines : EntityBase<decimal>
    {
        [Key]
        public override decimal Pk_Id { get; set; }

        public string Engine_Code { get; set; }

        public string Engine_Name { get; set; }

        public string Engine_Desc { get; set; }

        public bool? Is_Active { get; set; }

        public int? Max_Exec_Time { get; set; }

        public string Entity_Code { get; set; }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Utils.Common.Assemblies;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.EFCore.Entities.SchemaInfos;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Tech;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Data.Auth.Entities.Views;
using VPBANK.RMD.Repositories.Auth.Implements;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Services.Auth.Implements;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.PhoenixData;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.Repositories.Collection.Interfaces;
using VPBANK.RMD.Repositories.Collection.Implements;
using VPBANK.RMD.Services.Collection.Interfaces;
using VPBANK.RMD.Services.Collection.Implements;
using VPBANK.RMD.Data.Collection.StoredProcedures;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Repositories.PhoenixConf.Implements.App;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.Tech;
using VPBANK.RMD.Repositories.PhoenixConf.Implements.Tech;
using VPBANK.RMD.Services.PhoenixConf.Implements.Tech;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.Tech;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.PhoenixConf.Implements.App;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.WebCore;
using VPBANK.RMD.Data.PhoenixConf.Views.WebCore;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.WebCore;
using VPBANK.RMD.Repositories.PhoenixConf.Implements.WebCore;
using VPBANK.RMD.Data.Collection.Views;
using VPBANK.RMD.Data.PhoenixConf.Functions;
using VPBANK.RMD.Data.PhoenixData.Entities.POCOs.Core;
using VPBANK.RMD.Repositories.PhoenixData.Interfaces.Core;
using VPBANK.RMD.Services.PhoenixData.Interfaces.Core;
using VPBANK.RMD.Services.PhoenixData.Implements.Core;
using VPBANK.RMD.Repositories.PhoenixData.Implements.Core;
using VPBANK.RMD.Repositories.PhoenixConf.Implements.Schema;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.Schema;
using VPBANK.RMD.Repositories.PhoenixData.Interfaces.Schema;
using VPBANK.RMD.Repositories.PhoenixData.Implements.Schema;
using VPBANK.RMD.Repositories.Collection.Interfaces.Schema;
using VPBANK.RMD.Repositories.Collection.Implements.Schema;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Schema;
using VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Schema;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces.Schema;
using VPBANK.RMD.Repositories.IFRS9_Data.Implements.Schema;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Core;

namespace VPBANK.RMD.API.Common.Features
{
    public static class DbContextConfigurator
    {
        internal static bool IsContextAdded { get; set; }

        public static IServiceCollection ConfigureBusinessFeatures(this IServiceCollection services, IConfiguration _configuration)
        {
            if (!IsContextAdded)
            {
                // Regix connection string
                services.AddDbContext<AuthContext>(c =>
                {
                    c.UseSqlServer(_configuration.GetConnectionString(nameof(AppSettings.ConnectionStrings.AuthConnection)), options =>
                    {
                        options.MigrationsAssembly(DefAssemblies.VBP_RMD_Data_Auth);
                    });
                });

                services.AddDbContext<PhoenixConfContext>(c =>
                {
                    c.UseSqlServer(_configuration.GetConnectionString(nameof(AppSettings.ConnectionStrings.PhoenixConfConnection)), options =>
                    {
                        options.MigrationsAssembly(DefAssemblies.VBP_RMD_Data_PhoenixConf);
                    });
                });

                services.AddDbContext<PhoenixDataContext>(c =>
                {
                    c.UseSqlServer(_configuration.GetConnectionString(nameof(AppSettings.ConnectionStrings.PhoenixDataConnection)), options =>
                    {
                        options.MigrationsAssembly(DefAssemblies.VBP_RMD_Data_PhoenixData);
                    });
                });

                services.AddDbContext<CollectionContext>(c =>
                {
                    c.UseSqlServer(_configuration.GetConnectionString(nameof(AppSettings.ConnectionStrings.CollectionConnection)), options =>
                    {
                        options.MigrationsAssembly(DefAssemblies.VBP_RMD_Data_Collection);
                    });
                });

                services.AddDbContext<IFRS9_ConfContext>(c =>
                {
                    c.UseSqlServer(_configuration.GetConnectionString(nameof(AppSettings.ConnectionStrings.IFRS9ConfConnection)), options =>
                    {
                        options.MigrationsAssembly(DefAssemblies.VBP_RMD_Data_IFRS9_Conf);
                    });
                });

                services.AddDbContext<IFRS9_DataContext>(c =>
                {
                    c.UseSqlServer(_configuration.GetConnectionString(nameof(AppSettings.ConnectionStrings.IFRS9DataConnection)), options =>
                    {
                        options.MigrationsAssembly(DefAssemblies.VBP_RMD_Data_IFRS9_Data);
                    });
                });

                services.AddConfigureContext()
                        .AddConfigureAuth()
                        .AddConfigurePhoenixConf()
                        .AddConfigurePhoenixData()
                        .AddConfigureCollection()
                        .AddConfigureIFRS9Conf()
                        .AddConfigureIFRS9Data();

                IsContextAdded = true;
            }

            return services;
        }

        private static IServiceCollection AddConfigureContext(this IServiceCollection services)
        {
            // Data Context
            services.AddScoped<DbContext, AuthContext>();
            services.AddScoped<DbContext, PhoenixConfContext>();
            services.AddScoped<DbContext, PhoenixDataContext>();
            services.AddScoped<DbContext, CollectionContext>();
            services.AddScoped<DbContext, IFRS9_ConfContext>();
            services.AddScoped<DbContext, IFRS9_DataContext>();

            // UnitOfWork
            services.AddScoped<IUnitOfWork<AuthContext>, UnitOfWork<AuthContext>>();
            services.AddScoped<IUnitOfWork<PhoenixConfContext>, UnitOfWork<PhoenixConfContext>>();
            services.AddScoped<IUnitOfWork<PhoenixDataContext>, UnitOfWork<PhoenixDataContext>>();
            services.AddScoped<IUnitOfWork<CollectionContext>, UnitOfWork<CollectionContext>>();
            services.AddScoped<IUnitOfWork<IFRS9_ConfContext>, UnitOfWork<IFRS9_ConfContext>>();
            services.AddScoped<IUnitOfWork<IFRS9_DataContext>, UnitOfWork<IFRS9_DataContext>>();

            // Generic repository, trackable, service pattern
            services.AddTransient(typeof(IDomainRepository<,,>), typeof(DomainRepository<,,>));
            services.AddTransient(typeof(ITrackableRepository<,,>), typeof(TrackableRepository<,,>));
            services.AddTransient(typeof(IGenericRepository<,,>), typeof(GenericRepository<,,>));

            // Queryable generic
            services.AddTransient(typeof(IQueryableRepository<,>), typeof(QueryableRepository<,>));

            return services;
        }

        private static IServiceCollection AddConfigureAuth(this IServiceCollection services)
        {
            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, BusinessUnitRole, int>), typeof(DomainRepository<AuthContext, BusinessUnitRole, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, BusinessUnitRole, int>), typeof(TrackableRepository<AuthContext, BusinessUnitRole, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, BusinessUnitRole, int>), typeof(GenericRepository<AuthContext, BusinessUnitRole, int>));
            services.AddScoped<IRoleService, RoleService>();

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, ComponentUserRole, int>), typeof(DomainRepository<AuthContext, ComponentUserRole, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, ComponentUserRole, int>), typeof(TrackableRepository<AuthContext, ComponentUserRole, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, ComponentUserRole, int>), typeof(GenericRepository<AuthContext, ComponentUserRole, int>));

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, DataPermission, int>), typeof(DomainRepository<AuthContext, DataPermission, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, DataPermission, int>), typeof(TrackableRepository<AuthContext, DataPermission, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, DataPermission, int>), typeof(GenericRepository<AuthContext, DataPermission, int>));

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, DataPermissionEngine, int>), typeof(DomainRepository<AuthContext, DataPermissionEngine, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, DataPermissionEngine, int>), typeof(TrackableRepository<AuthContext, DataPermissionEngine, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, DataPermissionEngine, int>), typeof(GenericRepository<AuthContext, DataPermissionEngine, int>));

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, DataPermissionEntity, int>), typeof(DomainRepository<AuthContext, DataPermissionEntity, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, DataPermissionEntity, int>), typeof(TrackableRepository<AuthContext, DataPermissionEntity, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, DataPermissionEntity, int>), typeof(GenericRepository<AuthContext, DataPermissionEntity, int>));

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, DataRole, int>), typeof(DomainRepository<AuthContext, DataRole, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, DataRole, int>), typeof(TrackableRepository<AuthContext, DataRole, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, DataRole, int>), typeof(GenericRepository<AuthContext, DataRole, int>));
            services.AddScoped<IRoleService, RoleService>();

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, DataRolePermission, int>), typeof(DomainRepository<AuthContext, DataRolePermission, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, DataRolePermission, int>), typeof(TrackableRepository<AuthContext, DataRolePermission, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, DataRolePermission, int>), typeof(GenericRepository<AuthContext, DataRolePermission, int>));

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, DataUserRole, int>), typeof(DomainRepository<AuthContext, DataUserRole, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, DataUserRole, int>), typeof(TrackableRepository<AuthContext, DataUserRole, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, DataUserRole, int>), typeof(GenericRepository<AuthContext, DataUserRole, int>));

            // 
            services.AddScoped(typeof(IDomainRepository<AuthContext, FunctionUserRole, int>), typeof(DomainRepository<AuthContext, FunctionUserRole, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, FunctionUserRole, int>), typeof(TrackableRepository<AuthContext, FunctionUserRole, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, FunctionUserRole, int>), typeof(GenericRepository<AuthContext, FunctionUserRole, int>));

            // User
            services.AddScoped(typeof(IDomainRepository<AuthContext, User, int>), typeof(DomainRepository<AuthContext, User, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, User, int>), typeof(TrackableRepository<AuthContext, User, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, User, int>), typeof(GenericRepository<AuthContext, User, int>));
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();

            // User_Archived
            services.AddScoped(typeof(IDomainRepository<AuthContext, UserArchived, int>), typeof(DomainRepository<AuthContext, UserArchived, int>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, UserArchived, int>), typeof(TrackableRepository<AuthContext, UserArchived, int>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, UserArchived, int>), typeof(GenericRepository<AuthContext, UserArchived, int>));
            services.AddScoped<IUserArchivedRepository, UserArchivedRepository>();

            // View_User_Role
            services.AddScoped(typeof(IDomainRepository<AuthContext, ViewUserRole, long>), typeof(DomainRepository<AuthContext, ViewUserRole, long>));
            services.AddScoped(typeof(ITrackableRepository<AuthContext, ViewUserRole, long>), typeof(TrackableRepository<AuthContext, ViewUserRole, long>));
            services.AddScoped(typeof(IGenericRepository<AuthContext, ViewUserRole, long>), typeof(GenericRepository<AuthContext, ViewUserRole, long>));
            services.AddScoped<IViewUserRoleRepository, ViewUserRoleRepository>();
            services.AddScoped<IViewUserRoleService, ViewUserRoleService>();

            return services;
        }

        private static IServiceCollection AddConfigurePhoenixConf(this IServiceCollection services)
        {
            #region INFORMATION SCHEMA

            services.AddScoped(typeof(IQueryableRepository<PhoenixConfContext, TableInfo>), typeof(QueryableRepository<PhoenixConfContext, TableInfo>));
            services.AddScoped<IConfTableRepository, ConfTableRepository>();
            services.AddScoped(typeof(IQueryableRepository<PhoenixConfContext, ColumnInfo>), typeof(QueryableRepository<PhoenixConfContext, ColumnInfo>));
            services.AddScoped<IConfColumnRepository, ConfColumnRepository>();

            #endregion

            #region APP

            // ApproveStatus
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ApproveStatus, int>), typeof(DomainRepository<PhoenixConfContext, ApproveStatus, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ApproveStatus, int>), typeof(TrackableRepository<PhoenixConfContext, ApproveStatus, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ApproveStatus, int>), typeof(GenericRepository<PhoenixConfContext, ApproveStatus, int>));
            services.AddScoped<IApproveStatusRepository, ApproveStatusRepository>();
            services.AddScoped<IApproveStatusService, ApproveStatusService>();

            // RequestObject
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, RequestObject, int>), typeof(DomainRepository<PhoenixConfContext, RequestObject, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, RequestObject, int>), typeof(TrackableRepository<PhoenixConfContext, RequestObject, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, RequestObject, int>), typeof(GenericRepository<PhoenixConfContext, RequestObject, int>));
            services.AddScoped<IRequestObjectRepository, RequestObjectRepository>();
            services.AddScoped<IRequestObjectService, RequestObjectService>();

            // EmailTempt
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, EmailTempt, int>), typeof(DomainRepository<PhoenixConfContext, EmailTempt, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, EmailTempt, int>), typeof(TrackableRepository<PhoenixConfContext, EmailTempt, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, EmailTempt, int>), typeof(GenericRepository<PhoenixConfContext, EmailTempt, int>));
            services.AddScoped<IEmailTemptRepository, EmailTemptRepository>();

            // Email_File_Attach
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, EmailFileAttach, int>), typeof(DomainRepository<PhoenixConfContext, EmailFileAttach, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, EmailFileAttach, int>), typeof(TrackableRepository<PhoenixConfContext, EmailFileAttach, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, EmailFileAttach, int>), typeof(GenericRepository<PhoenixConfContext, EmailFileAttach, int>));
            services.AddScoped<IEmailFileAttachRepository, EmailFileAttachRepository>();

            // FTP_Config
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, FTPConfig, int>), typeof(DomainRepository<PhoenixConfContext, FTPConfig, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, FTPConfig, int>), typeof(TrackableRepository<PhoenixConfContext, FTPConfig, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, FTPConfig, int>), typeof(GenericRepository<PhoenixConfContext, FTPConfig, int>));
            services.AddScoped<IFTPConfigRepository, FTPConfigRepository>();

            // Document_Type
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, FTPDocumentType, int>), typeof(DomainRepository<PhoenixConfContext, FTPDocumentType, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, FTPDocumentType, int>), typeof(TrackableRepository<PhoenixConfContext, FTPDocumentType, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, FTPDocumentType, int>), typeof(GenericRepository<PhoenixConfContext, FTPDocumentType, int>));
            services.AddScoped<IFTPDocumentTypeRepository, FTPDocumentTypeRepository>();

            // SubscriberInfo
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, SubscriberInfo, decimal>), typeof(DomainRepository<PhoenixConfContext, SubscriberInfo, decimal>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, SubscriberInfo, decimal>), typeof(TrackableRepository<PhoenixConfContext, SubscriberInfo, decimal>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, SubscriberInfo, decimal>), typeof(GenericRepository<PhoenixConfContext, SubscriberInfo, decimal>));
            services.AddScoped<ISubscriberInfoRepository, SubscriberInfoRepository>();

            // NotificationCount
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, NotificationCount, int>), typeof(DomainRepository<PhoenixConfContext, NotificationCount, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, NotificationCount, int>), typeof(TrackableRepository<PhoenixConfContext, NotificationCount, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, NotificationCount, int>), typeof(GenericRepository<PhoenixConfContext, NotificationCount, int>));
            services.AddScoped<INotificationCountRepository, NotificationCountRepository>();
            services.AddScoped<INotificationService, NotificationService>();

            #endregion

            #region BCL

            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ConfGloEngine, decimal>), typeof(DomainRepository<PhoenixConfContext, ConfGloEngine, decimal>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ConfGloEngine, decimal>), typeof(TrackableRepository<PhoenixConfContext, ConfGloEngine, decimal>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ConfGloEngine, decimal>), typeof(GenericRepository<PhoenixConfContext, ConfGloEngine, decimal>));

            #endregion

            #region WEB_CORE

            // Conf_Table_Mapping
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ConfTableMapping, int>), typeof(DomainRepository<PhoenixConfContext, ConfTableMapping, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ConfTableMapping, int>), typeof(TrackableRepository<PhoenixConfContext, ConfTableMapping, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ConfTableMapping, int>), typeof(GenericRepository<PhoenixConfContext, ConfTableMapping, int>));
            services.AddScoped<IConfTableMappingRepository, ConfTableMappingRepository>();

            // View_Conf_Table_Mapping
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ViewConfTableMapping, int>), typeof(DomainRepository<PhoenixConfContext, ViewConfTableMapping, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ViewConfTableMapping, int>), typeof(TrackableRepository<PhoenixConfContext, ViewConfTableMapping, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ViewConfTableMapping, int>), typeof(GenericRepository<PhoenixConfContext, ViewConfTableMapping, int>));

            #endregion

            #region TECH

            // Date_Avaiable
            services.AddScoped(typeof(IQueryableRepository<PhoenixConfContext, AvaiableDate>), typeof(QueryableRepository<PhoenixConfContext, AvaiableDate>));
            services.AddScoped<IAvaiableDateRepository, AvaiableDateRepository>();

            // CONF_FIL_CE
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ConfFilCe, decimal>), typeof(DomainRepository<PhoenixConfContext, ConfFilCe, decimal>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ConfFilCe, decimal>), typeof(TrackableRepository<PhoenixConfContext, ConfFilCe, decimal>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ConfFilCe, decimal>), typeof(GenericRepository<PhoenixConfContext, ConfFilCe, decimal>));
            services.AddScoped<IConfFilCeRepository, ConfFilCeRepository>();
            services.AddScoped<IConfFilCeService, ConfFilCeService>();

            // Conf_Cf_Assumption
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ConfCfAssumption, decimal>), typeof(DomainRepository<PhoenixConfContext, ConfCfAssumption, decimal>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ConfCfAssumption, decimal>), typeof(TrackableRepository<PhoenixConfContext, ConfCfAssumption, decimal>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ConfCfAssumption, decimal>), typeof(GenericRepository<PhoenixConfContext, ConfCfAssumption, decimal>));

            #endregion

            return services;
        }

        private static IServiceCollection AddConfigurePhoenixData(this IServiceCollection services)
        {
            #region INFORMATION SCHEMA

            services.AddScoped(typeof(IQueryableRepository<PhoenixDataContext, TableInfo>), typeof(QueryableRepository<PhoenixDataContext, TableInfo>));
            services.AddScoped<IDataTableRepository, DataTableRepository>();
            services.AddScoped(typeof(IQueryableRepository<PhoenixDataContext, ColumnInfo>), typeof(QueryableRepository<PhoenixDataContext, ColumnInfo>));
            services.AddScoped<IDataColumnRepository, DataColumnRepository>();

            #endregion

            #region CORE

            services.AddScoped(typeof(IDomainRepository<PhoenixDataContext, OcePredealData, long>), typeof(DomainRepository<PhoenixDataContext, OcePredealData, long>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixDataContext, OcePredealData, long>), typeof(TrackableRepository<PhoenixDataContext, OcePredealData, long>));
            services.AddScoped(typeof(IGenericRepository<PhoenixDataContext, OcePredealData, long>), typeof(GenericRepository<PhoenixDataContext, OcePredealData, long>));
            services.AddScoped<IOcePredealDataRepository, OcePredealDataRepository>();
            services.AddScoped<IOcePredealDataService, OcePredealDataService>();

            #endregion

            return services;
        }

        private static IServiceCollection AddConfigureCollection(this IServiceCollection services)
        {
            #region INFORMATION SCHEMA

            services.AddScoped(typeof(IQueryableRepository<CollectionContext, TableInfo>), typeof(QueryableRepository<CollectionContext, TableInfo>));
            services.AddScoped<IColnTableRepository, ColnTableRepository>();
            services.AddScoped(typeof(IQueryableRepository<CollectionContext, ColumnInfo>), typeof(QueryableRepository<CollectionContext, ColumnInfo>));
            services.AddScoped<IColnColumnRepository, ColnColumnRepository>();

            #endregion

            // IMPORT
            services.AddScoped(typeof(IDomainRepository<CollectionContext, CollectionDeadLoan, long>), typeof(DomainRepository<CollectionContext, CollectionDeadLoan, long>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, CollectionDeadLoan, long>), typeof(TrackableRepository<CollectionContext, CollectionDeadLoan, long>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, CollectionDeadLoan, long>), typeof(GenericRepository<CollectionContext, CollectionDeadLoan, long>));
            services.AddScoped<ICollectionDeadLoanRepository, CollectionDeadLoanRepository>();
            services.AddScoped<ICollectionDeadLoanService, CollectionDeadLoanService>();

            services.AddScoped(typeof(IDomainRepository<CollectionContext, CollectionSellLoan, long>), typeof(DomainRepository<CollectionContext, CollectionSellLoan, long>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, CollectionSellLoan, long>), typeof(TrackableRepository<CollectionContext, CollectionSellLoan, long>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, CollectionSellLoan, long>), typeof(GenericRepository<CollectionContext, CollectionSellLoan, long>));
            services.AddScoped<ICollectionSellLoanRepository, CollectionSellLoanRepository>();
            services.AddScoped<ICollectionSellLoanService, CollectionSellLoanService>();

            services.AddScoped(typeof(IDomainRepository<CollectionContext, ConCollectionListDaily, long>), typeof(DomainRepository<CollectionContext, ConCollectionListDaily, long>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, ConCollectionListDaily, long>), typeof(TrackableRepository<CollectionContext, ConCollectionListDaily, long>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, ConCollectionListDaily, long>), typeof(GenericRepository<CollectionContext, ConCollectionListDaily, long>));
            services.AddScoped<IConCollectionListRepository, ConCollectionListRepository>();
            services.AddScoped<IConCollectionListService, ConCollectionListService>();

            // ViewCollectionEmail
            services.AddScoped(typeof(IDomainRepository<PhoenixConfContext, ViewCollectionEmail, int>), typeof(DomainRepository<PhoenixConfContext, ViewCollectionEmail, int>));
            services.AddScoped(typeof(ITrackableRepository<PhoenixConfContext, ViewCollectionEmail, int>), typeof(TrackableRepository<PhoenixConfContext, ViewCollectionEmail, int>));
            services.AddScoped(typeof(IGenericRepository<PhoenixConfContext, ViewCollectionEmail, int>), typeof(GenericRepository<PhoenixConfContext, ViewCollectionEmail, int>));
            services.AddScoped<ICollectionEmailFileAttachRepository, CollectionEmailFileAttachRepository>();
            services.AddScoped<ICollectionOutsourceEmailService, CollectionOutsourceEmailService>();

            // ConCollectionMigrate
            services.AddScoped(typeof(IDomainRepository<CollectionContext, ConCollectionMigrate, long>), typeof(DomainRepository<CollectionContext, ConCollectionMigrate, long>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, ConCollectionMigrate, long>), typeof(TrackableRepository<CollectionContext, ConCollectionMigrate, long>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, ConCollectionMigrate, long>), typeof(GenericRepository<CollectionContext, ConCollectionMigrate, long>));
            services.AddScoped<IConCollectionMigrateRepository, ConCollectionMigrateRepository>();
            services.AddScoped<IConCollectionMigrateService, ConCollectionMigrateService>();

            // OsCompany
            services.AddScoped(typeof(IDomainRepository<CollectionContext, OsCompany, int>), typeof(DomainRepository<CollectionContext, OsCompany, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, OsCompany, int>), typeof(TrackableRepository<CollectionContext, OsCompany, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, OsCompany, int>), typeof(GenericRepository<CollectionContext, OsCompany, int>));
            services.AddScoped<IOsCompanyService, OsCompanyService>();

            // REPORTS
            services.AddScoped(typeof(IQueryableRepository<CollectionContext, CollectionRepayReport>), typeof(QueryableRepository<CollectionContext, CollectionRepayReport>));
            services.AddScoped<ICollectionRepayReportRepository, CollectionRepayReportRepository>();
            services.AddScoped(typeof(IQueryableRepository<CollectionContext, CollectionNewbookReport>), typeof(QueryableRepository<CollectionContext, CollectionNewbookReport>));
            services.AddScoped<ICollectionNewbookReportRepository, CollectionNewbookReportRepository>();

            // LU_Campaign
            services.AddScoped(typeof(IDomainRepository<CollectionContext, LuCampaign, int>), typeof(DomainRepository<CollectionContext, LuCampaign, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, LuCampaign, int>), typeof(TrackableRepository<CollectionContext, LuCampaign, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, LuCampaign, int>), typeof(GenericRepository<CollectionContext, LuCampaign, int>));
            services.AddScoped<ILuCampaignService, LuCampaignService>();

            // Mp_Contract_Campaign
            services.AddScoped(typeof(IDomainRepository<CollectionContext, MpContractCampaign, int>), typeof(DomainRepository<CollectionContext, MpContractCampaign, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, MpContractCampaign, int>), typeof(TrackableRepository<CollectionContext, MpContractCampaign, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, MpContractCampaign, int>), typeof(GenericRepository<CollectionContext, MpContractCampaign, int>));

            // LU_Days_Past_Due
            services.AddScoped(typeof(IDomainRepository<CollectionContext, LuDaysPastDue, int>), typeof(DomainRepository<CollectionContext, LuDaysPastDue, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, LuDaysPastDue, int>), typeof(TrackableRepository<CollectionContext, LuDaysPastDue, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, LuDaysPastDue, int>), typeof(GenericRepository<CollectionContext, LuDaysPastDue, int>));
            services.AddScoped<ILuDaysPastDueService, LuDaysPastDueService>();

            // Conf_Collection_Fee_Ratio
            services.AddScoped(typeof(IDomainRepository<CollectionContext, ConfCollectionFeeRatio, int>), typeof(DomainRepository<CollectionContext, ConfCollectionFeeRatio, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, ConfCollectionFeeRatio, int>), typeof(TrackableRepository<CollectionContext, ConfCollectionFeeRatio, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, ConfCollectionFeeRatio, int>), typeof(GenericRepository<CollectionContext, ConfCollectionFeeRatio, int>));
            services.AddScoped<IConfCollectionFeeRatioService, ConfCollectionFeeRatioService>();

            // Collection_Repay_Adj
            services.AddScoped(typeof(IDomainRepository<CollectionContext, CollectionRepayAdj, long>), typeof(DomainRepository<CollectionContext, CollectionRepayAdj, long>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, CollectionRepayAdj, long>), typeof(TrackableRepository<CollectionContext, CollectionRepayAdj, long>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, CollectionRepayAdj, long>), typeof(GenericRepository<CollectionContext, CollectionRepayAdj, long>));
            services.AddScoped<ICollectionRepayAdjRepository, CollectionRepayAdjRepository>();
            services.AddScoped<ICollectionRepayAdjService, CollectionRepayAdjService>();

            // Collection_Dpd_Manual
            services.AddScoped(typeof(IDomainRepository<CollectionContext, CollectionDpdManual, long>), typeof(DomainRepository<CollectionContext, CollectionDpdManual, long>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, CollectionDpdManual, long>), typeof(TrackableRepository<CollectionContext, CollectionDpdManual, long>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, CollectionDpdManual, long>), typeof(GenericRepository<CollectionContext, CollectionDpdManual, long>));
            services.AddScoped<ICollectionDpdManualRepository, CollectionDpdManualRepository>();
            services.AddScoped<ICollectionDpdManualService, CollectionDpdManualService>();

            // Segments
            services.AddScoped(typeof(IDomainRepository<CollectionContext, Segment, int>), typeof(DomainRepository<CollectionContext, Segment, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, Segment, int>), typeof(TrackableRepository<CollectionContext, Segment, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, Segment, int>), typeof(GenericRepository<CollectionContext, Segment, int>));
            services.AddScoped<ISegmentService, SegmentService>();

            // Conf_Rotation_Book_Schedule
            services.AddScoped(typeof(IDomainRepository<CollectionContext, ConfRotationBookSchedule, int>), typeof(DomainRepository<CollectionContext, ConfRotationBookSchedule, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, ConfRotationBookSchedule, int>), typeof(TrackableRepository<CollectionContext, ConfRotationBookSchedule, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, ConfRotationBookSchedule, int>), typeof(GenericRepository<CollectionContext, ConfRotationBookSchedule, int>));
            services.AddScoped<IConfRotationBookScheduleService, ConfRotationBookScheduleService>();

            // Conf_Target_Recovery_Amount
            services.AddScoped(typeof(IDomainRepository<CollectionContext, ConfTargetRecoveryAmount, int>), typeof(DomainRepository<CollectionContext, ConfTargetRecoveryAmount, int>));
            services.AddScoped(typeof(ITrackableRepository<CollectionContext, ConfTargetRecoveryAmount, int>), typeof(TrackableRepository<CollectionContext, ConfTargetRecoveryAmount, int>));
            services.AddScoped(typeof(IGenericRepository<CollectionContext, ConfTargetRecoveryAmount, int>), typeof(GenericRepository<CollectionContext, ConfTargetRecoveryAmount, int>));
            services.AddScoped<IConfTargetRecoveryAmountService, ConfTargetRecoveryAmountService>();

            return services;
        }

        private static IServiceCollection AddConfigureIFRS9Conf(this IServiceCollection services)
        {
            #region INFORMATION SCHEMA

            services.AddScoped(typeof(IQueryableRepository<IFRS9_ConfContext, TableInfo>), typeof(QueryableRepository<IFRS9_ConfContext, TableInfo>));
            services.AddScoped<IIfrs9ConfColumnRepository, Ifrs9ConfColumnRepository>();
            services.AddScoped(typeof(IQueryableRepository<IFRS9_ConfContext, ColumnInfo>), typeof(QueryableRepository<IFRS9_ConfContext, ColumnInfo>));
            services.AddScoped<IIfrs9ConfTableRepository, Ifrs9ConfTableRepository>();

            #endregion

            #region WF

            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, DefWorkFlow, int>), typeof(DomainRepository<IFRS9_ConfContext, DefWorkFlow, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, DefWorkFlow, int>), typeof(TrackableRepository<IFRS9_ConfContext, DefWorkFlow, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, DefWorkFlow, int>), typeof(GenericRepository<IFRS9_ConfContext, DefWorkFlow, int>));

            //DefWorkFlowStep
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, DefWorkFlowStep, int>), typeof(DomainRepository<IFRS9_ConfContext, DefWorkFlowStep, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, DefWorkFlowStep, int>), typeof(TrackableRepository<IFRS9_ConfContext, DefWorkFlowStep, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, DefWorkFlowStep, int>), typeof(GenericRepository<IFRS9_ConfContext, DefWorkFlowStep, int>));
            
            //Task
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, Task, int>), typeof(DomainRepository<IFRS9_ConfContext, Task, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, Task, int>), typeof(TrackableRepository<IFRS9_ConfContext, Task, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, Task, int>), typeof(GenericRepository<IFRS9_ConfContext, Task, int>));

            //TaskParameter
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, TaskParameter, int>), typeof(DomainRepository<IFRS9_ConfContext, TaskParameter, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, TaskParameter, int>), typeof(TrackableRepository<IFRS9_ConfContext, TaskParameter, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, TaskParameter, int>), typeof(GenericRepository<IFRS9_ConfContext, TaskParameter, int>));

            //TaskStep
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, TaskStep, int>), typeof(DomainRepository<IFRS9_ConfContext, TaskStep, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, TaskStep, int>), typeof(TrackableRepository<IFRS9_ConfContext, TaskStep, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, TaskStep, int>), typeof(GenericRepository<IFRS9_ConfContext, TaskStep, int>));

            //WorkFlowStepMapping
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, WorkFlowStepMapping, int>), typeof(DomainRepository<IFRS9_ConfContext, WorkFlowStepMapping, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, WorkFlowStepMapping, int>), typeof(TrackableRepository<IFRS9_ConfContext, WorkFlowStepMapping, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, WorkFlowStepMapping, int>), typeof(GenericRepository<IFRS9_ConfContext, WorkFlowStepMapping, int>));

            #endregion

            #region Core
            //MP_GL_IFRS9
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpGlIfrs9, int>), typeof(DomainRepository<IFRS9_ConfContext, MpGlIfrs9, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpGlIfrs9, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpGlIfrs9, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpGlIfrs9, int>), typeof(GenericRepository<IFRS9_ConfContext, MpGlIfrs9, int>));

            //MP_DEFAULT_FLAG
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpDefaultFlag, int>), typeof(DomainRepository<IFRS9_ConfContext, MpDefaultFlag, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpDefaultFlag, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpDefaultFlag, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpDefaultFlag, int>), typeof(GenericRepository<IFRS9_ConfContext, MpDefaultFlag, int>));

            //MP_GROUP_SEGMENT
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpGroupSegment, int>), typeof(DomainRepository<IFRS9_ConfContext, MpGroupSegment, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpGroupSegment, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpGroupSegment, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpGroupSegment, int>), typeof(GenericRepository<IFRS9_ConfContext, MpGroupSegment, int>));

            //MP_Model_Segment_Group
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpModelSegmentGroup, int>), typeof(DomainRepository<IFRS9_ConfContext, MpModelSegmentGroup, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpModelSegmentGroup, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpModelSegmentGroup, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpModelSegmentGroup, int>), typeof(GenericRepository<IFRS9_ConfContext, MpModelSegmentGroup, int>));

            //MP_QTRR_SEGMENT
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpQtrrSegment, int>), typeof(DomainRepository<IFRS9_ConfContext, MpQtrrSegment, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpQtrrSegment, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpQtrrSegment, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpQtrrSegment, int>), typeof(GenericRepository<IFRS9_ConfContext, MpQtrrSegment, int>));

            //Mp_Qtrr_Segment
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpSectorGroup, int>), typeof(DomainRepository<IFRS9_ConfContext, MpSectorGroup, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpSectorGroup, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpSectorGroup, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpSectorGroup, int>), typeof(GenericRepository<IFRS9_ConfContext, MpSectorGroup, int>));

            //MP_Accrual_GL
            services.AddScoped(typeof(IDomainRepository<IFRS9_ConfContext, MpAccrualGl, int>), typeof(DomainRepository<IFRS9_ConfContext, MpAccrualGl, int>));
            services.AddScoped(typeof(ITrackableRepository<IFRS9_ConfContext, MpAccrualGl, int>), typeof(TrackableRepository<IFRS9_ConfContext, MpAccrualGl, int>));
            services.AddScoped(typeof(IGenericRepository<IFRS9_ConfContext, MpAccrualGl, int>), typeof(GenericRepository<IFRS9_ConfContext, MpAccrualGl, int>));

            #endregion
            return services;
        }

        private static IServiceCollection AddConfigureIFRS9Data(this IServiceCollection services)
        {
            #region INFORMATION SCHEMA

            services.AddScoped(typeof(IQueryableRepository<IFRS9_DataContext, TableInfo>), typeof(QueryableRepository<IFRS9_DataContext, TableInfo>));
            services.AddScoped<IIfrs9DataColumnRepository, Ifrs9DataColumnRepository>();
            services.AddScoped(typeof(IQueryableRepository<IFRS9_DataContext, ColumnInfo>), typeof(QueryableRepository<IFRS9_DataContext, ColumnInfo>));
            services.AddScoped<IIfrs9DataTableRepository, Ifrs9DataTableRepository>();

            #endregion

            return services;
        }
    }
}

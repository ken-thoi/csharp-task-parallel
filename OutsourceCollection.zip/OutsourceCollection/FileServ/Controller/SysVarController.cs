﻿using Entities;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Linq;

namespace FileServ.Controller
{
    public class SysVarController
    {
        private static Dictionary<string, string> DictSysVar = new Dictionary<string, string>();
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void LoadSysVar()
        {
            logger.Info("------ START: Loading System variable ------");
            string command = "[FileServ].[SysVar_Sel]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command);
            foreach(DataRow dr in dt.Rows)
            {
                var item = Utils.UtilFunction.CreateItemFromRow<SysVar>(dr);
                DictSysVar.Add((item.GName + "-" + item.VarName), item.VarValue);
                logger.Info("- " + item.GName +  " - " + item.VarName + " - " + item.VarValue);
            }

            string[] repositoryUrls = ConfigurationManager.AppSettings.AllKeys.Select(key => key).ToArray();
            foreach (var item in repositoryUrls)
            {
                if(DictSysVar.ContainsKey(item))
                {
                    DictSysVar[item] = ConfigurationManager.AppSettings[item];
                }
                else
                {
                    DictSysVar.Add(item, ConfigurationManager.AppSettings[item]);
                }
                logger.Info("- Re config by AppConfig: " + item + " - " + ConfigurationManager.AppSettings[item]);
            }

            logger.Info("------ END: Loading System variable ------");
        }

        public static string GetSystemValue(string GName, string Varname)
        {
            return DictSysVar[GName + "-" + Varname];
        }
    }
}

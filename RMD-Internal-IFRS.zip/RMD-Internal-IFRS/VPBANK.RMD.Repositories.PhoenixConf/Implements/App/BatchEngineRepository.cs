﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Data;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.AppEngines;
using VPBANK.RMD.Data.PhoenixConf.SqlParams;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common;
using System.Text;

namespace VPBANK.RMD.Repositories.PhoenixConf.Implements.App
{
    public class BatchEngineRepository : Repository<PhoenixConfContext, Engines, decimal>, IBatchEngineRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly ILogger<ApproveStatus> _logger;
        protected readonly PhoenixConfContext _context;

        public BatchEngineRepository(IDistributedCache distributedCache, ILogger<ApproveStatus> logger, ITrackableRepository<PhoenixConfContext, Engines, decimal> trackableRepository,
            PhoenixConfContext phoenixConfContext) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _logger = logger;
            _context = phoenixConfContext;
        }

        [Obsolete]
        public int BatchJobEnginesExecution(BatchEngineExecutionParam batchEngineExecution)
        {
            try
            {
                // ExecuteSqlCommandAsync calls IRelationalCommand.ExecuteNonQuery internally. It returns the number of rows affected.
                // var sql = PhoenixConf_SqlQuery_Define.EXEC_RUN_BATCH_ENGINES;
                var sql = new StringBuilder();
                sql.Append("EXEC Tech.Run_Batch_Engine @p_Business_Date, @p_Batch_ID, @p_Entity_Code, @p_Approach, @p_Scenario_ID, @p_Version_ID, @p_additional_param, @p_Batch_Log_ID OUT");

                // output param
                var batchLogIdParam = new SqlParameter
                {
                    ParameterName = "p_Batch_Log_ID",
                    SqlDbType = SqlDbType.Int,
                    Direction = ParameterDirection.Output,
                    Value = 0
                };

                // run
                var result = _context.Database.ExecuteSqlCommand(sql.ToString(),
                    new []
                    {
                        new SqlParameter("p_Business_Date", batchEngineExecution.Business_Date.ToString(DefFormats.DATE_FORMAT)),
                        new SqlParameter { ParameterName = "p_Batch_ID", SqlDbType = SqlDbType.Decimal, Direction = ParameterDirection.Input, Value = (decimal)batchEngineExecution.Batch_Id },
                        new SqlParameter("p_Entity_Code", batchEngineExecution.Entity_Code),
                        new SqlParameter("p_Approach", batchEngineExecution.Approach),
                        new SqlParameter("p_Scenario_ID", batchEngineExecution.Approach),
                        new SqlParameter("p_Version_ID", batchEngineExecution.Version_Id),
                        new SqlParameter("p_additional_param", batchEngineExecution.Additional_Param),
                        batchLogIdParam
                    });

                return (int)batchLogIdParam.Value;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Collection.SqlParams
{
    public class CollectionRepayReportParam : SqlParamBase
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string CustomerId { get; set; }
        public string OsCompany { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr
{
    [Table("Written_Off_Upload", Schema = "Apr")]
    public class WrittenOffUpload : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }
        public int Fk_Written_Off_File_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Uploaded_File_Name { get; set; }
        public string Latest_Upload_By { get; set; }
        public DateTime Latest_Upload_Date { get; set; }
    }
}

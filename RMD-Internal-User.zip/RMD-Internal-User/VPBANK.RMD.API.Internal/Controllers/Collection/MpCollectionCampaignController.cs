﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Serilog;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using System.Net.Mime;
using Newtonsoft.Json;
using System.Globalization;
using Microsoft.EntityFrameworkCore.Internal;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Internal.Controllers.Collection
{
    public class MpCollectionCampaignController : QueryController<CollectionContext, MpContractCampaign, int>
    {
        public MpCollectionCampaignController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<CollectionContext> unitOfWork,
            ITrackableRepository<CollectionContext, MpContractCampaign, int> trackableRepository,
            IGenericRepository<CollectionContext, MpContractCampaign, int> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// Valid data file import by dat file(.dat)
        /// </summary>
        /// <param name="file">file input: dat file by stream</param>
        /// <returns>
        /// If file error return: Row error and error message by row
        /// If file not error return: string empty
        /// </returns>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Octet)]
        public IActionResult ValidateDatFile([FromBody] byte[] file)
        {
            try
            {
                var content = System.Text.Encoding.UTF8.GetString(file);

                //var errors = new StringBuilder();
                var errors = new Dictionary<int, string>();
                if (string.IsNullOrEmpty(content) || string.IsNullOrWhiteSpace(content))
                    return Ok(JsonConvert.SerializeObject(errors));

                var datas = content.Split(SpecificSystems.NEXTLINE);
                var fileName = datas[0];
                var size = datas[1];
                var time = datas[2];
                var headers = datas[3].Split(SpecificSystems.PILE);
                Log.Information($"fileName: {fileName}");
                Log.Information($"size: {size}");
                Log.Information($"time: {time}");
                Log.Information($"headers: {JsonConvert.SerializeObject(headers, Formatting.Indented)}");

                // validate data
                for (int i = DAT_TAG_FILE_EX.COLN_START_LINE_VALIDATE; i < datas.Length; i++)
                {
                    var items = datas[i].Split(SpecificSystems.PILE);

                    try
                    {
                        var rowErrors = new List<string>();
                        var mpContractCompaign = new MpContractCampaign();

                        var type = string.Empty;
                        if (!string.IsNullOrEmpty(items[0]))
                            type = Convert.ToString(items[0]).Replace(SpecificSystems.QUOTE_DOUBLE, string.Empty);
                        var contractId = string.Empty;
                        if (!string.IsNullOrEmpty(items[1]))
                            contractId = Convert.ToString(items[1]).Replace(SpecificSystems.QUOTE_DOUBLE, string.Empty);
                        var campaignCode = string.Empty;
                        if (!string.IsNullOrEmpty(items[2]))
                            campaignCode = Convert.ToString(items[2]).Replace(SpecificSystems.QUOTE_DOUBLE, string.Empty);
                        var sStartDate = string.Empty;
                        if (!string.IsNullOrEmpty(items[3]))
                            sStartDate = Convert.ToString(items[3]).Replace(SpecificSystems.QUOTE_DOUBLE, string.Empty);
                        var sEndDate = string.Empty;
                        if (!string.IsNullOrEmpty(items[4]))
                            sEndDate = Convert.ToString(items[4]).Replace(SpecificSystems.QUOTE_DOUBLE, string.Empty);

                        if (string.IsNullOrEmpty(type))
                            rowErrors.Add(string.Format(ErrorMessages.EM001, nameof(mpContractCompaign.Type)));

                        if (string.IsNullOrEmpty(campaignCode))
                            rowErrors.Add(string.Format(ErrorMessages.EM001, nameof(mpContractCompaign.Campaign_Code)));

                        if (string.IsNullOrEmpty(contractId))
                            rowErrors.Add(string.Format(ErrorMessages.EM001, nameof(mpContractCompaign.Mapping_Id)));

                        // Start_Date
                        if (string.IsNullOrEmpty(sStartDate))
                            rowErrors.Add(string.Format(ErrorMessages.EM001, nameof(mpContractCompaign.Start_Date)));

                        DateTime startDate;
                        var isStartDate = DateTime.TryParseExact(sStartDate, DefFormats.DATE_FORMAT, CultureInfo.InvariantCulture, DateTimeStyles.None, out startDate);
                        if (!isStartDate)
                            rowErrors.Add(string.Format(ErrorMessages.EM002, nameof(mpContractCompaign.Start_Date), DefFormats.DATE_FORMAT));

                        // End_Date
                        if (!string.IsNullOrEmpty(Convert.ToString(sEndDate)))
                        {
                            DateTime endDate;
                            var isEndDate = DateTime.TryParseExact(sEndDate, DefFormats.DATE_FORMAT, CultureInfo.InvariantCulture, DateTimeStyles.None, out endDate);
                            if (!isEndDate)
                                rowErrors.Add(string.Format(ErrorMessages.EM002, nameof(mpContractCompaign.End_Date), DefFormats.DATE_FORMAT));
                        }

                        if (rowErrors.Count > 0)
                            errors.Add(i, rowErrors.Join(SpecificSystems.SEMICOLON));
                    }
                    catch (Exception)
                    {
                        continue;
                    }
                }

                var resultErrors = JsonConvert.SerializeObject(errors);
                Log.Information($"Collection_Sell_Loan validate results: {resultErrors}");
                return Ok(resultErrors);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
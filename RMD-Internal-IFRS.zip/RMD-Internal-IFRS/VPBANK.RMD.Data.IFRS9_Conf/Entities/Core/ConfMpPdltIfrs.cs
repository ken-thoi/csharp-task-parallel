﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Conf_MP_PDLT_IFRS", Schema = "BCL")]
    public class ConfMpPdltIfrs : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Model_Segment { get; set; }
        public string Rating { get; set; }
        public decimal? Pdlt_Value { get; set; }
        public DateTime? Pdlt_Date { get; set; }
        public int? Pdlt_Period { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

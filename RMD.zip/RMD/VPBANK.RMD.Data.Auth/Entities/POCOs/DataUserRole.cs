﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("Data_User_Role", Schema = "Core")]
    public class DataUserRole : BaseEntity<int>
    {
        public override int Pk_Id { get; set; }

        [Key]
        public string Username { get; set; }

        [Key]
        public int Fk_Role_Id { get; set; }
    }
}

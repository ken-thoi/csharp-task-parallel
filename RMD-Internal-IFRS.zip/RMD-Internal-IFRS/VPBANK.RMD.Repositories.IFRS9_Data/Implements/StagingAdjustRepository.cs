﻿using Microsoft.Extensions.Caching.Distributed;
using Serilog;
using System;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class StagingAdjustRepository : Repository<IFRS9_DataContext, StagingAdjust, int>, IStagingAdjustRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public StagingAdjustRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, StagingAdjust, int> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public StagingAdjust FindStagingAdjustByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                return TrackableRepository
                       .QueryableFromSqlRaw($"SELECT c.* FROM Core.Staging_Adjust AS c WHERE c.Customer_Id = '{customerId}' AND c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'")
                       .AsEnumerable()
                       .FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }

        public StagingAdjust FindStagingAdjustByCustomerIdAndFlowExecutionId(string customerId, DateTime businessDate, int flowExecId, int taskExecId)
        {
            try
            {
                return TrackableRepository
                       .QueryableFromSqlRaw($"SELECT c.* FROM Core.Staging_Adjust AS c WHERE c.Customer_Id = '{customerId}' AND c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}' AND c.Fk_Flow_Execution_Id = {flowExecId} AND c.Fk_Task_Execution_Id = {taskExecId}")
                       .AsEnumerable()
                       .FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                return null;
            }
        }
    }
}

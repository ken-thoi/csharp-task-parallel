﻿using Microsoft.EntityFrameworkCore;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Tech;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Data.PhoenixConf.Views.WebCore;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.WebCore;
using VPBANK.RMD.Data.PhoenixConf.Functions;
using VPBANK.RMD.EFCore.Entities.SchemaInfos;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.AppEngines;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl;

namespace VPBANK.RMD.Data.PhoenixConf
{
    public partial class PhoenixConfContext : DbContext
    {
        public PhoenixConfContext(DbContextOptions<PhoenixConfContext> options) : base(options)
        {
        }

        #region DbQuery<T> is for Stored Procedure

        public DbQuery<AvaiableDateResult> AvaiableDates { get; set; }
        public DbQuery<TableInfo> TableInfos { get; set; }
        public DbQuery<ColumnInfo> ColumnInfos { get; set; }

        #endregion

        // POCO data
        #region APP

        public virtual DbSet<ApproveStatus> ApproveStatus { get; set; }
        public virtual DbSet<RequestObject> RequestObjects { get; set; }
        public virtual DbSet<EmailTempt> EmailTempts { get; set; }
        public virtual DbSet<EmailFileAttach> EmailFileAttaches { get; set; }
        public virtual DbSet<FTPConfig> FTPConfigs { get; set; }
        public virtual DbSet<FTPDocumentType> FTPDocumentTypes { get; set; }
        public virtual DbSet<NotificationCount> NotificationCounts { get; set; }
        public virtual DbSet<SubscriberInfo> SubscriberInfos { get; set; }
        public virtual DbSet<Engines> Engines { get; set; }
        public virtual DbSet<EngineBatchLog> EngineBatchLogs { get; set; }

        #endregion

        #region BCL

        public virtual DbSet<ConfGloConfiguration> ConfGloConfigurations { get; set; }
        public virtual DbSet<ConfGloEngine> ConfGloEngines { get; set; }
        public virtual DbSet<ConfGloMpAccrualGl> ConfGloMpAccrualGls { get; set; }
        public virtual DbSet<ConfGloMpGeneralLedger> ConfGloMpGeneralLedgers { get; set; }
        public virtual DbSet<ConfGloMpGeneralLedgerKplus> ConfGloMpGeneralLedgerKpluses { get; set; }
        public virtual DbSet<ConfGloMpProduct> ConfGloMpProducts { get; set; }

        #endregion

        #region VIEWS WEB_CORE

        public virtual DbSet<ConfTableMapping> ConfTableParameterMappings { get; set; }

        #endregion

        #region TECH

        public virtual DbSet<ConfFilCe> ConfFilCes { get; set; }
        public virtual DbSet<ConfCfAssumption> ConfCfAssumptions { get; set; }

        #endregion

        #region VIEWS

        public virtual DbSet<ViewConfTableMapping> ViewConfTableMappings { get; set; }
        public virtual DbQuery<ViewConfTableMappingIfrs> ViewConfTableMappingIfrss { get; set; }

        #endregion

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region APP

            modelBuilder.Entity<ApproveStatus>().ToTable("Approve_Status", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<ApproveStatus>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<RequestObject>().ToTable("Request_Object", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<RequestObject>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<EmailTempt>().ToTable("Email_Tempt", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<EmailTempt>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<EmailFileAttach>().ToTable("Email_File_Attach", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<EmailFileAttach>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<FTPConfig>().ToTable("FTP_Config", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<FTPConfig>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<FTPDocumentType>().ToTable("FTP_Document_Type", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<FTPDocumentType>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<SubscriberInfo>().ToTable("Subscriber_Info", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<SubscriberInfo>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<NotificationCount>().ToTable("Notification_Count", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<NotificationCount>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<Engines>().ToTable("Engines", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<Engines>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<EngineBatchLog>().ToTable("Engine_Batch_Log", PhoenixConfDbConstants.APP);
            modelBuilder.Entity<EngineBatchLog>().HasKey(item => new { item.Pk_Id });

            #endregion

            #region BCL

            modelBuilder.Entity<ConfGloConfiguration>().ToTable("Conf_Glo_Configuration", PhoenixConfDbConstants.BCL);
            modelBuilder.Entity<ConfGloConfiguration>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfGloEngine>().ToTable("conf_glo_engine", PhoenixConfDbConstants.BCL);
            modelBuilder.Entity<ConfGloEngine>().HasKey(item => new { item.Pk_Id });

            // Conf_Glo_MP_Accrual_GL
            modelBuilder.Entity<ConfGloMpAccrualGl>().ToTable("Conf_Glo_MP_Accrual_GL", "BCL");
            modelBuilder.Entity<ConfGloMpAccrualGl>().HasKey(item => new { item.Pk_Id });

            // MP_General_Ledger
            modelBuilder.Entity<ConfGloMpGeneralLedger>().ToTable("Conf_Glo_MP_General_Ledger", "BCL");
            modelBuilder.Entity<ConfGloMpGeneralLedger>().HasKey(item => new { item.Pk_Id });

            // MP_General_Ledger_Kplus
            modelBuilder.Entity<ConfGloMpGeneralLedgerKplus>().ToTable("Conf_Glo_MP_General_Ledger_Kplus", "BCL");
            modelBuilder.Entity<ConfGloMpGeneralLedgerKplus>().HasKey(item => new { item.Pk_Id });

            // MP_Product
            modelBuilder.Entity<ConfGloMpProduct>().ToTable("Conf_Glo_MP_Product", "BCL");
            modelBuilder.Entity<ConfGloMpProduct>().HasKey(item => new { item.Pk_Id });

            #endregion

            #region WEB_CORE

            modelBuilder.Entity<ConfTableMapping>().ToTable("Conf_Table_Mapping", PhoenixConfDbConstants.WEB_CORE);
            modelBuilder.Entity<ConfTableMapping>().HasKey(item => new { item.Pk_Id });

            #endregion

            #region TECH

            modelBuilder.Entity<ConfFilCe>().ToTable("Conf_Fil_CE", PhoenixConfDbConstants.TECH);
            modelBuilder.Entity<ConfFilCe>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Entity<ConfCfAssumption>().ToTable("Conf_Cf_Assumption", PhoenixConfDbConstants.TECH);
            modelBuilder.Entity<ConfCfAssumption>().HasKey(item => new { item.Pk_Id });

            #endregion

            #region VIEWS WEB_CORE

            modelBuilder.Entity<ViewConfTableMapping>().ToTable("View_Conf_Table_Mapping", PhoenixConfDbConstants.WEB_CORE);
            modelBuilder.Entity<ViewConfTableMapping>().HasKey(item => new { item.Pk_Id });

            modelBuilder.Query<ViewConfTableMappingIfrs>().ToView("View_Conf_Table_Mapping_Ifrs", PhoenixConfDbConstants.WEB_CORE);
            #endregion

            base.OnModelCreating(modelBuilder);
        }
    }
}

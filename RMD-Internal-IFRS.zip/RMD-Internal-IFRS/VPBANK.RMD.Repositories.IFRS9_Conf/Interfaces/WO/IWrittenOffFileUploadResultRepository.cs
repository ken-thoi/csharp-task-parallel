﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.WO
{
    public interface IWrittenOffFileUploadResultRepository : IQueryRepository<IFRS9_ConfContext, WrittenOffFileUploadResult>
    {
        List<WrittenOffFileUploadResult> FindAllWrittenOffFileUploads(DateTime businessDate, int flowExecutionId, int taskExecutionId);
        Task<int> CalculationWrittenOff(DateTime businessDate);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Threading.Tasks;

namespace Email_Notification
{
    public static class EmailExcuter
    {
        static string strConnection = string.Empty;
        static Dictionary<string, EmailConfig> emailConfigDict;
        static string emailConfigStringStatus = "   DipslayName : {0} -- Username : {1} -- Password : ********* -- EnableSSL : {2} -- port : {3} -- STMPServer : {4} -- TimeLoop : {5} (ms) -- TimeOut : {6} (ms) -- Status: {7} \r\n";
        static List<Task> listRunningTask = new List<Task>();
        static string SQL_EMAIL_CONFIG_SEL = string.Empty;
        static string SQL_EMAIL_CONFIG_UPD_LASTEXCUTED = string.Empty;
        static string SQL_EMAIL_QUEUE_SEL = string.Empty;
        static string SQL_EMAIL_QUEUE_HIS_INS = string.Empty;

        public static void EmailExcute(string processID)
        {
            try
            {
                GetConnetion();
#if DEBUG
                PushInfo("EmailExcute", "Service is run on Debug mode");
#endif
                GetParameter();
                Send_Email();
            }
            catch (Exception ex)
            {
                PushEror("EmailExcute", ex.ToString());
                throw;
            }
        }

        public static void StopSendEmail()
        {
            foreach (var item in emailConfigDict)
                item.Value.IsRunning = false;

            Task.WaitAll(listRunningTask.ToArray());
        }

        private static void PushInfo(string v_Step_name, string Description)
        {
            EventLog.WriteEntry("Email Notification Service", v_Step_name + ": \r\n" + Description, EventLogEntryType.Information);
        }

        private static void PushEror(string v_Step_name, string Description)
        {
            EventLog.WriteEntry("Email Notification Service", v_Step_name + ": " + Description, EventLogEntryType.Error);
        }

        public static void GetParameter()
        {
            string message = string.Empty;
            message += "1.GetConfig: " + Environment.NewLine;
            SQL_EMAIL_CONFIG_SEL = ConfigurationManager.AppSettings["SQL_EMAIL_CONFIG_SEL"];
            SQL_EMAIL_CONFIG_UPD_LASTEXCUTED = ConfigurationManager.AppSettings["SQL_EMAIL_CONFIG_UPD_LASTEXCUTED"];
            SQL_EMAIL_QUEUE_SEL = ConfigurationManager.AppSettings["SQL_EMAIL_QUEUE_SEL"];
            SQL_EMAIL_QUEUE_HIS_INS = ConfigurationManager.AppSettings["SQL_EMAIL_QUEUE_HIS_INS"];
            message += "  - SQL_EMAIL_CONFIG_SEL: " + SQL_EMAIL_CONFIG_SEL + Environment.NewLine;
            message += "  - SQL_EMAIL_CONFIG_UPD_LASTEXCUTED: " + SQL_EMAIL_CONFIG_UPD_LASTEXCUTED + Environment.NewLine;
            message += "  - SQL_EMAIL_QUEUE_SEL: " + SQL_EMAIL_QUEUE_SEL + Environment.NewLine;
            message += "  - SQL_EMAIL_QUEUE_HIS_INS: " + SQL_EMAIL_QUEUE_HIS_INS + Environment.NewLine;
            if(string.IsNullOrEmpty(SQL_EMAIL_CONFIG_SEL) || string.IsNullOrEmpty(SQL_EMAIL_CONFIG_UPD_LASTEXCUTED) 
                || string.IsNullOrEmpty(SQL_EMAIL_QUEUE_SEL) || string.IsNullOrEmpty(SQL_EMAIL_QUEUE_HIS_INS))
                throw new Exception("SQL_EMAIL_CONFIG_SEL, SQL_EMAIL_CONFIG_UPD_LASTEXCUTED, SQL_EMAIL_QUEUE_SEL, SQL_EMAIL_QUEUE_HIS_INS must not null or empty string");
            DataTable param_Table = ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_CONFIG_SEL);
            emailConfigDict = new Dictionary<string, EmailConfig>();
            message += "2.Get config from DB: successful" + Environment.NewLine;
            message += "3.Detail email account:" + Environment.NewLine;
            foreach (DataRow dr in param_Table.Rows)
            {
                message += "---------------------------------------------------" + Environment.NewLine;
                var emailConfig = CreateItemFromRow<EmailConfig>(dr);
                try
                {
                    emailConfig.client = CreateSMTPConnection(emailConfig);
                    message += string.Format(emailConfigStringStatus, emailConfig.DipslayName, emailConfig.Username, emailConfig.EnableSSL, emailConfig.Port, emailConfig.STMPServer, emailConfig.TimeLoop.ToString("N0"), emailConfig.TimeOut.ToString("N0"), "Successful");
                }
                catch (Exception ex)
                {
                    message += string.Format(emailConfigStringStatus, emailConfig.DipslayName, emailConfig.Username, emailConfig.EnableSSL, emailConfig.Port, emailConfig.STMPServer, emailConfig.TimeLoop.ToString("N0"), emailConfig.TimeOut.ToString("N0"), "failed");
                    message += "Failed resion: " + ex.Message + " -- Detail:" + ex.ToString() + Environment.NewLine;
                    emailConfig.client = null;
                }
                emailConfigDict.Add(emailConfig.Username.ToUpper(), emailConfig);
            }
            message += "---------------------------------------------------" + Environment.NewLine;
            message += "GetEmailParameter: successful" + Environment.NewLine;
            PushInfo("GetParameter", message);
        }

        private static SmtpClient CreateSMTPConnection(EmailConfig emailConfig)
        {
            var client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential(emailConfig.Username, emailConfig.Password);
            client.Host = emailConfig.STMPServer;
            client.Port = emailConfig.Port;
            client.Timeout = emailConfig.TimeOut;
            client.EnableSsl = emailConfig.EnableSSL;
            return client;
        }

        public static void GetConnetion()
        {
            PushInfo("GetConnetion", "Get Connetion");

            string strCon = string.Empty;
            string strConEn = string.Empty;
            string strKeyEn = string.Empty;

            strCon = ConfigurationManager.AppSettings["ConnectionString"];
            strConEn = ConfigurationManager.AppSettings["ConnectionString_Encrypt"];
            strKeyEn = ConfigurationManager.AppSettings["keyEncrypt"];

            if (string.IsNullOrEmpty(strKeyEn))
            {
                throw new Exception("Not found keyEncrypt in App.Config");
            }
            if (string.IsNullOrEmpty(strConEn))
            {
                PushInfo("GetConnetion", "Not found ConnectionString_Encrypt");
                if (!string.IsNullOrEmpty(strCon))
                {
                    PushInfo("GetConnetion", "found ConnectionString and keyEncrypt, start encypt ConnectionString");
                    Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                    strConEn = CryptorEngine.Encrypt(strCon, true, strKeyEn);
                    config.AppSettings.Settings.Remove("ConnectionString_Encrypt");
                    config.AppSettings.Settings.Add("ConnectionString_Encrypt", strConEn);
                    config.AppSettings.Settings.Remove("ConnectionString");
                    config.AppSettings.Settings.Add("ConnectionString", string.Empty);
                    config.Save(ConfigurationSaveMode.Minimal, true);
                    PushInfo("GetConnetion", "ConnectionString encrypt sucessfull, new string already in App.Config");
                }
                else
                {
                    throw new Exception("either ConnectionString or ConnectionString_Encrypt must have value");
                }
            }
            strConnection = CryptorEngine.Decrypt(strConEn, true, strKeyEn);
            PushInfo("GetConnetion", "Get connection successful");
        }

        private static DataTable ExcutedCommandReturnDatatable(string strConnection, string strCommand, bool isProc = false)
        {
            if (string.IsNullOrEmpty(strConnection))
                throw new Exception("connection is empty");
            while (true)
            {
                try
                {
                    DataTable dtResult = new DataTable();
                    SqlConnection conn = new SqlConnection(strConnection);
                    conn.Open();
                    try
                    {
                        using (SqlCommand command = new SqlCommand(strCommand, conn))
                        {
                            command.CommandTimeout = 120;
                            if (isProc)
                                command.CommandType = CommandType.StoredProcedure;

                            using (SqlDataReader dr = command.ExecuteReader())
                            {
                                dtResult.Load(dr);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        EventLog.WriteEntry("Email Notification Service", "ExcutedCommandReturnDatatable: " + ex.Message, EventLogEntryType.Error);
                        //throw ex;
                    }
                    finally
                    {
                        conn.Close();
                    }
                    return dtResult;
                }
                catch (Exception ex)
                {
                    EventLog.WriteEntry("Email Notification Service", "ExcutedCommandReturnDatatable" + ": fail to excuted: " + strCommand + "\r\nAction: Restart after 30 Seconds" + "\r\nResion: " + ex.Message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(30000);
                }
            }
        }

        private static DataTable ExcutedCommandReturnDatatable(string strConnection, string strCommand, SqlParameter[] parameters, bool isProc = false)
        {
            if (string.IsNullOrEmpty(strConnection))
                throw new Exception("connection is empty");
            while (true)
            {
                try
                {
                    DataTable dtResult = new DataTable();
                    SqlConnection conn = new SqlConnection(strConnection);
                    conn.Open();
                    try
                    {
                        using (SqlCommand command = new SqlCommand(strCommand, conn))
                        {
                            if (parameters != null)
                            {
                                foreach (var item in parameters)
                                    if (item.Value == null)
                                        item.Value = DBNull.Value;
                                command.Parameters.AddRange(parameters);
                            }

                            command.CommandTimeout = 120;
                            if (isProc)
                                command.CommandType = CommandType.StoredProcedure;

                            using (SqlDataReader dr = command.ExecuteReader())
                            {
                                dtResult.Load(dr);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        EventLog.WriteEntry("Email Notification Service", "ExcutedCommandReturnDatatable: " + ex.Message, EventLogEntryType.Error);
                        //throw ex;
                    }
                    finally
                    {
                        conn.Close();
                    }
                    return dtResult;
                }
                catch (Exception ex)
                {
                    EventLog.WriteEntry("Email Notification Service", "ExcutedCommandReturnDatatable" + ": fail to excuted: " + strCommand + "\r\nAction: Restart after 30 Seconds" + "\r\nResion: " + ex.Message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(30000);
                }
            }
        }

        public static void Send_Email()
        {
            foreach (var emailConfig in emailConfigDict)
            {
                listRunningTask.Add(
                Task.Factory.StartNew(() =>
                {
                    while (emailConfig.Value.IsRunning)
                    {
                        string message = string.Empty;
                        while (emailConfig.Value.client == null)
                        {
                            message += "Error: Connection to STMP server is not available. system will reconnect again:" + Environment.NewLine;
                            int retryConnectionCount = 3;
                            try
                            {
                                emailConfig.Value.client = CreateSMTPConnection(emailConfig.Value);
                                message += "    Tring to reconnect to SMTP server: " + emailConfig.Value.STMPServer + " with username: " + emailConfig.Value.Username + ": successful" + Environment.NewLine;
                            }
                            catch (Exception ex)
                            {
                                message += "    Tring to reconnect to SMTP server: " + emailConfig.Value.STMPServer + " with username: " + emailConfig.Value.Username + ": failed " + (3 - retryConnectionCount) + " time(s) retry after 3 seconds" + Environment.NewLine;
                                emailConfig.Value.client = null;
                                retryConnectionCount--;
                                if (retryConnectionCount < 1)
                                {
                                    message += ex.Message + Environment.NewLine;
                                    message += ex.ToString() + Environment.NewLine;
                                    break;
                                }
                                System.Threading.Thread.Sleep(3000);
                            }
                        }

                        if (emailConfig.Value.client == null)
                        {
                            message += "Can not send email from: " + emailConfig.Value.Username + "because connection to STMP server is not available" + Environment.NewLine;
                            ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_CONFIG_UPD_LASTEXCUTED,
                                new SqlParameter[] { new SqlParameter("@pv_Username", emailConfig.Value.Username), new SqlParameter("@pv_CurrentStatus", message) }, true);
                        }
                        else
                        {
                            ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_CONFIG_UPD_LASTEXCUTED,
                                new SqlParameter[] { new SqlParameter("@pv_Username", emailConfig.Value.Username), new SqlParameter("@pv_CurrentStatus", "Service running normal"), }, true);
                            message += "1. Send email from mail: " + emailConfig.Value.Username + Environment.NewLine;
                            message += "2. Get Email Queue from DB" + Environment.NewLine;
                            DataTable data_Email = ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_QUEUE_SEL, new SqlParameter[] { new SqlParameter("@pv_From_Mail", emailConfig.Value.Username) }, true);
                            if (data_Email.Rows.Count > 0)
                            {
                                message += "System get: " + data_Email.Rows.Count + " email(s) will send from email: " + emailConfig.Value.Username;
                                foreach (DataRow dr in data_Email.Rows)
                                {
                                    try
                                    {
                                        MailMessage msg = new MailMessage();
                                        msg.From = new MailAddress(emailConfig.Value.Username, string.IsNullOrEmpty(emailConfig.Value.DipslayName) ? emailConfig.Value.Username : emailConfig.Value.DipslayName);
                                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Mail_To"])))
                                        {
                                            var list = Convert.ToString(dr["Mail_To"]).Split(';');
                                            foreach (var item in list)
                                                if (!string.IsNullOrEmpty(item.Trim()))
                                                    msg.To.Add(item.Trim());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(dr["OriginMessageID"])))
                                            msg.Headers["In-Reply-To"] = Convert.ToString(dr["OriginMessageID"]);
                                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Mail_CC"])))
                                        {
                                            var list = Convert.ToString(dr["Mail_CC"]).Split(';');
                                            foreach (var item in list)
                                                if (!string.IsNullOrEmpty(item.Trim()))
                                                    msg.CC.Add(item.Trim());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Mail_BCC"])))
                                        {
                                            var list = Convert.ToString(dr["Mail_BCC"]).Split(';');
                                            foreach (var item in list)
                                                if (!string.IsNullOrEmpty(item.Trim()))
                                                    msg.Bcc.Add(item.Trim());
                                        }
                                        msg.Subject = Convert.ToString(dr["Subject"]);
                                        msg.Body = Convert.ToString(dr["Content"]);
                                        msg.IsBodyHtml = true;

                                        if (!string.IsNullOrEmpty(Convert.ToString(dr["Attachment"])))
                                        {
                                            var listAttachLocation = Convert.ToString(dr["Attachment"]).Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);

                                            foreach (var item in listAttachLocation)
                                                using (FileStream fsSource = new FileStream(item.Trim(), FileMode.Open, FileAccess.Read))
                                                {
                                                    Stream memoryStream = new MemoryStream();
                                                    fsSource.CopyTo(memoryStream);
                                                    memoryStream.Position = 0;
                                                    msg.Attachments.Add(new Attachment(memoryStream, item.Split('\\').Last()));
                                                    fsSource.Close();
                                                }
                                        }

                                        int trySendCount = 3;
                                        while (trySendCount > 0)
                                        {
                                            try
                                            {
                                                emailConfig.Value.client.Send(msg);
                                                ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_QUEUE_HIS_INS,
                                                    new SqlParameter[] { new SqlParameter("@pv_ID", Convert.ToString(dr["ID"])), new SqlParameter("@pv_IsError", false), new SqlParameter("@pv_Log", DBNull.Value), new SqlParameter("@pv_Log_msg", DBNull.Value) }, true);
                                                break;
                                            }
                                            catch (Exception ex)
                                            {
                                                trySendCount--;
                                                System.Threading.Thread.Sleep(1000);
                                                if (trySendCount <= 0)
                                                {
                                                    ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_QUEUE_HIS_INS, new SqlParameter[] {new SqlParameter("@pv_ID", Convert.ToString(dr["ID"])),new SqlParameter("@pv_IsError", true),new SqlParameter("@pv_Log", ex.ToString()),new SqlParameter("@pv_Log_msg", ex.Message)}, true);
                                                    throw;
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {

                                        ExcutedCommandReturnDatatable(strConnection, SQL_EMAIL_QUEUE_HIS_INS, new SqlParameter[] {new SqlParameter("@pv_ID", Convert.ToString(dr["ID"])),new SqlParameter("@pv_IsError", true),new SqlParameter("@pv_Log", ex.ToString()),new SqlParameter("@pv_Log_msg", ex.Message)}, true);
                                    }
                                }
                            }
                        }
                        PushInfo("Send_Email", message);
                        System.Threading.Thread.Sleep(emailConfig.Value.TimeLoop);
                    }
                }));
            }

            Task.WaitAll(listRunningTask.ToArray());
        }

        public static T CreateItemFromRow<T>(DataRow row) where T : new()
        {
            // create a new object
            T item = new T();

            // set the item
            SetItemFromRow(item, row);

            // return 
            return item;
        }

        public static void SetItemFromRow<T>(T item, DataRow row) where T : new()
        {
            // go through each column
            foreach (DataColumn c in row.Table.Columns)
            {
                // find the property for the column
                PropertyInfo p = item.GetType().GetProperty(c.ColumnName);

                // if exists, set the value
                if (p != null && row[c] != DBNull.Value)
                {
                    p.SetValue(item, Convert.ChangeType(row[c], p.PropertyType), null);
                }
            }
        }
    }

    public class EmailConfig
    {
        public string DipslayName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public bool EnableSSL { get; set; }
        public int Port { get; set; } = -1;
        public string STMPServer { get; set; }
        public int TimeLoop { get; set; }
        public int TimeOut { get; set; }
        public string Last_Excuted_Time { get; set; }
        public SmtpClient client { get; set; }
        public bool IsRunning { get; set; } = true;

    }
}

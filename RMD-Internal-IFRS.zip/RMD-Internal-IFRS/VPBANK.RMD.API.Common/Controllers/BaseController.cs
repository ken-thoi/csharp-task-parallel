﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Memory;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http.Extensions;
using AutoMapper;
using System.Net.Mime;
using Serilog;
using Newtonsoft.Json;
using System.IO;
using System.Threading.Tasks;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Common.Extensions;
using VPBANK.RMD.Utils.Security.Models;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Filters;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.API.Settings.Sections;
using VPBANK.RMD.Utils.Security.SRAJose;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.Auth.Entities.POCOs;

namespace VPBANK.RMD.API.Common.Controllers
{
    [ApiController]
    [ApiVersion(ApiKeys.API_VERSION, Deprecated = true)]
    [AddHeader(ApiKeys.API_AUTHOR_HEADER, ApiKeys.API_AUTHOR)]
    [Route(template: ApiKeys.ROUTE_TEMPLATE)]
    [Produces(typeof(IActionResult))]
    [Consumes(MediaTypeNames.Application.Json)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public class BaseController : ControllerBase
    {
        protected readonly IMemoryCache _memoryCache;
        protected readonly IConfiguration _configuration;
        protected readonly IWebHostEnvironment _env;
        protected readonly IAppSettingsReader _appSettings;
        protected readonly IHttpClientFactory _httpClientFactory;
        protected readonly IMapper _mapper;

        protected readonly IRabbitMqPublisher _rabbitManager;
        protected readonly ISubscriberInfoRepository _subscriberRepository;
        protected readonly IUserService _userService;

        public BaseController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,

            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService)
        {
            _memoryCache = memoryCache;
            _configuration = configuration;
            _env = env;
            _appSettings = appSettings;
            _httpClientFactory = httpClientFactory;
            _mapper = mapper;

            _rabbitManager = rabbitManager;
            _subscriberRepository = subscriberRepository;
            _userService = userService;
        }

        protected Dictionary<string, string> GetConfig()
        {
            var result = new Dictionary<string, string>();

            // get data config from app setting
            var configs = _configuration
                .GetSection(nameof(AppSettings.ConnectionStrings))
                .AsEnumerable()
                .Where(x => x.Key != nameof(AppSettings.ConnectionStrings))
                // Since we are enumerating the root, each key will be prefixed with our target section, so we need to strip that prefix off.
                .ToDictionary(x => x.Key, x => x.Value);

            foreach (var config in configs)
                result.Add(config.Key, config.Value);

            result.Add("Key", "Value");

            return result;
        }

        protected void SetTokenCookie(string key, string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddDays(7)
            };
            Response.Cookies.Append(key, token, cookieOptions);
        }

        protected string GetToken()
        {
            try
            {
                if (!Request.Headers.TryGetValue(ApiKeys.X_AUTH_TOKEN, out var apiKeyHeaderValues)) return null;
                if (apiKeyHeaderValues.Count == 0) return null;
                var token = apiKeyHeaderValues.FirstOrDefault();
                if (string.IsNullOrWhiteSpace(token)) return null;
                return token;
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected User FindByUsernameAndIsActiveAndIsDeleted(string username, string status, bool isDeleted)
        {
            try
            {
                return _userService.FindByUsernameAndIsActiveAndIsDeleted(username, status, isDeleted);
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected UserPayload GetUserPayloadFromHeader()
        {
            try
            {
                //was the header provided?
                var headerAuthTokenValue = Request.Headers[ApiKeys.X_AUTH_TOKEN];
                if (!headerAuthTokenValue.Any()) return null;

                var providedApiKey = headerAuthTokenValue.FirstOrDefault();
                if (string.IsNullOrWhiteSpace(providedApiKey)) return null;

                // check PUBLIC_KEY
                var jwtConfig = JWTSetting.GetJwtSection(_configuration);
                var publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtConfig.PublicKey);
                var publicKey = System.IO.File.ReadAllText(publicKeyPath);

                // check payload from token
                var payload = TokenConsumer.Consume(providedApiKey, publicKey);
                return payload;
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected UserPayload GetUserPayload()
        {
            try
            {
                return SessionHelper.Get<UserPayload>(HttpContext.Session, SESSION_KEYS.USER_PAYLOAD);
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected List<string> GetEngineDataRolesFromHeader()
        {
            var results = new List<string>();
            try
            {
                //was the header provided?
                var headerAuthTokenValue = Request.Headers[ApiKeys.X_AUTH_TOKEN];
                if (!headerAuthTokenValue.Any()) return null;

                var providedApiKey = headerAuthTokenValue.FirstOrDefault();
                if (string.IsNullOrWhiteSpace(providedApiKey)) return null;

                // check PUBLIC_KEY
                var jwtConfig = JWTSetting.GetJwtSection(_configuration);
                var publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtConfig.PublicKey);
                var publicKey = System.IO.File.ReadAllText(publicKeyPath);

                // check payload from token
                var payload = TokenConsumer.Consume(providedApiKey, publicKey);

                // Concat both entity & engine (data role)
                if (payload != null && !string.IsNullOrEmpty(payload.DataRole))
                {
                    var dataRolesOfUser = payload.DataRole.Split(SpecificSystems.SEMICOLON);
                    foreach (var dataRole in dataRolesOfUser)
                        if (!string.IsNullOrEmpty(dataRole) && dataRole.Contains(ENGINE_CODES.ENGINE_EXTENTION))
                            results.Add(dataRole.Trim().Replace(ENGINE_CODES.ENGINE_EXTENTION, string.Empty));
                }

                return results;
            }
            catch (Exception)
            {
                //string mess = ex.Message;
                //if (ex.InnerException != null)
                //    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                //throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
                return results;
            }
        }

        protected List<string> GetEntityDataRolesFromHeader()
        {
            var results = new List<string>();
            try
            {
                //was the header provided?
                var headerAuthTokenValue = Request.Headers[ApiKeys.X_AUTH_TOKEN];
                if (!headerAuthTokenValue.Any()) return null;

                var providedApiKey = headerAuthTokenValue.FirstOrDefault();
                if (string.IsNullOrWhiteSpace(providedApiKey)) return null;

                // check PUBLIC_KEY
                var jwtConfig = JWTSetting.GetJwtSection(_configuration);
                var publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtConfig.PublicKey);
                var publicKey = System.IO.File.ReadAllText(publicKeyPath);

                // check payload from token
                var payload = TokenConsumer.Consume(providedApiKey, publicKey);

                // Concat both entity & engine (data role)
                if (payload != null && !string.IsNullOrEmpty(payload.DataRole))
                {
                    var dataRolesOfUser = payload.DataRole.Split(SpecificSystems.SEMICOLON);
                    foreach (var dataRole in dataRolesOfUser)
                        if (!string.IsNullOrEmpty(dataRole) && dataRole.Contains(ENTITY_CODES.ENTITY_EXTENTION))
                            results.Add(dataRole.Trim().Replace(ENTITY_CODES.ENTITY_EXTENTION, string.Empty));
                }

                return results;
            }
            catch (Exception)
            {
                return results;
            }
        }

        protected List<int> GetBusinessUnitDataRolesFromHeader()
        {
            var results = new List<int>();
            try
            {
                //was the header provided?
                var headerAuthTokenValue = Request.Headers[ApiKeys.X_AUTH_TOKEN];
                if (!headerAuthTokenValue.Any()) return null;

                var providedApiKey = headerAuthTokenValue.FirstOrDefault();
                if (string.IsNullOrWhiteSpace(providedApiKey)) return null;

                // check PUBLIC_KEY
                var jwtConfig = JWTSetting.GetJwtSection(_configuration);
                var publicKeyPath = Path.Combine(Directory.GetCurrentDirectory(), jwtConfig.PublicKey);
                var publicKey = System.IO.File.ReadAllText(publicKeyPath);

                // check payload from token
                var payload = TokenConsumer.Consume(providedApiKey, publicKey);

                // business_unit
                if (payload != null && !string.IsNullOrEmpty(payload.DataRole))
                {
                    var dataRolesOfUser = payload.DataRole.Split(SpecificSystems.SEMICOLON);
                    foreach (var dataRole in dataRolesOfUser)
                        if (!string.IsNullOrEmpty(dataRole) && dataRole.Contains(BUSINESS_UNIT_CODES.BUSINESS_UNIT_EXTENTION))
                            results.Add(Convert.ToInt32(dataRole.Trim().Replace(BUSINESS_UNIT_CODES.BUSINESS_UNIT_EXTENTION, string.Empty)));
                }

                return results;
            }
            catch (Exception)
            {
                return results;
            }
        }

        protected string GetFullUri()
        {
            try
            {
                var uri = Request.GetDisplayUrl();
                Log.Information(uri);
                return $"{Request.Scheme}://{Request.Host}{Request.Path}{Request.QueryString}";
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected string GetPathUri()
        {
            try
            {
                return $"/{Request.Path}";
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected string GetBaseUri()
        {
            try
            {
                return $"{Request.Scheme}://{Request.Host}";
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected string GetHeader(string key)
        {
            if (!Request.Headers.TryGetValue(key, out var result))
                return null;

            if (!result.Any())
                return null;

            return result.FirstOrDefault();
        }

        /// <summary>
        /// Using generic query data (with select from table, view)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="source"></param>
        /// <param name="paginatedParams"></param>
        /// <returns></returns>
        protected async Task<PaginatedContentResults<object>> GenericQueryDataAsync(int total, IEnumerable<object> source, PaginatedInputModel paginatedParams)
        {
            // Filters & Sorting by SQL
            Log.Information($"Filter_Expression: {paginatedParams.FilterExpression}");

            // Paging
            var data = await PaginatedResults<object>.GenericQueryDataAsync(source, paginatedParams.PageIndex, paginatedParams.PageSize, total);

            // Results
            var results = new PaginatedContentResults<object>
            {
                TotalPages = data.TotalPages,
                TotalElements = data.TotalElements,
                Number = data.PageIndex,
                Size = data.PageSize,
                NumberOfElements = data.NumberOfElements,
                HasPreviousPage = data.HasPreviousPage,
                HasNextPage = data.HasNextPage,
                First = data.First,
                Last = data.Last,
                Empty = data.Empty,
                Content = data,
            };

            return results;
        }

        /// <summary>
        /// Using other query data (with select from store procudure, function, table fucntion)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="source"></param>
        /// <param name="paginatedParams"></param>
        /// <returns></returns>
        protected async Task<PaginatedContentResults<object>> QueryDataAsync(int total, IEnumerable<object> source, PaginatedInputModel paginatedParams)
        {
            // Filters & Sorting by SQL
            Log.Information($"Filter_Expression: {paginatedParams.FilterExpression}");

            // Paging
            var data = await PaginatedResults<object>.QueryDataAsync(source, paginatedParams.PageIndex, paginatedParams.PageSize, total);

            // Results
            var results = new PaginatedContentResults<object>
            {
                TotalPages = data.TotalPages,
                TotalElements = data.TotalElements,
                Number = data.PageIndex,
                Size = data.PageSize,
                NumberOfElements = data.NumberOfElements,
                HasPreviousPage = data.HasPreviousPage,
                HasNextPage = data.HasNextPage,
                First = data.First,
                Last = data.Last,
                Empty = data.Empty,
                Content = data,
            };

            return results;
        }

        ///// <summary>
        ///// Other version
        ///// </summary>
        ///// <param name="source"></param>
        ///// <param name="paginatedParams"></param>
        ///// <returns></returns>
        //protected async Task<dynamic> QueryDataAsync(IEnumerable<object> source, PaginatedInputModel paginatedParams)
        //{
        //    // Filter
        //    if (paginatedParams != null && paginatedParams.FilterParams != null && paginatedParams.FilterParams.Any())
        //        source = FilterUtility.Filter<object>.FilteredData(paginatedParams.FilterParams, source) ?? source;

        //    // Sorting
        //    // Enum.IsDefined(typeof(SortingUtility.SortOrders), paginatedParams.SortingParams.Select(x => x.SortOrder))
        //    if (paginatedParams != null && paginatedParams.SortingParams != null && paginatedParams.SortingParams.Count() > 0)
        //        source = SortingUtility.Sorting<object>.SortData(source, paginatedParams.SortingParams);

        //    // Grouping
        //    if (paginatedParams != null && paginatedParams.GroupingColumns != null && paginatedParams.GroupingColumns.Count() > 0)
        //        source = SortingUtility.Sorting<object>.GroupingData(source, paginatedParams.GroupingColumns) ?? source;

        //    // Paging
        //    var data = await PaginatedResults<object>.QueryDataAsync(source, paginatedParams.PageIndex, paginatedParams.PageSize);

        //    // Results
        //    var results = new PaginatedContentResults<object>
        //    {
        //        TotalPages = data.TotalPages,
        //        TotalElements = data.TotalElements,
        //        Number = data.PageIndex,
        //        Size = data.PageSize,
        //        NumberOfElements = data.NumberOfElements,
        //        HasPreviousPage = data.HasPreviousPage,
        //        HasNextPage = data.HasNextPage,
        //        First = data.First,
        //        Last = data.Last,
        //        Empty = data.Empty,
        //        Content = data,
        //    };

        //    return results;
        //}

        #region Send notifications

        protected void SendNotifications(ActionTypes actionType, string target, string status, string routeKey, List<string> subscribers, dynamic other)
        {
            #region publicer (for c#)

            //var rabbitMqConf = RabbitMqSetting.GetRabbitMqSetting(_configuration);
            //_rabbitManager.Publish(
            //    message: BuildNotiPayload(actionType, target, status, routeKey),
            //    exchangeName: rabbitMqConf.NotiExchange,
            //    exchangeType: ExchangeType.Fanout,
            //    routeKey: routeKey);

            #endregion

            try
            {
                var notification = _userService.BuildNotiPayload(actionType, target, status, routeKey, subscribers, GetUserPayloadFromHeader().Username, other);

                // send msg to j_api
                var api_1 = _configuration[$"{nameof(AppSettings.Properties)}:{nameof(Properties.API1)}"];
                var api_1_endpoint = string.Format($"{api_1}{RequestSegment.NOTIFICATION_SEND_MSG}");
                APIHelper.Post(api_1_endpoint, GetToken(), JsonConvert.SerializeObject(notification), MediaTypeNames.Application.Json, API_METHODS.POST);
            }
            catch (Exception ex)
            {
                Log.Error($"Error Message: {ex.Message}");
                Log.Error($"Error StackTrace: {ex.StackTrace}");
            }
        }

        #endregion
    }
}

﻿using System;

namespace VPBANK.RMD.Data.PhoenixConf.Params
{
    public class CollectionViewLogParam
    {
        public DateTime Business_Date { get; set; }
        public string Segment { get; set; }
        public string Os_Company { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System.Net;
using System;
using Serilog;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Authorization;
using TrackableEntities.Common.Core;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Services.Auth.DataTransferObjects;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Validates;

namespace VPBANK.RMD.API.Auth.Controllers
{
    public class UserController : TrackingController<AuthContext, User, int>
    {
        protected readonly RequestHandler _requestHandler;
        protected readonly IUserRepository _userRepository;
        protected readonly IUserArchivedRepository _userArchivedRepository;
        protected readonly IUserService _userService;

        public UserController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<AuthContext> unitOfWork,
            ITrackableRepository<AuthContext, User, int> trackableRepository,
            IGenericRepository<AuthContext, User, int> genericRepository,

            RequestHandler requestHandler,
            IUserRepository userRepository,
            IUserArchivedRepository userArchivedRepository,
            IUserService userService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestHandler = requestHandler;
            _userRepository = userRepository;
            _userArchivedRepository = userArchivedRepository;
            _userService = userService;
        }

        /// <summary>
        /// Create new record.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="entity"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        public override async Task<ActionResult<User>> Create([Required][NotNull][FromBody] User entity)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entity == null || string.IsNullOrEmpty(entity.Username) || string.IsNullOrEmpty(entity.Email))
                    return BadRequest(ModelState);

                // set tracking state
                entity.TrackingState = TrackingState.Added;

                // validate
                var errors = ValidateUser(entity);
                if (errors.Count > 0)
                    return BadRequest(errors);

                // results
                return await base.Create(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Update exists record.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="id"></param>
        /// <param name="entity"></param>
        /// <returns>A newly updated object</returns>
        /// <response code="200">Returns OK</response>
        /// <response code="400">If the item is null</response>
        /// <response code="404">The item is not found</response>
        [HttpPut(template: "{id}")]
        public override async Task<ActionResult<User>> Update([Required][NotNull][FromRoute] int id, [Required][NotNull][FromBody] User entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null || entity.Pk_Id == 0 || string.IsNullOrEmpty(entity.Username) || string.IsNullOrEmpty(entity.Email))
                    return BadRequest(ModelState);

                var existed = _userService.FindByUsername(entity.Username);
                if (existed == null || existed.Pk_Id != entity.Pk_Id)
                    return NotFound();

                // set tracking state
                entity.TrackingState = TrackingState.Modified;

                // validate
                var errors = ValidateUser(entity);
                if (errors.Count > 0)
                    return BadRequest(errors);

                // save
                _genericRepository.Update(entity);
                var result = await _unitOfWork.SaveChangesAsync();
                if (result == 0)
                    return BadRequest();

                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        private IList<FieldValidateResponse> ValidateUser(User entity)
        {
            var results = new List<FieldValidateResponse>();
            if (!EmailValidate.IsValid(entity.Email))
            {
                results.Add(new FieldValidateResponse
                {
                    Error = string.Format(ErrorMessages.EM141, nameof(entity.Email)),
                    Field = $"{nameof(entity.Email)}",
                    Description = string.Format(ErrorMessages.EM141, nameof(entity.Email))
                });
                return results;
            }
            if (entity.TrackingState == TrackingState.Added)
            {
                var existedUsername = _userService.FindByUsername(entity.Username);
                var existedEmail = _userService.FindByEmail(entity.Email);
                if (existedUsername == null && existedEmail == null)
                    return results;

                if (existedUsername != null && existedEmail != null)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM900,
                        Field = $"{nameof(entity.Username)}",
                        Description = ErrorMessages.EM900
                    });
                    return results;
                }

                if (existedUsername != null && existedUsername.Status == UserStatusConstant.ACTIVE)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9011,
                        Field = $"{nameof(entity.Username)}",
                        Description = ErrorMessages.EM9011
                    });
                    return results;
                }

                if (existedEmail != null && existedEmail.Status == UserStatusConstant.ACTIVE)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9012,
                        Field = $"{nameof(entity.Email)}",
                        Description = ErrorMessages.EM9012
                    });
                    return results;
                }

                if (existedUsername != null && existedUsername.Is_Deleted)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9021,
                        Field = $"{nameof(entity.Username)}",
                        Description = ErrorMessages.EM9021
                    });
                    return results;
                }

                if (existedEmail != null && existedEmail.Is_Deleted)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9022,
                        Field = $"{nameof(entity.Email)}",
                        Description = ErrorMessages.EM9022
                    });
                    return results;
                }
            }
            else
            {
                var existedUsername = _userService.FindByUsernameAndOtherId(entity.Pk_Id, entity.Username);
                var existedEmail = _userService.FindByEmailAndOtherId(entity.Pk_Id, entity.Email);
                if (existedUsername == null && existedEmail == null)
                    return results;

                if (existedUsername != null && existedEmail != null)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM900,
                        Field = $"{nameof(entity.Username)}",
                        Description = ErrorMessages.EM900
                    });
                    return results;
                }

                if (existedUsername != null && existedUsername.Status == UserStatusConstant.ACTIVE)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9011,
                        Field = $"{nameof(entity.Username)}",
                        Description = ErrorMessages.EM9011
                    });
                    return results;
                }

                if (existedEmail != null && existedEmail.Status == UserStatusConstant.ACTIVE)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9012,
                        Field = $"{nameof(entity.Email)}",
                        Description = ErrorMessages.EM9012
                    });
                    return results;
                }

                if (existedUsername != null && existedUsername.Is_Deleted)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9021,
                        Field = $"{nameof(entity.Username)}",
                        Description = ErrorMessages.EM9021
                    });
                    return results;
                }

                if (existedEmail != null && existedEmail.Is_Deleted)
                {
                    results.Add(new FieldValidateResponse
                    {
                        Error = ErrorMessages.EM9022,
                        Field = $"{nameof(entity.Email)}",
                        Description = ErrorMessages.EM9022
                    });
                    return results;
                }
            }

            return results;
        }

        /// <summary>
        /// Delete record.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete(template: "{id}")]
        public override async Task<IActionResult> Delete([Required][NotNull][FromRoute] int id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                if (!await _genericRepository.ExistsAsync(id))
                    return NotFound();
                var user = _userRepository.FindByIdAndIsDeleted(id, false);
                if (user == null)
                    return NotFound();
                var userArchived = _mapper.Map<User, UserArchived>(user);
                userArchived.Modified_By = GetUserPayloadByHeader().Username;
                userArchived.Modified_Date = DateTime.Now;
                _userArchivedRepository.Insert(userArchived);
                _userService.DeleteUserById(id);
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find object by key.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Object</returns>
        [HttpGet(template: "{id}")]
        [AllowAnonymous]
        public override async Task<ActionResult<User>> FindById([Required][NotNull][FromRoute] int id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var entity = await _genericRepository.FindAsync(id);
                if (entity == null) return NotFound();
                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find User by username
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        [HttpGet(template: "{username}")]
        [AllowAnonymous]
        public virtual ActionResult<User> FindByUsername([Required][NotNull][FromRoute] string username)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var entity = _userService.FindByUsername(username);

                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find User by username (object)
        /// </summary>
        /// <param name="userAuthDto"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public virtual ActionResult<User> FindByUsername([Required][NotNull][FromBody] UserAuthDto userAuthDto)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var entity = _userService.FindByUsername(userAuthDto.Username);

                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find all username is supper administrator
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<List<string>> FindBySupperAdmin()
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var usernames = _userService.FindBySupperAdmin();

                return Ok(usernames);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find all emails by all username
        /// </summary>
        /// <param name="usernames"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<List<string>> FindEmailsByUsernames([Required][NotNull][FromBody] List<string> usernames)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                return Ok(_userService.FindEmailsByUsernames(usernames));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find all emails of users active by all username
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<List<string>> FindEmailsActiveByUsernames()
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                return Ok(_userService.FindEmailsByUsernamesActive());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get all usernames not be grant roles (selected_item)
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<List<SelectedItem>> FindByUserNonRole()
        {
            try
            {
                return Ok(_userService.FindByUserNonRole());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find all usernames for selected_item
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual async Task<ActionResult<List<SelectedItem>>> FindUsernames()
        {
            try
            {
                return Ok(await _userService.FindUsernames());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw ex;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// Get by permission by user
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public override async Task<ActionResult<PaginatedContentResults<User>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                return await base.Query(BuildFilterExpressionUser(paginatedParams));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        private PaginatedInputModel BuildFilterExpressionUser(PaginatedInputModel paginatedParams)
        {
            try
            {
                var userAvaiable = $"[Username] NOT IN ('{GetUserPayloadByHeader().Username}') AND [Is_Deleted] = 0";
                paginatedParams.FilterExpression = string.IsNullOrEmpty(paginatedParams.FilterExpression)
                        ? $"{userAvaiable}"
                        : $"{userAvaiable}{ Operations.AND}{ConvertColumnNameToJsonFilter(paginatedParams.FilterExpression, true)}";

                if (paginatedParams.SortingParams != null && paginatedParams.SortingParams.Any())
                    foreach (var item in paginatedParams.SortingParams)
                        item.ColumnName = ConvertColumnNameToJsonFilter(item.ColumnName, false);

                if (paginatedParams.FilterParams != null && paginatedParams.FilterParams.Any())
                    foreach (var item in paginatedParams.FilterParams)
                        item.ColumnName = ConvertColumnNameToJsonFilter(item.ColumnName, false);

                return paginatedParams;
            }
            catch (Exception)
            {
                return paginatedParams;
            }
        }

        private string ConvertColumnNameToJsonFilter(string jsonField, bool isfilterExpression)
        {
            var field = jsonField;
            if (isfilterExpression)
            {
                field = jsonField.Replace("id", "Pk_Id").Replace("displayName", "Display_Name").Replace("superRole", "Super_Role").Replace("isDeleted", "Is_Deleted")
                    .Replace("createdDate", "Created_Date").Replace("createUser", "Create_User").Replace("modifiedDate", "Modified_Date")
                    .Replace("modifiedBy", "Modified_By").Replace("lastLogin", "Last_Login");
            }
            else
            {
                switch (jsonField.ToLower())
                {
                    case "id":
                        field = "Pk_Id";
                        break;
                    case "displayname":
                        field = "Display_Name";
                        break;
                    case "superrole":
                        field = "Super_Role";
                        break;
                    case "isdeleted":
                        field = "Is_Deleted";
                        break;
                    case "createddate":
                        field = "Created_Date";
                        break;
                    case "createuser":
                        field = "Create_User";
                        break;
                    case "modifieddate":
                        field = "Modified_Date";
                        break;
                    case "modifiedby":
                        field = "Modified_By";
                        break;
                    case "lastlogin":
                        field = "Last_Login";
                        break;
                }
            }
            return field;
        }
    }
}
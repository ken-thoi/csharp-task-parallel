﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;

using Serilog;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Wfs;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Helpers;
using VPBANK.RMD.Utils.Notification.Publisher;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Wfs
{
    public class WfUiController : GenericController<IFRS9_ConfContext, Task, int>
    {
        private readonly ITaskService _taskService;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfStatus, int> _genConfStatusRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfTaskType, int> _genConfTaskTypeRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, ConfScreenTask, int> _genConfScreenTaskRepository;

        public WfUiController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            ITaskService taskService,
            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, Task, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, Task, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, ConfStatus, int> genConfStatusRepository,
            IGenericRepository<IFRS9_ConfContext, ConfTaskType, int> genConfTaskTypeRepository,
            IGenericRepository<IFRS9_ConfContext, ConfScreenTask, int> genConfScreenTaskRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _taskService = taskService;

            _genConfStatusRepository = genConfStatusRepository;
            _genConfTaskTypeRepository = genConfTaskTypeRepository;
            _genConfScreenTaskRepository = genConfScreenTaskRepository;
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetTasksDropdown()
        {
            try
            {
                return Ok(_taskService.GetTasksDropdownBox(false));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetConfTaskTypesDropdown()
        {
            try
            {
                return Ok(_genConfTaskTypeRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => !c.Is_Deleted)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Task_Type_Code,
                        Val = c.Task_Type_Name
                    })
                    .OrderBy(c => c.Val)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetConfScreenTasksDropdown()
        {
            try
            {
                return Ok(_genConfScreenTaskRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => !c.Is_Deleted)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Screen_Code,
                        Val = $"{c.Screen_Name} ({c.Screen_Code})"
                    })
                    .OrderBy(c => c.Val)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get status dropdown for Flow, Task, Job
        /// </summary>
        /// <param name="type">FLOW, TASK, JOB</param>
        /// <returns></returns>
        [HttpGet("{type}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetConfStatusDropdown([Required][NotNull][FromRoute] string type)
        {
            try
            {
                if (string.IsNullOrEmpty(type)) return null;

                return Ok(_genConfStatusRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Status_Type.Equals(type, StringComparison.CurrentCultureIgnoreCase) && !c.Is_Deleted)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Status_Code,
                        Val = c.Status_Name
                    })
                    .OrderBy(c => c.Val)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get status dropdown for Flow
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiConfFlowStatus()
        {
            try
            {
                return Ok(_genConfStatusRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Status_Type.Equals("FLOW", StringComparison.CurrentCultureIgnoreCase) && !c.Is_Deleted)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Status_Code,
                        Val = c.Status_Name
                    })
                    .OrderBy(c => c.Val)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get status dropdown for Task
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiConfTaskStatus()
        {
            try
            {
                return Ok(_genConfStatusRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Status_Type.Equals("TASK", StringComparison.CurrentCultureIgnoreCase) && !c.Is_Deleted)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Status_Code,
                        Val = c.Status_Name
                    })
                    .OrderBy(c => c.Val)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get status dropdown for Job
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiConfJobStatus()
        {
            try
            {
                return Ok(_genConfStatusRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Status_Type.Equals("JOB", StringComparison.CurrentCultureIgnoreCase) && !c.Is_Deleted)
                    .Select(c => new SelectedItem
                    {
                        Key = c.Status_Code,
                        Val = c.Status_Name
                    })
                    .OrderBy(c => c.Val)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get status dropdown for Request
        /// </summary>
        /// <param name="type">REQUEST</param>
        /// <param name="isApprove">REQUEST</param>
        /// <returns></returns>
        [HttpGet("{type}/approve/{isApprove}")]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetConfReqStatusDropdown([Required][NotNull][FromRoute] string type, [Required][NotNull][FromRoute] bool isApprove)
        {
            try
            {
                if (string.IsNullOrEmpty(type) || !type.Equals(ActionTypes.REQUEST.ToDescription(), StringComparison.CurrentCultureIgnoreCase)) return null;

                if (isApprove)
                    return Ok(_genConfStatusRepository
                        .Queryable()
                        .AsEnumerable()
                        .Where(c => c.Status_Type.Equals(type, StringComparison.CurrentCultureIgnoreCase) && !c.Is_Deleted && !c.Status_Code.Equals(IfrsRequestStatus.PENDING, StringComparison.CurrentCultureIgnoreCase))
                        .Select(c => new SelectedItem
                        {
                            Key = c.Status_Code,
                            Val = c.Status_Name
                        })
                        .OrderBy(c => c.Val)
                        .Distinct()
                        .ToList());
                else
                    return Ok(_genConfStatusRepository
                        .Queryable()
                        .AsEnumerable()
                        .Where(c => c.Status_Type.Equals(type, StringComparison.CurrentCultureIgnoreCase) && !c.Is_Deleted)
                        .Select(c => new SelectedItem
                        {
                            Key = c.Status_Code,
                            Val = c.Status_Name
                        })
                        .OrderBy(c => c.Val)
                        .Distinct()
                        .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get gui list flag for cashflow
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiCashflowListFlag()
        {
            try
            {
                return new List<SelectedItem> {
                    new SelectedItem
                    {
                        Key = "Y",
                        Val = "Inputted"
                    },
                    new SelectedItem
                    {
                        Key = "N",
                        Val = "Default"
                    }
                };
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Get gui action flag for ILLP customer list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiIllpCustomerActionFlag()
        {
            try
            {
                return new List<SelectedItem> {
                    new SelectedItem
                    {
                        Key = "Y",
                        Val = "Add"
                    },
                    new SelectedItem
                    {
                        Key = "N",
                        Val = "Delete"
                    }
                };
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

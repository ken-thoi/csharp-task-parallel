﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Views.Core
{
    [Table("view_IFRS_INIT_Contract", Schema = "Core")]
    public class ViewIfrsInitContract : EntityBase<long>
    {
        [Key]
        public override long Pk_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
    }
}

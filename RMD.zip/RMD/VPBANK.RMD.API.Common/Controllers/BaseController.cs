﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Memory;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http.Extensions;
using AutoMapper;
using System.Net.Mime;
using Serilog;
using Newtonsoft.Json;
using System.Threading.Tasks;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Common.Extensions;
using VPBANK.RMD.Utils.Security.Models;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Filters;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Notification;
using VPBANK.RMD.Utils.Common.Helpers;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.Datas;

namespace VPBANK.RMD.API.Common.Controllers
{
    [ApiController]
    [ApiVersion(ApiKeys.API_VERSION, Deprecated = true)]
    [AddHeader(ApiKeys.API_AUTHOR_HEADER, ApiKeys.API_AUTHOR)]
    [Route(template: ApiKeys.ROUTE_TEMPLATE)]
    [Produces(typeof(IActionResult))]
    [Consumes(MediaTypeNames.Application.Json)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public class BaseController : ControllerBase
    {
        protected readonly IMemoryCache _memoryCache;
        protected readonly IConfiguration _configuration;
        protected readonly IWebHostEnvironment _env;
        protected readonly IAppSettingsReader _appSettings;
        protected readonly IHttpClientFactory _httpClientFactory;
        protected readonly IMapper _mapper;
        protected readonly IRabbitMqPublisher _rabbitManager;
        protected readonly ISubscriberInfoRepository _subscriberRepository;

        public BaseController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository)
        {
            _memoryCache = memoryCache;
            _configuration = configuration;
            _env = env;
            _appSettings = appSettings;
            _httpClientFactory = httpClientFactory;
            _mapper = mapper;
            _rabbitManager = rabbitManager;
            _subscriberRepository = subscriberRepository;
        }

        protected Dictionary<string, string> GetConfig()
        {
            var result = new Dictionary<string, string>();

            // get data config from app setting
            var configs = _configuration
                .GetSection(nameof(AppSettings.ConnectionStrings))
                .AsEnumerable()
                .Where(x => x.Key != nameof(AppSettings.ConnectionStrings))
                // Since we are enumerating the root, each key will be prefixed with our target section, so we need to strip that prefix off.
                .ToDictionary(x => x.Key, x => x.Value);

            foreach (var config in configs)
                result.Add(config.Key, config.Value);

            result.Add("Key", "Value");

            return result;
        }

        protected void SetTokenCookie(string key, string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddDays(7)
            };
            Response.Cookies.Append(key, token, cookieOptions);
        }

        protected string GetToken()
        {
            try
            {
                if (!Request.Headers.TryGetValue(ApiKeys.X_AUTH_TOKEN, out var apiKeyHeaderValues)) return null;
                if (apiKeyHeaderValues.Count == 0) return null;
                var token = apiKeyHeaderValues.FirstOrDefault();
                if (string.IsNullOrWhiteSpace(token)) return null;
                return token;
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected UserPayload GetUserPayload()
        {
            try
            {
                return SessionHelper.Get<UserPayload>(HttpContext.Session, SESSION_KEYS.USER_PAYLOAD);
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected string GetFullUri()
        {
            try
            {
                var uri = Request.GetDisplayUrl();
                Log.Information(uri);
                return $"{Request.Scheme}://{Request.Host}{Request.Path}{Request.QueryString}";
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected string GetPathUri()
        {
            try
            {
                return $"/{Request.Path}";
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected string GetBaseUri()
        {
            try
            {
                return $"{Request.Scheme}://{Request.Host}";
            }
            catch (Exception ex)
            {
                string mess = ex.Message;
                if (ex.InnerException != null)
                    mess += $"{SpecificSystems.PILE}Inner Exception: " + ex.InnerException.Message;
                throw new Exception("API ERROR: " + mess + $"{SpecificSystems.PILE}API URL: " + Request.GetDisplayUrl());
            }
        }

        protected async Task<PaginatedContentResults<object>> SqlQueryDataAsync(int total, IEnumerable<object> source, PaginatedInputModel paginatedParams)
        {
            // Filters & Sorting by SQL
            Log.Information($"FilterExpression: {paginatedParams.FilterExpression}");

            // Paging
            var data = await PaginatedResults<object>.QueryDataAsync(source, paginatedParams.PageIndex, paginatedParams.PageSize, total);

            // Results
            var results = new PaginatedContentResults<object>
            {
                TotalPages = data.TotalPages,
                TotalElements = data.TotalElements,
                Number = data.PageIndex,
                Size = data.PageSize,
                NumberOfElements = data.NumberOfElements,
                HasPreviousPage = data.HasPreviousPage,
                HasNextPage = data.HasNextPage,
                First = data.First,
                Last = data.Last,
                Empty = data.Empty,
                Content = data,
            };

            return results;
        }

        protected async Task<dynamic> QueryDataAsync(IEnumerable<object> source, PaginatedInputModel paginatedParams)
        {
            // Filter
            if (paginatedParams != null && paginatedParams.FilterParams != null && paginatedParams.FilterParams.Any())
                source = FilterUtility.Filter<object>.FilteredData(paginatedParams.FilterParams, source) ?? source;

            // Sorting
            // Enum.IsDefined(typeof(SortingUtility.SortOrders), paginatedParams.SortingParams.Select(x => x.SortOrder))
            if (paginatedParams != null && paginatedParams.SortingParams != null && paginatedParams.SortingParams.Count() > 0)
                source = SortingUtility.Sorting<object>.SortData(source, paginatedParams.SortingParams);

            // Grouping
            if (paginatedParams != null && paginatedParams.GroupingColumns != null && paginatedParams.GroupingColumns.Count() > 0)
                source = SortingUtility.Sorting<object>.GroupingData(source, paginatedParams.GroupingColumns) ?? source;

            // Paging
            var data = await PaginatedResults<object>.QueryDataAsync(source, paginatedParams.PageIndex, paginatedParams.PageSize);

            // Results
            var results = new PaginatedContentResults<object>
            {
                TotalPages = data.TotalPages,
                TotalElements = data.TotalElements,
                Number = data.PageIndex,
                Size = data.PageSize,
                NumberOfElements = data.NumberOfElements,
                HasPreviousPage = data.HasPreviousPage,
                HasNextPage = data.HasNextPage,
                First = data.First,
                Last = data.Last,
                Empty = data.Empty,
                Content = data,
            };

            return results;
        }

        #region Send notifications

        protected void SendNotifications(ActionTypes actionType, string target, string status, string routeKey, List<string> subscribers)
        {
            try
            {
                var notification = BuildNotiPayload(actionType, target, status, routeKey, subscribers);

                #region publicer

                //var rabbitMqConf = RabbitMqSetting.GetRabbitMqSetting(_configuration);
                //_rabbitManager.Publish(
                //    message: BuildNotiPayload(actionType, target, status, routeKey),
                //    exchangeName: rabbitMqConf.NotiExchange,
                //    exchangeType: ExchangeType.Fanout,
                //    routeKey: routeKey);

                #endregion

                // send msg to j_api
                var jApi = _configuration[nameof(AppSettings.ApiUri_Jav)];
                var jSendNotiEndPoint = string.Format($"{jApi}{RequestSegment.NOTIFICATION_SEND_MSG}");
                APIHelper.Post(jSendNotiEndPoint, GetToken(), JsonConvert.SerializeObject(notification), MediaTypeNames.Application.Json, API_METHODS.POST);
            }
            catch (Exception ex)
            {
                Log.Error($"Error Message: {ex.Message}");
                Log.Error($"Error StackTrace: {ex.StackTrace}");
            }
        }

        protected Notification BuildNotiPayload(ActionTypes actionType, string target, string status, string routeKey, List<string> subscribers)
        {
            string msg = string.Empty;
            var type = string.Empty;
            var time = DateTime.Now.ToString(DefFormats.DATETIME_FORMAT);
            var username = GetUserPayload().Username;
            try
            {
                switch (actionType)
                {
                    case ActionTypes.REQUEST:
                        type = ActionTypes.REQUEST.ToDescription();
                        msg = string.Format($"A pending for approval from {username} on table {target} at {time}");
                        break;
                    case ActionTypes.APPROVAL:
                        type = ActionTypes.APPROVAL.ToDescription();
                        msg = string.Format($"Changed on table {target} is {status} by {username} at {time}");
                        break;
                    case ActionTypes.CANCEL:
                        type = ActionTypes.CANCEL.ToDescription();
                        msg = string.Format($"A request pending for approval on table {target} changed {status} by {username} at {time}");
                        break;
                    case ActionTypes.REJECT:
                        type = ActionTypes.REJECT.ToDescription();
                        msg = string.Format($"A request pending for approval on table {target} changed {status} by {username} at {time}");
                        break;
                    case ActionTypes.BATCH_EXEC:
                    case ActionTypes.JOB_EXEC:
                    case ActionTypes.ARCHIVE:
                    case ActionTypes.BATCH_JOB_MONITOR:
                        break;
                    case ActionTypes.UPLOAD:
                        type = ActionTypes.UPLOAD.ToDescription();
                        msg = string.Format($"A pending for approval from {username} on upload file manual at {time}");
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Log.Error($"Error Message: {ex.Message}");
                Log.Error($"Error StackTrace: {ex.StackTrace}");
                msg = ex.Message;
            }

            var notification = new Notification
            {
                id = Guid.NewGuid().ToString(),
                recvTime = DateTime.UtcNow,
                type = type,
                messageType = MESSAGE_TYPE.INFO,
                routingKey = routeKey,
                receiver = subscribers.ToArray(),
                payload = msg,
                extractInfo = new Dictionary<string, object>()
            };

            return notification;
        }

        #endregion
    }
}

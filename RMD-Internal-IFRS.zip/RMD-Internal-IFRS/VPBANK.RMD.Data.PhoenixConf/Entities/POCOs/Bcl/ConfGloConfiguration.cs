﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl
{
    [Table("Conf_Glo_Configuration", Schema = "BCL")]
    public class ConfGloConfiguration : EntityBase<decimal>
    {
        [Key]
        public override decimal Pk_Id { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime End_Date { get; set; }
        public string Param_Name { get; set; }
        public string Param_Desc { get; set; }
        public string Param_Value { get; set; }
        public string Value_Desc { get; set; }
        public DateTime? Created_Dt { get; set; }
        public DateTime? Updated_Dt { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using System.Net;
using System.Net.Http;
using AutoMapper;
using Serilog;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.AuditLog;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.AuditLog.Models;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Common.Controllers.Base
{
    [Authorize]
    public class NotiController : BaseController
    {
        private INotiElasticProvider<NotificationHistory> _notiElasticProvider;
        private INotificationService _notificationService;

        public NotiController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            INotiElasticProvider<NotificationHistory> notiElasticProvider,
            INotificationService notificationService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService)
        {
            _notiElasticProvider = notiElasticProvider;
            _notificationService = notificationService;
        }

        /// <summary>
        /// Query find notification from elasticsearch, search by session user logined, no filters, has paginated
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Query([FromBody] PaginatedInputModel paginatedParams)
        {
            if (paginatedParams == null)
                return null;

            var param = new ElasticSearchPaging
            {
                From = paginatedParams.PageIndex,
                Size = paginatedParams.PageSize,
                Filters = GetUserPayload().Username
            };

            try
            {
                return Ok(await GetHistories(paginatedParams, param));
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("invalid_alias_name_exception", StringComparison.CurrentCultureIgnoreCase))
                    return Ok(await GetHistories(paginatedParams, param));
                return null;
            }
        }

        private async Task<PaginatedContentResults<object>> GetHistories(PaginatedInputModel paginatedParams, ElasticSearchPaging param)
        {
            try
            {
                var data = await _notiElasticProvider.QueryAuditLogsAsync(param);
                param.From = 0;
                param.Size = 10000;

                var total = await _notiElasticProvider.CountAsync(param);
                dynamic result = await GenericQueryResultAsync(Convert.ToInt32(total), data, paginatedParams, false);
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Get number notification unread.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<int> UnreadAmount()
        {
            try
            {
                var username = GetUserPayloadFromHeader().Username;
                var count = _notificationService.GetNotiCount(username);
                return Ok(count);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
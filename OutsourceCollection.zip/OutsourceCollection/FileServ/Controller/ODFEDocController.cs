﻿using Entities;
using HtmlAgilityPack;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace FileServ.Controller
{
    public static class ODFEDocController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private static object _lockGetCustDoc = new object();
        private static IWebDriver masterDriver = null;
        private static Source source = null;
        private static bool isSessionValid = true;

        public static void RunIDLEDownload()
        {
            logger.Info("------ START RunIDLEDownload OD FECredit Compenent ------");
            source = SourceController.GetSource("od.fecredit.com.vn");
            Executed(true);
        }

        private static void Executed(bool isMultiThread = false)
        {
            if(isMultiThread)
            {
                List<Task> listWorkingTask = new List<Task>();

                Task.Factory.StartNew(() =>
                {
                    while (true)
                    {
                        if (!isSessionValid)
                        {
                            Thread.Sleep(60000);
                            logger.Info("Auto Login routine check discover Invalid Session. Start clear Object and re-login");
                            ForceClearReLogin();
                            isSessionValid = true;
                        }

                        if (masterDriver == null)
                            ODFELoginToSystemBySelenium();
                        else
                            Thread.Sleep(1000);
                    }
                });

                while (true)
                {
                    if (listWorkingTask.Count < 1) //source.NumberOfProcess && masterDriver != null && isSessionValid)
                    {
                        lock (listWorkingTask)
                        {
                            var task = new Task(() =>
                            {
                                {
                                    var custDoc = GetIDLEDoc;
                                    if (custDoc == null)
                                    {
                                        logger.Info("Not found any new document to download on OD FECredit, sleep for 60 seconds");
                                        Thread.Sleep(5000);
                                    }
                                    else
                                        ODFEFindDocument(custDoc, true);
                                }
                            });
                            task.ContinueWith(t =>
                            {
                                lock (listWorkingTask)
                                    listWorkingTask.Remove(task);
                            });
                            listWorkingTask.Add(task);
                            task.Start();
                        }
                    }
                    else
                        Thread.Sleep(1000);
                }
            }
            else
            {
                while (true)
                {
                    {
                        var custDoc = GetIDLEDoc;
                        if(custDoc == null)
                        {
                            logger.Info("Not found any new document to download on OD FECredit, sleep for 60 seconds");
                            Thread.Sleep(60000);
                            continue;
                        }
                        else
                            ODFEFindDocument(custDoc, false);
                    }
                }
            }
        }

        private static bool isThisTimeIsIDLETime
        {
            get
            {
                int startHour = Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "OD_START_HOUR"));
                int endHour = Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "OD_END_HOUR"));
                TimeSpan start = new TimeSpan(startHour, 0, 0);
                TimeSpan end = new TimeSpan(endHour, 0, 0);
                TimeSpan now = DateTime.Now.TimeOfDay;
                if (start < end)
                    return start <= now && now <= end;
                return !(end < now && now < start);
            }
        }

        public static CustomerDocument GetIDLEDoc
        {
            get
            {
                lock (_lockGetCustDoc)
                {
                    string command = "[FileServ].[CustomerDocument_Get_To_Process]";
                    DataTable dt = new DataTable();
                    Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FK_Source", source.Id) });
                    if (dt.Rows.Count == 0)
                        return null;
                    else
                        return Utils.UtilFunction.CreateItemFromRow<CustomerDocument>(dt.Rows[0]);
                }
            }
        }

        public static ChromeOptions chromeOptions
        {
            get
            {
                string path = CurrentTempDownloadFolder;
                string path_profile = CurrentTempCacheFolder;
                Directory.CreateDirectory(path);
                if(Directory.Exists(path_profile))
                    Directory.Delete(path_profile, true);
                Directory.CreateDirectory(path_profile);
                var chromeOptions = new ChromeOptions();
                chromeOptions.AddUserProfilePreference("download.default_directory", path);
                chromeOptions.AddArgument($"user-data-dir={path_profile}");
                chromeOptions.AddArgument("--safebrowsing-disable-download-protection");
                chromeOptions.AddUserProfilePreference("safebrowsing.enabled", false);
                chromeOptions.AddUserProfilePreference("download.prompt_for_download", false);
                chromeOptions.AddUserProfilePreference("disable-popup-blocking", true);
                chromeOptions.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1);
                chromeOptions.AddArgument("incognito");
                return chromeOptions;
            }
        }

        public static string CurrentTempDownloadFolder
        {
            get
            {
                return Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "TEMP_DOWNLOAD"), "2.OD_FE_TempDownload");
            }
        }

        public static string CurrentTempCacheFolder
        {
            get
            {
                return Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "CACHE"), "2.OD_FE_TempDownload");
            }
        }

        private static void ForceClearReLogin()
        {
            if(masterDriver != null)
            {
                masterDriver.Quit();
                masterDriver.Dispose();
                masterDriver = null;
                Thread.Sleep(1000);
            }
        }

        public static void ODFELoginToSystemBySelenium()
        {
            while (true)
            {
                if (masterDriver != null)
                {
                    IWebElement loginCheck = CheckLogin(masterDriver as ChromeDriver);
                    if (loginCheck != null)
                    {
                        return;
                    }
                }

                var driver = new ChromeDriver(chromeOptions);
                driver.Manage().Cookies.DeleteAllCookies();
                try
                {
                    driver.Navigate().GoToUrl("https://od.fecredit.com.vn/omnidocs/dist/#/web");
                    var account = driver.FindElement(By.Id("userName"));
                    account.SendKeys(source.Username);
                    var password = driver.FindElement(By.Name("password"));
                    password.SendKeys(source.Password);
                    Thread.Sleep(1000);
                    DoClickAction(driver, "/html/body/app-root/omnidocs-web-router/omnidocs-login/div/div/div[2]/div/div[2]/div/div[2]/button");
                    Thread.Sleep(1000);
                    try
                    {
                        var notifi = driver.FindElement(By.XPath("/html/body/app-root/omnidocs-web-router/omnidocs-login/div/div/div[2]/div/div[2]/div/div[2]/p"));
                        Thread.Sleep(1000);
                        DoClickAction(driver, "/html/body/app-root/omnidocs-web-router/omnidocs-login/div/div/div[2]/div/div[2]/div/div[3]/button[1]");
                    }
                    catch (Exception)
                    {

                    }
                    IWebElement loginCheck = CheckLogin(driver);

                    if (loginCheck == null)
                    {
                        driver.Quit();
                        continue;
                    }

                    masterDriver = driver;
                    isSessionValid = true;
                    break;
                }
                catch (Exception)
                {
                    driver.Quit();
                }
            }
        }

        private static IWebElement CheckLogin(ChromeDriver driver)
        {
            int count = 25;
            while (count > 0)
            {
                try
                {
                    return driver.FindElement(By.Id("searchBreadcrumbDocumentUpload"));
                }
                catch (Exception)
                {
                    count--;
                    Thread.Sleep(200);
                }
            }

            return null;
        }

        public static void ODFEFindDocument(CustomerDocument custDoc, bool isMultiThread)
        {
            string processID = Guid.NewGuid().ToString();
            int countFailed = 5;
            while (countFailed > 0)
            {
                try
                {
                    if(!isSessionValid)
                    {
                        countFailed = 5;
                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": PAUSE. Because do not have valid session to process. Re-try after 10 seconds");
                        Thread.Sleep(1000);
                        continue;
                    }

                    var driver = masterDriver;
                    Dictionary<string, string> dictQuery = null;

                    try
                    {
                        dictQuery = SearchParamDocByDocumnetId(driver, custDoc.DocumentID);

                        if (dictQuery.Count == 0)
                        {
                            logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + ". ContractID: " + custDoc.ContractNumber + " Not found any document");
                            custDoc.Status = CustomerDocumentStatus.NotFoundAnyFile;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            countFailed--;
                            break;
                        }
                    }
                    catch (Exception)
                    {
                        custDoc.Status = CustomerDocumentStatus.SearchDocumentError;
                        custDoc.Priority -= 10;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        throw;
                    }

                    Dictionary<string, List<HtmlNode>> lstChildFolder = new Dictionary<string, List<HtmlNode>>();
                    foreach (var item in dictQuery)
                    {
                        var listFile = ListDocByDocumnetId(driver, custDoc, item.Value);
                        lstChildFolder.Add(item.Key, listFile);
                    }

                    List<Task> listWorkingTask = new List<Task>();
                    List<FileDownload> listFileDownload = new List<FileDownload>();
                    foreach(var childDirectory in lstChildFolder)
                    {
                        foreach(var fileNode in childDirectory.Value)
                        {
                            var listTd = fileNode.Descendants("td").ToArray();
                            FileDownload file = new FileDownload();
                            file.OriginalFileName = Utils.UtilFunction.RemoveInvalidCharsFileName(Utils.UtilFunction.CleanText(listTd[1].InnerText));
                            file.TempFileName = Guid.NewGuid().ToString();
                            file.FK_CustomerDocument = custDoc.Id;
                            file.ProcessTime = DateTime.Now;
                            file.Status = FileStatus.NotFound;
                            file.exID = Utils.UtilFunction.CleanText(listTd[3].InnerText);
                            file.Destination = Path.Combine(custDoc.FilePackageName, childDirectory.Key, file.OriginalFileName);
                            DocumentType tmpDoc = new DocumentType();
                            tmpDoc.FK_Source_Id = source.Id;
                            tmpDoc.DocumentName = Utils.UtilFunction.CleanText(listTd[1].InnerText);
                            var urlToDownload = listTd[7].Descendants("a").FirstOrDefault().GetAttributes("href").FirstOrDefault().Value;
                            var docType = DocumentTypeController.GetDocumentType(tmpDoc);
                            file.FK_DocumentType = docType.Id;
                            if (string.IsNullOrEmpty(file.OriginalFileName))
                            {
                                file.Status = FileStatus.OrgNameIsEmpty;
                                FileDownloadController.UpdateFileDownload(file);
                                logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Because file do not having name");
                                continue;
                            }
                            listFileDownload.Add(file);

                            if (docType.AllowToDownload)
                            {
                                //DownloadFile(processID, childDirectory.Key, custDoc, driver, file, urlToDownload);

                                listWorkingTask.Add(Task.Factory.StartNew(() =>
                                {
                                    DownloadFile(processID, childDirectory.Key, custDoc, driver, file, urlToDownload);
                                }));
                            }
                        }
                    }

                    var waitResult = Task.WaitAll(listWorkingTask.ToArray(), GetDownloadTimeout);
                    
                    if(!waitResult && !custDoc.IgnoreErrorFile)
                    {
                        custDoc.Status = CustomerDocumentStatus.DownloadingError;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        Thread.Sleep(300000);
                        throw new Exception("File Download Timeout, remain coutn failed: " + countFailed);
                    }

                    if ((listFileDownload.Where(x => x.Status != FileStatus.Verified).Count() > 0 && !custDoc.IgnoreErrorFile)
                         || listFileDownload.Where(x => x.Status != FileStatus.Verified).Count() == listFileDownload.Count)
                    {
                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + ". ContractID: " + custDoc.ContractNumber + " Not found any document");
                        custDoc.Status = CustomerDocumentStatus.DownloadingError;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        countFailed--;
                        break;
                    }

                    if (listFileDownload.Count == 0)
                    {
                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + ". ContractID: " + custDoc.ContractNumber + " Not found any document");
                        custDoc.Status = CustomerDocumentStatus.NotFoundAnyFile;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        countFailed--;
                        break;
                    }

                    var storagePath = Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "STORAGE"), custDoc.FilePackageName);
                    if (Directory.Exists(storagePath))
                        Directory.Delete(storagePath, true);

                    foreach(var item in lstChildFolder)
                    {
                        var storagePathByOpt = Path.Combine(storagePath, item.Key);
                        Directory.CreateDirectory(storagePathByOpt);
                    }
                                        
                    foreach (var file in listFileDownload)
                    {
                        if (file.Status != FileStatus.Verified)
                            continue;

                        var actualFilename = file.OriginalFileName;
                        var newFilename = Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "STORAGE"), file.Destination);
                        int countFileName = 0;
                        while (true)
                        {
                            if (!File.Exists(newFilename))
                                break;
                            else
                            {
                                countFileName++;
                                actualFilename = file.OriginalFileName.Replace("." + file.OriginalFileName.Split('.').LastOrDefault(), string.Empty) + " (" +
                                        countFileName + ")." + file.OriginalFileName.Split('.').LastOrDefault();
                                file.Destination = file.Destination.Replace("\\" + file.OriginalFileName , "\\" + actualFilename);
                                newFilename = Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "STORAGE"), file.Destination);
                            }
                        }

                        while (true)
                        {
                            File.Copy(Path.Combine(CurrentTempDownloadFolder, file.TempFileName), newFilename, true);
                            var destchecksum = Utils.UtilFunction.CalculateMD5FromFile(newFilename);
                            if (destchecksum.Equals(file.MD5Checksum))
                            {
                                File.Delete(Path.Combine(CurrentTempDownloadFolder, file.TempFileName));
                                break;
                            }
                        }
                        file.Status = FileStatus.MovingToStorage;
                        FileDownloadController.UpdateFileDownload(file);
                    }
                    custDoc.Status = CustomerDocumentStatus.Downloaded;
                    CustDocController.UpdateCustDocStatus(custDoc);

                    break;
                }
                catch (Exception ex)
                {
                    countFailed--;
                    logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Process failed count" + (10 - countFailed));
                    logger.Error(ex);
                }
            }
        }

        private static int GetDownloadTimeout
        {
            get
            {
                return Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "ODFE_CUST_DOC_TIME_OUT"));
            }
        }

        private static Dictionary<string, string> SearchParamDocByDocumnetId(IWebDriver driver, string searchstring)
        {
            string url = string.Format("https://od.fecredit.com.vn/VPBank/DocUploadAppList.jsp?BatchNo=1&searchstring={0}", HttpUtility.UrlEncode(searchstring));
            var js = @" var result = null;
                        var xhr = new XMLHttpRequest();
                        xhr.open('GET', '<<URL>>', false);
                        xhr.onloadend = function (event) {
                            result = (xhr.response);	                        
                        }
                        xhr.send(); 
                        return result;
                      ";
            js = js.Replace("<<URL>>", url);
            var result = Convert.ToString(((IJavaScriptExecutor)driver).ExecuteScript(js));
            if (result.IndexOf("error.jsp?error=Invalid Session. Please Relogin.&sessionStatus=N") > 0)
            {
                string error = "OD FECredit session is timeout";
                logger.Error(error);
                isSessionValid = false;
                throw new Exception(error);
            }
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(result);
            var listChildFolder = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("class", "").Equals("EWLabelGrey")).ToList();
            Dictionary<string, string> dictUrl = new Dictionary<string, string>();
            foreach(var item in listChildFolder)
            {
                var urltmp = Convert.ToString(item.Descendants("a").FirstOrDefault().GetAttributes("href").FirstOrDefault().Value);
                string key = System.Web.HttpUtility.ParseQueryString(urltmp)["modName"];
                dictUrl.Add(key, urltmp);
            }
            return dictUrl;
        }

        private static List<HtmlNode> ListDocByDocumnetId(IWebDriver driver, CustomerDocument custDoc, string searchstring)
        {
            string url = string.Format("https://od.fecredit.com.vn/VPBank/{0}", searchstring);
            var js = @" var result = null;
                        var xhr = new XMLHttpRequest();
                        xhr.open('GET', '<<URL>>', false);
                        xhr.onloadend = function (event) {
                            result = (xhr.response);	                        
                        }
                        xhr.send(); 
                        return result;
                      ";
            js = js.Replace("<<URL>>", url);
            var result = Convert.ToString(((IJavaScriptExecutor)driver).ExecuteScript(js));
            if(result.IndexOf("error.jsp?error=Invalid Session. Please Relogin.&sessionStatus=N") > 0)
            {
                string error = "OD FECredit session is timeout";
                logger.Error(error);
                isSessionValid = false;
                throw new Exception(error);
            }
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(result);
            var listChildFolder = doc.DocumentNode.Descendants("tr").Where(node => node.InnerHtml.ToLower().Contains("class='ewtablecontents'"))//.ToList();
            .Where(node => !"null".Equals(node.Descendants("td").ToArray()[3].InnerText.ToLower().Trim()))
            .Where(node => custDoc.DocumentID.Equals(node.Descendants("td").ToArray()[0].InnerText.ToLower().Trim())).ToList();
            return listChildFolder;
        }

        private static string ExcuteGetExt(IWebDriver driver, string urlPart)
        {
            string url = string.Format("https://od.fecredit.com.vn/{0}", urlPart);
            var js = @" console.log('Get HEADER: <<URL>>');
                        var orgFileName = null;
                        var xhr = new XMLHttpRequest();
                        xhr.open('HEAD', '<<URL>>', true);
                        xhr.onloadend = function (event) {
	                        orgFileName = (xhr.getResponseHeader('content-disposition'));
                        }
                        xhr.send();
                        console.log('Get HEADER value:' + orgFileName);
                        return (orgFileName);";
            js = js.Replace("<<URL>>", url);
            var result = Convert.ToString(((IJavaScriptExecutor)driver).ExecuteScript(js));
            return result;
        }

        private static void ExcuteDownload(IWebDriver driver, string fileTempName, string urlPart)
        {
            string url = string.Format("https://od.fecredit.com.vn/{0}", urlPart);
            var js = @" var xhr = new XMLHttpRequest();
                        xhr.open('GET', '<<URL>>', true);
                        xhr.responseType = 'blob';
                        xhr.onloadend = function (event) {
	                         if (this.status == 200) {
		                        blob = new Blob([xhr.response], { type: 'application/octet-stream' });
		                        var link = document.createElement('a');
		                        link.href = window.URL.createObjectURL(blob);
                                var fileType = xhr.getResponseHeader('Content-Disposition').split('filename=').slice(-1).pop().split('.').slice(-1).pop().replace('<<DOUBLE_QUOTE>>', '');
                                link.download = '<<TMP_FILE_NAME>>.' + fileType;
		                        link.click();
	                        } else {
	                        }
                        }
                        xhr.send();";
            js = js.Replace("<<URL>>", url);
            js = js.Replace("<<TMP_FILE_NAME>>", fileTempName);
            js = js.Replace("<<DOUBLE_QUOTE>>", "\\\"");
            ((IJavaScriptExecutor)driver).ExecuteScript(js);
        }

        private static void DownloadFile(string processID, string childFolder, CustomerDocument custDoc, IWebDriver driver, FileDownload file, string urlToDownload)
        {
            var path = string.Empty;
            int count = 5;
            while (count > 0)
            {
                try
                {
                    if (!isSessionValid)
                    {
                        logger.Error(processID + "| Process on File: " + file.OriginalFileName + " with DocumentID: " + custDoc.DocumentID + ": PAUSE. Because do not have valid session to process. Re-try after 10 seconds");
                        Thread.Sleep(10000);
                        break;
                    }

                    if (!string.IsNullOrEmpty(path) && File.Exists(path))
                        File.Delete(path);

                    try
                    {
                        ExcuteDownload(driver, file.TempFileName, urlToDownload);
                    }
                    catch (Exception)
                    {
                        string error = processID + "|Download file error: " + file.OriginalFileName + " on customer: " + custDoc.ContractNumber + " because download not working.";
                        logger.Error(error);
                        throw;
                    }

                    int countDownload = 120;
                    while (true)
                    {
                        if (!isSessionValid)
                        {
                            logger.Error(processID + "| Process on File: " + file.OriginalFileName + " with DocumentID: " + custDoc.DocumentID + ": PAUSE. Because do not have valid session to process. Re-try after 10 seconds");
                            Thread.Sleep(10000);
                            throw new Exception("Session timeout");
                        }

                        var tmpFile = FindFileName(file.TempFileName);
                        if(!string.IsNullOrEmpty(tmpFile) && !tmpFile.ToLower().EndsWith(".crdownload"))
                        {
                            file.TempFileName = tmpFile;
                            break;
                        }
                        else
                        {
                            countDownload--;
                            if(countDownload <= 0)
                            {
                                var testResult = ExcuteGetExt(driver, urlToDownload);
                                custDoc.Priority -= 10;
                                CustDocController.UpdateCustDocStatus(custDoc);
                                string error = processID + "|Can not download file: " + file.OriginalFileName + " on customer: " + custDoc.ContractNumber + " because download not working. Return Excuted Result: '" + testResult + "'";
                                file.Status = FileStatus.DownloadError;
                                FileDownloadController.UpdateFileDownload(file);
                                isSessionValid = false;
                                logger.Error(error);
                                custDoc.Priority -= 1;
                                CustDocController.UpdateCustDocStatus(custDoc);
                                return;
                            }
                            Thread.Sleep(1000);
                        }
                    }
                    
                    file.OriginalFileName += "." + file.TempFileName.Split('.').LastOrDefault();
                    file.Destination += "." + file.TempFileName.Split('.').LastOrDefault();
                    string fileName = Path.Combine(CurrentTempDownloadFolder, file.TempFileName);
                    path = Path.Combine(CurrentTempDownloadFolder, file.TempFileName);
                    FileDownloadController.UpdateFileDownload(file);

                    if (!File.Exists(fileName))
                    {
                        file.Status = FileStatus.NotFound;
                        FileDownloadController.UpdateFileDownload(file);
                        count--;
                        continue;
                    }

                    file.Status = FileStatus.Downloading;
                    FileDownloadController.UpdateFileDownload(file);

                    var fi1 = new FileInfo(path);
                    while (true)
                    {
                        if (Utils.UtilFunction.IsFileLocked(fi1))
                            Thread.Sleep(2000);
                        else
                            break;
                    }

                    file.Status = FileStatus.Downloaded;
                    FileDownloadController.UpdateFileDownload(file);

                    try
                    {
                        var fileEXT = file.TempFileName.Split('.').LastOrDefault().ToLower();
                        FileDownloadController.VerifiedAfterDownload(processID, file, path, fileEXT);
                    }
                    catch (Exception)
                    {
                        file.Status = FileStatus.Corrupted;
                        FileDownloadController.UpdateFileDownload(file);
                        logger.Error(processID + "|File: " + file.OriginalFileName + " on customer: " + custDoc.ContractNumber + " is Corrupted: re-download after 2 second, remaning retry: " + (count));
                    }

                    file.MD5Checksum = Utils.UtilFunction.CalculateMD5FromFile(fileName);
                    file.Status = FileStatus.Verified;
                    FileDownloadController.UpdateFileDownload(file);
                    break;
                }
                catch (Exception ex)
                {
                    isSessionValid = false;
                    logger.Error(ex);
                    logger.Error("Number of try remain: " + count);
                    count--;
                    if (count <= 0)
                    {
                        custDoc.Priority -= 10;
                        CustDocController.UpdateCustDocStatus(custDoc);            
                        file.Status = FileStatus.DownloadError;
                        FileDownloadController.UpdateFileDownload(file);
                    }
                }
            }
        }

        private static string FindFileName(string serachPartern)
        {
            string name = string.Empty;
            var files = Directory.GetFiles(CurrentTempDownloadFolder, serachPartern + ".*");
            if (files.Count() > 0)
                return files.FirstOrDefault().Split('\\').LastOrDefault();
            return name;
        }

        private static void DoClickAction(IWebDriver driver, string xPath, string actionName = "")
        {
            driver.FindElement(By.XPath(xPath)).Click();
        }
    }
}

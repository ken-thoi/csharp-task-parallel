﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;
using TrackableEntities.Common.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Services.Auth.Interfaces;
using Microsoft.Extensions.Hosting;

namespace VPBANK.RMD.API.Common.Controllers
{
    public abstract class QueryController<TContext, TEntity, TKey> : GenericController<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        public QueryController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<TContext> unitOfWork,
            ITrackableRepository<TContext, TEntity, TKey> trackableRepository,
            IGenericRepository<TContext, TEntity, TKey> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// List all records.
        /// </summary>
        /// <returns>IEnumerable</returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<TEntity>> All()
        {
            try
            {
                //var webrootFolder = _env.WebRootPath;
                var results = _genericRepository.Queryable().AsEnumerable();
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find object by key.
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns>Object</returns>
        [HttpGet(template: "{pk_Id}")]
        public virtual async Task<ActionResult<TEntity>> FindById([Required][NotNull][FromRoute] TKey pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var entity = await _genericRepository.FindAsync(pk_Id);
                if (entity == null) return NotFound();
                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Check existed object
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{pk_Id}")]
        public virtual async Task<bool> Exists([Required][NotNull][FromRoute] TKey pk_Id)
        {
            return await _genericRepository.ExistsAsync(pk_Id);
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// Get by permission by user
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public virtual async Task<ActionResult<PaginatedContentResults<TEntity>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                var results = BuildResults(paginatedParams);
                var total = results.Item1;
                var data = results.Item2;

                // result
                dynamic result = await GenericQueryDataAsync(total, data, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        protected Tuple<int, List<TEntity>> BuildResults(PaginatedInputModel paginatedParams)
        {
            try
            {
                // build data roles filter
                var engineDataRoles = new List<string>();
                var entityDataRoles = new List<string>();
                // business_unit
                var businessUnitRoles = new List<int>();

                var hasEngineCol = false;
                var hasEntityCol = false;
                var hasBuCol = false;
                var hasBu1Col = false;
                var hasBu2Col = false;
                var hasBu3Col = false;

                var userPayload = GetUserPayloadFromHeader();
                var user = FindByUsernameAndIsActiveAndIsDeleted(userPayload.Username, UserStatusConstant.ACTIVE, false);
                if (user == null)
                    throw new NullReferenceException();

                // check data roles
                if (!string.IsNullOrEmpty(user.Super_Role) && !user.Super_Role.Equals(UserPermissionConstant.SUPPER_ADMIN, StringComparison.CurrentCultureIgnoreCase))
                {
                    // build data roles filter
                    engineDataRoles = GetEngineDataRolesFromHeader();
                    entityDataRoles = GetEntityDataRolesFromHeader();

                    // check this table generic has engine_code, entity_code
                    var entityCodeProperty = typeof(TEntity).GetProperty(COLUMNS_NAME.ENTITY_CODE);
                    var engineCodeProperty = typeof(TEntity).GetProperty(COLUMNS_NAME.ENGINE_CODE);
                    hasEngineCol = engineCodeProperty != null && !string.IsNullOrEmpty(engineCodeProperty.Name);
                    hasEntityCol = entityCodeProperty != null && !string.IsNullOrEmpty(entityCodeProperty.Name);

                    // business_unit
                    businessUnitRoles = GetBusinessUnitDataRolesFromHeader();

                    var businessUnitProperty = typeof(TEntity).GetProperty(COLUMNS_NAME.Business_Unit_Code);
                    var businessUnit1Property = typeof(TEntity).GetProperty(COLUMNS_NAME.Business_Unit_Code1);
                    var businessUnit2Property = typeof(TEntity).GetProperty(COLUMNS_NAME.Business_Unit_Code2);
                    var businessUnit3Property = typeof(TEntity).GetProperty(COLUMNS_NAME.Business_Unit_Code3);
                    hasBuCol = businessUnitProperty != null && !string.IsNullOrEmpty(businessUnitProperty.Name);
                    hasBu1Col = businessUnit1Property != null && !string.IsNullOrEmpty(businessUnit1Property.Name);
                    hasBu2Col = businessUnit2Property != null && !string.IsNullOrEmpty(businessUnit2Property.Name);
                    hasBu3Col = businessUnit3Property != null && !string.IsNullOrEmpty(businessUnit3Property.Name);
                }

                #region for all field common

                // "[Is_Deleted] = 0"
                var entityIsDeleted = typeof(TEntity).GetProperty(COLUMNS_NAME.IS_DELETED);
                var haIsDeletedCol = entityIsDeleted != null && !string.IsNullOrEmpty(entityIsDeleted.Name);
                if (haIsDeletedCol)
                    paginatedParams.FilterExpression = string.IsNullOrEmpty(paginatedParams.FilterExpression)
                        ? $"[{COLUMNS_NAME.IS_DELETED}] = 0"
                        : $"{ paginatedParams.FilterExpression} AND [{COLUMNS_NAME.IS_DELETED}] = 0";

                #endregion

                // Query data
                var total = _genericRepository.CountDataPaginated(paginatedParams, hasEngineCol, engineDataRoles, hasEntityCol, entityDataRoles,
                    hasBuCol, hasBu1Col, hasBu2Col, hasBu3Col, businessUnitRoles);
                var data = _genericRepository.QueryDataPaginated(paginatedParams, hasEngineCol, engineDataRoles, hasEntityCol, entityDataRoles,
                    hasBuCol, hasBu1Col, hasBu2Col, hasBu3Col, businessUnitRoles);

                return Tuple.Create(total, data.ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Entities.Commons;

namespace VPBANK.RMD.Services.Auth.Interfaces
{
    public interface IUserService
    {
        User FindByUsername(string username);
        List<string> FindBySupperAdmin();
        List<string> FindEmailsByUsernames(List<string> usernames);
        void DeleteUserById(int pk_Id);
        Task<List<SelectedItem>> FindUsernames();
        List<SelectedItem> FindByUserNonRole();
    }
}

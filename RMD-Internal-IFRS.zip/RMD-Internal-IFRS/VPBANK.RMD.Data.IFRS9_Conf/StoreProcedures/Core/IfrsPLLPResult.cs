﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core
{
    public class IfrsPLLPResult : QueryObjectResult
    {
        public DateTime? Business_Date { get; set; }
        public DateTime? Cash_Flow_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Contract_Id_N { get; set; }
        public string Statement_Type { get; set; }
        public string Ccy_Code { get; set; }
        public decimal? Amount_Lcy { get; set; }
        public decimal? Accrual_39_Lcy { get; set; }
        public decimal? Accrual_94_Lcy { get; set; }
        public decimal? Fee_Lcy { get; set; }
        public decimal? Total_Unused_Limit { get; set; }
        public int? No_Ovd_Day { get; set; }
        public string Qtrr_Segment { get; set; }
        public string Default_Status { get; set; }
        public DateTime? Default_Date { get; set; }

        public decimal? Eir { get; set; }
        public string Model_Segment { get; set; }
        public string Rating_Ini { get; set; }
        public string Rating { get; set; }
        public decimal? Ccf_Card { get; set; }
        public string Kplus_Ar_Nbr { get; set; }
        public string Rst_Flag { get; set; }
        public DateTime? Rst_Date { get; set; }
        public string Good_Rst_Flag { get; set; }
        public string Stage { get; set; }
        public string Downgrade_Flag { get; set; }
        public decimal? Repay_Principal { get; set; }
        public decimal? Repay_Interest { get; set; }
        public int? Days_On_Book { get; set; }

        public decimal? Ead { get; set; }
        public decimal? Pdlt { get; set; }
        public decimal? Pdlt_Lag { get; set; }
        public decimal? Pdlt_Marginal { get; set; }
        public decimal? Lgd { get; set; }
        public decimal? Loss_Period { get; set; }
    }
}

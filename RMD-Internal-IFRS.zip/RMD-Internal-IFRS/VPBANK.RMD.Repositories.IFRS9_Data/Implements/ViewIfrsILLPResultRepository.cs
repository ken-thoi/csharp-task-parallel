﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces.ECLCalc;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements.ECLCalc
{
    public class ViewIfrsILLPResultRepository : Repository<IFRS9_DataContext, ViewIfrsILLPResult, long>, IViewIfrsILLPResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public ViewIfrsILLPResultRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_DataContext, ViewIfrsILLPResult, long> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<ViewIfrsILLPResult> FindAllByBusinessDate(DateTime business_Date)
        {
            try
            {
                var query = new StringBuilder();
                query.Append($"SELECT c.* FROM Core.view_IFRS_ILLP_ECL AS c WHERE c.Business_Date = '{business_Date.ToString(DefFormats.DATE_FORMAT)}'");
                return TrackableRepository
                    .QueryableFromSqlRaw(query.ToString())
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

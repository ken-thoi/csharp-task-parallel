﻿using System;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Interfaces
{
    public interface IStagingAdjustRepository : IRepository<IFRS9_DataContext, StagingAdjust, int>
    {
        StagingAdjust FindStagingAdjustByCustomerId(string customerId, DateTime businessDate);
        StagingAdjust FindStagingAdjustByCustomerIdAndFlowExecutionId(string customerId, DateTime businessDate, int flowExecId, int taskExecId);
    }
}

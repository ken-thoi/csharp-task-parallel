﻿namespace VPBANK.RMD.Utils.Common
{
    public class DefFormats
    {
        public static readonly string DATE_FORMAT = "yyyy-MM-dd";
        public static readonly string DATE_FORMAT_ = "yyyy/MM/dd";
        public static readonly string DATETIME_FORMAT = "yyyy'-'MM'-'dd HH':'mm':'ss";
        public static readonly string DATETIME_FORMAT_Z = "yyyy'-'MM'-'dd HH':'mm':'ss'Z'";

        public static readonly string DATETIME_FORMAT_ICT = "ddd MMM dd HH:mm:ss ICT yyyy";

        public static readonly string DATETIME_LOG_FORMAT = "Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz";

        public static readonly string DATE_YYYY_MM_DD_OTHER = "yyyy-MM-dd";

        public static readonly string DATE_YYYYMM = "yyyyMM";
        public static readonly string DATE_YYYYMM_ = "yyyy-MM";

        public static readonly string DATE_YYYY = "yyyy";

        public static readonly string DATE_MMYYYY = "MMyyyy";

        public static readonly string DATE_YYYYMMDD = "yyyyMMdd";
        public static readonly string DATE_YYYY_MM_DD = "yyyy/MM/dd";
        public static readonly string DATE_DDMMYYYY = "dd/MM/yyyy";
        public static readonly string DATE_MMDDYYYY = "MM/dd/yyyy";

        public static readonly string DECIMAL_FORMAT = "Ex: 1643.57";
        public static readonly string INT_FORMAT = "Ex: 164357";
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using Serilog;
using System.Net;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Services.Auth.Interfaces;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.BCL;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.BCL
{
    public class ConfLuValidationTypeController : ProcessController<IFRS9_ConfContext, ConfLuValidationType, int>
    {
        private readonly IConfLuValidationTypeService _confLuValidationTypeService;
        public ConfLuValidationTypeController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, ConfLuValidationType, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, ConfLuValidationType, int> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository,

            IConfLuValidationTypeService confLuValidationTypeService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
            _confLuValidationTypeService = confLuValidationTypeService;
        }

        /// <summary>
        /// List all record by combobox
        /// </summary>
        /// <returns>IEnumerable</returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GetValidationTypeDropdown()
        {
            try
            {
                return Ok(_genericRepository
                    .Queryable()
                    .AsEnumerable()
                    .Select(c => new SelectedItem
                    {
                        Key = c.Pk_Id,
                        Val = c.Type_Name
                    })
                    .OrderBy(c => c.Key)
                    .Distinct()
                    .ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find LU validation type name by Lu validation
        /// </summary>
        /// <param name="luValidationId"></param>
        /// <returns></returns>
        [HttpGet("{luValidationId}")]
        public virtual ActionResult<IEnumerable<CallbackObjectRes>> FindTypeName([NotNull][FromRoute] int luValidationId)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || luValidationId == 0)
                    return BadRequest(ModelState);

                var luValidation = _confLuValidationTypeService.FindByLuValidation(luValidationId);
                if (luValidation == null)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                return Ok(new List<CallbackObjectRes> { new CallbackObjectRes { controlId = "fk_Validation_Type_Name", value = luValidation.Type_Name } });
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

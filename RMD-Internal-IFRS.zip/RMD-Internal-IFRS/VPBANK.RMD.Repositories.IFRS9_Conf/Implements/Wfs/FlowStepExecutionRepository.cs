﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Wfs
{
    public class FlowStepExecutionRepository : Repository<IFRS9_ConfContext, FlowStepExecution, int>, IFlowStepExecutionRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public FlowStepExecutionRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_ConfContext, FlowStepExecution, int> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<FlowStepExecution> FindAllByFlowExecutionId(int flowExecutionId)
        {
            try
            {
                return Queryable().AsEnumerable().Where(c => c.Fk_Flow_Execution_Id == flowExecutionId).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<FlowStepExecution> FindAllByFkCurrentTaskStepId(int fkCurrentTaskStepId)
        {
            try
            {
                return Queryable().Where(c => c.Fk_Current_Task_Step_Id == fkCurrentTaskStepId).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<FlowStepExecution> FindAllByFkCurrentTaskStepIdAndFkFlowExecutionId(int fkCurrentTaskStepId, int fkFlowExecutionId)
        {
            try
            {
                return Queryable().Where(c => c.Fk_Current_Task_Step_Id == fkCurrentTaskStepId && c.Fk_Flow_Execution_Id == fkFlowExecutionId).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<FlowStepExecution> FindAllByFkNextTaskStepIdAndFkFlowExecutionId(int fkNextTaskStepId, int fkFlowExecutionId)
        {
            try
            {
                return Queryable().Where(c => c.Fk_Next_Task_Step_Id.HasValue && c.Fk_Next_Task_Step_Id.Value == fkNextTaskStepId && c.Fk_Flow_Execution_Id == fkFlowExecutionId).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Obsolete]
        public async Task<int> DeleteFlowStepExecutionByFlowId(int flowExecutionId)
        {
            try
            {
                return await _context.Database.ExecuteSqlCommandAsync($"DELETE WF.Flow_Step WHERE Fk_Flow_Id = '{flowExecutionId}'");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

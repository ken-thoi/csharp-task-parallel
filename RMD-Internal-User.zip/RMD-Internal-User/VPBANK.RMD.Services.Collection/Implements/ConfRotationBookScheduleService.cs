﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Services.Collection.Interfaces;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Shared;

namespace VPBANK.RMD.Services.Collection.Implements
{
    public class ConfRotationBookScheduleService : IConfRotationBookScheduleService
    {
        private readonly IUnitOfWork<CollectionContext> _unitOfWork;
        private readonly IGenericRepository<CollectionContext, ConfRotationBookSchedule, int> _genConfRotationBookScheduleRepository;
        public ConfRotationBookScheduleService(IUnitOfWork<CollectionContext> unitOfWork,
            IGenericRepository<CollectionContext, ConfRotationBookSchedule, int> genConfRotationBookScheduleRepository)
        {
            _unitOfWork = unitOfWork;
            _genConfRotationBookScheduleRepository = genConfRotationBookScheduleRepository;
        }

        public IList<FieldValidateResponse> Validate(ConfRotationBookScheduleDto entity)
        {
            var results = new List<FieldValidateResponse>();
            try
            {
                
                if (entity.End_Date.Date < entity.Start_Date.Date)
                    results.Add(new FieldValidateResponse
                    {
                        Error = string.Format(ErrorMessages.EM019, "Effective To", "Effective From"),
                        Field = nameof(entity.End_Date),
                        Description = string.Format(ErrorMessages.EM019, "Effective To", "Effective From")
                    });
            }
            catch (Exception ex)
            {
                results.Add(new FieldValidateResponse
                {
                    Error = ex.Message,
                    Field = Constants.BUSSINESS_EXCEPTION,
                    Description = ex.Message
                });
            }
            return results;
        }
    }
}

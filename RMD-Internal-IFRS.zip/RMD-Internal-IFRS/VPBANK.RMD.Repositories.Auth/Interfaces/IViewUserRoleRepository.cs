﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.Views;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.Auth.Interfaces
{
    public interface IViewUserRoleRepository : IRepository<AuthContext, ViewUserRole, int>
    {
        Task<IEnumerable<ViewUserRole>> FindAllAsync();
        ViewUserRole FindByUserName(string username);
        Task<ViewUserRole> FindByUserNameAsync(string username);
    }
}

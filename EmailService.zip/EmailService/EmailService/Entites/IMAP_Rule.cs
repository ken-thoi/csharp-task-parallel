﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class IMAP_Rule
    {
        public int Id { get; set; }
        public int FK_IMAP_Config_Id { get; set; }
        public string RuleType { get; set; }
        public string Folder { get; set; }
        public string AfterFeedStore { get; set; }
    }
}

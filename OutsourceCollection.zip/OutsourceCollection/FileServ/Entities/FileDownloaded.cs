﻿using System;

namespace FileServ.Entities
{
    public class FileDownload
    {
        public int Id { get; set; } = -1;
        public int FK_CustomerDocument { get; set; }
        public int FK_DocumentType { get; set; }
        public string OriginalFileName { get; set; }
        public string Destination { get; set; }
        public DateTime ProcessTime { get; set; }
        public string TempFileName { get; set; }
        public string exID { get; set; }
        public string MD5Checksum { get; set; }
        public FileStatus Status { get; set; }
    }

    public enum FileStatus
    {
        NotFound = 10,
        Downloading = 20,
        OrgNameIsEmpty = 25,
        Downloaded = 30,
        Corrupted = 40,
        Verified = 50,
        MovingToStorage = 60,
        Packaged = 70,
        Completed = 80
    }
}

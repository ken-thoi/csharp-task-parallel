﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("TaskStep", Schema = "WF")]
    public class TaskStep : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int? FK_Task_Id { get; set; }

        public int? FK_WorkFlowStep_StepOrder { get; set; }

        public int? Status { get; set; }

        public string AssignedTo { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? AssignedTime { get; set; }
    }
}

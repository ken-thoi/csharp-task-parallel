﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class FilePackage
    {
        public int Id { get; set; }
        public int FK_Customer { get; set; }
        public string Destination { get; set; }
        public string ProcessTime { get; set; }
        public FilePackageStatus Status { get; set; }
        public long Size { get; set; }
        public string MD5Checksum { get; set; }
    }

    public enum FilePackageStatus
    {
        Waiting = 10,
        Processing = 20,
        ProcessingError = 25,
        WaitingFileDownload = 30,
        DownloadCompleted = 40,
        Packing = 50,
        PackingCompleted = 60,
        Verified = 70,
        VerifiedFailed = 75,
        Done = 80,
        FileUploadCustom = 90
    }
}

﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.DataValidations;
using VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.DataValidations
{
    public class ViewIfrsDataValidationResultRepository : Repository<IFRS9_ConfContext, ViewIfrsDataValidationResult, int>, IViewIfrsDataValidationResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public ViewIfrsDataValidationResultRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_ConfContext, ViewIfrsDataValidationResult, int> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<ViewIfrsDataValidationResult> FindAllByBusinessDate(DateTime businessDate)
        {
            try
            {
                var query = new StringBuilder();
                query.Append($"SELECT c.* FROM BCL.View_Ifrs_Data_Validation_Result AS c WHERE c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'");
                return TrackableRepository
                    .QueryableFromSqlRaw(query.ToString())
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

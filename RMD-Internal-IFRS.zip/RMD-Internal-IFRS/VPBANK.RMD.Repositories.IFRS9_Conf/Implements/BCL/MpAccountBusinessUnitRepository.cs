﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.BCL;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.BCL
{
    public class MpAccountBusinessUnitRepository : Repository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int>, IMpAccountBusinessUnitRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public MpAccountBusinessUnitRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<ConfMpAccountBusinessUnit> FindAllByUsername(string username)
        {
            try
            {
                var query = new StringBuilder();
                query.Append($"SELECT c.* FROM BCL.Conf_MP_Account_Business_Unit AS c");
                query.Append($"\nWHERE c.Username = '{username}'");
                return TrackableRepository
                    .QueryableFromSqlRaw(query.ToString())
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ConfMpAccountBusinessUnit> FindAllByUsernameAndStatus(string username, string status)
        {
            try
            {
                var query = new StringBuilder();
                query.Append($"SELECT c.* FROM BCL.Conf_MP_Account_Business_Unit AS c");
                query.Append($"\nINNER JOIN BCL.Conf_LU_Business_Unit AS x ON x.Pk_Id = c.Fk_Business_Unit_Id");
                query.Append($"\nWHERE c.Username = '{username}' AND c.[Status] = '{status}'");
                return TrackableRepository
                    .QueryableFromSqlRaw(query.ToString())
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<string> FindAllUsernamesHasBusinessUnit()
        {
            try
            {
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> DeleteMpAccountBusinessUnitByUsernameAsync(string username)
        {
            try
            {
                return await _context.Database.ExecuteSqlRawAsync($"DELETE BCL.Conf_MP_Account_Business_Unit WHERE Username = '{username}'");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

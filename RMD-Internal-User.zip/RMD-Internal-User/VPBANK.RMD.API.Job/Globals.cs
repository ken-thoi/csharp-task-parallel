﻿namespace VPBANK.RMD.API.Job
{
    public static class Globals
    {
    }
}

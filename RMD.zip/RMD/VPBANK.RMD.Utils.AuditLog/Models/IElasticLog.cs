﻿namespace VPBANK.RMD.Utils.AuditLog.Models
{
    public interface IElasticLog
    {
    }
}

﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Interfaces.ECLCalc
{
    public interface IViewIfrsILLPResultRepository : IRepository<IFRS9_DataContext, ViewIfrsILLPResult, long>
    {
        public List<ViewIfrsILLPResult> FindAllByBusinessDate(DateTime business_Date);
    }
}
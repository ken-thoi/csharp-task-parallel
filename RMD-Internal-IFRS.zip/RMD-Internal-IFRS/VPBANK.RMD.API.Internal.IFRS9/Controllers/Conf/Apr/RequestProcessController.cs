﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using Serilog;
using System.Net;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Core;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Data.Core
{
    public class RequestProcessController : QueryController<IFRS9_DataContext, RequestsProcess, int>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, Requests, int> _genRequestsRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, RequestsProcess, int> _genRequestsProcessRepository;

        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;
        private readonly IILLPAdjustService _illpAdjustService;
        private readonly IIfrsILLPResultRepository _ifrsILLPResultRepository;
        private readonly ICustomerResultRepository _customerResultRepository;

        public RequestProcessController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_DataContext> unitOfWork,
            ITrackableRepository<IFRS9_DataContext, RequestsProcess, int> trackableRepository,
            IGenericRepository<IFRS9_DataContext, RequestsProcess, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, Requests, int> genRequestsRepository,
            IGenericRepository<IFRS9_ConfContext, RequestsProcess, int> genRequestsProcessRepository,

            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,

            IILLPAdjustService illpAdjustService,
            IIfrsILLPResultRepository ifrsILLPResultRepository,
            ICustomerResultRepository customerResultRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genRequestsRepository = genRequestsRepository;
            _genRequestsProcessRepository = genRequestsProcessRepository;

            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;

            _illpAdjustService = illpAdjustService;
            _ifrsILLPResultRepository = ifrsILLPResultRepository;
            _customerResultRepository = customerResultRepository;
        }

        /// <summary>
        /// Validate Approve/Reject existed request.
        /// Approve (Request_action = 7)
        /// Reject (Request_action = 9)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly approved/rejected request</returns>
        [HttpPost]
        public virtual ActionResult<Requests> ValidApprove([NotNull][FromBody] IfrsDataApr req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || req.Request_Id == 0)
                    return BadRequest(ModelState);

                var reqProcess = _genRequestsProcessRepository
                        .Queryable()
                        .Where(x => x.Fk_Request_Id == req.Request_Id)
                        .OrderByDescending(x => x.Process_Date)
                        .FirstOrDefault();

                //if (reqProcess != null &&
                //    (req.Request_Action == (int)ActionTypes.APPROVAL || req.Request_Action == (int)ActionTypes.REJECT) &&
                //    (reqProcess.Request_Status.Equals(IfrsRequestStatus.APPROVED, StringComparison.CurrentCultureIgnoreCase) || reqProcess.Request_Status.Equals(IfrsRequestStatus.REJECTED, StringComparison.CurrentCultureIgnoreCase)))
                //    return Tuple.Create(ErrorMessagesIfrs.EM043, new Requests());

                //// error, invalid
                //if (!string.IsNullOrEmpty(msg) || request == null)
                //    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                // results
                return CreatedAtAction(nameof(ValidApprove), null);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

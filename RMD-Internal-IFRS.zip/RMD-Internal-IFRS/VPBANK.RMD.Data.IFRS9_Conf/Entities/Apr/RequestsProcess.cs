﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr
{
    [Table("Requests_Process", Schema = "Apr")]
    public class RequestsProcess : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Request_Id { get; set; }
        public string Processor { get; set; }
        public string Request_Action { get; set; }
        public string Request_Status { get; set; }
        public string Comments { get; set; }
        public DateTime Process_Date { get; set; }
    }
}

﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class Operations
    {
        public const string AND = " AND ";
        public const string OR = " OR ";
        public const string IN = " IN ";
        public const string NOT_IN = " NOT IN ";
    }
}

﻿using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core
{
    public interface ICustomerResultRepository : IQueryRepository<IFRS9_ConfContext, CustomerResult>
    {
        CustomerResult FindByCustomerId(string customerId);
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations
{
    [Table("View_Ifrs_Data_Validation_Result", Schema = "BCL")]
    public class ViewIfrsDataValidationResult : EntityBase<int>
    {
        public override int Pk_Id { get; set; }
        //public override int Pk_Id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public string Flow_Name { get; set; }

        public int? Fk_Business_Unit_Id { get; set; }

        public int? Fk_Lu_Validation_Id { get; set; }

        public string Fk_Lu_Upload_Id { get; set; }

        public DateTime? Start_Date { get; set; }

        public DateTime? End_Date { get; set; }

        #region

        public string Validation_Rule { get; set; }

        public string Validation_Source { get; set; }

        public string Validation_Description { get; set; }

        public DateTime Business_Date { get; set; }

        public string Assign_Validation_Group { get; set; }

        public int? Fail_Record { get; set; }

        public string Type_Name { get; set; }

        #endregion
    }
}

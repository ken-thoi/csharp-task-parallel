﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("Component_User_Role", Schema = "Core")]
    public class ComponentUserRole : EntityBase<int>
    {
        [Key]
        [Column(name: "PK_Id")]
        public override int Pk_Id { get; set; }

        [Column(name: "Username")]
        public string Username { get; set; }

        [Column(name: "Role")]
        public string Role { get; set; }

        [Column(name: "Is_Deleted")]
        public bool Is_Deleted { get; set; }
    }
}

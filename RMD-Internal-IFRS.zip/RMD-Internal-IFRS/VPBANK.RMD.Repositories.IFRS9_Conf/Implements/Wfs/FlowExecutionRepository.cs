﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Wfs
{
    public class FlowExecutionRepository : Repository<IFRS9_ConfContext, FlowExecution, int>, IFlowExecutionRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public FlowExecutionRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_ConfContext, FlowExecution, int> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<FlowExecution> FindAllByFlowIdAndBusinessDateAndFlowExecutionStatus(int flowId, DateTime businessDate, string flowStatus)
        {
            try
            {
                var query = new StringBuilder();
                query.Append($"SELECT c.* FROM WF.Flow_Execution AS c WHERE c.Fk_Flow_Id = {flowId} AND c.Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}' AND c.Flow_Execution_Status = '{flowStatus}'");
                return TrackableRepository
                    .QueryableFromSqlRaw(query.ToString())
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

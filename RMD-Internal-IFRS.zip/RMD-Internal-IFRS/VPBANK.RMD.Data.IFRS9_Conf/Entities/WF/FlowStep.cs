﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Flow_Step", Schema = "WF")]
    public class FlowStep : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int Fk_Flow_Id { get; set; }

        public int Fk_Current_Task_Step_Id { get; set; }

        public int? Fk_Next_Task_Step_Id { get; set; }

        public int Task_Level { get; set; }

        public string Task_Status_Condition { get; set; }

        public bool Is_First_Task { get; set; }

        public bool Is_End_Task { get; set; }

        public string Created_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Created_Time { get; set; }

        public string Updated_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Updated_Time { get; set; }
    }
}

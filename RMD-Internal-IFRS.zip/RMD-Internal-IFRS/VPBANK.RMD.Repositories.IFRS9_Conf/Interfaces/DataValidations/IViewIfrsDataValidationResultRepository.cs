﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.DataValidations
{
    public interface IViewIfrsDataValidationResultRepository : IRepository<IFRS9_ConfContext, ViewIfrsDataValidationResult, int>
    {
        public List<ViewIfrsDataValidationResult> FindAllByBusinessDate(DateTime businessDate);
    }
}

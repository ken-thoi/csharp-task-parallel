﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using VPBANK.RMD.Data.Job.Entities.POCOs;

namespace VPBANK.RMD.Data.Job
{
    public class JobContext : DbContext
    {
        //private IHttpContextAccessor _httpContextAccessor;

        public JobContext(DbContextOptions<JobContext> options) : base(options)
        {
            //ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        //public AuthContext(DbContextOptions<AuthContext> options, IHttpContextAccessor httpContextAccessor) : base(options)
        //{
        //    this._httpContextAccessor = httpContextAccessor;
        //}

        // POCO
        public DbSet<UserJob> UserJobs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserJob>().ToTable("User_Job", "App");
            modelBuilder.Entity<UserJob>().HasKey(item => new { item.Pk_Id });

            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            //var now = DateTime.Now;

            //// Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            //var entries = ChangeTracker
            //    .Entries()
            //    .Where(e => e.Entity is Auditable && (e.State == EntityState.Added || e.State == EntityState.Modified));

            //// For each entity we will set the Audit properties
            //if (entries != null)
            //    foreach (var entityEntry in entries)
            //    {
            //        // If the entity state is Added let's set the CreatedAt and CreatedBy properties
            //        if (entityEntry.State == EntityState.Added)
            //        {
            //            ((Auditable)entityEntry.Entity).CreatedAt = now;
            //            ((Auditable)entityEntry.Entity).CreatedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "MyApp";
            //        }
            //        else
            //        {
            //            // If the state is Modified then we don't want to modify the CreatedAt and CreatedBy properties so we set their state as IsModified to false
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedAt).IsModified = false;
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedBy).IsModified = false;
            //        }

            //    // In any case we always want to set the properties ModifiedAt and ModifiedBy
            //    ((Auditable)entityEntry.Entity).ModifiedAt = now;
            //        ((Auditable)entityEntry.Entity).ModifiedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "MyApp";
            //    }

            // After we set all the needed properties we call the base implementation of SaveChanges to actually save our entities in the database
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            //var now = DateTime.Now;

            //// Get all the entities that inherit from AuditableEntity and have a state of Added or Modified
            //var entries = ChangeTracker
            //    .Entries()
            //    .Where(e => e.Entity is Auditable && (e.State == EntityState.Added || e.State == EntityState.Modified));

            //// For each entity we will set the Audit properties
            //if (entries != null)
            //    foreach (var entityEntry in entries)
            //    {
            //        // If the entity state is Added let's set the CreatedAt and CreatedBy properties
            //        if (entityEntry.State == EntityState.Added)
            //        {
            //            ((Auditable)entityEntry.Entity).CreatedAt = now;
            //            ((Auditable)entityEntry.Entity).CreatedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "VBP_MRD_Administrator";
            //        }
            //        else
            //        {
            //            // If the state is Modified then we don't want to modify the CreatedAt and CreatedBy properties so we set their state as IsModified to false
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedAt).IsModified = false;
            //            Entry((Auditable)entityEntry.Entity).Property(p => p.CreatedBy).IsModified = false;
            //        }

            //    // In any case we always want to set the properties ModifiedAt and ModifiedBy
            //    ((Auditable)entityEntry.Entity).ModifiedAt = now;
            //        ((Auditable)entityEntry.Entity).ModifiedBy = /*this._httpContextAccessor?.HttpContext?.User?.Identity?.Name ??*/ "VBP_MRD_Administrator";
            //    }

            // After we set all the needed properties we call the base implementation of SaveChangesAsync to actually save our entities in the database
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}

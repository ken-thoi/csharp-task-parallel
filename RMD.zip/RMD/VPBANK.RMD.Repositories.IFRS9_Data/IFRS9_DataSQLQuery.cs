﻿namespace VPBANK.RMD.Repositories.IFRS9_Data
{
    public static class IFRS9_DataSQLQuery
    {
        public static readonly string SP_ = "EXECUTE IFRS9_Data.dbo.sp_ @Business_Date";
    }
}

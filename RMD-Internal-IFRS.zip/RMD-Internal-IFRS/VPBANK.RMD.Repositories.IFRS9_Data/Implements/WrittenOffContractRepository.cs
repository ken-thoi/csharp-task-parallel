﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class WrittenOffContractRepository : Repository<IFRS9_DataContext, IfrsContractWo, long>, IWrittenOffContractRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public WrittenOffContractRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, IfrsContractWo, long> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public async Task<int> DeleteContractWrittenOffByBusinessDateAsync(DateTime businessDate)
        {
            try
            {
                return await _context.Database.ExecuteSqlRawAsync($"DELETE Core.IFRS_Contract_WO WHERE Business_Date = '{businessDate.ToString(DefFormats.DATE_FORMAT)}'");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

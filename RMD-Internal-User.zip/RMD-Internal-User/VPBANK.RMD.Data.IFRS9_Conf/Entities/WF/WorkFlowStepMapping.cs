﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("WorkFlowStepMapping", Schema = "WF")]
    public class WorkFlowStepMapping : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int? FK_DefWorkFlow_Id { get; set; }

        public int? Step { get; set; }

        public int? ParentStep { get; set; }
    }
}

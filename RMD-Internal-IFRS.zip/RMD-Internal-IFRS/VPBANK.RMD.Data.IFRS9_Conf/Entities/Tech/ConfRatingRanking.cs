﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech
{
    [Table("Conf_Rating_Ranking", Schema = "Tech")]
    public class ConfRatingRanking : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Model_Segment { get; set; }
        public string Rating { get; set; }
        public int Notch_Level { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Core;
using VPBANK.RMD.Services.Auth.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using VPBANK.RMD.EFCore.Entities.Commons;
using System.Diagnostics.CodeAnalysis;
using System;
using Serilog;
using VPBANK.RMD.API.Common.Middlewares;
using System.Net;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Core
{
    public class MpGlIfrs9Controller : ProcessController<IFRS9_ConfContext, ConfMpGlIfrs, int>
    {
        public MpGlIfrs9Controller(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, ConfMpGlIfrs, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, ConfMpGlIfrs, int> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
        }

        /// <summary>
        /// Get statemetn type for dropdown_list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<SelectedItem>> GuiStatementTypes()
        {
            try
            {
                return new List<SelectedItem> {
                    new SelectedItem { Key = "FI", Val = "FI" },
                    new SelectedItem { Key = "LOAN", Val = "LOAN" },
                    new SelectedItem { Key = "REC", Val = "REC" },
                    new SelectedItem { Key = "OFF", Val = "OFF" }
                };
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

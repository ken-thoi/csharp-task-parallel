﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core
{
    [Table("PLLP_Customer", Schema = "Core")]
    public class PLLPCustomer : EntityBase<decimal>
    {
        [Key]
        public override decimal Pk_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
    }
}
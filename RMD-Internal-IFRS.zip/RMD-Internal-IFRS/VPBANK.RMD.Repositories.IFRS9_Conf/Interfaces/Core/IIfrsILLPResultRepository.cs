﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core
{
    public interface IIfrsILLPResultRepository : IQueryRepository<IFRS9_ConfContext, IfrsILLPResult>
    {
        List<IfrsILLPResult> FindAllILLPsByCustomerIdAndBusinessDate(string customerId, DateTime businessDate);
        Task<int> ConsolidateAdjustByBusinessDate(DateTime businessDate);
    }
}

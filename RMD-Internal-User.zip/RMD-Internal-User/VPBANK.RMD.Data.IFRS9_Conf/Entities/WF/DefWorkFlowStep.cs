﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("DefWorkFlowStep", Schema = "WF")]
    public class DefWorkFlowStep : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int? FK_DefWorkFlow_Id { get; set; }

        public int? ParentStepOrder { get; set; }

        public int? StepOrder { get; set; }

        public string StepName { get; set; }

        public string CallModid { get; set; }

        public string StepDesc { get; set; }

        public string CreatedBy { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? CreatedTime { get; set; }

        public string UpdatedBy { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? UpdatedTime { get; set; }
    }
}

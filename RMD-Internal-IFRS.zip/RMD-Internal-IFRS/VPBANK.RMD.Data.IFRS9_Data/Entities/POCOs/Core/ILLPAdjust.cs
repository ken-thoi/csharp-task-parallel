﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core
{
    [Table("ILLP_Adjust", Schema = "Core")]
    public class ILLPAdjust : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Action_Flag { get; set; }
        public string List_Flag { get; set; }
        public string Request_Comment { get; set; }
        public string Approval_Comment { get; set; }
        public DateTime Created_Time { get; set; }
    }
}
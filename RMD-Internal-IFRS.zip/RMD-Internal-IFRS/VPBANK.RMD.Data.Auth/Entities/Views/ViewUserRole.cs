﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.Views
{
    [Table("View_User_Role", Schema = "Core")]
    public class ViewUserRole : EntityBase<int>
    {
        [Key]
        [JsonPropertyName("id")]
        [JsonProperty("id")]
        public override int Pk_Id { get; set; }

        [JsonPropertyName("username")]
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonPropertyName("superRole")]
        [JsonProperty("superRole")]
        public string Super_Role { get; set; }

        [JsonPropertyName("fkDataRole")]
        [JsonProperty("fkDataRole")]
        public string Fk_Data_Role { get; set; }

        [JsonPropertyName("dataRole")]
        [JsonProperty("dataRole")]
        public string Data_Role { get; set; }

        [JsonPropertyName("functionRole")]
        [JsonProperty("functionRole")]
        public string Function_Role { get; set; }

        [JsonPropertyName("componentRole")]
        [JsonProperty("componentRole")]
        public string Component_Role { get; set; }
    }
}

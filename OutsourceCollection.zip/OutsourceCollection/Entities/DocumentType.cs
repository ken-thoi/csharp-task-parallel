﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class DocumentType
    {
        public DocumentType()
        {

        }

        public DocumentType(int FK_Source_Id, string DocumentName)
        {
            Id = FK_Source_Id;
            this.DocumentName = DocumentName;
        }

        public int Id { get; set; }
        public int FK_Source_Id { get; set; }
        public string DocumentName { get; set; }
        public string DocumentDesc { get; set; }
        public bool AllowToDownload { get; set; }
        public bool AllowSendToOS { get; set; }
    }
}

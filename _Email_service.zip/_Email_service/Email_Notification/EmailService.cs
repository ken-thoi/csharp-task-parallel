﻿using System.Diagnostics;
using System.ServiceProcess;

namespace Email_Notification
{
    partial class EmailService : ServiceBase
    {
        public EmailService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            RunEmailSync();
        }

        public void StartDebug()
        {
            RunEmailSync();
        }

        private void RunEmailSync()
        {
            EventLog.WriteEntry("Email_Notification.Service", "Starting Service", EventLogEntryType.Information);
            EmailExcuter.EmailExcute(Process.GetCurrentProcess().Id.ToString());
        }

        protected override void OnStop()
        {
            EmailExcuter.StopSendEmail();
        }
    }
}

﻿namespace VPBANK.RMD.Data.PhoenixData
{
    public class PhoenixDataSqlQuery
    {
    }
}

﻿namespace VPBANK.RMD.EFCore.Entities
{
    public abstract class BaseQueryResult : IBaseQueryResult
    {
    }

    public interface IBaseQueryResult
    {
    }
}

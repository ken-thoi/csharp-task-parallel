﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core
{
    [Table("ILLP_CF_Adjust_Detail", Schema = "Core")]
    public class ILLPCashflowAdjustDetail : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Cashflow_Adjust_Summary_Id { get; set; }
        public int Fk_Flow_Execution_Id { get; set; }
        public int Fk_Task_Execution_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public DateTime Created_Time { get; set; }

        public decimal? Cf_Date_Sc1 { get; set; }
        public decimal? Principal_Payment_Sc1 { get; set; }
        public decimal? Cashflow_Sc1 { get; set; }
        public decimal? Tenor_Sc1 { get; set; }
        public decimal? Dcf_Sc1 { get; set; }
        public decimal? Cashflow_Sc2 { get; set; }
        public decimal? Tenor_Sc2 { get; set; }
        public decimal? Dcf_Sc2 { get; set; }
        public decimal? Cashflow_Date_St3 { get; set; }
        public decimal? Collateral_Amt_St3 { get; set; }
        public decimal? Tenor_St3 { get; set; }
        public decimal? Dcf_Collateral_St3 { get; set; }
    }
}
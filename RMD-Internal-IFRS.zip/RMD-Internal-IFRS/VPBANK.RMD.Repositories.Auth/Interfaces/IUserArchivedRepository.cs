﻿using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.Auth.Interfaces
{
    public interface IUserArchivedRepository : IRepository<AuthContext, UserArchived, int>
    {
    }
}

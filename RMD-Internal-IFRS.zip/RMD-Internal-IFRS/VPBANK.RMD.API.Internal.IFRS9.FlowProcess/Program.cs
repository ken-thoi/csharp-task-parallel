﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using System;
using System.IO;
using System.Threading.Tasks;
using VPBANK.RMD.API.Common.Features;
using VPBANK.RMD.API.Common.Helpers.Mapping;
using VPBANK.RMD.API.Common.Helpers.Requests;
using VPBANK.RMD.API.Logs;
using VPBANK.RMD.API.Settings;

namespace VPBANK.RMD.API.Internal.IFRS9.FlowProcess
{
    class Program
    {
        private static IConfigurationRoot _configuration;

        static int Main(string[] args)
        {
            try
            {
                // Start!
                Console.Title = "Flow Process Started!";
                MainAsync(args).Wait();
                return 0;
            }
            catch (Exception ex)
            {
                //DisposeServices(serviceProvider);
                Log.Error(ex.StackTrace);
                Log.Error(ex.Message);
                return 1;
            }
        }

        static async Task MainAsync(string[] args)
        {
            #region Logger

            // Build configuration
            _configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetParent(AppContext.BaseDirectory).FullName)
                .AddJsonFile(path: "appsettings.json", optional: false, reloadOnChange: true)
                //.AddJsonFile(path: "appsettings.Development.json", optional: true, reloadOnChange: true)
                .AddJsonFile(path: "appsettings.Production.json", optional: true, reloadOnChange: true)
                .Build();

            // log file name
            var logFilename = _configuration.GetSection("Serilog:Loggly:ApplicationName");
            var apiBase = _configuration.GetSection($"{nameof(AppSettings.Properties)}:{nameof(Properties.API_BASE)}").Value;
            var serverUrl = _configuration[$"{nameof(AppSettings.Properties)}:{apiBase}"].ToString();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(_configuration)
                .MinimumLevel.Debug()
                .MinimumLevel.Override(nameof(Microsoft), LogEventLevel.Information)
                .MinimumLevel.Override(nameof(System), LogEventLevel.Warning)
                .MinimumLevel.Override(nameof(Microsoft.AspNetCore), LogEventLevel.Information)
                .Enrich.FromLogContext()
                .WriteTo.Console()
                .WriteTo.Seq(serverUrl)
                //Serilog.Sinks.File    //Output---- 1. log.txt, 2. log_001.txt, 3. log_002.txt
                .WriteTo.File(path: $"logs/{logFilename.Value}-.log",
                              outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u4}] {Message:l}{NewLine}{Exception}",
                              rollingInterval: RollingInterval.Day,
                              fileSizeLimitBytes: 512000000,
                              rollOnFileSizeLimit: true,
                              retainedFileCountLimit: null)
                .CreateLogger();
            //NLogBuilder.ConfigureNLog("nlog.config");

            #endregion

            #region Create service collection

            Log.Information("Creating service collection");
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);

            // Create service provider
            Log.Information("Building service provider");
            IServiceProvider serviceProvider = serviceCollection.BuildServiceProvider();

            #endregion

            try
            {
                Log.Information("Starting service");
                await serviceProvider.GetService<App>().RunAsync(args);
                Log.Information("Ending service");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error running service");
                throw ex;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        static void ConfigureServices(IServiceCollection serviceCollection)
        {
            // Add logging
            serviceCollection.AddSingleton(LoggerFactory.Create(builder =>
            {
                builder.AddSerilog(dispose: true);
            }));

            // Add access to generic IConfigurationRoot
            serviceCollection.AddSingleton<IConfigurationRoot>(_configuration);

            // Add app
            serviceCollection.AddOptions();
            serviceCollection.AddTransient<App>();

            // other configs
            serviceCollection.AddLogging();
            serviceCollection.AddSingleton<INLogManager, NLogManager>();
            // Data mapper profiler setting
            serviceCollection.AddAutoMapper(typeof(ModelMappingProfile).Assembly);
            serviceCollection.AddSingleton(Log.Logger);
            serviceCollection.AddCacheConfiguration(_configuration);
            serviceCollection.AddHttpClient();

            // Mvc, Controller, JsonOptions
            serviceCollection.ConfigureBaseOptionsFeature();

            // RabbitMq
            serviceCollection
                .AddConfRabbitMq(_configuration)
                .AddPublicerRabbitMQ(_configuration);
            // ELK
            serviceCollection.AddElasticSearchConf(_configuration);

            // Session
            serviceCollection.AddSession(options =>
            {
                // Set a short timeout
                options.IdleTimeout = TimeSpan.FromMinutes(20);
                options.Cookie.HttpOnly = true;
            });
            serviceCollection.AddSingleton<RequestHandler>();
            serviceCollection.AddHttpContextAccessor();

            // Data Context
            serviceCollection.ConfigureBusinessFeatures(_configuration: _configuration);
        }

        private static void DisposeServices(IServiceProvider serviceProvider)
        {
            if (serviceProvider == null)
            {
                return;
            }
            if (serviceProvider is IDisposable sp)
            {
                sp.Dispose();
            }
        }
    }
}

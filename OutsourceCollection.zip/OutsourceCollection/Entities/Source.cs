﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Source
    {
        public int Id { get; set; }
        public string Source_name { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int NumberOfProcess { get; set; }
    }
}

﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class Operations
    {
        public const string AND = " AND ";
        public const string OR = " OR ";
    }
}

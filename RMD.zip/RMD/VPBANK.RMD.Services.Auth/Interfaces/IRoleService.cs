﻿using System.Collections.Generic;
using VPBANK.RMD.Data.Auth.Entities.Views;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Services.Auth.DataContracts;
using VPBANK.RMD.Utils.Common.Helpers.Paging;

namespace VPBANK.RMD.Services.Auth.Interfaces
{
    public interface IRoleService
    {
        IEnumerable<SelectedItem> GuiDataRoles();
        PaginatedContentResults<ViewUserRole> QueryUserRoles(PaginatedInputModel paginatedParams);
        UserRoleMappingDto Save(UserRoleMappingDto userRoleMapping);
        void DeleteRoleByUsername(string username);
        void DeleteFunctionRole(string funcRole);
        void DeleteComponentRole(string compRole);
    }
}

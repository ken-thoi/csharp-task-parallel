﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.Repositories.Auth.Interfaces;

namespace VPBANK.RMD.Repositories.Auth.Implements
{
    public class UserRepository : Repository<AuthContext, User, int>, IUserRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly ILogger<User> _logger;
        protected readonly AuthContext _authContext;

        public UserRepository(IDistributedCache distributedCache, ILogger<User> logger, ITrackableRepository<AuthContext, User, int> trackableRepository,
            AuthContext authContext) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _logger = logger;
            _authContext = authContext;
        }

        public async Task<IEnumerable<User>> FindAllAsync()
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users;
        }

        public User FindByIdAndIsDeleted(int pk_Id, string isDeleted)
        {
            return TrackableRepository
                .Queryable()
                .AsEnumerable()
                .SingleOrDefault(c => c.Pk_Id == pk_Id && !string.IsNullOrEmpty(c.Is_Deleted) && c.Is_Deleted.Equals(isDeleted));
        }

        public User FindByUserNameAndIsDeleted(string username, string isDeleted)
        {
            return TrackableRepository
                .Queryable()
                .AsEnumerable()
                .SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) &&
                                      c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase) &&
                                      (string.IsNullOrEmpty(c.Is_Deleted) || c.Is_Deleted.Equals(0.ToString())));
        }

        public async Task<User> FindByUserNameAndIsDeletedAsync(string username, string isDeleted)
        {
            var users = await TrackableRepository.Query().SelectAsync();
            return users.SingleOrDefault(c => !string.IsNullOrEmpty(c.Username) &&
                                              c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase) &&
                                              (string.IsNullOrEmpty(c.Is_Deleted) || c.Is_Deleted.Equals(0.ToString())));
        }

        public IEnumerable<User> FindAllByQuery(bool? isDeleted)
        {
            var isDeletedParam = new SqlParameter("@IsDeleted", isDeleted);
            return _authContext.UsersQuery.FromSqlRaw("EXEC core.Get_Users @IsDeleted = @IsDeleted", isDeletedParam).AsEnumerable();
        }

        public IEnumerable<User> FindAllNonRole()
        {
            var query = "SELECT * FROM core.[User] WHERE Username NOT IN (SELECT username FROM core.View_User_Role) AND Is_Deleted = 0";
            return _authContext.UsersQuery.FromSqlRaw(query).AsEnumerable();
        }
    }
}

﻿namespace VPBANK.RMD.EFCore.Entities
{
    public class EfCoreConstants
    {
        public const string Pk_Id = "Pk_Id";
    }
}

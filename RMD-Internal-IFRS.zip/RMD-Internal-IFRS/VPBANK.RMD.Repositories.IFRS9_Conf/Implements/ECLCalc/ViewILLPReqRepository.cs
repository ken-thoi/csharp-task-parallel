﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.ECLCalc;
using VPBANK.RMD.Data.IFRS9_Conf.Views.WF;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.ECLCalc
{
    public class ViewILLPReqRepository : Repository<IFRS9_ConfContext, ViewIfrsILLPReq, long>, IViewILLPReqRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public ViewILLPReqRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_ConfContext, ViewIfrsILLPReq, long> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<ViewIfrsILLPReq> FindAllByCustomerAndReqStatus(int fk_Flow_Execution_Id, int fk_Task_Execution_Id, string customer_Id, DateTime business_Date, string request_Status)
        {
            try
            {
                var query = new StringBuilder();
                query.Append($"SELECT c.* FROM Apr.View_IFRS_ILLP_Req AS c WHERE c.Fk_Flow_Execution_Id = {fk_Flow_Execution_Id} AND c.Fk_Task_Execution_Id = {fk_Task_Execution_Id} AND c.Customer_Id = '{customer_Id}' AND c.Business_Date = '{business_Date.ToString(DefFormats.DATE_FORMAT)}' AND c.Request_Status = '{request_Status}'");
                return TrackableRepository
                    .QueryableFromSqlRaw(query.ToString())
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

Phoenix -> External
Risk -> Internal

.NET Core template: v3.1.6
TrackableEntities.Common.Core: v3.1.0
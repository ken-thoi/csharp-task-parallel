﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class SpecificCharacteristics
    {
        public const char DOT = '.';
        public const char COMMA = ',';
        public const char SEMICOLON = ';';
        public const char EXCLAMATION = '!';
        public const char BULLET = '*';
        public const char PILE = '|';
        public const char QUOTE_SIGNLE = '\'';
        public const char QUOTE_DOUBLE = '\"';
        public const char SLASH = '/';
        public const char BACK_SLASH = '\\';
        public const char DASH = '-';
        public const char UNDERSCORE = '_';
        public const char WHITE_SPACE = ' ';
        public const char POUND = '#';
        public const char PERCENT = '%';

        public const char BRACKET_FIRST = '[';
        public const char BRACKET_LAST = ']';
        public const char PARENTHESES_FIRST = '(';
        public const char PARENTHESES_LAST = ')';
    }
}

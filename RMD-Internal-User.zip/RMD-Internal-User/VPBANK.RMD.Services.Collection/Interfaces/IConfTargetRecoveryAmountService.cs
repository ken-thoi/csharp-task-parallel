﻿using System.Collections.Generic;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.Utils.Common.Datas;

namespace VPBANK.RMD.Services.Collection.Interfaces
{
    public interface IConfTargetRecoveryAmountService
    {
        IList<FieldValidateResponse> Validate(ConfTargetRecoveryAmountDto entity);
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations
{
    [Table("View_Ifrs_Data_Initial_Result", Schema = "BCL")]
    public class ViewIfrsDataInitialResult : EntityBase<int>
    {
        public override int Pk_Id { get; set; }
        public string File_Name { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public int Fk_Lu_Upload_Id { get; set; }
        public string Fk_Business_Unit_Id1 { get; set; }
        public string Fk_Business_Unit_Id2 { get; set; }
        public string Bu_Inputer { get; set; }
        public string Bu_Approval { get; set; }
        public string Validation_Rule { get; set; }
    }
}

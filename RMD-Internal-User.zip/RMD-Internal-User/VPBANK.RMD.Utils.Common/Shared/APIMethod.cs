﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class API_METHODS
    {
        public const string GET = "GET";
        public const string POST = "POST";
        public const string PUT = "PUT";
        public const string DELETE = "DELETE";
        public const string PATCH = "PATCH";
    }
}

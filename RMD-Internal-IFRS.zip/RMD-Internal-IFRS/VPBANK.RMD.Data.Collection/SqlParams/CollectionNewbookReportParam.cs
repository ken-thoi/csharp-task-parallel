﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Collection.SqlParams
{
    public class CollectionNewbookReportParam : SqlParamBase
    {
        public DateTime ReportDate { get; set; }
        public string CustomerId { get; set; }
        public string OsCompany { get; set; }
    }
}

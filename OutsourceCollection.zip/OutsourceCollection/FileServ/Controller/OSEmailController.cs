﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class OSEmailController
    {
        public static OSEmail GetOSEmail(string email)
        {
            string procedureName = "[FileServ].[OSEmail_SEL]";
            List<SqlParameter> listParam = new List<SqlParameter>();
            listParam.Add(new SqlParameter("@pv_Email", email));
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, procedureName, listParam.ToArray());
            OSEmail osEmail = new OSEmail();
            if (dt.Rows.Count != 1)
                return null;
            else
                return Utils.UtilFunction.CreateItemFromRow<OSEmail>(dt.Rows[0]);
        }
    }
}

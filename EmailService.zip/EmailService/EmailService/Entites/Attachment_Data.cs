﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class Attachment_Data
    {
        public long Id { get; set; }
        public int MessageID { get; set; }
        public string Filename { get; set; }
        public byte [] FileData { get; set; }
    }
}

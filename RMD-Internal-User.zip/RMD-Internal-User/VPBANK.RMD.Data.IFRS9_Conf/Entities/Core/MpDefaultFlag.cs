﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Mp_Default_Flag", Schema = "Core")]
    public class MpDefaultFlag : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Violate_Reason { get; set; }
        public string Customer_Type { get; set; }
        public string Wo_Flag { get; set; }
        public string Bb_Flag { get; set; }
        public string Ews_result { get; set; }
        public string Cust_loan_group_Range { get; set; }
        public string Default_Flag { get; set; }
        public DateTime? Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

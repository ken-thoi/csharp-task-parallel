﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech
{
    [Table("Conf_Exposure_Type", Schema = "Tech")]
    public class ConfExposureType : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Contract_Id_N_Filter { get; set; }
        public string Gl_Filter { get; set; }
        public string Sum_Amount_Fcy_Range { get; set; }
        public string Product_Code_Filter { get; set; }
        public string Sub_Portfolio_Code { get; set; }
        public int Priority { get; set; }
        public string Exposure_Type { get; set; }
        public string Ecl_Approach { get; set; }

        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Entities.Commons;

namespace VPBANK.RMD.Services.Auth.Interfaces
{
    public interface IUserService
    {
        User FindByUsername(string username);
        User FindByUsernameAndOtherId(int id, string username);
        User FindByEmail(string email);
        User FindByEmailAndOtherId(int id, string email);
        User FindByUsernameAndEmail(string username, string email);
        User FindByUsernameAndEmailAndId(int id, string username, string email);
        IList<string> FindBySupperAdmin();
        IList<string> FindEmailsByUsernames(List<string> usernames);
        IList<string> FindEmailsByUsernamesActive();
        void DeleteUserById(int pk_Id);
        Task<IList<SelectedItem>> FindUsernames();
        IList<SelectedItem> FindByUserNonRole();

        void UpdateLastLoginByUserName(string userName);
    }
}

﻿using Entities;
using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class FileRequestController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private static object _lockGetRequest = new object();

        public static void ProcessRequest()
        {
            logger.Info("=== Start Run Process Request ===");
            while (true)
            {
                string processID = Guid.NewGuid().ToString();
                try
                {
                    string command = "[FileServ].[FileRequest_INS_From_Email]";
                    Utils.SqlHelper.ExecuteNonQuery(command, true, 120000);
                    Thread.Sleep(10000);
                }
                catch (Exception ex)
                {
                    logger.Error(processID + "| Process request Failed");
                    logger.Error(ex);
                    logger.Error(processID + "| Process request will sleep for 5 second");
                    Thread.Sleep(5000);
                }
            }
        }

        public static void ProcessRequestDetail()
        {
            string commandGetUnprocess = "[FileServ].[FileRequest_Get_UnProcess_ID]";
            string commandProcess = "[FileServ].[FileRequest_Process_Request]";
            while (true)
            {
                string processID = Guid.NewGuid().ToString();
                try
                {
                    string id = Convert.ToString(Utils.SqlHelper.ExecuteScalar(commandGetUnprocess));
                    if (string.IsNullOrEmpty(id))
                        Thread.Sleep(10000);
                    else
                    {
                        Utils.SqlHelper.ExecuteNonQuery(commandProcess, new SqlParameter[] { new SqlParameter("@pv_Id", id) });
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(processID + "| Process request detail Failed");
                    logger.Error(ex);
                    logger.Error(processID + "| Process request detail will sleep for 5 second");
                    Thread.Sleep(5000);
                }
            }
        }

        public static void ProcessResponeRequest()
        {
            logger.Info("=== Start Run Process Respone Request ===");
            List<Task> listWorkingTask = new List<Task>();
            while (true)
            {
                try
                {
                    if (listWorkingTask.Count < GetMaximunProcess)
                    {
                        lock (listWorkingTask)
                        {
                            var fileRequest = GetFileRequestToRespone;
                            if (fileRequest != null)
                            {
                                logger.Info("Before Start: Curent running respone task: " + listWorkingTask.Count);
                                var task = Task.Factory.StartNew(() =>
                                {
                                    ResponeRequest(fileRequest);
                                    //ResponeRequestThread(fileRequest);
                                });
                                task.ContinueWith(t =>
                                {
                                    lock (listWorkingTask)
                                    {
                                        listWorkingTask.Remove(task);
                                        logger.Info("After Run: Curent running respone task: " + listWorkingTask.Count);
                                    }
                                });
                                listWorkingTask.Add(task);
                            }
                            else
                                Thread.Sleep(1000);
                        }
                    }
                    else
                    {
                        logger.Info("Process Respone Request is running max process allow, waiting for 10 seconds");
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                    Thread.Sleep(5000);
                }
            }
        }

        static HashSet<string> currentProcessFile = new HashSet<string>();

        private static void ResponeRequest(FileRequest fileRequest)
        {
            logger.Info($"--Start Respone request Id: {fileRequest.Id}");
            int count = 5;
            while (count > 0)
            {
                try
                {
                    var handle = new EventWaitHandle(false, EventResetMode.ManualReset);
                    Thread thread = new Thread(delegate ()
                    {
                        ResponeRequestWork(fileRequest);
                        handle.Set();
                    });
                    thread.Start();
                    handle.WaitOne(20 * 60 * 1000);
                    if(thread.IsAlive)
                    {
                        thread.Abort();
                        throw new Exception("Thread respone take to long, kill for restart");
                    }
                    break;
                }
                catch (Exception ex)
                {
                    fileRequest.Status = RequestStatus.UploadedToShareFileError;
                    FileRequestUpdateStatus(fileRequest);
                    logger.Error(ex);
                    count--;
                }
            }
        }

        private static void ResponeRequestWork(FileRequest fileRequest)
        {
            var osEmail = OSEmailController.GetOSEmail(fileRequest.From);
            string year = Convert.ToString(DateTime.Now.Year);
            string quater = "Q" + GetQuarter;
            var newfolderLocation = Path.Combine(GetSharepointFolder, year, year + "-" + quater, osEmail.OSCompany, DateTime.Now.ToString("yyyy-MM-dd"));
            Directory.CreateDirectory(newfolderLocation);
            List<Task> listWorkingTask = new List<Task>();

            var lstFileRequest = GetFilePackageToRespone(fileRequest.Id);
            foreach (var filePkg in lstFileRequest)
            {
                if (!IsFileShared(filePkg.FK_Customer, filePkg.MD5Checksum, osEmail.OSCompany))
                {
                    lock (currentProcessFile)
                    {
                        var processingKey = filePkg.FK_Customer + "$" + filePkg.MD5Checksum + "$" + osEmail.OSCompany;
                        if (currentProcessFile.Contains(processingKey))
                        {
                            listWorkingTask.Add(Task.Factory.StartNew(() =>
                            {
                                int countFaild = 600;
                                while (true)
                                {
                                    if (IsFileShared(filePkg.FK_Customer, filePkg.MD5Checksum, osEmail.OSCompany))
                                        break;
                                    else
                                    {
                                        Thread.Sleep(3000);
                                        countFaild--;
                                        if (countFaild <= 0)
                                        {
                                            string Error = "Time to up load file: " + Path.Combine(newfolderLocation, filePkg.Destination) + " is to long";
                                            throw new Exception(Error);
                                        }
                                    }

                                }
                            }));
                        }
                        else
                        {
                            currentProcessFile.Add(processingKey);
                            listWorkingTask.Add(Task.Factory.StartNew(() =>
                            {
                                ProcessRequestOverSharePoint(fileRequest, filePkg, newfolderLocation);
                                UpdateSharedInfo(filePkg.FK_Customer, filePkg.MD5Checksum, osEmail.OSCompany);
                                lock (currentProcessFile)
                                    currentProcessFile.Remove(processingKey);
                            }));
                        }
                    }
                }
            }

            Task.WaitAll(listWorkingTask.ToArray());
            SendResponeEmail(fileRequest);
            fileRequest.Status = RequestStatus.Done;
            FileRequestUpdateStatus(fileRequest);
        }

        private static Dictionary<string, Thread> listWorkingTask = new Dictionary<string, Thread>();

        private static void ResponeRequestThread(FileRequest fileRequest)
        {
            logger.Info($"--Start Respone request Id: {fileRequest.Id}");
            int count = 5;
            while (count > 0)
            {
                try
                {
                    var osEmail = OSEmailController.GetOSEmail(fileRequest.From);
                    string year = Convert.ToString(DateTime.Now.Year);
                    string quater = "Q" + GetQuarter;
                    var newfolderLocation = Path.Combine(GetSharepointFolder, year, year + "-" + quater, osEmail.OSCompany, DateTime.Now.ToString("yyyy-MM-dd"));
                    Directory.CreateDirectory(newfolderLocation);
                    Dictionary<string, WaitHandle> listWaitHandle = new Dictionary<string, WaitHandle>();

                    var lstFileRequest = GetFilePackageToRespone(fileRequest.Id);
                    foreach (var filePkg in lstFileRequest)
                    {
                        if (!IsFileShared(filePkg.FK_Customer, filePkg.MD5Checksum, osEmail.OSCompany))
                        {
                            var processingKey = filePkg.FK_Customer + "$" + filePkg.MD5Checksum + "$" + osEmail.OSCompany;

                            lock (currentProcessFile)
                            {
                                if (currentProcessFile.Contains(processingKey))
                                {
                                    lock (listWorkingTask)
                                    {
                                        var handle = new EventWaitHandle(false, EventResetMode.ManualReset);
                                        Thread thread = new Thread(delegate ()
                                        {
                                            int countFaild = 600;
                                            while (true)
                                            {
                                                if (IsFileShared(filePkg.FK_Customer, filePkg.MD5Checksum, osEmail.OSCompany))
                                                    break;
                                                else
                                                {
                                                    Thread.Sleep(3000);
                                                    countFaild--;
                                                    if (countFaild <= 0)
                                                    {
                                                        listWorkingTask[processingKey].Abort();
                                                        (listWaitHandle[processingKey] as EventWaitHandle).Set();
                                                        lock (listWorkingTask)
                                                            listWorkingTask.Remove(processingKey);
                                                        string Error = "Time to up load file: " + Path.Combine(newfolderLocation, filePkg.Destination) + " is to long";
                                                        break;
                                                    }
                                                }
                                            }
                                            handle.Set();
                                        });
                                        listWaitHandle.Add(processingKey, handle);
                                        thread.Start();
                                    }
                                }
                                else
                                {
                                    lock (listWorkingTask)
                                    {
                                        currentProcessFile.Add(processingKey);
                                        var handle = new EventWaitHandle(false, EventResetMode.ManualReset);
                                        Thread thread = new Thread(delegate ()
                                        {
                                            ProcessRequestOverSharePoint(fileRequest, filePkg, newfolderLocation);
                                            UpdateSharedInfo(filePkg.FK_Customer, filePkg.MD5Checksum, osEmail.OSCompany);
                                            lock (currentProcessFile)
                                                currentProcessFile.Remove(processingKey);
                                            handle.Set();
                                        });
                                        listWorkingTask.Add(processingKey, thread);
                                        listWaitHandle.Add(processingKey, handle);
                                        thread.Start();
                                    }
                                }
                            }
                        }
                    }
                    WaitHandle.WaitAll(listWaitHandle.Values.ToArray());
                    SendResponeEmail(fileRequest);
                    fileRequest.Status = RequestStatus.Done;
                    FileRequestUpdateStatus(fileRequest);
                    break;
                }
                catch (Exception ex)
                {
                    fileRequest.Status = RequestStatus.UploadedToShareFileError;
                    FileRequestUpdateStatus(fileRequest);
                    logger.Error(ex);
                    count--;

                    if (count <= 0)
                    {
                        SendResponeErorEmail(fileRequest);
                    }
                }
            }
        }

        private static void SendResponeErorEmail(FileRequest fileRequest)
        {
            Email_Queue email = new Email_Queue();
            email.From_Mail = fileRequest.To;
            email.Mail_To = fileRequest.From;
            email.OriginMessageID = fileRequest.MessageID;
            email.Subject = "RE: " + fileRequest.Subject;
            email.Content = SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_TEMP_DOWN_SERVICE");
            EmailController.SendEmail(email);
        }

        private static void ProcessRequestOverSharePoint(FileRequest fileRequest, FilePackage filePkg, string newfolderLocation)
        {
            int count = 10;
            while (count > 0)
            {
                try
                {
                    var fileLocation = Path.Combine(FilePackageController.GetPackageFolder, filePkg.Destination);
                    var newFileLocation = Path.Combine(newfolderLocation, filePkg.Destination);
                    if (File.Exists(newFileLocation))
                    {
                        if (fileRequest.ForceExcute)
                        {
                            File.Delete(newFileLocation);
                            File.Copy(fileLocation, newFileLocation);
                        }
                    }
                    else
                        File.Copy(fileLocation, newFileLocation);
                    break;
                }
                catch (Exception ex)
                {
                    count--;
                    logger.Error(ex);
                    throw;
                }
            }
        }

        private static void SendResponeEmail(FileRequest fileRequest)
        {
            Email_Queue email = new Email_Queue();
            email.From_Mail = fileRequest.To;
            email.Mail_To = fileRequest.From;
            email.OriginMessageID = fileRequest.MessageID;
            email.Subject = "RE: " + fileRequest.Subject;

            var listContractSuccessful = GetFileProcessSuccessful(fileRequest.Id);
            var listContractFailed = GetFileProcessFailed(fileRequest.Id);
            var listDocumentIDFailed = GetFileDoumentIDFailed(fileRequest.Id);

            string body = string.Empty;
            if (!string.IsNullOrEmpty(listContractSuccessful))
                body += SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_SUCCESSFUL_PART").Replace("[@ContractNumber]", listContractSuccessful);

            if (!string.IsNullOrEmpty(listContractFailed))
                body += SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_DOWNLOAD_ERROR_PART").Replace("[@ContractNumber]", listContractFailed);

            if (!string.IsNullOrEmpty(listDocumentIDFailed))
                body += SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_DOCID_ERROR_PART").Replace("[@ContractNumber]", listDocumentIDFailed);

            email.Content = SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST").Replace("[@Body]", body);
            EmailController.SendEmail(email);
        }

        public static int GetQuarter
        {
            get
            {
                return (DateTime.Now.Month + 2) / 3;
            }
        }

        private static void ProcessRequestOverEmail(FileRequest fileRequest, FilePackage filePkg)
        {
            var fileLocation = Path.Combine(FilePackageController.GetPackageFolder, filePkg.Destination);
            var info = new FileInfo(fileLocation);

            if (info.Length < GetMaximunFileSize)
            {
                Email_Queue email = new Email_Queue();
                email.From_Mail = fileRequest.To;
                email.Mail_To = fileRequest.From;
                email.OriginMessageID = fileRequest.MessageID;
                email.Attachment = fileLocation;
                email.Subject = "RE: " + fileRequest.Subject;
                email.Content = GetResponeTemplate;
                EmailController.SendEmail(email);
            }
            else
            {
                var listSegment = FilePackageSegmentController.SelectFilePackageSegment(filePkg.Id);
                if (listSegment.Count == 0)
                {
                    CreateZipSegment(fileRequest, filePkg, fileLocation);
                }
                else
                {
                    foreach (var item in listSegment)
                    {
                        Email_Queue email = new Email_Queue();
                        email.From_Mail = fileRequest.To;
                        email.Mail_To = fileRequest.From;
                        email.OriginMessageID = fileRequest.MessageID;
                        email.Attachment = Path.Combine(GetEmailAttachSegment, item.Destination);
                        email.Subject = "RE: " + fileRequest.Subject;
                        email.Content = GetResponeTemplate;
                        EmailController.SendEmail(email);
                    }
                }
            }
        }

        private static void CreateZipSegment(FileRequest fileRequest, FilePackage filePkg, string fileLocation)
        {
            var newFileLocation = Path.Combine(GetEmailAttachSegment, filePkg.Destination);
            using (ZipFile zip = new ZipFile())
            {
                zip.AddFile(fileLocation, "/");
                zip.MaxOutputSegmentSize = GetMaximunFileSize;
                zip.CompressionLevel = Ionic.Zlib.CompressionLevel.None;
                zip.CompressionMethod = CompressionMethod.None;
                zip.Save(newFileLocation);
                var total = zip.NumberOfSegmentsForMostRecentSave;
                List<FilePackageSegment> listFilePackageSegment = new List<FilePackageSegment>();
                List<FileInfo> listFile = new List<FileInfo>();
                for (int i = 0; i < total - 1; i++)
                {
                    FilePackageSegment filePackageSegment = new FilePackageSegment();
                    filePackageSegment.FK_FilePackage_Id = filePkg.Id;
                    string segPath = GenSegmentFilename(newFileLocation, i + 1);
                    filePackageSegment.Destination = segPath.Replace(GetEmailAttachSegment, "");
                    filePackageSegment.Destination = filePackageSegment.Destination.StartsWith("\\") ? filePackageSegment.Destination.Substring(1) : filePackageSegment.Destination;
                    filePackageSegment.Size = new FileInfo(segPath).Length;
                    filePackageSegment.MD5Checksum = Utils.UtilFunction.CalculateMD5FromFile(segPath);
                    listFilePackageSegment.Add(filePackageSegment);

                    Email_Queue email = new Email_Queue();
                    email.From_Mail = fileRequest.To;
                    email.Mail_To = fileRequest.From;
                    email.OriginMessageID = fileRequest.MessageID;
                    email.Attachment = segPath;
                    email.Subject = "RE: " + fileRequest.Subject;
                    email.Content = GetResponeTemplate;
                    EmailController.SendEmail(email);
                }

                FilePackageSegmentController.DeleteFilePackageSegment(filePkg.Id);
                FilePackageSegmentController.InsertFilePackageSegment(listFilePackageSegment);
            }
        }

        private static string GenSegmentFilename(string input, int fileNumber)
        {
            return input.Replace("." + input.Split('.').LastOrDefault(), "") + ".z" + fileNumber.ToString("D2");
        }

        private static string GetEmailAttachSegment
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "EMAIL_ATTACH_SEGMENT");
            }
        }

        private static string GetResponeTemplate
        {
            get
            {
                return SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST");
            }
        }

        private static string GetResponeTemplateWithErrorDownloadOnly
        {
            get
            {
                return SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_WITH_DOWNLOAD_ERROR");
            }
        }

        private static string GetResponeTemplateWithDocumentIDErrorOnly
        {
            get
            {
                return SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_WITH_DOCUMENTID_ERROR");
            }
        }

        private static string GetResponeTemplateWithDocumentIdAndDownloadError
        {
            get
            {
                return SysVarController.GetSystemValue("EMAIL_TEMPLATE", "RESPONE_REQUEST_WITH_DOCUMENTID_DOWNLOAD_ERROR");
            }
        }

        public static string GetSharepointFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "SHAREPOINT_ONLINE_FOLDER");
            }
        }

        private static int GetMaximunProcess
        {
            get
            {
                return Convert.ToInt32(SysVarController.GetSystemValue("PROCESS_CONTROL", "FILE_REQUEST_MAXIMUM_THREAD"));
            }
        }

        private static int GetMaximunFileSize
        {
            get
            {
                return Convert.ToInt32(SysVarController.GetSystemValue("EMAIL_TEMPLATE", "MAXIMUM_FILE_ATTACH_SIZE"));
            }
        }

        public static FileRequest GetFileRequestToRespone
        {
            get
            {
                lock (_lockGetRequest)
                {
                    string command = "[FileServ].[FileRequest_Get_Request_To_Respone]";
                    DataTable dt = new DataTable();
                    Utils.SqlHelper.Fill(dt, command, true, 120000);
                    if (dt.Rows.Count == 0)
                        return null;
                    else
                        return Utils.UtilFunction.CreateItemFromRow<FileRequest>(dt.Rows[0]);
                }
            }
        }

        public static List<FilePackage> GetFilePackageToRespone(int FileRequest_id)
        {
            List<FilePackage> lstReturn = new List<FilePackage>();
            string command = "[FileServ].[FilePackage_GetByFileRequest]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FileRequest_id", FileRequest_id) });
            foreach (DataRow dr in dt.Rows)
                lstReturn.Add(Utils.UtilFunction.CreateItemFromRow<FilePackage>(dr));
            return lstReturn;
        }

        public static string GetFileProcessSuccessful(int FileRequest_id)
        {
            string command = "[FileServ].[FilePackage_GetByFileRequest_Successful]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FileRequest_id", FileRequest_id) });
            if (dt.Rows.Count == 0)
                return string.Empty;
            else
                return string.Join("; ", dt.AsEnumerable().Select(r => Convert.ToString(r[0])).ToArray());
        }

        public static string GetFileProcessFailed(int FileRequest_id)
        {
            string command = "[FileServ].[FilePackage_GetByFileRequest_ProcessFailed]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FileRequest_id", FileRequest_id) });
            if (dt.Rows.Count == 0)
                return string.Empty;
            else
                return string.Join("; ", dt.AsEnumerable().Select(r => Convert.ToString(r[0])).ToArray());
        }

        public static string GetFileDoumentIDFailed(int FileRequest_id)
        {
            string command = "[FileServ].[FilePackage_GetByFileRequest_DocumentIDFaild]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FileRequest_id", FileRequest_id) });
            if (dt.Rows.Count == 0)
                return string.Empty;
            else
                return string.Join("; ", dt.AsEnumerable().Select(r => Convert.ToString(r[0])).ToArray());
        }

        private static void FileRequestUpdateStatus(FileRequest fileRequest)
        {
            List<SqlParameter> lstParam = new List<SqlParameter>();
            lstParam.Add(new SqlParameter("@pv_Id", fileRequest.Id));
            lstParam.Add(new SqlParameter("@pv_Status", fileRequest.Status));
            Utils.SqlHelper.ExecuteNonQuery("[FileServ].[FileRequest_Update_Status]", lstParam.ToArray());
        }

        private static bool IsFileShared(int fk_ContractNumber, string ChecksumMD5, string OSCompany)
        {
            List<SqlParameter> lstParam = new List<SqlParameter>();
            lstParam.Add(new SqlParameter("@pv_FK_CustomerDocument_ID", fk_ContractNumber));
            lstParam.Add(new SqlParameter("@pv_ChecksumMD5", ChecksumMD5));
            lstParam.Add(new SqlParameter("@pv_OSCompany", OSCompany));
            return Convert.ToBoolean(Utils.SqlHelper.ExecuteScalar("[FileServ].[LoanAllocation_CheckSharedFile]", lstParam.ToArray()));
        }

        private static void UpdateSharedInfo(int fk_ContractNumber, string ChecksumMD5, string OSCompany)
        {
            List<SqlParameter> lstParam = new List<SqlParameter>();
            lstParam.Add(new SqlParameter("@pv_FK_CustomerDocument_ID", fk_ContractNumber));
            lstParam.Add(new SqlParameter("@pv_ChecksumMD5", ChecksumMD5));
            lstParam.Add(new SqlParameter("@pv_OSCompany", OSCompany));
            Utils.SqlHelper.ExecuteNonQuery("[FileServ].[LoanAllocation_UpdateSharedInfo]", lstParam.ToArray());
        }
    }
}

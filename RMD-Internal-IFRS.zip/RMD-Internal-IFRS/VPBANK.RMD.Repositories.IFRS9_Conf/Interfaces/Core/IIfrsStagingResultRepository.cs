﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core
{
    public interface IIfrsStagingResultRepository : IQueryRepository<IFRS9_ConfContext, IfrsStagingResult>
    {
        List<IfrsStagingResult> FindAllContractStagingByCustomerId(string customerId, DateTime businessDate);
    }
}

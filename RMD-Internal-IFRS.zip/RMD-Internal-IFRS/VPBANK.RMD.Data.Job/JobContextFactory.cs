﻿using Microsoft.EntityFrameworkCore.Design;

namespace VPBANK.RMD.Data.Job
{
    public class JobContextFactory : IDesignTimeDbContextFactory<JobContext>
    {
        public JobContext CreateDbContext(string[] args)
        {
            //var optionsBuilder = new DbContextOptionsBuilder<JobContext>();
            //optionsBuilder.UseSqlServer("Server=10.37.16.226\\dev; Database=Job; User ID=dev_user; Password=12345a@");
            //return new JobContext(optionsBuilder.Options);
            return null;
        }
    }
}

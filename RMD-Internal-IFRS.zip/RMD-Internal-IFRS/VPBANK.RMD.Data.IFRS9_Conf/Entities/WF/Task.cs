﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Task", Schema = "WF")]
    public class Task : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Fk_Business_Unit_Id { get; set; }

        public string Task_Name { get; set; }

        public string Task_Screen_Code { get; set; }

        public string Task_Desc { get; set; }

        public string Task_Short_Desc { get; set; }

        public string Task_Type { get; set; }

        public int? Action_Origin_Id { get; set; }

        public int? Linked_Job_Id { get; set; }

        public string Entity_Code { get; set; }

        public string Scenario_Id { get; set; }

        public string Version_Id { get; set; }

        public bool Is_Deleted { get; set; }

        public string Created_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Created_Time { get; set; }

        public string Updated_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Updated_Time { get; set; }
    }

    public class TaskRequestable : Requestable
    {
        public int? Pk_Id { get; set; }

        public string Fk_Business_Unit_Id { get; set; }

        public string Task_Name { get; set; }

        public string Task_Screen_Code { get; set; }

        public string Task_Desc { get; set; }

        public string Task_Short_Desc { get; set; }

        public string Task_Type { get; set; }

        public int? Action_Origin_Id { get; set; }

        public int? Linked_Job_Id { get; set; }

        public string Entity_Code { get; set; }

        public string Scenario_Id { get; set; }

        public string Version_Id { get; set; }

        public bool Is_Deleted { get; set; }

        public string Created_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Created_Time { get; set; }

        public string Updated_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Updated_Time { get; set; }
    }
}

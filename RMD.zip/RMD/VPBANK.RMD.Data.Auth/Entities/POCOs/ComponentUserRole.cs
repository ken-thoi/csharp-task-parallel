﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("Component_User_Role", Schema = "Core")]
    public class ComponentUserRole : BaseEntity<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Username { get; set; }

        public string Role { get; set; }

        public bool Is_Deleted { get; set; }
    }
}

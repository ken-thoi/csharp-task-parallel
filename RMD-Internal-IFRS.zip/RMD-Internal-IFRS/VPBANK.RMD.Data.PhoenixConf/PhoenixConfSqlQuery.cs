﻿namespace VPBANK.RMD.Data.PhoenixConf
{
    public static class PhoenixConf_SqlQuery_Define
    {
        public static readonly string Tech_Get_Coln_Avail_Date = "select * from tech.get_Coln_Avail_Date ('{0}')";

        public static readonly string EXEC_Collection_Send_Email = "EXECUTE Tech.Collection_Send_Email @Business_Date, @in_Segment, @in_Os_Company";
        public static readonly string EXEC_RUN_BATCH_ENGINES = "EXECUTE Tech.Run_Batch_Engine @p_Business_Date = '{0}', @p_Batch_ID = {1}, @p_Entity_Code = '{2}', @p_Approach = '{3}', @p_Scenario_ID = '{4}', @p_Version_ID = '{5}', @p_additional_param = '{6}', @p_Batch_Log_ID = {7} OUTPUT";
        // -- p_FK_Action_Origin_ID: Loader Batch, 2: Engine Job, 7: Loader manual, 8: Engine manual
        public static readonly string EXEC_CHANGE_ADJUST_EXECUTION = "EXECUTE Tech.change_Execution @p_Log_ID, @p_FK_Action_Origin_ID, @p_FK_Trg_Exec_Status_ID";

        // IFRS
        public static readonly string Tech_Get_Table_Ifrs_Validation = "select * from tech.Tech_Get_Table_Ifrs_Validation ('{0}')";
    }
}
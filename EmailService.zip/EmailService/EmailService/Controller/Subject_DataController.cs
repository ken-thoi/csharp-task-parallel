﻿using EmailService.Entites;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Controller
{
    public static class Subject_DataController
    {
        public static void InsertOrUpdateSubjectData(Subject_Data data)
        {
            string command = "[dbo].[Subject_Data_INS]";
            List<SqlParameter> lstParma = new List<SqlParameter>();
            lstParma.Add(new SqlParameter("@pv_MessageID", data.MessageID));
            lstParma.Add(new SqlParameter("@pv_From", data.From));
            lstParma.Add(new SqlParameter("@pv_To", data.To));
            lstParma.Add(new SqlParameter("@pv_Subject", data.Subject));
            lstParma.Add(new SqlParameter("@pv_DateUTC", data.DateUTC));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParma.ToArray());
        }
    }
}

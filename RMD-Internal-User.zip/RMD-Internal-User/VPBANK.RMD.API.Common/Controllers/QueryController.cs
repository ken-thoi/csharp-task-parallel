﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;
using TrackableEntities.Common.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Shared;

namespace VPBANK.RMD.API.Common.Controllers
{
    public abstract class QueryController<TContext, TEntity, TKey> : GenericController<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        public QueryController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<TContext> unitOfWork,
            ITrackableRepository<TContext, TEntity, TKey> trackableRepository,
            IGenericRepository<TContext, TEntity, TKey> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// List all records.
        /// </summary>
        /// <returns>IEnumerable</returns>
        [HttpGet]
        public virtual ActionResult<IEnumerable<TEntity>> All()
        {
            try
            {
                //var webrootFolder = _env.WebRootPath;
                var results = _genericRepository.Queryable().AsEnumerable();
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find object by key.
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns>Object</returns>
        [HttpGet(template: "{pk_Id}")]
        public virtual async Task<ActionResult<TEntity>> FindById([Required][NotNull][FromRoute] TKey pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var entity = await _genericRepository.FindAsync(pk_Id);
                if (entity == null) return NotFound();
                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Check existed object
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{pk_Id}")]
        public virtual async Task<bool> Exists([Required][NotNull][FromRoute] TKey pk_Id)
        {
            return await _genericRepository.ExistsAsync(pk_Id);
        }

        /// <summary>
        /// Post list all records with filter, sort, paging.
        /// Get by permission by user
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost]
        public virtual async Task<ActionResult<PaginatedContentResults<TEntity>>> Query([Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                // build data role filter
                paginatedParams = BuildFilterExpressionDataRoles(paginatedParams);

                // All data
                var total = _genericRepository.CountDataPaginated(paginatedParams);
                var data = _genericRepository.QueryDataPaginated(paginatedParams);
                dynamic result = await SqlQueryDataAsync(total, data, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        private PaginatedInputModel BuildFilterExpressionDataRoles(PaginatedInputModel paginatedParams)
        {
            try
            {
                // Get token
                var payload = GetUserPayloadByHeader();

                // Concat both entity & engine (data role)
                var dataRoleConditions = string.Empty;
                if (payload != null && !string.IsNullOrEmpty(payload.DataRole))
                {
                    var enginesOfUser = payload.DataRole.Split(SpecificSystems.SEMICOLON);
                    foreach (var engine in enginesOfUser)
                    {
                        if (!string.IsNullOrEmpty(engine))
                        {
                            var dataRole = engine.Trim()
                                .Replace(ENGINE_CODES.ENGINE_EXTENTION, string.Empty)
                                .Replace(ENTITY_CODES.ENTITY_EXTENTION, string.Empty);
                            dataRoleConditions = string.IsNullOrEmpty(dataRoleConditions)
                                ? $"{SpecificSystems.QUOTE_SIGNLE}{dataRole}{SpecificSystems.QUOTE_SIGNLE}"
                                : $"{dataRoleConditions}{SpecificSystems.COL_JOIN_COMMA}{SpecificSystems.QUOTE_SIGNLE}{dataRole}{SpecificSystems.QUOTE_SIGNLE}";
                        }
                    }

                    if (!string.IsNullOrEmpty(dataRoleConditions))
                        dataRoleConditions = $"{SpecificSystems.PARENTHESES_FIRST}{dataRoleConditions}{SpecificSystems.PARENTHESES_LAST}";
                }

                // Check has columns permission (Entity_Code, Engine_Code)
                var entityCodeProperty = typeof(TEntity).GetProperty(COLUMNS_NAME.ENTITY_CODE);
                var engineCodeProperty = typeof(TEntity).GetProperty(COLUMNS_NAME.ENGINE_CODE);
                if (entityCodeProperty != null && !string.IsNullOrEmpty(entityCodeProperty.Name) && !string.IsNullOrEmpty(dataRoleConditions))
                {
                    var queryEntityCodeCondition = $"{COLUMNS_NAME.ENTITY_CODE}{Operations.IN}{dataRoleConditions}";
                    paginatedParams.FilterExpression = string.IsNullOrEmpty(paginatedParams.FilterExpression)
                        ? queryEntityCodeCondition
                        : $"{paginatedParams.FilterExpression}{Operations.AND}{queryEntityCodeCondition}";
                }
                if (engineCodeProperty != null && !string.IsNullOrEmpty(engineCodeProperty.Name) && !string.IsNullOrEmpty(dataRoleConditions))
                {
                    var queryEngineCodeCondition = $"{COLUMNS_NAME.ENGINE_CODE}{Operations.IN}{dataRoleConditions}";
                    paginatedParams.FilterExpression = string.IsNullOrEmpty(paginatedParams.FilterExpression)
                        ? queryEngineCodeCondition
                        : $"{paginatedParams.FilterExpression}{Operations.AND}{queryEngineCodeCondition}";
                }

                return paginatedParams;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                throw;
            }
        }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.DataValidations
{
    [Table("View_Web_Core_Request_Detail", Schema = "BCL")]
    public class ViewWebCoreRequestDetail : EntityBase<int>
    {
        public override int Pk_Id { get; set; }
        public DateTime Created_Time { get; set; }
        public string Mod_Id { get; set; }
        public string Request_Detail { get; set; }
        public long Sub_Id { get; set; }
        public long Request_Id { get; set; }
        public string Action { get; set; }
        public string Action_Comment { get; set; }
        public string Req_Status { get; set; }

        public int Fk_Flow_Execution_Id
        {
            get
            {
                try
                {
                    var objJson = JsonConvert.DeserializeObject<dynamic>(Request_Detail);
                    return objJson.Fk_Flow_Execution_Id;
                }
                catch (Exception)
                {
                    return 0;
                }
            }
        }

        public int Fk_Task_Execution_Id
        {
            get
            {
                try
                {
                    var objJson = JsonConvert.DeserializeObject<dynamic>(Request_Detail);
                    return objJson.Fk_Task_Execution_Id;
                }
                catch (Exception)
                {
                    return 0;
                }
            }
        }

        public int Fk_Lu_Upload_Id
        {
            get
            {
                try
                {
                    var objJson = JsonConvert.DeserializeObject<dynamic>(Request_Detail);
                    return objJson.Fk_Lu_Upload_Id;
                }
                catch (Exception)
                {
                    return 0;
                }
            }
        }

        public string File_Name_Upload
        {
            get
            {
                try
                {
                    var objJson = JsonConvert.DeserializeObject<dynamic>(Request_Detail);
                    return objJson.File_Name_Upload.ToString();
                }
                catch (Exception)
                {
                    return string.Empty;
                }
            }
        }
    }
}

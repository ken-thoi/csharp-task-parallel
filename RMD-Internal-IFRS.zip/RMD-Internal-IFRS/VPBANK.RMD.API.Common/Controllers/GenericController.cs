﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Net.Http;
using AutoMapper;
using TrackableEntities.Common.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.API.Common.Controllers
{
    [Authorize]
    public abstract class GenericController<TContext, TEntity, TKey> : BaseController
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        protected readonly IUnitOfWork<TContext> _unitOfWork;
        protected readonly ITrackableRepository<TContext, TEntity, TKey> _trackableRepository;
        protected readonly IGenericRepository<TContext, TEntity, TKey> _genericRepository;

        public GenericController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<TContext> unitOfWork,
            ITrackableRepository<TContext, TEntity, TKey> trackableRepository,
            IGenericRepository<TContext, TEntity, TKey> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService)
        {
            _unitOfWork = unitOfWork;
            _trackableRepository = trackableRepository;
            _genericRepository = genericRepository;
        }
    }
}

﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Utils.Common;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Core
{
    public class IfrsStagingResultRepository : QueryRepository<IFRS9_ConfContext, IfrsStagingResult>, IIfrsStagingResultRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public IfrsStagingResultRepository(IDistributedCache distributedCache,
            IQueryableRepository<IFRS9_ConfContext, IfrsStagingResult> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<IfrsStagingResult> FindAllContractStagingByCustomerId(string customerId, DateTime businessDate)
        {
            try
            {
                if (!string.IsNullOrEmpty(customerId))
                    customerId = customerId.Replace(" ", "l");

                return QueryableRepository
                    .QueryableSql($"exec Core.Get_IFRS_STG '{businessDate.ToString(DefFormats.DATE_FORMAT)}', '{customerId}'")
                    .AsEnumerable()
                    .ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

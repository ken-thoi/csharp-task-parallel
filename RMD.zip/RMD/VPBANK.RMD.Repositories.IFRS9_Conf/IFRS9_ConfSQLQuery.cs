﻿namespace VPBANK.RMD.Repositories.IFRS9_Conf
{
    public static class IFRS9_ConfSQLQuery
    {
        public static readonly string SP_ = "EXECUTE IFRS9_Conf.dbo.sp_ @Business_Date";
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_Written_Off_File", Schema = "BCL")]
    public class ConfWrittenOffFile : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string File_Convention_Code { get; set; }
        public string File_Convention_Name { get; set; }
        public string File_Convention_Desc { get; set; }
        public bool Actived { get; set; }
    }
}

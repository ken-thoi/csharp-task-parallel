﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("Data_Role_Permission", Schema = "Core")]
    public class DataRolePermission : BaseEntity<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int Fk_Role_Id { get; set; }

        public int Fk_Permission_Id { get; set; }
    }
}

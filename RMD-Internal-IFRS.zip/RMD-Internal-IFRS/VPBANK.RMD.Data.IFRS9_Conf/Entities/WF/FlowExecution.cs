﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Flow_Execution", Schema = "WF")]
    public class FlowExecution : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int Fk_Flow_Id { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Business_Date { get; set; }

        public string Flow_Execution_Status { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Start_Time { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? End_Time { get; set; }

        public string Executor_By { get; set; }

        public string Created_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Created_Time { get; set; }

        public string Updated_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Updated_Time { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class IMAP_Config
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int SecureSocketOptions { get; set; }
        public int Port { get; set; }
        public string IMAPServer { get; set; }
        public int TimeLoop { get; set; }
        public string TimeOut { get; set; }
        public string Last_Excuted_Time { get; set; }
    }
}

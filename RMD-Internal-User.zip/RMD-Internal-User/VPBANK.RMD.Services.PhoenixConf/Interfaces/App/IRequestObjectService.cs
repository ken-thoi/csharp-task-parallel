﻿using System;
using System.Threading.Tasks;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Utils.Common.Datas;

namespace VPBANK.RMD.Services.PhoenixConf.Interfaces.App
{
    public interface IRequestObjectService
    {
        Task<RequestObject> InsertOrUpdateAsync(RequestObject req, string reqStatus, RequestStep step, string username, DateTime currentDate);
    }
}

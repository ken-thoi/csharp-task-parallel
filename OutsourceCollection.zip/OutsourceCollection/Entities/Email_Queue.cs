﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Email_Queue
    {
        public int ID { get; set; }
        public string From_Mail { get; set; }
        public string Mail_To { get; set; }
        public string OriginMessageID { get; set; }
        public string Mail_CC { get; set; }
        public string Mail_BCC { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public string Attachment { get; set; }
    }
}

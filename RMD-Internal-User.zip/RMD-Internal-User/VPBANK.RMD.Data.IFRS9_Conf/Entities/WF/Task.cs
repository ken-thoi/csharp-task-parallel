﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("Task", Schema = "WF")]
    public class Task : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int? FK_DefWorkFlow_Id { get; set; }

        public string TaskName { get; set; }

        public string TaskDesc { get; set; }

        public DateTime? BussinessDate { get; set; }

        public string CreatedBy { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? CreatedTime { get; set; }

        public string UpdatedBy { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? UpdatedTime { get; set; }
    }
}

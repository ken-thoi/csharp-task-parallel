﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.BCL
{
    [Table("View_MP_Account_Business_Unit", Schema = "BCL")]
    public class ViewMpAccountBusinessUnit : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Username { get; set; }
        public string Fk_Business_Unit_Id { get; set; }
        public string Business_Unit_Names { get; set; }
        public string Status { get; set; }
    }

    public class ViewMpAccountBusinessUnitRequestable : Requestable
    {
        public int? Pk_Id { get; set; }
        public string Username { get; set; }
        public string Fk_Business_Unit_Id { get; set; }
        public string Business_Unit_Names { get; set; }
        public string Status { get; set; }
    }
}

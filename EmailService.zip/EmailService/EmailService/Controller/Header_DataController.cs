﻿using EmailService.Entites;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Controller
{
    public static class Header_DataController
    {
        public static void InsertOrUpdateHeaderData(Header_Data data)
        {
            string command = "[dbo].[Header_Data_INS]";
            List<SqlParameter> lstParma = new List<SqlParameter>();
            lstParma.Add(new SqlParameter("@pv_uid", data.MessageID));
            lstParma.Add(new SqlParameter("@pv_FK_Header_Type_Id", data.FK_Header_Type_Id));
            lstParma.Add(new SqlParameter("@pv_HeaderValue", data.HeaderValue));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParma.ToArray());
        }

        public static void DeleteHeaderData(int MessageID)
        {
            string command = "[dbo].[Header_Data_DEL]";
            List<SqlParameter> lstParma = new List<SqlParameter>();
            lstParma.Add(new SqlParameter("@pv_MessageID", MessageID));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParma.ToArray());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Services.Auth.DataTransferObjects;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.Services.Auth.Implements
{
    public class RoleService : IRoleService
    {
        private readonly IUnitOfWork<AuthContext> _unitOfWork;
        private readonly IGenericRepository<AuthContext, DataRole, int> _dataRoleRepository;
        private readonly IGenericRepository<AuthContext, BusinessUnitRole, int> _businessUnitRoleRepository;

        private readonly IGenericRepository<AuthContext, DataUserRole, int> _dataUserRoleRepository;
        private readonly IGenericRepository<AuthContext, FunctionUserRole, int> _funcUserRoleRepository;
        private readonly IGenericRepository<AuthContext, ComponentUserRole, int> _compUserRoleRepository;

        public RoleService(IUnitOfWork<AuthContext> unitOfWork,
            IGenericRepository<AuthContext, DataRole, int> dataRoleRepository,
            IGenericRepository<AuthContext, BusinessUnitRole, int> businessUnitRoleRepository,

            IGenericRepository<AuthContext, DataUserRole, int> dataUserRoleRepository,
            IGenericRepository<AuthContext, FunctionUserRole, int> funcUserRoleRepository,
            IGenericRepository<AuthContext, ComponentUserRole, int> compUserRoleRepository)
        {
            _unitOfWork = unitOfWork;
            _dataRoleRepository = dataRoleRepository;
            _businessUnitRoleRepository = businessUnitRoleRepository;

            _dataUserRoleRepository = dataUserRoleRepository;
            _funcUserRoleRepository = funcUserRoleRepository;
            _compUserRoleRepository = compUserRoleRepository;
        }

        public IList<SelectedItem> GuiDataRoles()
        {
            return _dataRoleRepository
                .Queryable()
                .AsEnumerable()
                .Select(c => new SelectedItem
                {
                    Key = c.Pk_Id,
                    Val = c.Name
                })
                .Distinct()
                .ToList();
        }

        public IList<SelectedItem> GuiDataBusinessUnitRoles()
        {
            return _businessUnitRoleRepository
                .Queryable()
                .AsEnumerable()
                .Select(c => new SelectedItem
                {
                    Key = c.Pk_Id,
                    Val = c.Code
                })
                .Distinct()
                .ToList();
        }

        public UserRoleMappingDto Save(UserRoleMappingDto userRoleMapping)
        {
            try
            {
                _unitOfWork.BeginTransaction();

                #region Delete all roles mapping by username

                var _dataUserRoles = _dataUserRoleRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Username.Equals(userRoleMapping.Username, StringComparison.CurrentCultureIgnoreCase))
                    .ToList();
                var data1 = new List<object>();
                data1.AddRange(_dataUserRoles);
                _dataUserRoleRepository.BulkDelete(data1);

                var _funcUserRoles = _funcUserRoleRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Username.Equals(userRoleMapping.Username, StringComparison.CurrentCultureIgnoreCase))
                    .ToList();
                var data2 = new List<object>();
                data2.AddRange(_funcUserRoles);
                _funcUserRoleRepository.BulkDelete(data2);

                var _compUserRoles = _compUserRoleRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Username.Equals(userRoleMapping.Username, StringComparison.CurrentCultureIgnoreCase))
                    .ToList();
                var data3 = new List<object>();
                data3.AddRange(_compUserRoles);
                _compUserRoleRepository.BulkDelete(data3);

                #endregion

                // Data_User_Role
                var dataUserRoles = new List<object>();
                foreach (var fkDataRole in userRoleMapping.FkDataRole)
                {
                    dataUserRoles.Add(new DataUserRole
                    {
                        Pk_Id = 0,
                        Username = userRoleMapping.Username,
                        Fk_Role_Id = fkDataRole
                    });
                }
                _dataUserRoleRepository.BulkInsert(dataUserRoles);

                // Function_User_Role
                var funcUserRoles = new List<object>();
                foreach (var funcRole in userRoleMapping.FunctionRole)
                {
                    funcUserRoles.Add(new FunctionUserRole
                    {
                        Pk_Id = 0,
                        Username = userRoleMapping.Username,
                        Role = funcRole,
                        Is_Deleted = false
                    });
                }
                _funcUserRoleRepository.BulkInsert(funcUserRoles);

                // Component_User_Role
                var compUserRoles = new List<object>();
                foreach (var funcRole in userRoleMapping.ComponentRole)
                {
                    compUserRoles.Add(new ComponentUserRole
                    {
                        Pk_Id = 0,
                        Username = userRoleMapping.Username,
                        Role = funcRole,
                        Is_Deleted = false
                    });
                }
                _compUserRoleRepository.BulkInsert(compUserRoles);

                _unitOfWork.Commit();
                return userRoleMapping;
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                throw ex;
            }
        }

        public void DeleteRoleByUsername(string username)
        {
            _unitOfWork.BeginTransaction();

            var dataUserRoles = _dataUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase))
                .ToList();
            var data1 = new List<object>();
            data1.AddRange(dataUserRoles);
            _dataUserRoleRepository.BulkDelete(data1);

            var funcUserRoles = _funcUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase))
                .ToList();
            var data2 = new List<object>();
            data2.AddRange(funcUserRoles);
            _funcUserRoleRepository.BulkDelete(data2);

            var compUserRoles = _compUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase))
                .ToList();
            var data3 = new List<object>();
            data3.AddRange(compUserRoles);
            _compUserRoleRepository.BulkDelete(data3);

            _unitOfWork.SaveChanges();
            _unitOfWork.Commit();
        }

        public void DeleteFunctionRole(string funcRole)
        {
            _unitOfWork.BeginTransaction();

            var funcUserRoles = _funcUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(funcRole, StringComparison.CurrentCultureIgnoreCase))
                .ToList(); ;
            if (funcUserRoles != null && funcUserRoles.Any())
            {
                var data = new List<object>();
                foreach (var funcUserRole in funcUserRoles)
                {
                    funcUserRole.Is_Deleted = true;
                    data.Add(funcUserRole);
                }
                _funcUserRoleRepository.BulkUpdate(data);
            }

            _unitOfWork.SaveChanges();
            _unitOfWork.Commit();
        }

        public void DeleteComponentRole(string compRole)
        {
            _unitOfWork.BeginTransaction();

            var compUserRoles = _compUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(compRole, StringComparison.CurrentCultureIgnoreCase))
                .ToList(); ;
            if (compUserRoles != null && compUserRoles.Any())
            {
                var data = new List<object>();
                foreach (var compUserRole in compUserRoles)
                {
                    compUserRole.Is_Deleted = true;
                    data.Add(compUserRole);
                }
                _compUserRoleRepository.BulkUpdate(data);
            }

            _unitOfWork.SaveChanges();
            _unitOfWork.Commit();
        }
    }
}

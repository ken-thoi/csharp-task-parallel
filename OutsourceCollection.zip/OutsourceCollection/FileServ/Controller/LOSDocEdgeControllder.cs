﻿using Entities;
using HtmlAgilityPack;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace FileServ.Controller
{
    class LOSDocEdgeControllder
    {
            private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
            private static object _lockGetCustDoc = new object();
            private static IWebDriver masterDriver = null;
            private static LOSStatus currentDriverStatus = LOSStatus.LogingIn;
            private static Source source = null;
            private static bool needReRunQuerry = false;
            private static List<Task> ListProcessTask = new List<Task>();

            public static void RunIDLEDownload()
            {
                logger.Info("------ START RunIDLEDownload LOS Compenent ------");
                source = SourceController.GetSource("los.vpbank.com.vn");

                var taskWatching = Task.Factory.StartNew(() =>
                {
                    while (masterDriver != null)
                    {
                        if (string.IsNullOrEmpty(masterDriver.CurrentWindowHandle))
                        {
                            masterDriver.Quit();
                            masterDriver = null;
                            break;
                        }
                        else
                            Thread.Sleep(1000);
                        Thread.Sleep(1000);
                    }
                });

                //while (true)
                {
                    //if (!isThisTimeIsIDLETime)
                    //{
                    //    Thread.Sleep(Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "LOS_DELAY_RECHECK_TIME")));
                    //    continue;
                    //}

                    while (true)
                    {
                        if (ListProcessTask.Count >= source.NumberOfProcess)
                            Thread.Sleep(1000);
                        else
                        {
                            var custDoc = GetIDLEDoc;
                            if (custDoc == null)
                            {
                                logger.Info("Not found any new document to download on LOS System, sleep for 60 seconds");
                                Thread.Sleep(10000);
                            }
                            else
                                LOSFindDocumentNew(custDoc);
                        }
                    }
                }
            }

            private static bool isThisTimeIsIDLETime
            {
                get
                {
                    int startHour = Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "LOS_START_HOUR"));
                    int endHour = Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "LOS_END_HOUR"));
                    TimeSpan start = new TimeSpan(startHour, 0, 0);
                    TimeSpan end = new TimeSpan(endHour, 0, 0);
                    TimeSpan now = DateTime.Now.TimeOfDay;
                    if (start < end)
                        return start <= now && now <= end;
                    return !(end < now && now < start);
                }
            }

            public static CustomerDocument GetRequest
            {
                get
                {
                    lock (_lockGetCustDoc)
                    {
                        string command = "[FileServ].[FileRequest_Get_Request_To_Process]";
                        DataTable dt = new DataTable();
                        Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FK_Source", source.Id) });
                        if (dt.Rows.Count == 0)
                            return null;
                        else
                            return Utils.UtilFunction.CreateItemFromRow<CustomerDocument>(dt.Rows[0]);
                    }
                }
            }

            public static CustomerDocument GetIDLEDoc
            {
                get
                {
                    lock (_lockGetCustDoc)
                    {
                        string command = "[FileServ].[CustomerDocument_Get_To_Process]";
                        DataTable dt = new DataTable();
                        Utils.SqlHelper.Fill(dt, command, new SqlParameter[] { new SqlParameter("@pv_FK_Source", source.Id) });
                        if (dt.Rows.Count == 0)
                            return null;
                        else
                            return Utils.UtilFunction.CreateItemFromRow<CustomerDocument>(dt.Rows[0]);
                    }
                }
            }

            public static ChromeOptions chromeOptions
            {
                get
                {
                    string path = CurrentTempDownloadFolder;
                    Directory.CreateDirectory(path);

                var options = new EdgeOptions();
                options. = true;
                options.BinaryLocation = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";   // Here add the Edge browser exe path.
                options.AddUserProfilePreference("download.default_directory", @"D://Folder1");             // Here modify the download path.
                var driver = new EdgeDriver(@"D:\selenium web drivers\edgedriver_win64 83.0.478.61\", options); // Here modify the selenium web driver path.

                var chromeOptions = new ChromeOptions();
                    chromeOptions.AddUserProfilePreference("download.default_directory", path);
                    chromeOptions.AddUserProfilePreference("download.prompt_for_download", false);
                    chromeOptions.AddUserProfilePreference("disable-popup-blocking", true);
                    chromeOptions.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1);
                    chromeOptions.AddArgument("incognito");
                    return chromeOptions;
                }
            }

            public static string CurrentTempDownloadFolder
            {
                get
                {
                    return Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "TEMP_DOWNLOAD"), "1.LOS_TempDownload");
                }
            }

            public static void LOSLoginToSystemBySelenium()
            {
                while (true)
                {
                    if (masterDriver != null)
                        return;

                    var driver = new ChromeDriver(chromeOptions);
                    try
                    {
                        driver.Navigate().GoToUrl("https://los.vpbank.com.vn/csfweb/secure/logon.do");
                        var account = driver.FindElement(By.XPath("/html/body/form/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/table/tbody/tr[3]/td/table/tbody/tr[1]/td[2]/input"));
                        account.SendKeys(source.Username);
                        var password = driver.FindElement(By.XPath("/html/body/form/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/table/tbody/tr[3]/td/table/tbody/tr[2]/td[2]/input[1]"));
                        password.SendKeys(source.Password);
                        DoClickAction(driver, "/html/body/form/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/table/tbody/tr[3]/td/table/tbody/tr[5]/td[2]/input");
                        IWebElement loginCheck = null;

                        try
                        {
                            loginCheck = driver.FindElement(By.XPath("/html/body/form/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/table/tbody/tr[2]/td/div/div/div[3]/table/tbody/tr/td"));
                        }
                        catch (Exception)
                        {
                            if (loginCheck == null)
                                loginCheck = driver.FindElement(By.XPath("/html/body/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[3]/td/span[1]"));
                        }

                        if (loginCheck == null)
                            continue;

                        if ("Successful Logon".ToLower().Equals(loginCheck.Text.ToLower()))
                        {
                            var task = Task.Factory.StartNew(() =>
                            {
                                while (driver.WindowHandles.Count == 1)
                                {
                                    Thread.Sleep(500);
                                }
                                while (driver.WindowHandles.Count > 1)
                                {
                                    driver.SwitchTo().Window(driver.WindowHandles.LastOrDefault());
                                    driver.Close();
                                    driver.SwitchTo().Window(driver.WindowHandles.LastOrDefault());
                                    Thread.Sleep(300);
                                }
                            });
                            var result = Task.WaitAll(new Task[] { task }, 15000);

                            if (!result)
                                throw new Exception("Error wait to loooooooooooooooooog ");

                            masterDriver = driver;
                            currentDriverStatus = LOSStatus.ReadyToDownload;

                            return;
                        }
                        else
                        {
                            if ("This user is already logged in. Logout".ToLower().Equals(loginCheck.Text.ToLower()))
                            {
                                driver.Navigate().GoToUrl("https://los.vpbank.com.vn/csfweb/secure/logout.do");
                                driver.Quit();
                            }
                            else
                                driver.Quit();
                        }
                    }
                    catch (Exception)
                    {
                        driver.Quit();
                    }
                }
            }

            public static void LOSFindDocument(CustomerDocument custDoc)
            {
                string processID = Guid.NewGuid().ToString();
                int countFailed = 5;
                while (countFailed > 0)
                {
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    try
                    {
                        LOSLoginToSystemBySelenium();
                        var driver = masterDriver;

                        logger.Error(processID + "| 10. Login Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        while (true)
                        {
                            QueryCustomerInfoByContractNumber(driver, custDoc);
                            if (CheckSessionAvalidable(driver))
                            {
                                if (needReRunQuerry)
                                {
                                    needReRunQuerry = false;
                                    QueryCustomerInfoByContractNumber(driver, custDoc);
                                }
                                break;
                            }
                        }

                        logger.Error(processID + "| 20. Search Document Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        int countOperator = 40;
                        while (masterDriver != null)
                        {
                            try
                            {
                                var objOperator = driver.FindElement(By.Id("OPRTNS"));
                                objOperator.Click();
                                break;
                            }
                            catch
                            {
                                countOperator--;
                                if (countOperator <= 0)
                                    throw;
                                Thread.Sleep(500);
                            }
                        }

                        logger.Error(processID + "| 30. Process Operator Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        countOperator = 40;
                        while (true)
                        {
                            try
                            {
                                Thread.Sleep(200);
                                logger.Info(processID + "| 35. child frame");
                                var objOperator = driver.FindElement(By.XPath("/html/body/table/tbody/tr[1]/td[3]/div/table/tbody/tr[3]/td/div[2]/ul/li/div/table/tbody/tr/td[1]"));
                                Thread.Sleep(200);
                                DoClickAction(driver, "/html/body/table/tbody/tr[1]/td[3]/div/table/tbody/tr[3]/td/div[2]/ul/li/div/table/tbody/tr/td[1]");
                                break;
                            }
                            catch
                            {
                                countOperator--;
                                if (countOperator <= 0)
                                    throw;
                                Thread.Sleep(500);
                            }
                        }

                        logger.Error(processID + "| 40. Select Document Operator Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        countOperator = 40;
                        while (true)
                        {
                            try
                            {
                                Thread.Sleep(200);
                                driver.SwitchTo().Frame(driver.FindElement(By.XPath("//iframe[substring(@id,string-length(@id) -string-length('$page_Frame') +1) = '$page_Frame']")));
                                break;
                            }
                            catch
                            {
                                countOperator--;
                                if (countOperator <= 0)
                                    throw;
                                Thread.Sleep(500);
                            }
                        }

                        logger.Error(processID + "| 50. Switch Frame Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));
                        HtmlDocument doc = new HtmlDocument();
                        Thread.Sleep(200);
                        int changeStage = 20;
                        while (true)
                        {
                            try
                            {
                                //Change stage
                                SelectElement cbStage = new SelectElement(driver.FindElement(By.Id("cmbStage")));
                                cbStage.SelectByText("--Select--");
                                Thread.Sleep(1000);
                                break;
                            }
                            catch (Exception)
                            {
                                Thread.Sleep(500);
                                logger.Error(processID + "| Change stage failed: " + (10 - changeStage));
                                changeStage--;
                                if (changeStage == 0)
                                    throw;
                            }
                        }

                        logger.Error(processID + "| 60. Change combo doc to --Select-- Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        List<HtmlNode> docIds = new List<HtmlNode>();
                        List<HtmlNode> docStatus = new List<HtmlNode>();
                        List<HtmlNode> docNames = new List<HtmlNode>();
                        List<HtmlNode> docireqs = new List<HtmlNode>();
                        int count = 40;
                        while (count > 0)
                        {
                            doc.LoadHtml(driver.PageSource);
                            docireqs = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("ireq")).ToList();
                            docIds = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("docactid")).ToList();
                            docStatus = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("recdocstatus")).ToList();
                            docNames = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("filename")).ToList();
                            if (docIds.Where(x => !string.IsNullOrEmpty(x.InnerText)).Count() > 0)
                                break;
                            else
                            {
                                count--;
                                Thread.Sleep(500);
                            }
                        }
                        List<Task> listWorkingTask = new List<Task>();
                        List<FileDownload> listFileDownload = new List<FileDownload>();


                        for (int i = 0; i < docStatus.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(docStatus[i].InnerText))
                            {
                                if ("view".Equals(docStatus[i].InnerText.ToLower()))
                                {

                                    FileDownload file = new FileDownload();
                                    file.OriginalFileName = docNames[i].InnerText.Trim();
                                    file.FK_CustomerDocument = custDoc.Id;
                                    file.ProcessTime = DateTime.Now;
                                    file.Status = FileStatus.NotFound;
                                    file.exID = docIds[i].InnerText;
                                    DocumentType tmpDoc = new DocumentType();
                                    tmpDoc.FK_Source_Id = source.Id;
                                    tmpDoc.DocumentName = docireqs[i].InnerText;
                                    var docType = DocumentTypeController.GetDocumentType(tmpDoc);
                                    file.FK_DocumentType = docType.Id;
                                    if (string.IsNullOrEmpty(file.OriginalFileName))
                                    {
                                        file.Status = FileStatus.OrgNameIsEmpty;
                                        FileDownloadController.UpdateFileDownload(file);
                                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Because file do not having name");
                                        continue;
                                    }
                                    listFileDownload.Add(file);
                                    FileDownloadController.UpdateFileDownload(file);

                                    if (docType.AllowToDownload)
                                    {
                                        //LOSDownloadFile(processID, custDoc, driver, file);
                                        listWorkingTask.Add(Task.Factory.StartNew(() =>
                                        {
                                            LOSDownloadFile(processID, custDoc, driver, file);
                                        }));
                                    }
                                }
                            }
                        }

                        logger.Error(processID + "| 70. Setup for download Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        var waitResult = Task.WaitAll(listWorkingTask.ToArray(), GetDownloadTimeout);

                        logger.Error(processID + "| 80. Download child file Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        if (!waitResult && !custDoc.IgnoreErrorFile)
                        {
                            custDoc.Status = CustomerDocumentStatus.DownloadingError;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            throw new Exception("File Download Timeout, remain coutn failed: " + countFailed);
                        }

                        if ((listFileDownload.Where(x => x.Status != FileStatus.Verified).Count() > 0 && !custDoc.IgnoreErrorFile)
                            || listFileDownload.Where(x => x.Status != FileStatus.Verified).Count() == listFileDownload.Count)
                        {
                            logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + ". ContractID: " + custDoc.ContractNumber + " Not found any document");
                            custDoc.Status = CustomerDocumentStatus.DownloadingError;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            countFailed--;
                            break;
                        }

                        if (listFileDownload.Count == 0)
                        {
                            logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " Not found any document");
                            custDoc.Status = CustomerDocumentStatus.NotFoundAnyFile;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            countFailed--;
                            break;
                        }

                        var storagePath = Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "STORAGE"), custDoc.FilePackageName);
                        if (Directory.Exists(storagePath))
                            Directory.Delete(storagePath, true);

                        Directory.CreateDirectory(storagePath);
                        foreach (var file in listFileDownload)
                        {
                            if (file.Status != FileStatus.Verified)
                                continue;

                            var actualFilename = file.OriginalFileName;
                            var newFilename = Path.Combine(storagePath, file.OriginalFileName);
                            int countFileName = 0;
                            while (true)
                            {
                                if (!File.Exists(newFilename))
                                    break;
                                else
                                {
                                    countFileName++;
                                    actualFilename = file.OriginalFileName.Replace("." + file.OriginalFileName.Split('.').LastOrDefault(), string.Empty) + "-" +
                                            countFileName + "." + file.OriginalFileName.Split('.').LastOrDefault();
                                    newFilename = Path.Combine(storagePath, actualFilename);
                                }
                            }

                            while (true)
                            {
                                File.Copy(Path.Combine(CurrentTempDownloadFolder, file.TempFileName), newFilename, true);
                                var destchecksum = Utils.UtilFunction.CalculateMD5FromFile(newFilename);
                                if (destchecksum.Equals(file.MD5Checksum))
                                {
                                    File.Delete(Path.Combine(CurrentTempDownloadFolder, file.TempFileName));
                                    break;
                                }
                            }
                            file.Destination = Path.Combine(custDoc.FilePackageName, actualFilename);
                            FileDownloadController.UpdateFileDownload(file);
                        }

                        logger.Error(processID + "| 90. Done Document | " + watch.ElapsedMilliseconds.ToString("N0"));
                        //custDoc.Status = CustomerDocumentStatus.Packaging;
                        //CustDocController.UpdateCustDocStatus(custDoc);

                        //var zipPath = Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "PACKAGE"), custDoc.FilePackageName + ".zip");
                        //ZipFile.CreateFromDirectory(storagePath, zipPath);

                        custDoc.Status = CustomerDocumentStatus.Downloaded;
                        CustDocController.UpdateCustDocStatus(custDoc);

                        break;
                    }
                    catch (Exception ex)
                    {
                        countFailed--;
                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Process failed count" + (30 - countFailed));
                        logger.Error(ex);
                        custDoc.Priority -= 1;
                        custDoc.Status = CustomerDocumentStatus.DownloadingError;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        Thread.Sleep(3000);
                    }
                }
            }

            public static void LOSFindDocumentNew(CustomerDocument custDoc)
            {
                string processID = Guid.NewGuid().ToString();
                int countFailed = 5;
                while (countFailed > 0)
                {
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    try
                    {
                        LOSLoginToSystemBySelenium();
                        var driver = masterDriver;

                        logger.Error(processID + "| 10. Login Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        while (true)
                        {
                            QueryCustomerInfoByContractNumber(driver, custDoc);
                            if (CheckSessionAvalidable(driver))
                            {
                                if (needReRunQuerry)
                                {
                                    needReRunQuerry = false;
                                    QueryCustomerInfoByContractNumber(driver, custDoc);
                                }
                                break;
                            }
                        }

                        logger.Error(processID + "| 20. Search Document Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        int countOperator = 40;
                        while (masterDriver != null)
                        {
                            try
                            {
                                var objOperator = driver.FindElement(By.Id("OPRTNS"));
                                objOperator.Click();
                                break;
                            }
                            catch
                            {
                                countOperator--;
                                if (countOperator <= 0)
                                    throw;
                                Thread.Sleep(500);
                            }
                        }

                        logger.Error(processID + "| 30. Process Operator Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        countOperator = 40;
                        while (true)
                        {
                            try
                            {
                                Thread.Sleep(200);
                                logger.Info(processID + "| 35. child frame");
                                var objOperator = driver.FindElement(By.XPath("/html/body/table/tbody/tr[1]/td[3]/div/table/tbody/tr[3]/td/div[2]/ul/li/div/table/tbody/tr/td[1]"));
                                Thread.Sleep(200);
                                DoClickAction(driver, "/html/body/table/tbody/tr[1]/td[3]/div/table/tbody/tr[3]/td/div[2]/ul/li/div/table/tbody/tr/td[1]");
                                break;
                            }
                            catch
                            {
                                countOperator--;
                                if (countOperator <= 0)
                                    throw;
                                Thread.Sleep(500);
                            }
                        }

                        logger.Error(processID + "| 40. Select Document Operator Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        countOperator = 40;
                        while (true)
                        {
                            try
                            {
                                Thread.Sleep(200);
                                driver.SwitchTo().Frame(driver.FindElement(By.XPath("//iframe[substring(@id,string-length(@id) -string-length('$page_Frame') +1) = '$page_Frame']")));
                                break;
                            }
                            catch
                            {
                                countOperator--;
                                if (countOperator <= 0)
                                    throw;
                                Thread.Sleep(500);
                            }
                        }

                        logger.Error(processID + "| 50. Switch Frame Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));
                        Thread.Sleep(200);
                        int changeStage = 20;
                        while (true)
                        {
                            try
                            {
                                //Change stage
                                SelectElement cbStage = new SelectElement(driver.FindElement(By.Id("cmbStage")));
                                cbStage.SelectByText("--Select--");
                                Thread.Sleep(1000);
                                break;
                            }
                            catch (Exception)
                            {
                                Thread.Sleep(500);
                                logger.Error(processID + "| Change stage failed: " + (10 - changeStage));
                                changeStage--;
                                if (changeStage == 0)
                                    throw;
                            }
                        }

                        logger.Error(processID + "| 60. Change combo doc to --Select-- Sucessfull | " + watch.ElapsedMilliseconds.ToString("N0"));

                        HtmlDocument doc = new HtmlDocument();
                        doc.LoadHtml(driver.PageSource);
                        List<HtmlNode> docIds = new List<HtmlNode>();
                        List<HtmlNode> docStatus = new List<HtmlNode>();
                        List<HtmlNode> docNames = new List<HtmlNode>();
                        List<HtmlNode> docireqs = new List<HtmlNode>();
                        int count = 40;
                        while (count > 0)
                        {

                            docireqs = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("ireq")).ToList();
                            docIds = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("docactid")).ToList();
                            docStatus = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("recdocstatus")).ToList();
                            docNames = doc.DocumentNode.Descendants("td").Where(node => node.GetAttributeValue("id", "").Equals("filename")).ToList();
                            if (docIds.Where(x => !string.IsNullOrEmpty(x.InnerText)).Count() > 0)
                                break;
                            else
                            {
                                count--;
                                Thread.Sleep(500);
                            }
                        }

                        lock (ListProcessTask)
                        {
                            var task = new Task(() =>
                            {
                                ProcessChildFileDownload(processID, custDoc, docireqs, docIds, docStatus, docNames);
                            });
                            task.ContinueWith(t =>
                            {
                                lock (ListProcessTask)
                                    ListProcessTask.Remove(task);
                            });
                            ListProcessTask.Add(task);
                            task.Start();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        countFailed--;
                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Process failed count" + (30 - countFailed));
                        logger.Error(ex);
                        custDoc.Priority -= 1;
                        custDoc.Status = CustomerDocumentStatus.DownloadingError;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        Thread.Sleep(3000);
                    }
                }
            }

            private static void ProcessChildFileDownload(string processID, CustomerDocument custDoc, List<HtmlNode> docireqs, List<HtmlNode> docIds, List<HtmlNode> docStatus, List<HtmlNode> docNames)
            {
                int countFailed = 5;
                while (countFailed > 0)
                {
                    try
                    {
                        while (true)
                        {
                            if (currentDriverStatus == LOSStatus.ReadyToDownload)
                                break;
                            else
                                Thread.Sleep(10000);
                        }

                        List<Task> listWorkingTask = new List<Task>();
                        List<FileDownload> listFileDownload = new List<FileDownload>();
                        for (int i = 0; i < docStatus.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(docStatus[i].InnerText))
                            {
                                if ("view".Equals(docStatus[i].InnerText.ToLower()))
                                {
                                    FileDownload file = new FileDownload();
                                    file.OriginalFileName = docNames[i].InnerText.Trim();
                                    file.FK_CustomerDocument = custDoc.Id;
                                    file.ProcessTime = DateTime.Now;
                                    file.Status = FileStatus.NotFound;
                                    file.exID = docIds[i].InnerText;
                                    DocumentType tmpDoc = new DocumentType();
                                    tmpDoc.FK_Source_Id = source.Id;
                                    tmpDoc.DocumentName = docireqs[i].InnerText;
                                    var docType = DocumentTypeController.GetDocumentType(tmpDoc);
                                    file.FK_DocumentType = docType.Id;
                                    if (string.IsNullOrEmpty(file.OriginalFileName))
                                    {
                                        file.Status = FileStatus.OrgNameIsEmpty;
                                        FileDownloadController.UpdateFileDownload(file);
                                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Because file do not having name");
                                        continue;
                                    }
                                    listFileDownload.Add(file);
                                    FileDownloadController.UpdateFileDownload(file);

                                    if (docType.AllowToDownload)
                                    {
                                        //LOSDownloadFile(processID, custDoc, masterDriver, file);
                                        listWorkingTask.Add(Task.Factory.StartNew(() =>
                                        {
                                            LOSDownloadFile(processID, custDoc, masterDriver, file);
                                        }));
                                    }
                                }
                            }
                        }

                        var waitResult = Task.WaitAll(listWorkingTask.ToArray(), GetDownloadTimeout);
                        if (!waitResult && !custDoc.IgnoreErrorFile)
                        {
                            custDoc.Status = CustomerDocumentStatus.DownloadingError;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            throw new Exception("File Download Timeout, remain coutn failed: " + countFailed);
                        }

                        if ((listFileDownload.Where(x => x.Status != FileStatus.Verified).Count() > 0 && !custDoc.IgnoreErrorFile)
                            || (listFileDownload.Where(x => x.Status != FileStatus.Verified)
                                .Where(x => DocumentTypeController.DictDocumentTypeById[source.Id][x.FK_DocumentType].AllowSendToOS).Count() > 0))
                        {
                            logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + ". ContractID: " + custDoc.ContractNumber + " Not found any document");
                            custDoc.Status = CustomerDocumentStatus.DownloadingError;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            countFailed--;
                            break;
                        }

                        if (listFileDownload.Count == 0)
                        {
                            logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " Not found any document");
                            custDoc.Status = CustomerDocumentStatus.NotFoundAnyFile;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            countFailed--;
                            break;
                        }

                        var storagePath = Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "STORAGE"), custDoc.FilePackageName);
                        if (Directory.Exists(storagePath))
                            Directory.Delete(storagePath, true);

                        Directory.CreateDirectory(storagePath);
                        foreach (var file in listFileDownload)
                        {
                            if (file.Status != FileStatus.Verified)
                                continue;

                            var actualFilename = file.OriginalFileName;
                            var newFilename = Path.Combine(storagePath, file.OriginalFileName);
                            int countFileName = 0;
                            while (true)
                            {
                                if (!File.Exists(newFilename))
                                    break;
                                else
                                {
                                    countFileName++;
                                    actualFilename = file.OriginalFileName.Replace("." + file.OriginalFileName.Split('.').LastOrDefault(), string.Empty) + "-" +
                                            countFileName + "." + file.OriginalFileName.Split('.').LastOrDefault();
                                    newFilename = Path.Combine(storagePath, actualFilename);
                                }
                            }

                            while (true)
                            {
                                File.Copy(Path.Combine(CurrentTempDownloadFolder, file.TempFileName), newFilename, true);
                                var destchecksum = Utils.UtilFunction.CalculateMD5FromFile(newFilename);
                                if (destchecksum.Equals(file.MD5Checksum))
                                {
                                    File.Delete(Path.Combine(CurrentTempDownloadFolder, file.TempFileName));
                                    break;
                                }
                            }
                            file.Status = FileStatus.MovingToStorage;
                            file.Destination = Path.Combine(custDoc.FilePackageName, actualFilename);
                            FileDownloadController.UpdateFileDownload(file);
                        }

                        custDoc.Status = CustomerDocumentStatus.Downloaded;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        break;
                    }
                    catch (Exception ex)
                    {
                        countFailed--;
                        logger.Error(processID + "| Process on customer: " + custDoc.CustomerName + " with DocumentID: " + custDoc.DocumentID + ": FAILED. Process failed count: " + countFailed);
                        logger.Error(ex);
                        custDoc.Priority -= 1;
                        custDoc.Status = CustomerDocumentStatus.DownloadingError;
                        CustDocController.UpdateCustDocStatus(custDoc);
                        Thread.Sleep(3000);

                        if (countFailed <= 0)
                        {
                            custDoc.Status = CustomerDocumentStatus.Waitting;
                            custDoc.Priority -= 10;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            logger.Error(processID + "| Terminate on customer: " + custDoc.CustomerName + " with because fail on download to much ");

                        }
                    }

                }
            }

            private static bool CheckSessionAvalidable(IWebDriver driver)
            {
                try
                {
                    var account = driver.FindElement(By.XPath("/html/body/form/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/table/tbody/tr[3]/td/table/tbody/tr[1]/td[2]/input"));
                    var password = driver.FindElement(By.XPath("/html/body/form/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/table/tbody/tr[3]/td/table/tbody/tr[2]/td[2]/input[1]"));
                    if (account != null && password != null)
                    {
                        currentDriverStatus = LOSStatus.LogingIn;
                        driver.Quit();
                        needReRunQuerry = true;
                        masterDriver = null;
                        LOSLoginToSystemBySelenium();
                        return CheckSessionAvalidable(driver);
                    }
                }
                catch (Exception)
                {
                    currentDriverStatus = LOSStatus.ReadyToDownload;
                    return true;
                }
                return false;
            }

            private static void QueryCustomerInfoByContractNumber(IWebDriver driver, CustomerDocument custDoc)
            {
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("id", "-268493908");
                nvc.Add("fxml", string.Format("<filter type=\"AND\"><qcondition attribute=\"DSPLAPPID\" extdata=\"\" funccode=\"\" operator=\"caseinsensitive-contains\" datatype=\"number\" value=\"{0}\" description=\"{0}\" default=\"\" defaultdesc=\"\" cmpfld=\"N\" caption=\"Application No\" fid=\"\" conditionid=\"\" pfid=\"\" code=\"\" sclfunc=\"\"/></filter>", custDoc.DocumentID));
                nvc.Add("lid", "LIST_APLCTN");
                nvc.Add("vid", "LIST_APLCTNVIEW");
                nvc.Add("cfr", "Y");
                string url = "https://los.vpbank.com.vn/csfweb/secure/ac.do" + Utils.UtilFunction.ParamToQueryString(nvc);
                if (driver.WindowHandles.Count == 1)
                {
                    ((IJavaScriptExecutor)driver).ExecuteScript("window.open('" + url + "','_blank');");
                    driver.SwitchTo().Window(driver.WindowHandles.LastOrDefault());
                }
                else
                {
                    driver.SwitchTo().Window(driver.WindowHandles.LastOrDefault());
                    driver.Navigate().GoToUrl(url);
                }
            }

            private static List<HtmlNode> ListDocByDocumnetId(IWebDriver driver, CustomerDocument custDoc)
            {
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("id", "-268493908");
                nvc.Add("fxml", string.Format("<filter type=\"AND\"><qcondition attribute=\"DSPLAPPID\" extdata=\"\" funccode=\"\" operator=\"caseinsensitive-contains\" datatype=\"number\" value=\"{0}\" description=\"{0}\" default=\"\" defaultdesc=\"\" cmpfld=\"N\" caption=\"Application No\" fid=\"\" conditionid=\"\" pfid=\"\" code=\"\" sclfunc=\"\"/></filter>", custDoc.DocumentID));
                nvc.Add("lid", "LIST_APLCTN");
                nvc.Add("vid", "LIST_APLCTNVIEW");
                nvc.Add("cfr", "Y");
                string url = "https://los.vpbank.com.vn/csfweb/secure/ac.do" + Utils.UtilFunction.ParamToQueryString(nvc);
                var js = @" var result = null;
                        var xhr = new XMLHttpRequest();
                        xhr.open('GET', '<<URL>>', false);
                        xhr.onloadend = function (event) {
                            result = (xhr.response);	                        
                        }
                        xhr.send(); 
                        return result;
                      ";
                js = js.Replace("<<URL>>", url);
                var result = Convert.ToString(((IJavaScriptExecutor)driver).ExecuteScript(js));
                HtmlDocument doc = new HtmlDocument();
                doc.LoadHtml(result);
                var listChildFolder = doc.DocumentNode.Descendants("tr").Where(node => node.InnerHtml.ToLower().Contains("class='ewtablecontents'"))//.ToList();
                .Where(node => !"null".Equals(node.Descendants("td").ToArray()[3].InnerText.ToLower().Trim()))
                .Where(node => custDoc.DocumentID.Equals(node.Descendants("td").ToArray()[0].InnerText.ToLower().Trim())).ToList();
                return listChildFolder;
            }

            private static void ExcuteDownload(IWebDriver driver, string fileTempName, string strKey1)
            {
                var js = @"var base64data = null;
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', 'https://los.vpbank.com.vn/csfweb/secure/documentTransAction.do', true);
                        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                        xhr.responseType = 'blob';
                        xhr.onloadend = function (event) {
	                         if (this.status == 200) {
                                    blob = new Blob([xhr.response], { type: 'application/octet-stream' });
                                    var link = document.createElement('a');
                                    link.href = window.URL.createObjectURL(blob);" +
                                        "link.download = '" + HttpUtility.JavaScriptStringEncode(fileTempName) + "';" +
                                        @"link.click();
                                } else {
                                }
                        }
                        xhr.send('_ACTION=DOWNLOAD&strFileName=m.pdf&strStreamProvider=documentfileprovider&strKey1=" + strKey1 + "'); ";
                var result = ((IJavaScriptExecutor)driver).ExecuteScript(js);
            }

            private static void LOSDownloadFile(string processID, CustomerDocument custDoc, IWebDriver driver, FileDownload file)
            {
                int count = 10;
                bool needRecheckSession = false;
                while (count > 0)
                {
                    file.TempFileName = Guid.NewGuid().ToString() + "." + file.OriginalFileName.Split('.').LastOrDefault();
                    var path = Path.Combine(CurrentTempDownloadFolder, file.TempFileName);
                    try
                    {
                        FileDownloadController.UpdateFileDownload(file);
                        if (needRecheckSession)
                            while (true)
                            {
                                QueryCustomerInfoByContractNumber(driver, custDoc);
                                if (CheckSessionAvalidable(driver))
                                {
                                    if (currentDriverStatus == LOSStatus.ReadyToDownload)
                                        QueryCustomerInfoByContractNumber(driver, custDoc);
                                    break;
                                }
                            }

                        FileDownloadController.UpdateFileDownload(file);
                        ExcuteDownload(driver, file.TempFileName, file.exID);
                        string fileName = Path.Combine(CurrentTempDownloadFolder, file.TempFileName);
                        int countTime = 120;
                        while (countTime > 0)
                        {
                            if (File.Exists(fileName))
                                break;
                            else
                            {
                                countTime--;
                                Thread.Sleep(500);
                            }
                        }

                        if (!File.Exists(fileName))
                        {
                            file.Status = FileStatus.NotFound;
                            FileDownloadController.UpdateFileDownload(file);
                            count--;
                        }
                        else
                        {
                            file.Status = FileStatus.Downloading;
                            FileDownloadController.UpdateFileDownload(file);

                            var fi1 = new FileInfo(path);
                            int countFileLock = 480;
                            while (true)
                            {
                                if (countFileLock <= 0)
                                {
                                    string error = processID + "|File is download to long: re-download after 2 second, remaning retry: " + (count);
                                    throw new Exception(error);
                                }
                                if (Utils.UtilFunction.IsFileLocked(fi1))
                                {
                                    Thread.Sleep(500);
                                    countFileLock--;
                                }
                                else
                                    break;
                            }

                            file.Status = FileStatus.Downloaded;
                            FileDownloadController.UpdateFileDownload(file);

                            try
                            {
                                var fileEXT = file.TempFileName.Split('.').LastOrDefault().ToLower();
                                FileDownloadController.VerifiedAfterDownload(processID, file, path, fileEXT);
                            }
                            catch (Exception)
                            {
                                string error = processID + "|File is Corrupted: re-download after 2 second, remaning retry: " + (count);
                                File.Delete(path);
                                file.Status = FileStatus.Corrupted;
                                FileDownloadController.UpdateFileDownload(file);
                                custDoc.Priority -= 1;
                                CustDocController.UpdateCustDocStatus(custDoc);
                                logger.Error(error);
                                break;
                            }

                            file.MD5Checksum = Utils.UtilFunction.CalculateMD5FromFile(fileName);
                            file.Status = FileStatus.Verified;
                            FileDownloadController.UpdateFileDownload(file);
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                        count--;
                        needRecheckSession = true;
                        if (count == 0)
                        {
                            custDoc.Priority -= 10;
                            CustDocController.UpdateCustDocStatus(custDoc);
                            throw;
                        }
                    }
                }
            }

            private static int GetDownloadTimeout
            {
                get
                {
                    return Convert.ToInt32(SysVarController.GetSystemValue("IDLE_SETUP", "LOS_CUST_DOC_TIME_OUT"));
                }
            }

            private static void DoClickAction(IWebDriver driver, string xPath, string actionName = "")
            {
                driver.FindElement(By.XPath(xPath)).Click();
            }

            public enum LOSStatus
            {
                LogingIn, ReadyToDownload
            }
    }
}

﻿namespace VPBANK.RMD.Data.IFRS9_Conf
{
    public static class IFRS9_Conf_Schemas
    {
        public static readonly string DBO = "dbo";
    }
}

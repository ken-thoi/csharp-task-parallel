﻿using Microsoft.Extensions.Configuration;
using VPBANK.RMD.API.Settings.Sections;

namespace VPBANK.RMD.API.Settings
{
    public interface IAppSettingsReader
    {
        AppSettings GetAppSettings();
    }

    public class AppSettingsReader : IAppSettingsReader
    {
        private readonly IConfiguration _configuration;

        public AppSettingsReader(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public AppSettings GetAppSettings()
        {
            var properties = new Properties
            {
                ApplicationName = _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.ApplicationName)).Value,
                Environment = _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.Environment)).Value,

                API_BASE =  _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.API_BASE)).Value,
                USERAPI =   _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.USERAPI)).Value,
                JOBAPI =    _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.JOBAPI)).Value,
                API1 =      _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.API1)).Value,
                API2 =      _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.API2)).Value,
                API3 =      _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.API3)).Value,
                API4 =      _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.API4)).Value,

                RunFlowPath = _configuration.GetSection(nameof(AppSettings.Properties)).GetSection(nameof(AppSettings.Properties.RunFlowPath)).Value
            };

            return new AppSettings
            {
                Properties = properties,
                ApiSwaggerInfo = SwaggerSetting.GetSwaggerInfoSection(_configuration),
                ConnectionStrings = new ConnectionStringsSection
                {
                    AuthConnection = _configuration.GetSection("ConnectionStrings:AuthConnection").Value,
                    JobConnection = _configuration.GetSection("ConnectionStrings:JobConnection").Value,
                    PhoenixConfConnection = _configuration.GetSection("ConnectionStrings:PhoenixConfConnection").Value,
                    PhoenixDataConnection = _configuration.GetSection("ConnectionStrings:PhoenixDataConnection").Value,
                    CollectionConnection = _configuration.GetSection("ConnectionStrings:CollectionConnection").Value,
                    CoreConnection = _configuration.GetSection("ConnectionStrings:CoreConnection").Value,
                    IFRS9ConfConnection = _configuration.GetSection("ConnectionStrings:IFRS9ConfConnection").Value,
                    IFRS9DataConnection = _configuration.GetSection("ConnectionStrings:IFRS9DataConnection").Value
                },
                Jwt = JWTSetting.GetJwtSection(_configuration),
                RabbitMq = RabbitMqSetting.GetRabbitMqSetting(_configuration),
                ElasticAudit = new ElasticAuditSection
                {
                    Uri = _configuration["ElasticAudit:Uri"],
                    FixAlias = bool.Parse(_configuration["ElasticAudit:FixAlias"]),
                    NotiAlias = _configuration["ElasticAudit:NotiAlias"],
                    AuditAlias = _configuration["ElasticAudit:AuditAlias"],
                    IndexPerYear = bool.Parse(_configuration["ElasticAudit:IndexPerYear"]),
                    AmountOfPreviousIndicesUsedInAlias = int.Parse(_configuration["ElasticAudit:AmountOfPreviousIndicesUsedInAlias"])
                },
                FtpInfo = FtpInfoSetting.GetFtpSecionSetting(_configuration)
            };
        }
    }
}

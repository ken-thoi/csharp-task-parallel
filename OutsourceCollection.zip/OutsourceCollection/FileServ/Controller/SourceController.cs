﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class SourceController
    {
        private static Dictionary<string, Source> DictSource = new Dictionary<string, Source>();
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void LoadSource()
        {
            logger.Info("------ START: Loading System Source ------");
            string command = "[FileServ].[Source_SEL]";
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, command);
            foreach (DataRow dr in dt.Rows)
            {
                var item = Utils.UtilFunction.CreateItemFromRow<Source>(dr);
                DictSource.Add(item.Source_name.ToLower(), item);
                logger.Info("- " + item.Source_name.ToLower() + ", Number of process: " + item.NumberOfProcess);
            }
            logger.Info("------ END: Loading System Source ------");
        }

        public static Source GetSource(string Source_name)
        {
            return DictSource[Source_name.ToLower()];
        }
    }
}

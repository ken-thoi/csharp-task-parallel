﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using AutoMapper;
using System;
using System.Linq;
using Serilog;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.WO;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using System.Collections.Generic;
using System.Net.Mime;
using System.Data;
using VPBANK.RMD.Utils.Common.ExcelUtils;
using System.IO;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Apr
{
    public class WrittenOffUploadController : TrackingController<IFRS9_ConfContext, WrittenOffUpload, int>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> _genTaskRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;

        private readonly IWrittenOffUploadService _writtenOffUploadService;

        public WrittenOffUploadController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_ConfContext> unitOfWork,
            ITrackableRepository<IFRS9_ConfContext, WrittenOffUpload, int> trackableRepository,
            IGenericRepository<IFRS9_ConfContext, WrittenOffUpload, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> genTaskRepository,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,

            IWrittenOffUploadService writtenOffUploadService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genTaskRepository = genTaskRepository;
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;

            _writtenOffUploadService = writtenOffUploadService;
        }

        /// <summary>
        /// View list all WrittenOffUpload (include upload & calc) records with filter, sort, paging.
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public async virtual Task<ActionResult<PaginatedContentResults<WrittenOffFileUploadResult>>> FindAllWrittenOffFileUploadByTaskExecution([FromRoute] int fk_Task_Execution_Id, [Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                var flowExecution = _genFlowExecutionRepository.Find(flowStepExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null)
                    return NotFound();

                var results = _writtenOffUploadService.FindAllByBusinessDate(flowExecution.Business_Date, flowExecution.Pk_Id, flowStepExecution.Pk_Id);
                var total = results.Count();
                var data = results.ToList();
                foreach (var item in data)
                {
                    if (!item.Business_Date.HasValue || !item.Fk_Flow_Execution_Id.HasValue || !item.Fk_Task_Execution_Id.HasValue)
                    {
                        item.Business_Date = flowExecution.Business_Date;
                        item.Fk_Flow_Execution_Id = flowExecution.Pk_Id;
                        item.Fk_Task_Execution_Id = flowStepExecution.Pk_Id;
                    }

                    if (string.IsNullOrEmpty(item.Status))
                        item.Status = Workflow_Status_Code.PEDING;
                }

                // result
                dynamic result = await GenericQueryResultAsync(total, data, paginatedParams, false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Validate flow & task execution
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="file_Convention_Name"></param>
        /// <returns></returns>
        [HttpGet("{fk_Task_Execution_Id}/file-conv/{file_Convention_Name}")]
        public virtual IActionResult Validate([FromRoute] int fk_Task_Execution_Id, [FromRoute] string file_Convention_Name)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // check task # ready to execute
                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (taskExecution == null || !taskExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // check flow 
                var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null || !flowExecution.Flow_Execution_Status.Equals(Workflow_Status_Code.EXECUTING, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // check status calculation (Workflow_Status_Code)
                var results = _writtenOffUploadService.FindAllByBusinessDate(flowExecution.Business_Date, flowExecution.Pk_Id, taskExecution.Pk_Id);
                if (results != null && results.Any(x => !string.IsNullOrEmpty(x.Status) && x.Status.Equals(Workflow_Status_Code.CALCULATING, StringComparison.CurrentCultureIgnoreCase)))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // results
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        private readonly string _fileExt = "xlsx";
        private readonly string _fileError = "_ERROR";
        private readonly string _sheet = "Sheet";
        private readonly string _cell = "Cell";
        private readonly string _errorMessage = "Error Message";
        private readonly string _rptReport = "ILLP_CF";
        private readonly string _approach_SBV = "SBV";
        private readonly Dictionary<string, string> _errors = new Dictionary<string, string>
        {
            { "EM001", ErrorMessagesIfrs.EM0011 },
            { "EM002", ErrorMessagesIfrs.EM0021 },
            { "EM021", ErrorMessagesIfrs.EM021 },
            { "EM022", ErrorMessagesIfrs.EM022 },
            { "EM050", ErrorMessagesIfrs.EM050 },
            { "EM051", ErrorMessagesIfrs.EM051 },
            { "EM053", ErrorMessagesIfrs.EM053 },
            { "EM054", ErrorMessagesIfrs.EM054 }
        };

        /// <summary>
        /// Data file import by binary Excel(.xlsx, .xls)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="fileConvName"></param>
        /// <param name="fileName"></param>
        /// <param name="fileContent">file input: excel stream</param>
        /// <returns></returns>
        [HttpPost(template: "{fk_Task_Execution_Id}/file-conv-name/{fileConvName}/file-name/{fileName}")]
        [Consumes(MediaTypeNames.Application.Octet)]
        public async virtual Task<ActionResult<byte[]>> ImportFile([FromRoute] int fk_Task_Execution_Id, string fileConvName, string fileName, [FromBody] byte[] fileContent)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(fileConvName) || string.IsNullOrEmpty(fileName) || fileContent == null)
                    return BadRequest();

                var msgError = string.Empty;

                // prepare data
                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);
                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);

                // check status
                if (!taskExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM037);

                // validate filename
                var msgValiFilename = _writtenOffUploadService.ValidateImportWrittenOff(flowExecution.Business_Date, flowExecution, taskExecution, fileConvName, fileName);
                if (!string.IsNullOrEmpty(msgValiFilename))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msgValiFilename);
                var extFilename = fileName.Split(SpecificSystems.DOT).Last();
                var shortFilename = fileName.Split(SpecificSystems.DOT).First();

                // insert error to data table
                Stream stream = new MemoryStream(fileContent);
                var dataTable = ExcelHelper.ReadDataTableFromStream(stream, false);

                // validate data, if error fill msg to file
                var msgErrorCells = _writtenOffUploadService.ValidateContentImportWrittenOff(fileConvName, dataTable);
                if (msgErrorCells != null && msgErrorCells.Item1)
                {
                    // fill errors and file
                    var fileContentError = ExcelHelper.FillDataTableToSheetFromStream(fileContent, 0, false, msgErrorCells.Item2);

                    HttpContext.Response.ContentType = MediaTypeExts.Application.OfficeDocument;
                    HttpContext.Response.Headers.Add(ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE, ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE_VAL);
                    var filenameError = $"{shortFilename}{_fileError}.{extFilename}";
                    HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, filenameError);

                    var fileContentResult = new FileContentResult(fileContentError, MediaTypeExts.Application.OfficeDocument) { FileDownloadName = filenameError };
                    return fileContentResult;
                }

                // data raw valid
                var __dataTable = ExcelHelper.ReadDataTableFromStream(stream, true);
                //_rawILLPCfService.SaveAsync(rawData, fk_Task_Execution_Id, customer_Id, user.Username);

                return CreatedAtAction(nameof(ImportFile), null);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Calc Adjust for.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <returns></returns>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public async virtual Task<ActionResult<int>> WoCalculation([FromRoute] int fk_Task_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0)
                    return BadRequest(ModelState);

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (!flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // results
                return Ok(null);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        ///// <summary>
        ///// Check result PLLP by customer_id, business_date (th by filename when upload)
        ///// </summary>
        ///// <param name="cashflowAdjustFile"></param>
        ///// <returns></returns>
        //[HttpPost]
        //public virtual ActionResult<bool> CheckPLLPCustomerByFilename([NotNull][FromBody] CashflowAdjustFileDto cashflowAdjustFile)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid || cashflowAdjustFile == null || string.IsNullOrEmpty(cashflowAdjustFile.Filename))
        //            throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

        //        var fileNames = cashflowAdjustFile.Filename.Split(SpecificCharacteristics.UNDERSCORE);
        //        if (fileNames == null || fileNames.Count() < 2)
        //            throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

        //        var _customerId = fileNames.First();
        //        var _businessDate = fileNames.Last();

        //        if (string.IsNullOrEmpty(_customerId) || string.IsNullOrEmpty(_businessDate))
        //            throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

        //        var businessDate = DateTime.ParseExact(_businessDate, DefFormats.DATE_YYYYMMDD, CultureInfo.InvariantCulture);
        //        if (businessDate == null)
        //            throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

        //        var result = _pllpCustomerRepository.FindPLLPCustomerByCustomerId(_customerId, businessDate);
        //        if (result == null)
        //            throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

        //        return Ok(true);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex.Message);
        //        Log.Error(ex.StackTrace);
        //        Log.Error(ex.InnerException?.Message);
        //        if (ex is HttpErrorException)
        //            throw;
        //        else
        //            throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
        //    }
        //    finally
        //    {
        //    }
        //}

        ///// <summary>
        ///// Read data file import and save to adjust tables
        ///// </summary>
        ///// <param name="fk_Task_Execution_Id"></param>
        ///// <param name="fileUploads">List file upload</param>
        ///// <returns></returns>
        ///// <response code="201">Returns OK</response>
        //[HttpPost(template: "{fk_Task_Execution_Id}")]
        //public async virtual Task<ActionResult<Requests>> Import([FromRoute] int fk_Task_Execution_Id, [FromBody] List<FileUploadReq> fileUploads)
        //{
        //    if (!ModelState.IsValid || fileUploads == null || fk_Task_Execution_Id == 0 || !fileUploads.Any() || fileUploads.Count != 1)
        //        return BadRequest();

        //    var setting = FtpInfoSetting.GetFtpSetting(_configuration);
        //    var remote = new FtpRemoteFileSystem(setting);
        //    remote.Connect();
        //    remote.SetRootAsWorkingDirectory();

        //    try
        //    {
        //        // insert new data
        //        var fileUpload = fileUploads.First();
        //        if (fileUpload != null)
        //        {
        //            var localPath = $"{Constants.WWWROOT}\\{fileUpload.Path}\\{fileUpload.Filename}";
        //            var remotePath = $"{fileUpload.Path}\\{fileUpload.Filename}";
        //            remote.DownloadFile(localPath, remotePath);

        //            var data = ExcelHelper.ReadDataSheetFromExcelPath(localPath);

        //            var results = await _requestsFileService.ImportAsync(localPath, fk_Task_Execution_Id);

        //            return Ok(data);
        //        }

        //        return StatusCode(StatusCodes.Status201Created);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex.Message);
        //        Log.Error(ex.StackTrace);
        //        Log.Error(ex.InnerException?.Message);
        //        if (ex is HttpErrorException)
        //            throw;
        //        else
        //            throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
        //    }
        //    finally
        //    {
        //        bool isConnected = remote.IsConnected();
        //        Log.Information($"FTP connect status: {isConnected}");
        //        remote.Disconnect();
        //        remote.Dispose();
        //    }
        //}

        ///// <summary>
        ///// Download lastest Excel file import(.xlsx, .xls)
        ///// </summary>
        ///// <param name="fk_Task_Execution_Id"></param>
        ///// <param name="customer_Id"></param>
        ///// <returns></returns>
        //[HttpGet(template: "{fk_Task_Execution_Id}/customers/{customer_Id}")]
        //public virtual ActionResult<byte[]> DownloadFileLastest([FromRoute] int fk_Task_Execution_Id, string customer_Id)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(customer_Id))
        //            return BadRequest();

        //        var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
        //        var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);

        //        var requestsFile = _requestsFileService.FindReqFileByCashflowUploadLastest(customer_Id, flowExecution.Business_Date);
        //        if (requestsFile == null || requestsFile.File_Content == null || string.IsNullOrEmpty(requestsFile.File_Name))
        //            throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM055);

        //        // Set the HTTP MIME type of the output stream
        //        HttpContext.Response.ContentType = MediaTypeExts.Application.OfficeDocument;
        //        HttpContext.Response.Headers.Add(ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE, ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE_VAL);
        //        HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, requestsFile.File_Name);

        //        var fileContentResult = new FileContentResult(requestsFile.File_Content, MediaTypeExts.Application.OfficeDocument) { FileDownloadName = requestsFile.File_Name };
        //        return fileContentResult;
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex.Message);
        //        Log.Error(ex.StackTrace);
        //        Log.Error(ex.InnerException?.Message);
        //        if (ex is HttpErrorException)
        //            throw;
        //        else
        //            throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
        //    }
        //    finally
        //    {
        //    }
        //}

        ///// <summary>
        ///// Download file Contractual Cashflow by Excel(.xlsx, .xls)
        ///// </summary>
        ///// <param name="fk_Task_Execution_Id"></param>
        ///// <param name="customer_Id"></param>
        ///// <returns></returns>
        //[HttpGet(template: "{fk_Task_Execution_Id}/customers/{customer_Id}")]
        //public async virtual Task<IActionResult> DownloadContractualCashflow([FromRoute] int fk_Task_Execution_Id, string customer_Id)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(customer_Id))
        //            return BadRequest();

        //        var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
        //        var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);
        //        var task = await _genTaskRepository.FindAsync(taskExecution.Fk_Current_Task_Step_Id);

        //        var sbvExcelReport = new SbvExcelReport
        //        {
        //            rptReport = _rptReport,
        //            businessDate = flowExecution.Business_Date,
        //            entityCode = task.Entity_Code,
        //            approach = _approach_SBV,
        //            scenarioId = task.Scenario_Id,
        //            versionId = task.Version_Id,
        //            additionalParams = $"customer_id^\"{customer_Id}\""
        //        };

        //        var api_1_report = $"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_SBV_REPORT}";
        //        Log.Information($"Call API1_adjust Batch, Job: {api_1_report}");
        //        Log.Information($"Batch_Engine_Execution adjust: {JsonConvert.SerializeObject(sbvExcelReport, Formatting.Indented)}");
        //        var results = APIHelper.PostAsString(api_1_report, GetToken(), JsonConvert.SerializeObject(sbvExcelReport), MediaTypeNames.Application.Json, API_METHODS.POST);
        //        Dictionary<string, List<dynamic>> data = JsonConvert.DeserializeObject<Dictionary<string, List<dynamic>>>(results);

        //        // get customer (rebuild filename)
        //        var filename = BuildFilename(customer_Id, flowExecution);
        //        HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, $"{filename}.xlsx");

        //        return Ok(data);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex.Message);
        //        Log.Error(ex.StackTrace);
        //        Log.Error(ex.InnerException?.Message);
        //        if (ex is HttpErrorException)
        //            throw;
        //        else
        //            throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
        //    }
        //    finally
        //    {
        //    }
        //}



        //private string BuildFilename(string customer_Id, FlowExecution flowExecution)
        //{
        //    // get customer (rebuild filename)
        //    var customer = _customerResultRepository.FindByCustomerId(customer_Id);
        //    var filename = string.IsNullOrEmpty(customer.Customer_Name)
        //        ? $"{customer_Id}{SpecificSystems.UNDERSCORE}{flowExecution.Business_Date.ToString(DefFormats.DATE_FORMAT).Replace(SpecificSystems.DASH, string.Empty)}"
        //        : $"{customer_Id}{SpecificSystems.UNDERSCORE}{customer.Customer_Name.Replace(SpecificSystems.WHITE_SPACE, SpecificSystems.UNDERSCORE)}{SpecificSystems.UNDERSCORE}{flowExecution.Business_Date.ToString(DefFormats.DATE_FORMAT).Replace(SpecificSystems.DASH, string.Empty)}";
        //    return filename;
        //}
    }
}

﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Functions
{
    public class AvaiableDate : BaseQueryResult
    {
        public DateTime Business_Date { get; set; }
    }
}

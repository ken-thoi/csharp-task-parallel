﻿namespace VPBANK.RMD.API.Common.Securities.Jwt
{
    public static class JwtAuth
    {
    }
}

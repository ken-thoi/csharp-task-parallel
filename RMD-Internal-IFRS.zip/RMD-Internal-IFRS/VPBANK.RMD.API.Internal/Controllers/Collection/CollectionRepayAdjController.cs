﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System;
using System.Net;
using Serilog;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using Newtonsoft.Json;
using System.Net.Mime;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using AutoMapper;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Services.Collection.Interfaces;
using VPBANK.RMD.Services.Auth.Interfaces;


namespace VPBANK.RMD.API.Internal.Controllers.Collection
{
    public class CollectionRepayAdjController : TrackingController<CollectionContext, CollectionRepayAdj, long>
    {
        private readonly ICollectionRepayAdjService _service;

        public CollectionRepayAdjController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<CollectionContext> unitOfWork,
            ITrackableRepository<CollectionContext, CollectionRepayAdj, long> trackableRepository,
            IGenericRepository<CollectionContext, CollectionRepayAdj, long> genericRepository,

            ICollectionRepayAdjService CollectionRepayAdjService) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _service = CollectionRepayAdjService;
        }

        /// <summary>
        /// Valid data file import by dat file(.dat)
        /// </summary>
        /// <param name="file">file input: dat file by stream</param>
        /// <returns>
        /// If file error return: Row error and error message by row
        /// If file not error return: string empty
        /// </returns>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Octet)]
        public IActionResult ValidateDatFile([FromBody] byte[] file)
        {
            try
            {
                var content = System.Text.Encoding.UTF8.GetString(file);
                var errors = _service.ValidateDatFileImport(content);
                var resultErrors = JsonConvert.SerializeObject(errors);
                Log.Information($"Collection_Repay_Adj validate results: {resultErrors}");
                return Ok(resultErrors);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

    }
}


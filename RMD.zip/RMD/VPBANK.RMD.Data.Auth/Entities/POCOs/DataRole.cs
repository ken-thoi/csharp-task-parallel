﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.Entities.POCOs
{
    [Table("Data_Role", Schema = "Core")]
    public class DataRole : BaseEntity<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }
}

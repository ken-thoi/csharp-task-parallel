﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class Subject_Data
    {
        public long Id { get; set; }
        public int MessageID { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Subject { get; set; }
        public DateTime DateUTC { get; set; }
    }
}

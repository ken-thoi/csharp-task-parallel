﻿using VPBANK.RMD.Data.Collection.Params;

namespace VPBANK.RMD.Services.Collection.DataContracts.Reports
{
    public class CollectionNewbookReportReq : CollectionNewbookReportParam
    {
    }
}

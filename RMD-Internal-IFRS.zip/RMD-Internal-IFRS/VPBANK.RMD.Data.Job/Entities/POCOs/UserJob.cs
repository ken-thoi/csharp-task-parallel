﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Job.Entities.POCOs
{
    [Table("User_Job", Schema = "App")]
    public class UserJob : EntityBase<decimal>
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(name: "PK_ID")]
        public override decimal Pk_Id { get; set; }

        [Column(name: "Uniq_Sys_ID")]
        public string Uniq_Sys_Id { get; set; }
        [Column(name: "Command")]
        public string Command { get; set; }
    }
}

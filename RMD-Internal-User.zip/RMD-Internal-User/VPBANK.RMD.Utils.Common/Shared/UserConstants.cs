﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class UserConstants
    {
        public const string WWWROOT = "wwwroot";


    }

    public static class UserStatusConstant
    {
        public const string ACTIVE = "A";
        public const string DEACTIVE = "D";
    }
}

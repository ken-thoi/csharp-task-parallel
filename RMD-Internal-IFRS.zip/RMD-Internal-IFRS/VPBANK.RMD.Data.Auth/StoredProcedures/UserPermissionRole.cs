﻿using System;
using System.Collections.Generic;
using System.Text;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Auth.StoredProcedures
{
    class UserPermissionRole : QueryObjectResult
    {
    }
}

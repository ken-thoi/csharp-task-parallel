﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Serilog;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Microsoft.EntityFrameworkCore.Internal;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.Collection;
using VPBANK.RMD.Data.Collection.Entities.POCOs;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Helpers.Errors;
using VPBANK.RMD.Services.Collection.Interfaces;

namespace VPBANK.RMD.API.Internal.Controllers.Collection
{
    public class ConfRotationBookScheduleController : ProcessController<CollectionContext, ConfRotationBookSchedule, int>
    {
        private readonly IConfRotationBookScheduleService _service;

        public ConfRotationBookScheduleController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<CollectionContext> unitOfWork,
            ITrackableRepository<CollectionContext, ConfRotationBookSchedule, int> trackableRepository,
            IGenericRepository<CollectionContext, ConfRotationBookSchedule, int> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository,

            IConfRotationBookScheduleService service) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository,
                reqRepository, requestService, appStaService, reqStatusRepository)
        {
            _service = service;
        }

        /// <summary>
        /// Validate data input by add, edit
        /// </summary>
        /// <param name="entity"></param>
        /// <returns>List error: field, error message</returns>
        [HttpPost]
        public virtual ActionResult<IList<FieldValidate>> Validate([FromBody] ConfRotationBookScheduleDto entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest();

                var results = _service.Validate(entity);
                if (results.Any())
                    return BadRequest(results);

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

    }
}
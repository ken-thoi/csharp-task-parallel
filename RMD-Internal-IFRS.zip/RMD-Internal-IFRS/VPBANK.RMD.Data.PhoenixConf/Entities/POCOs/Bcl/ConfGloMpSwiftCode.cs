﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Bcl
{
    [Table("Conf_Glo_MP_Swift_Code", Schema = "bcl")]
    public class ConfGloMpSwiftCode : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Customer_Id { get; set; }

        public string Swift_Code { get; set; }

        public DateTime Start_Date { get; set; }

        public DateTime? End_Date { get; set; }
    }

    public class ConfGloMpSwiftCodeRequestable : Requestable
    {
        public int? Pk_Id { get; set; }

        public string Customer_Id { get; set; }

        public string Swift_Code { get; set; }

        public DateTime Start_Date { get; set; }

        public DateTime? End_Date { get; set; }
    }
}

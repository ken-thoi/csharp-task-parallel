﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.Repositories.Auth.Interfaces;

namespace VPBANK.RMD.Repositories.Auth.Implements
{
    public class UserArchivedRepository : Repository<AuthContext, UserArchived, int>, IUserArchivedRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly ILogger<User> _logger;
        protected readonly AuthContext _authContext;

        public UserArchivedRepository(IDistributedCache distributedCache, ILogger<User> logger, ITrackableRepository<AuthContext, UserArchived, int> trackableRepository,
            AuthContext authContext) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _logger = logger;
            _authContext = authContext;
        }

    }
}

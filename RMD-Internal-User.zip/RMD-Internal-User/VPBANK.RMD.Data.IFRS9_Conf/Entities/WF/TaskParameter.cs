﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("TaskParameter", Schema = "WF")]
    public class TaskParameter : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public int? FK_Task_Id { get; set; }

        public string ParameterName { get; set; }

        public string ParameterType { get; set; }

        public string ParameterDesc { get; set; }
    }
}

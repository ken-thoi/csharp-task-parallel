﻿namespace VPBANK.RMD.Data.IFRS9_Data
{
    public static class IFRS9_Data_Schemas
    {
        public static readonly string DBO = "dbo";
    }
}

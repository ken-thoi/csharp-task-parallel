﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.Collection.Entities.POCOs
{
    [Serializable]
    [Table("Conf_Rotation_Book_Schedule", Schema = "dbo")]
    public class ConfRotationBookSchedule : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public DateTime Date_Before_Rotate_Book { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }

    public class ConfRotationBookScheduleRequestable : Requestable
    {
        public int? Pk_Id { get; set; }
        public DateTime Date_Before_Rotate_Book { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("MP_Model_Segment_Group", Schema = "Core")]
    public class MpModelSegmentGroup : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Model_Segment { get; set; }
        public string Model_Definition { get; set; }
        public string Model_Segment_Group { get; set; }
        public DateTime? Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

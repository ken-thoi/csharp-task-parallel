﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Entities
{
    public class FilePackage
    {
        public int Id { get; set; }
        public int FK_Customer { get; set; }
        public string Destination { get; set; }
        public string ProcessTime { get; set; }
    }
}

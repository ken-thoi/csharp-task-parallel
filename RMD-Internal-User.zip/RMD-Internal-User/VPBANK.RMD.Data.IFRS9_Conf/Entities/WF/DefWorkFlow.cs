﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.WF
{
    [Table("DefWorkFlow", Schema = "WF")]
    public class DefWorkFlow : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Role { get; set; }

        public string WorkFlowCode { get; set; }

        public string WorkFlowName { get; set; }

        public string WorkFlowDesc { get; set; }

        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

        public string CreatedBy { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? CreatedTime { get; set; }

        public string UpdatedBy { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? UpdatedTime { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("Mp_Gl_Ifrs9", Schema = "Core")]
    public class MpGlIfrs9 : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string TableName { get; set; }

        public decimal? GL { get; set; }

        public string Statement_Type { get; set; }

        public DateTime? Start_Date { get; set; }

        public DateTime? End_Date { get; set; }
    }
}

﻿namespace VPBANK.RMD.Utils.Common
{
    public static class SESSION_KEYS
    {
        public static readonly string USER_PAYLOAD = "USER_PAYLOAD";
        public static readonly string USER = "USER";


        public static readonly string APPROVE_SQL_EXCEPTION = "APPROVE_SQL_EXCEPTION";
    }
}

﻿namespace VPBANK.RMD.API.IFRS9
{
    public static class Globals
    {
    }
}

﻿using Microsoft.Extensions.Caching.Distributed;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class IfrsILLPCfAdjustSummaryRepository : Repository<IFRS9_DataContext, ILLPCashflowAdjustSummary, int>, IIfrsILLPCfAdjustSummaryRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public IfrsILLPCfAdjustSummaryRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, ILLPCashflowAdjustSummary, int> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }
    }
}

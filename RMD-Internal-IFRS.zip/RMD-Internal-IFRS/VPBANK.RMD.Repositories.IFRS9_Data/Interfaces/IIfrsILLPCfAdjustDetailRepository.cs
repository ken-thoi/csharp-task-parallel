﻿using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Interfaces
{
    public interface IIfrsILLPCfAdjustDetailRepository : IRepository<IFRS9_DataContext, ILLPCashflowAdjustDetail, int>
    {
    }
}

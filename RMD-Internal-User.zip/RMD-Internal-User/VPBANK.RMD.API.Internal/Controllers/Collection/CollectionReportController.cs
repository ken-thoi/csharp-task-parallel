﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Serilog;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Repositories.Collection.Interfaces;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Services.Collection.DataTransferObjects.Reports;
using VPBANK.RMD.Data.Collection.StoredProcedures;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Internal.Controllers.Collection
{
    [Authorize]
    public class CollectionReportController : BaseController
    {
        private readonly ICollectionRepayReportRepository _colcRepayRepository;
        private readonly ICollectionNewbookReportRepository _colcNewbookRepository;

        public CollectionReportController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            ICollectionRepayReportRepository colcRepayRepository,
            ICollectionNewbookReportRepository colcNewbookRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository)
        {
            _colcRepayRepository = colcRepayRepository;
            _colcNewbookRepository = colcNewbookRepository;
        }

        /// <summary>
        /// List all records Collection Repay Report by param filter.
        /// </summary>
        /// <param name="paramReq"></param>
        /// <returns>IEnumerable</returns>
        [HttpPost]
        public virtual ActionResult<IEnumerable<CollectionRepayReport>> GetCollectionRepayReport([FromBody] CollectionRepayReportReq paramReq)
        {
            try
            {
                var results = _colcRepayRepository.GetCollectionRepayReport(paramReq).ToList();

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// List all records Collection New Book by param filter.
        /// </summary>
        /// <param name="paramReq"></param>
        /// <returns>IEnumerable</returns>
        [HttpPost]
        public virtual ActionResult<IEnumerable<CollectionNewbookReport>> GetCollectionNewbookReport([FromBody] CollectionNewbookReportReq paramReq)
        {
            try
            {
                var results = _colcNewbookRepository.GetCollectionNewbookReport(paramReq).ToList();

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}
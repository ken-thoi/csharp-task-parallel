﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core
{
    // Get_Customer_INIT_Contract
    public class CustomerInitContractResult : QueryObjectResult
    {
        public DateTime Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
    }
}

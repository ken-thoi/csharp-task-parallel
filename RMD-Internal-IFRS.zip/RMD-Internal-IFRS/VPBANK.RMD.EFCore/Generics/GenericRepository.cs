﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TrackableEntities.Common.Core;
using System.Text;
using System.Linq;
using Serilog;
using static VPBANK.RMD.Utils.Common.Enums;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.Extensions;

namespace VPBANK.RMD.EFCore.Generics
{
    /// <summary>
    /// Generic Repository
    /// extending IRepository<TEntity> and/or ITrackableRepository<TEntity>, scope: application-wide
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public interface IGenericRepository<TContext, TEntity, TKey> : IRepository<TContext, TEntity, TKey>, IDomainRepository<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        TEntity Find(object[] keyValues, CancellationToken cancellationToken = default);

        TEntity Find(TKey keyValues, CancellationToken cancellationToken = default);

        IEnumerable<TEntity> ListViewModels(string spName, object[] parameters);

        Task<IEnumerable<TEntity>> ListViewModelsAsync(string spName, object[] parameters);

        int CountDataPaginated(PaginatedInputModel paginatedInputModel, bool hasEngineCol, List<string> engineDataRoles, bool hasEntityCol, List<string> entityDataRoles,
            bool hasBuCol, bool hasBu1Col, bool hasBu2Col, bool hasBu3Col, List<int> businessUnitRoles);

        IEnumerable<TEntity> QueryDataPaginated(PaginatedInputModel paginatedInputModel, bool hasEngineCol, List<string> engineDataRoles, bool hasEntityCol, List<string> entityDataRoles,
            bool hasBuCol, bool hasBu1Col, bool hasBu2Col, bool hasBu3Col, List<int> businessUnitRoles);
    }

    /// <summary>
    /// Generic Repository
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public class GenericRepository<TContext, TEntity, TKey> : Repository<TContext, TEntity, TKey>, IGenericRepository<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        private readonly IDomainRepository<TContext, TEntity, TKey> _domainRepository;

        public GenericRepository(IDomainRepository<TContext, TEntity, TKey> domainRepository) : base(domainRepository)
        {
            this._domainRepository = domainRepository;
        }

        public TContext GetContext() => _domainRepository.GetContext();

        public TEntity Find(object[] keyValues, CancellationToken cancellationToken = default)
        {
            return this._domainRepository.Find(keyValues, cancellationToken);
        }

        public TEntity Find(TKey keyValues, CancellationToken cancellationToken = default)
        {
            return this._domainRepository.Find(keyValues, cancellationToken);
        }

        public void BulkInsert(IList<object> entities, CancellationToken cancellationToken = default)
        {
            this._domainRepository.BulkInsert(entities);
        }

        public async Task BulkInsertAsync(IList<object> entities, CancellationToken cancellationToken = default)
        {
            await this._domainRepository.BulkInsertAsync(entities);
        }

        public void BulkUpdate(IList<object> entities, CancellationToken cancellationToken = default)
        {
            this._domainRepository.BulkUpdate(entities);
        }

        public async Task BulkUpdateAsync(IList<object> entities, CancellationToken cancellationToken = default)
        {
            await this._domainRepository.BulkUpdateAsync(entities);
        }

        public void BulkDelete(IList<object> entities, CancellationToken cancellationToken = default)
        {
            this._domainRepository.BulkDelete(entities);
        }

        public async Task BulkDeleteAsync(IList<object> entities, CancellationToken cancellationToken = default)
        {
            await this._domainRepository.BulkDeleteAsync(entities);
        }

        // implement get list by store procedure
        public IEnumerable<TEntity> ListViewModels(string spName, object[] parameters)
        {
            try
            {
                var result = _domainRepository.QueryableFromSqlRaw(spName, parameters);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // implement async get list by store procedure
        public async Task<IEnumerable<TEntity>> ListViewModelsAsync(string spName, object[] parameters)
        {
            try
            {
                var results = await this.TrackableRepository.Query().SelectSqlAsync(spName, parameters);
                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int CountDataPaginated(PaginatedInputModel paginatedInputModel, bool hasEngineCol, List<string> engineDataRoles, bool hasEntityCol, List<string> entityDataRoles,
            bool hasBuCol, bool hasBu1Col, bool hasBu2Col, bool hasBu3Col, List<int> businessUnitRoles)
        {
            try
            {
                var sqlQuery = CreateScriptRunQuery(false, paginatedInputModel, hasEngineCol, engineDataRoles, hasEntityCol, entityDataRoles,
                    hasBuCol, hasBu1Col, hasBu2Col, hasBu3Col, businessUnitRoles);
                var total = TrackableRepository.QueryableFromSqlRaw(sqlQuery).AsEnumerable().Count();
                //var _context = GetContext();
                //var total = _context.Database.ExecuteSqlCommand(sqlQuery);
                return total;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<TEntity> QueryDataPaginated(PaginatedInputModel paginatedInputModel, bool hasEngineCol, List<string> engineDataRoles, bool hasEntityCol, List<string> entityDataRoles,
            bool hasBuCol, bool hasBu1Col, bool hasBu2Col, bool hasBu3Col, List<int> businessUnitRoles)
        {
            try
            {
                var sqlQuery = CreateScriptRunQuery(true, paginatedInputModel, hasEngineCol, engineDataRoles, hasEntityCol, entityDataRoles,
                    hasBuCol, hasBu1Col, hasBu2Col, hasBu3Col, businessUnitRoles);
                var results = TrackableRepository.QueryableFromSqlRaw(sqlQuery).AsEnumerable();
                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string CreateScriptRunQuery(bool hasSortOrPaging, PaginatedInputModel paginatedInputModel, bool hasEngineCol, List<string> engineDataRoles, bool hasEntityCol, List<string> entityDataRoles,
            bool hasBuCol, bool hasBu1Col, bool hasBu2Col, bool hasBu3Col, List<int> businessUnitRoles)
        {
            var context = _domainRepository.GetContext();
            var entityType = context.Model.FindEntityType(typeof(TEntity));
            var tableName = entityType.GetTableName();
            var tableSchema = entityType.GetSchema();

            var tableFull = $"{tableSchema}].[{tableName}";

            var query = new StringBuilder();

            #region Engine_Codes temp table

            query.Append("DROP TABLE IF EXISTS #Engine_Codes");
            query.Append("\nCREATE TABLE #Engine_Codes (Role_Code VARCHAR(100))");
            if (engineDataRoles != null && engineDataRoles.Any())
                foreach (var engine in engineDataRoles)
                    if (!string.IsNullOrEmpty(engine))
                        query.Append("\nINSERT INTO #Engine_Codes VALUES ('" + engine + "')");

            #endregion

            #region Entity_Codes temp table

            query.Append("\nDROP TABLE IF EXISTS #Entity_Codes");
            query.Append("\nCREATE TABLE #Entity_Codes (Role_Code VARCHAR(100))");
            if (entityDataRoles != null && entityDataRoles.Any())
                foreach (var entity in entityDataRoles)
                    if (!string.IsNullOrEmpty(entity))
                        query.Append("\nINSERT INTO #Entity_Codes VALUES ('" + entity + "')");

            #endregion

            #region Business_Code temp table

            query.Append("\nDROP TABLE IF EXISTS #Business_Unit_Ids");
            query.Append("\nCREATE TABLE #Business_Unit_Ids (Business_Unit_Id VARCHAR(100))");
            if (businessUnitRoles != null && businessUnitRoles.Any())
                foreach (var buId in businessUnitRoles)
                    if (buId > 0)
                        query.Append("\nINSERT INTO #Business_Unit_Ids VALUES ('" + buId + "')");

            #endregion

            // Engine_Code
            var queryByEngines = new StringBuilder();
            if (hasEngineCol)
            {
                queryByEngines.Append($"\nSELECT DISTINCT T_ENGINE.* FROM [{tableFull}] AS T_ENGINE CROSS APPLY STRING_SPLIT(T_ENGINE.Engine_Code, ';')");
                queryByEngines.Append($"\n\tINNER JOIN #Engine_Codes AS EG ON EG.Role_Code = value");
            }

            // Entity_Code
            var queryByEntities = new StringBuilder();
            if (hasEntityCol)
            {
                queryByEntities.Append($"\nSELECT DISTINCT T_ENTITY.* FROM [{tableFull}] AS T_ENTITY CROSS APPLY STRING_SPLIT(T_ENTITY.Entity_Code, ';')");
                queryByEntities.Append($"\n\tINNER JOIN #Entity_Codes AS ET ON ET.Role_Code = value");
            }

            // Business_Unit
            var lstBuIds = new List<string>();
            if (hasBuCol) lstBuIds.Add("CAST(T_BU.Fk_Business_Unit_Id as NVARCHAR(MAX))");
            if (hasBu1Col) lstBuIds.Add("CAST(T_BU.Fk_Business_Unit_Id1 as NVARCHAR(MAX))");
            if (hasBu2Col) lstBuIds.Add("CAST(T_BU.Fk_Business_Unit_Id2 as NVARCHAR(MAX))");
            if (hasBu3Col) lstBuIds.Add("CAST(T_BU.Fk_Business_Unit_Id3 as NVARCHAR(MAX))");
            var businessUnitCrossApply = string.Join(@", ';', ", lstBuIds.ToArray());
            var concatBusinessUnits = string.Empty;
            if (lstBuIds.Any() && lstBuIds.Count == 1)
                concatBusinessUnits = lstBuIds.First();
            else if (lstBuIds.Any() && lstBuIds.Count > 1)
                concatBusinessUnits = $"CONCAT({businessUnitCrossApply})";
            else
                concatBusinessUnits = string.Empty;

            var queryByBusinessUnits = new StringBuilder();
            if (!string.IsNullOrEmpty(businessUnitCrossApply) || hasBuCol || hasBu1Col || hasBu2Col || hasBu3Col)
            {
                queryByBusinessUnits.Append($"\nSELECT DISTINCT T_BU.* FROM [{tableFull}] AS T_BU CROSS APPLY STRING_SPLIT({concatBusinessUnits}, ';') AS CA");
                queryByBusinessUnits.Append($"\n\tINNER JOIN #Business_Unit_Ids AS BU ON BU.Business_Unit_Id = CA.value");
            }

            // start query run
            // sorting & paging
            if (hasSortOrPaging)
                query.Append("\nSELECT x.* FROM (");
            else
                query.Append("\nSELECT x.* FROM (");
            //query.Append("\nSELECT COUNT(x.PK_ID) FROM (");

            // body query
            var queryBody = new StringBuilder();
            if (hasEngineCol && queryByEngines.Length > 0 && queryBody.Length > 0)
                queryBody.Append($"\nINTERSECT{queryByEngines}");
            else
                queryBody.Append($"{queryByEngines}");

            if (hasEntityCol && queryByEntities.Length > 0 && queryBody.Length > 0)
                queryBody.Append($"\nINTERSECT{queryByEntities}");
            else
                queryBody.Append($"{queryByEntities}");

            if ((hasBuCol || hasBu1Col || hasBu2Col || hasBu3Col) && queryByBusinessUnits.Length > 0 && queryBody.Length > 0)
                queryBody.Append($"\nINTERSECT{queryByBusinessUnits}");
            else
                queryBody.Append($"{queryByBusinessUnits}");

            if (queryBody.Length == 0)
                query.Append($"\nSELECT DISTINCT * FROM [{tableFull}]");
            else
                query.Append(queryBody);

            // end query run
            query.Append("\n) AS x");

            // filters
            var filters = paginatedInputModel.FilterExpression;
            if (!string.IsNullOrEmpty(filters))
                query.Append($"\nWHERE ({filters})");

            // sorting & paging
            if (hasSortOrPaging)
            {
                // sorting
                var sorts = new List<string>();
                if (paginatedInputModel.SortingParams != null && paginatedInputModel.SortingParams.Any())
                    foreach (var item in paginatedInputModel.SortingParams)
                        sorts.Add($"[{item.ColumnName}] {item.SortOrder.GetDescription()}");
                else
                    sorts.Add($"{EfCoreConstants.Pk_Id} {SortOrders.Asc.GetDescription()}");

                if (sorts != null && sorts.Any())
                    query.Append($"\nORDER BY {string.Join(SpecificSystems.COL_JOIN_COMMA, sorts)}");

                // paging
                var offSet = paginatedInputModel.PageIndex * paginatedInputModel.PageSize;
                var fetchNext = paginatedInputModel.PageSize;
                query.Append($"\nOFFSET {offSet} ROWS FETCH NEXT {fetchNext} ROWS ONLY");
            }

            return query.ToString();
        }
    }
}

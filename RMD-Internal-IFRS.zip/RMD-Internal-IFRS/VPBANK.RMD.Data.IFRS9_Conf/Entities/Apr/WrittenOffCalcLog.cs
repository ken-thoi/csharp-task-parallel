﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr
{
    [Table("Written_Off_Calc_Log", Schema = "Apr")]
    public class WrittenOffCalcLog : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Written_Off_Upload_Id { get; set; }
        public string Status { get; set; }
        public string Calculator { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

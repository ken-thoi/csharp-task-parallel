﻿namespace VPBANK.RMD.API.Internal.Internal
{
    public static class Globals
    {
    }
}

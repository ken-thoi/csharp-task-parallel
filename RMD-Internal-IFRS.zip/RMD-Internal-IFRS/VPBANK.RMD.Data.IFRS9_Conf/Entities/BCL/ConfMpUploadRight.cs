﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_MP_Upload_Right", Schema = "BCL")]
    public class ConfMpUploadRight : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public int Fk_Lu_Upload_Id { get; set; }
        public int Fk_Business_Unit_Id1 { get; set; }
        public int Fk_Business_Unit_Id2 { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }

    public class ConfMpUploadRightRequestable : Requestable
    {
        public int? Pk_Id { get; set; }
        public int Fk_Lu_Upload_Id { get; set; }
        public int Fk_Business_Unit_Id1 { get; set; }
        public int Fk_Business_Unit_Id2 { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

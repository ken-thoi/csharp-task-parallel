﻿using System;
using System.Collections.Generic;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core
{
    public interface IIfrsEclResultRepository : IQueryRepository<IFRS9_ConfContext, IfrsEclResult>
    {
        List<IfrsEclResult> FindAllEclResultByCustomerIdAndBusinessDate(string customerId, DateTime businessDate);
    }
}

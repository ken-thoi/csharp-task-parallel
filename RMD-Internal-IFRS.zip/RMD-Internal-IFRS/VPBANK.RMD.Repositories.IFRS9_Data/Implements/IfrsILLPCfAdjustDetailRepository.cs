﻿using Microsoft.Extensions.Caching.Distributed;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;

namespace VPBANK.RMD.Repositories.IFRS9_Data.Implements
{
    public class IfrsILLPCfAdjustDetailRepository : Repository<IFRS9_DataContext, ILLPCashflowAdjustDetail, int>, IIfrsILLPCfAdjustDetailRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_DataContext _context;

        public IfrsILLPCfAdjustDetailRepository(IDistributedCache distributedCache,
            ITrackableRepository<IFRS9_DataContext, ILLPCashflowAdjustDetail, int> trackableRepository,
            IFRS9_DataContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }
    }
}

﻿using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class MGLController
    {
        private static object _lockRunning = new object();
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        
        public static void MGLFileProcess()
        {
            logger.Info("------ START: Read MGL Document ------");
            var runTime = DateTime.Now;
            string currentBackupFolder = MoveFileToHistoryFolder(runTime);
            ScanFileMGL(currentBackupFolder, runTime);
            System.Threading.Thread.Sleep(10000);
            //Task.Factory.StartNew(() =>
            //{
            //    while (true)
            //    {
            //        MoveFileToHistoryFolder();
            //        ScanFileMGL();
            //        System.Threading.Thread.Sleep(10000);
            //    }
            //});
        }

        private static void ScanFileMGL(string folderMGL,DateTime runTime)
        {
            string sid = runTime.ToString("yyyyMMddHHmmssfff");
            var listFolder = Directory.GetDirectories(folderMGL);

            DataTable result = new DataTable();
            foreach (var folder in listFolder)
            {
                var listFile = Directory.GetFiles(folder, ".xlsb", SearchOption.TopDirectoryOnly);
                var folderName = folder.Split('\\').Last();
                foreach (var file in listFile)
                {
                    var dt = ExtractDataFromFile(file);
                    DataColumn newColumn1 = new DataColumn("SID", typeof(string));
                    newColumn1.DefaultValue = sid;
                    dt.Columns.Add(newColumn1);

                    DataColumn newColumn2 = new DataColumn("Folder", typeof(string));
                    newColumn2.DefaultValue = folderName;
                    dt.Columns.Add(newColumn2);

                    DataColumn newColumn3 = new DataColumn("FileName", typeof(string));
                    newColumn3.DefaultValue = file.Split('\\').Last();
                    dt.Columns.Add(newColumn3);

                    if (result.Rows.Count == 0)
                        result = dt.Clone();
                    else
                    {
                        result.Merge(dt);
                    }
                }
            }
            result.TableName = "[FileServ].[MGL_Staging]";
            Utils.SqlHelper.ExcuteBulkInsert(result);
        }

        

        private static DataTable ExtractDataFromFile(string file)
        {
            var wb = new Workbook();
            wb.LoadDocument(file);
            var range = wb.Worksheets[WorksheetToExport].GetUsedRange();
            DataTable dataTable = wb.Worksheets[WorksheetToExport].CreateDataTable(range, true);
            DataTableExporter exporter = wb.Worksheets[WorksheetToExport].CreateDataTableExporter(range, dataTable, true);
            exporter.Options.ConvertEmptyCells = true;
            exporter.Options.DefaultCellValueToColumnTypeConverter.SkipErrorValues = false;
            exporter.Export();
            return dataTable;
        }

        private static string MoveFileToHistoryFolder(DateTime runtime)
        {
            string bussinessDate = runtime.ToString("yyyy-MM-dd");
            string time = runtime.ToString("HHmmss");
            string backupFolder = Path.Combine(HistoryMGLFolder, bussinessDate, time);
            if (Directory.Exists(backupFolder))
                Directory.Delete(backupFolder, true);

            foreach (string dirPath in Directory.GetDirectories(CurrentMGLFolder, "*", SearchOption.AllDirectories))
                Directory.CreateDirectory(dirPath.Replace(CurrentMGLFolder, backupFolder));

            foreach (string newPath in Directory.GetFiles(CurrentMGLFolder, "*.*", SearchOption.AllDirectories))
                File.Copy(newPath, newPath.Replace(CurrentMGLFolder, backupFolder), true);
            return backupFolder;
        }

        public static string WorksheetToExport
        {
            get
            {
                return SysVarController.GetSystemValue("MGL_PROCESS", "WORKSHEET_TO_EXPORT");
            }
        }

        public static string CurrentMGLFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "MGL_FOLDER");
            }
        }

        public static string HistoryMGLFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "HISTORY_MGL_FOLDER");
            }
        }
    }
}

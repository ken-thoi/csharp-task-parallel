﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Entites
{
    public class Header_Data
    {
        public int Id { get; set; }
        public int MessageID { get; set; }
        public int FK_Header_Type_Id { get; set; }
        public string HeaderValue { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using Serilog;
using System.Net;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Apr
{
    public class IfrsPllpEclResultController : QueryController<IFRS9_DataContext, ViewIfrsPLLPResult, long>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;
        private readonly IIfrsEclResultRepository _ifrsEclResultRepository;

        public IfrsPllpEclResultController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_DataContext> unitOfWork,
            ITrackableRepository<IFRS9_DataContext, ViewIfrsPLLPResult, long> trackableRepository,
            IGenericRepository<IFRS9_DataContext, ViewIfrsPLLPResult, long> genericRepository,

            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,
            IIfrsEclResultRepository ifrsEclResultRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;
            _ifrsEclResultRepository = ifrsEclResultRepository;
        }

        /// <summary>
        /// Find ECL final result by customer_id (store procedure)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{fk_Task_Execution_Id}/customers/{customer_Id}")]
        public virtual ActionResult<IEnumerable<IfrsEclResult>> FindEclResult([FromRoute] int fk_Task_Execution_Id, [FromRoute] string customer_Id)
        {
            try
            {
                if (!ModelState.IsValid || string.IsNullOrEmpty(customer_Id))
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), "Error");

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), "Error");

                var flowExecution = _genFlowExecutionRepository.Find(flowStepExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), "Error");

                var results = _ifrsEclResultRepository.FindAllEclResultByCustomerIdAndBusinessDate(customer_Id, flowExecution.Business_Date);

                // result
                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find ECL final result by customer_id (from view) with filter, sort, paging.
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public async Task<ActionResult<PaginatedContentResults<ViewIfrsPLLPResult>>> QueryByTaskExecution([Required][NotNull][FromRoute] int fk_Task_Execution_Id, [Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0)
                    return BadRequest();

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                var flowExecution = _genFlowExecutionRepository.Find(flowStepExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null)
                    return NotFound();

                var query = $"Business_Date = '{flowExecution.Business_Date.ToString(DefFormats.DATE_FORMAT)}'";

                if (paginatedParams == null)
                    paginatedParams = new PaginatedInputModel { FilterExpression = query };
                else if (string.IsNullOrEmpty(paginatedParams.FilterExpression))
                    paginatedParams.FilterExpression = query;
                else
                    paginatedParams.FilterExpression = $"{paginatedParams.FilterExpression} AND {query}";

                var results = GetResults(paginatedParams);
                var total = results.Item1;
                var data = results.Item2;

                // result
                dynamic result = await GenericQueryResultAsync(total, data, paginatedParams, true);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

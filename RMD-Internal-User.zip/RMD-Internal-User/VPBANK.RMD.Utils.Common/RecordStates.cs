﻿namespace VPBANK.RMD.Utils.Common
{
    public class RecordStates
    {
        public static readonly string NEW = "New";
        public static readonly string UPDATE = "Update";
        public static readonly string DELETE = "Delete";
    }
}

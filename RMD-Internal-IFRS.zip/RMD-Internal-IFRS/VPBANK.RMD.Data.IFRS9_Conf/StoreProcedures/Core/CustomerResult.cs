﻿using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core
{
    public class CustomerResult : QueryObjectResult
    {
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Customer_Name_En { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class FileRequest
    {
        public int Id { get; set; }
        public string MessageID { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public DateTime RequestDateTime { get; set; }
        public RequestStatus Status { get; set; }
        public bool ForceExcute { get; set; }
        public string LogMSG { get; set; }
    }

    public enum RequestStatus
    {
        Waitting = 10,
        Validating = 15,
        ValidatedFailed_ContractNumberNotInAnyDoc = 14,
        ValidatedFailed_DoNotHavePermission = 16,
        ValidatedFailed_WrongTemplate = 17,
        ValidatedFailed_DoNotHavePermissionOnContract = 18,
        ValidatedSucessful = 19,
        WaitForPackageFile = 20,
        FilePackaged = 30,
        FileResponeOverMail = 40,
        UploadingToShareFile = 60,
        UploadedToShareFile = 70,
        UploadedToShareFileError = 75,
        Replying = 80,
        Done = 90
    }
}

﻿namespace VPBANK.RMD.Data.PhoenixConf
{
    public static class PhoenixConfDbConstants
    {
        public static readonly string DBO = "dbo";
        public static readonly string APP = "app";
        public static readonly string BCL = "bcl";
        public static readonly string TECH = "tech";
        public static readonly string WEB_CORE = "web_core";
    }
}

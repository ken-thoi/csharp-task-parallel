﻿using EmailService.Entites;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Controller
{
    public static class Body_DataController
    {
        public static void InsertOrUpdateBodyData(Body_Data data)
        {
            string command = "[dbo].[Body_Data_INS]";
            List<SqlParameter> lstParma = new List<SqlParameter>();
            lstParma.Add(new SqlParameter("@pv_MessageID", data.MessageID));
            lstParma.Add(new SqlParameter("@pv_Body", data.Body));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParma.ToArray());
        }
    }
}

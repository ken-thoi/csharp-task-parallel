﻿namespace VPBANK.RMD.Data.Core
{
    public static class Core_Schemas
    {
        public static readonly string DBO = "dbo";
        public static readonly string REF = "ref";
    }
}

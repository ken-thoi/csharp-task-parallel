﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL;
using VPBANK.RMD.EFCore.Abstractions;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.BCL
{
    public interface IMpAccountBusinessUnitRepository : IRepository<IFRS9_ConfContext, ConfMpAccountBusinessUnit, int>
    {
        public List<ConfMpAccountBusinessUnit> FindAllByUsername(string username);
        public List<ConfMpAccountBusinessUnit> FindAllByUsernameAndStatus(string username, string status);
        public List<string> FindAllUsernamesHasBusinessUnit();
        public Task<int> DeleteMpAccountBusinessUnitByUsernameAsync(string username);
    }
}

﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixData.Entities.POCOs.Core
{
    public class ViewIfrsValidation : QueryObjectResult
    {
        public DateTime Business_Date { get; set; }
        public string Field_Validation { get; set; }
        public int Fail_Record { get; set; }
    }
}
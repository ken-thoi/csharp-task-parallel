﻿using Microsoft.AspNetCore.Builder;
using VPBANK.RMD.API.Common.Middlewares;

namespace VPBANK.RMD.API.Common.Extensions
{
    public static class ExceptionExtensions
    {
        public static void ConfigureExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionMiddleware>();
        }
    }
}

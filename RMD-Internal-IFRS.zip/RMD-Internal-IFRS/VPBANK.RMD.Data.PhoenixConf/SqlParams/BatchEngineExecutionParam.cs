﻿using System;

namespace VPBANK.RMD.Data.PhoenixConf.SqlParams
{
    public class BatchEngineExecutionParam
    {
        public long Batch_Id { get; set; }
        public DateTime Business_Date { get; set; }
        public string Entity_Code { get; set; }
        public string Approach { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
        public string Additional_Param { get; set; }
    }
}
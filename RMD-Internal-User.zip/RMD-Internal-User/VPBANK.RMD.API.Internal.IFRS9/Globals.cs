﻿namespace VPBANK.RMD.API.Internal.IFRS9
{
    public static class Globals
    {
    }
}

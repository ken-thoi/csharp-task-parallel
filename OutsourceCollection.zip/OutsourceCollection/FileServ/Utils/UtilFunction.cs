﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Specialized;
using System.Reflection;
using System.Data;
using System.ComponentModel;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Configuration;
using System.IO;
using System.Net;
using DevExpress.Spreadsheet;
using DevExpress.XtraRichEdit;
using DocumentFormat.OpenXml.Validation;
using DevExpress.Pdf;
using DocumentFormat.OpenXml.Packaging;
using Newtonsoft.Json;
using System.CodeDom.Compiler;
using System.CodeDom;
using System.IO.Compression;
using System.Drawing;

namespace FileServ.Utils
{
    public static class UtilFunction
    {
        public static string RemoveInvalidCharsFileName(string filename)
        {
            return string.Concat(filename.Split(Path.GetInvalidFileNameChars()));
        }

        public static string CleanText(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            else
                return input.Replace("\r",string.Empty).Replace("\n", string.Empty).Trim();
        }

        public static string ASCIItoUTF8(string input)
        {
            Encoding latinEncoding = Encoding.GetEncoding("ISO-8859-1");
            Encoding utf8Encoding = Encoding.UTF8;

            byte[] latinBytes = utf8Encoding.GetBytes(input);
            byte[] utf8Bytes = Encoding.Convert(latinEncoding, utf8Encoding, latinBytes);

            return utf8Encoding.GetString(utf8Bytes);
        }

        public static string ToLiteral(string input)
        {
            using (var writer = new StringWriter())
            {
                using (var provider = CodeDomProvider.CreateProvider("CSharp"))
                {
                    provider.GenerateCodeFromExpression(new CodePrimitiveExpression(input), writer, null);
                    return writer.ToString();
                }
            }
        }

        public static void isValidatePDF(string path)
        {
            using (PdfDocumentProcessor pdfDocumentProcessor = new PdfDocumentProcessor())
            {
                pdfDocumentProcessor.LoadDocument(path);
                pdfDocumentProcessor.Dispose();
            }
        }

        public static void isValidateExcel(string path)
        {
            Workbook workbook = new Workbook();
            workbook.LoadDocument(path);
            workbook.Dispose();
        }

        public static void isValidateWord(string path)
        {
            RichEditDocumentServer wordProcessor = new RichEditDocumentServer();
            wordProcessor.LoadDocument(path);
            wordProcessor.Dispose();
        }

        public static void isValidateZip(string path)
        {
            using (var zipFile = ZipFile.OpenRead(path))
            {
                var entries = zipFile.Entries;
                zipFile.Dispose();
            }
        }

        public static void isValidGDIPlusImage(string path)
        {
            using (var bmp = new Bitmap(path))
            {
                bmp.Dispose();
            }
        }

        public static void isValidatePowerPoint(string path)
        {
            var validator = new OpenXmlValidator();
            var result = validator.Validate(PresentationDocument.Open(path, true));
            if (result.Count() > 0)
                throw new Exception(JsonConvert.SerializeObject(result));
        }

        public static bool IsFileLocked(FileInfo file)
        {
            try
            {
                using (FileStream stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    stream.Close();
                }
            }
            catch (IOException)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)
                return true;
            }

            //file is not locked
            return false;
        }

        public static string GetMIMEType(string extFile)
        {
            string mmType = "";
            if (CONSTANT.DictMIMEType.TryGetValue(extFile.ToLower().Trim(), out mmType))
                return mmType;
            else
                return "application/octet-stream";
        }

        public static string BuildIconURL(string url)
        {
            return url;
        }

        public static string ParamToQueryString(NameValueCollection nvc)
        {
            var array = (
                from key in nvc.AllKeys
                from value in nvc.GetValues(key)
                select string.Format("{0}={1}",WebUtility.UrlEncode(key),WebUtility.UrlEncode(value))).ToArray();
            return "?" + string.Join("&", array);
        }

        public static string BuildHidingData(int leng)
        {
            string data = string.Empty;
            while (leng > 0)
            {
                data += "*";
                leng--;
            }
            return data;
        }

        public static ulong GetHashNumber(string data)
        {
            return Encoding.ASCII.GetBytes(data).Select(byt => Convert.ToUInt64(Convert.ToString(byt, 2).PadLeft(8, '0'), 2)).Aggregate((currentSum, item) => currentSum + item);
        }

        public static string GetAppPharseKey()
        {
            return ConfigurationManager.AppSettings["AppPhraseKey"];
        }

        public static object CheckDBValueAPINull(object input)
        {
            if (input is string)
                if (string.IsNullOrEmpty(Convert.ToString(input)))
                    return DBNull.Value;
            if (input is DateTime)
                return DateTime.Parse(Convert.ToString(input)).ToString("yyyy-MM-ddTHH\\:00\\:00.000zzzz");
            if (input == null)
                return DBNull.Value;
            return input;
        }

        public static bool CheckStringRegex(string inputCheckString, string inputRegexPattern)
        {
            Regex regex = new Regex(inputRegexPattern);
            Match match = regex.Match(inputCheckString);
            if (match.Success)
                return true;
            else
                return false;
        }

        public static object CheckDBValueNull(object input)
        {
            if (input is string)
                if (string.IsNullOrEmpty(Convert.ToString(input)))
                    return DBNull.Value;
            if (input == null)
                return DBNull.Value;
            return input;
        }

        public static string CalculateMD5Hash(string input)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }

        public static T CreateItemFromRow<T>(DataRow row) where T : new()
        {
            // create a new object
            T item = new T();

            // set the item
            SetItemFromRow(item, row);

            // return 
            return item;
        }

        public static void SetItemFromRow<T>(T item, DataRow row) where T : new()
        {
            // go through each column
            foreach (DataColumn c in row.Table.Columns)
            {
                // find the property for the column
                PropertyInfo p = item.GetType().GetProperty(c.ColumnName);

                // if exists, set the value
                if (p != null && row[c] != DBNull.Value)
                {
                    if(p.PropertyType.IsEnum)
                        p.SetValue(item, Enum.ToObject(p.PropertyType, row[c]), null);
                    else
                        p.SetValue(item, Convert.ChangeType(row[c], p.PropertyType), null);
                }
            }
        }

        public static string FormatURL(string inputAddress, string[] Param)
        {
            if (Param.Length == 0)
                return inputAddress;

            inputAddress = inputAddress + "?";

            for (int i = 0; i < Param.Length; i++)
            {
                if (i == 0)
                    inputAddress += Param[i] + "={" + i + "}";
                else
                    inputAddress += "&" + Param[i] + "={" + i + "}";

            }
            return inputAddress;
        }

        public static string GetLastInListString(string InputString, char spreadChar)
        {
            var lst = InputString.Split(spreadChar);
            return lst[lst.Length - 1];
        }

        public static string FormatCallbackParam(string inputString)
        {
            inputString = inputString.Substring(inputString.IndexOf('('));
            if (inputString.EndsWith("()"))
                return inputString;
            else
            {
                var paramString = inputString.Substring(inputString.IndexOf('('));
                if (paramString.Length > 2)
                {
                    paramString = paramString.Substring(1, paramString.Length - 2);
                    var lstParam = paramString.Split(',');
                    for (int i = 0; i < lstParam.Length; i++)
                    {
                        lstParam[i] = "' + " + lstParam[i] + " + '";
                    }
                    return inputString.Substring(0, inputString.IndexOf('(') + 1) + string.Join(",", lstParam) + ")";
                }
                return inputString;
            }
        }

        public static List<string> GetAllParamFromSQLCommand(string sqlCommand)
        {
            return Regex.Matches(sqlCommand, @"\@\w+").Cast<Match>().Select(m => m.Value).Distinct().ToList();
        }

        public static void SetProperty(string compoundProperty, object target, object value)
        {
            string[] bits = compoundProperty.Split('.');
            for (int i = 0; i < bits.Length - 1; i++)
            {
                PropertyInfo propertyToGet = target.GetType().GetProperties().FirstOrDefault(p => p.Name.Equals(bits[i]));
                target = propertyToGet.GetValue(target, null);
            }
            PropertyInfo propertyToSet = target.GetType().GetProperties().FirstOrDefault(p => p.Name.Equals(bits.Last()));
            propertyToSet.SetValue(target, value, null);
        }

        public static PropertyInfo GetProperty(string compoundProperty, object target)
        {
            string[] bits = compoundProperty.Split('.');
            for (int i = 0; i < bits.Length - 1; i++)
            {
                PropertyInfo propertyToGet = target.GetType().GetProperty(bits[i]);
                target = propertyToGet.GetValue(target, null);
            }
            return target.GetType().GetProperty(bits.Last());
        }

        public static object GetPropertyValue(string compoundProperty, object target)
        {
            string[] bits = compoundProperty.Split('.');
            for (int i = 0; i < bits.Length - 1; i++)
            {
                PropertyInfo propertyToGet = target.GetType().GetProperty(bits[i]);
                target = propertyToGet.GetValue(target, null);
            }
            PropertyInfo propertyToSet = target.GetType().GetProperty(bits.Last());
            if (propertyToSet == null)
                return null;
            return propertyToSet.GetValue(target, null);
        }

        public static object GetPropertyDynamic(string compoundProperty, dynamic target)
        {
            if (target == null)
                return null;
            dynamic data = target;
            string[] bits = compoundProperty.Split('.');
            for (int i = 0; i < bits.Length; i++)
            {
                if (data == null)
                    return null;
                data = data[bits[i]];
            }
            return data;
        }

        public static DataTable DynamicToDataTable(DataTable dt, dynamic data)
        {
            dt.Rows.Clear();
            if (data == null)
                return dt;

            //if (data is Array)
            {
                foreach (var item in data)
                {
                    var row = dt.NewRow();
                    foreach (DataColumn col in dt.Columns)
                        row[col] = item[col.ColumnName] == null ? DBNull.Value : item[col.ColumnName];
                    dt.Rows.Add(row);
                }
            }
            return dt;
        }

        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection props =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
                //table.Columns.Add(new DataColumn { ColumnName = prop.Name, DataType = prop.PropertyType, AllowDBNull = true });
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }
            return table;
        }

        public static string GetParamName(string inputString)
        {
            inputString = inputString.Substring(inputString.IndexOf('('));
            if (!inputString.EndsWith("()"))
            {
                var paramString = inputString.Substring(inputString.IndexOf('('));
                if (paramString.Length > 2)
                {
                    return paramString = paramString.Substring(1, paramString.Length - 2);
                }
            }
            return string.Empty;
        }

        public static void ParseLanguage(string input, List<string> Key)
        {
            int start = input.IndexOf("<<<");
            int end = input.IndexOf(">>>");
            if (start > -1)
            {
                Key.Add(input.Substring(start, end + 3 - start));
                ParseLanguage(input.Substring(end + 3), Key);
            }
        }

        public static List<FieldInfo> GetConstants(Type type)
        {
            FieldInfo[] fieldInfos = type.GetFields(BindingFlags.Public |
                 BindingFlags.Static | BindingFlags.FlattenHierarchy);

            return fieldInfos.Where(fi => fi.IsLiteral && !fi.IsInitOnly).ToList();
        }

        /// <summary>
        /// Encrypt a string using dual encryption method. Return a encrypted cipher Text
        /// </summary>
        /// <param name="toEncrypt">string to be encrypted</param>
        /// <param name="useHashing">use hashing? send to for extra secirity</param>
        /// <returns></returns>
        public static string Encrypt(string toEncrypt, bool useHashing, string key)
        {
            byte[] keyArray;
            byte[] toEncryptArray = Encoding.UTF8.GetBytes(toEncrypt);

            System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
            // Get the key from config file

            if (string.IsNullOrEmpty(key))
                return string.Empty;

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        /// <summary>
        /// DeCrypt a string using dual encryption method. Return a DeCrypted clear string
        /// </summary>
        /// <param name="cipherString">encrypted string</param>
        /// <param name="useHashing">Did you use hashing to encrypt this data? pass true is yes</param>
        /// <returns></returns>
        public static string Decrypt(string cipherString, bool useHashing, string key)
        {
            byte[] keyArray;
            byte[] toEncryptArray = Convert.FromBase64String(cipherString);

            System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
            //Get your key from config file to open the lock!
            if (string.IsNullOrEmpty(key))
                return string.Empty;

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            tdes.Clear();
            return Encoding.UTF8.GetString(resultArray);
        }

        public static byte[] CreateMD5byte(string input)
        {
            // Use input string to calculate MD5 hash
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                return md5.ComputeHash(inputBytes);
            }
        }

        public static byte[] ReadByteToStream(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        public static string CalculateMD5FromFile(string filename)
        {
            using (var md5 = MD5.Create())
            {
                using (var stream = File.OpenRead(filename))
                {
                    var hash = md5.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }
        }
    }
}

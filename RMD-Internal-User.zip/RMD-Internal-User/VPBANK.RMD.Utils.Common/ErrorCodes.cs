﻿namespace VPBANK.RMD.Utils.Common
{
    public static class ErrorCodes
    {
        // EM00
        public static readonly string EM00 = "EM00";
        // NotFound
        public static readonly string EM01 = "EM000";


        // EM001	[Field #] is a required field. Please fill in.	Require input for mandatory fields
        public static readonly string EM001 = "EM001";
    }
}

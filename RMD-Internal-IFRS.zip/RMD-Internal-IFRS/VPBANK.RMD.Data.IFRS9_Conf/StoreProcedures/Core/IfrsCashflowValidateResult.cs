﻿using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core
{
    public class IfrsCashflowValidateResult : QueryObjectResult
    {
        public int Task_Exec_Id { get; set; }
        public string Customer_Id { get; set; }
        public string Sheet_Name { get; set; }
        public int Col_Row_Number { get; set; }
        public string Col_Address { get; set; }
        public string Error_Code { get; set; }
    }
}

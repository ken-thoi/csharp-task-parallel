﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace FileServ.Utils
{
    public static class SqlHelper
    {
        #region "FILL DATATABLE"
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void Fill(DataTable dataTable, string procedureName, bool IsStore = true, int timeout = 30000)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);
            if (IsStore)
                oCommand.CommandType = CommandType.StoredProcedure;
            else
                oCommand.CommandType = CommandType.Text;

            oCommand.CommandTimeout = timeout;
            SqlDataAdapter oAdapter = new SqlDataAdapter();

            oAdapter.SelectCommand = oCommand;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    oAdapter.SelectCommand.Transaction = oTransaction;
                    oAdapter.Fill(dataTable);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oAdapter.Dispose();
                }
            }
        }

        public static void Fill(DataTable dataTable, string procedureName, SqlParameter[] parameters, bool IsStore = true)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);
            oCommand.CommandType = CommandType.StoredProcedure;

            if (parameters != null)
            {
                foreach (var item in parameters)
                    if (item.Value == null)
                        item.Value = DBNull.Value;
                oCommand.Parameters.AddRange(parameters);
            }

            if (!IsStore)
                oCommand.CommandType = CommandType.Text;
            else
                oCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter oAdapter = new SqlDataAdapter();

            oAdapter.SelectCommand = oCommand;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    oAdapter.SelectCommand.Transaction = oTransaction;
                    oAdapter.Fill(dataTable);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oAdapter.Dispose();
                }
            }
        }

        public static string GetDataJson(string connection, string procedureName, SqlParameter[] parameters, bool IsStore = true)
        {
            string fingerPrint = Guid.NewGuid().ToString();
            var watch = System.Diagnostics.Stopwatch.StartNew();
            ///

            SqlConnection oConnection = new SqlConnection(connection);
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);
            if (IsStore)
                oCommand.CommandType = CommandType.StoredProcedure;
            else
                oCommand.CommandType = CommandType.Text;
            if (parameters != null)
                oCommand.Parameters.AddRange(parameters);
            oConnection.Open();
            var jsonResult = new StringBuilder();
            var reader = oCommand.ExecuteReader();
            if (!reader.HasRows)
            {
                jsonResult.Append("[]");
            }
            else
            {
                while (reader.Read())
                {
                    jsonResult.Append(reader.GetValue(0).ToString());
                }
            }
            return Convert.ToString(jsonResult);
        }
        #endregion

        #region "FILL DATASET"

        public static void Fill(DataSet dataSet, string procedureName)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);
            oCommand.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter oAdapter = new SqlDataAdapter();

            oAdapter.SelectCommand = oCommand;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    oAdapter.SelectCommand.Transaction = oTransaction;
                    oAdapter.Fill(dataSet);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oAdapter.Dispose();
                }
            }
        }

        public static void Fill(DataSet dataSet, string procedureName, SqlParameter[] parameters, bool isStored = true)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);

            if (isStored)
                oCommand.CommandType = CommandType.StoredProcedure;
            else
                oCommand.CommandType = CommandType.Text;

            if (parameters != null)
                oCommand.Parameters.AddRange(parameters);

            SqlDataAdapter oAdapter = new SqlDataAdapter();

            oAdapter.SelectCommand = oCommand;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    oAdapter.SelectCommand.Transaction = oTransaction;
                    oAdapter.Fill(dataSet);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oAdapter.Dispose();
                }
            }
        }

        #endregion

        #region "EXECUTE SCALAR"

        public static object ExecuteScalar(string procedureName)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);

            oCommand.CommandType = CommandType.StoredProcedure;
            object oReturnValue;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    oCommand.Transaction = oTransaction;
                    oReturnValue = oCommand.ExecuteScalar();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oCommand.Dispose();
                }
            }
            return oReturnValue;
        }

        public static object ExecuteScalar(string procedureName, SqlParameter[] parameters, bool IsStore = true)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);

            if (IsStore)
                oCommand.CommandType = CommandType.StoredProcedure;
            else
                oCommand.CommandType = CommandType.Text;

            object oReturnValue;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    if (parameters != null)
                        oCommand.Parameters.AddRange(parameters);

                    oCommand.Transaction = oTransaction;
                    oReturnValue = oCommand.ExecuteScalar();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oCommand.Dispose();
                }
            }
            return oReturnValue;
        }

        #endregion

        #region "EXECUTE NON QUERY"

        public static int ExecuteNonQuery(string procedureName, bool IsStore = true, int timeout = 30000)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);

            if (IsStore)
                oCommand.CommandType = CommandType.StoredProcedure;
            else
                oCommand.CommandType = CommandType.Text;
            oCommand.CommandTimeout = timeout;

            int iReturnValue;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    oCommand.Transaction = oTransaction;
                    iReturnValue = oCommand.ExecuteNonQuery();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oCommand.Dispose();
                }
            }
            return iReturnValue;
        }

        public static int ExecuteNonQuery(string procedureName, SqlParameter[] parameters, bool IsStore = true)
        {
            SqlConnection oConnection = new SqlConnection(AccessConfig.GetConnectionString());
            SqlCommand oCommand = new SqlCommand(procedureName, oConnection);

            if (IsStore)
                oCommand.CommandType = CommandType.StoredProcedure;
            else
                oCommand.CommandType = CommandType.Text;

            int iReturnValue;
            oConnection.Open();
            using (SqlTransaction oTransaction = oConnection.BeginTransaction())
            {
                try
                {
                    string fingerPrint = Guid.NewGuid().ToString();
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    ///
                    if (parameters != null)
                        oCommand.Parameters.AddRange(parameters);

                    oCommand.Transaction = oTransaction;
                    iReturnValue = oCommand.ExecuteNonQuery();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (oConnection.State == ConnectionState.Open)
                        oConnection.Close();
                    oConnection.Dispose();
                    oCommand.Dispose();
                }
            }
            return iReturnValue;
        }

        #endregion

        #region "BULK INSERT"
        public static void ExcuteBulkInsert(DataTable InputTable, int batchSize = 10000, int bulkCopyTimeout = 100000)
        {
            using (SqlConnection connection = new SqlConnection(AccessConfig.GetConnectionString()))
            {
                string fingerPrint = Guid.NewGuid().ToString();
                var watch = System.Diagnostics.Stopwatch.StartNew();
                ///

                SqlBulkCopy bulkCopy =
                    new SqlBulkCopy
                    (
                    connection,
                    SqlBulkCopyOptions.TableLock |
                    SqlBulkCopyOptions.FireTriggers |
                    SqlBulkCopyOptions.UseInternalTransaction |
                    SqlBulkCopyOptions.KeepNulls,
                    null
                    );

                DataTable newInputTable = new DataTable();
                var colDict = BuildColTypeDict(InputTable.TableName);
                foreach (var item in colDict)
                {
                    var newCol = new DataColumn();
                    newCol.ColumnName = item.Key;
                    newCol.DataType = Type.GetType(item.Value);
                    newInputTable.Columns.Add(newCol);
                }
                newInputTable.TableName = InputTable.TableName;
                foreach (DataRow dr in InputTable.Rows)
                {
                    DataRow toInsert = newInputTable.NewRow();
                    bool isEmptyRow = true;
                    foreach (DataColumn col in newInputTable.Columns)
                    {
                        if (string.IsNullOrEmpty(Convert.ToString(dr[col.Caption])))
                            toInsert[col.Caption] = DBNull.Value;
                        else
                        {
                            toInsert[col.Caption] = dr[col.Caption];
                            isEmptyRow = false;
                        }
                    }

                    if (!isEmptyRow)
                        newInputTable.Rows.Add(toInsert);
                }
                bulkCopy.BatchSize = batchSize;
                bulkCopy.BulkCopyTimeout = bulkCopyTimeout;
                bulkCopy.DestinationTableName = InputTable.TableName;
                connection.Open();
                bulkCopy.WriteToServer(newInputTable);
                connection.Close();
            }
        }

        private static Dictionary<string, string> BuildColTypeDict(string tableName)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            SqlConnection conn = new SqlConnection(AccessConfig.GetConnectionString());
            conn.Open();
            SqlCommand command = new SqlCommand(string.Format("SELECT * FROM {0} WHERE (1=0)", tableName), conn);
            try
            {
                command.CommandTimeout = 300000;
                var schema = command.ExecuteReader().GetSchemaTable();
                foreach (DataRow dr in schema.Rows)
                    result.Add(Convert.ToString(dr["ColumnName"]), Convert.ToString(dr["DataType"]));
            }
            catch (Exception ex)
            {
                throw new Exception("Count Row From DB: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return result;
        }
        #endregion
    }

    internal class AccessConfig
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        internal static string GetConnectionString()
        {
            ConnectionStringSettings mySetting = ConfigurationManager.ConnectionStrings["ApplicationServices"];
            if (mySetting == null || string.IsNullOrEmpty(mySetting.ConnectionString))
            {
                var ex = new Exception("Missing connection to Web service string in config file");
                logger.Fatal(ex);
                throw ex;
            }
            return mySetting.ConnectionString;
        }
    }
}

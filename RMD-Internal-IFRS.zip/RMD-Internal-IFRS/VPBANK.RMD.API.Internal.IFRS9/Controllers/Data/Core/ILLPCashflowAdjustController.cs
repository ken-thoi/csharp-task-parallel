﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using AutoMapper;
using System;
using System.Linq;
using Serilog;
using System.Data;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mime;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Collections.Generic;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Views.Core;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Utils.Common.ExcelUtils;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.API.Settings.Sections;
using VPBANK.RMD.Utils.Common.Remote.FTP;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Business;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Services.IFRS9_Data.Interfaces.Core;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using VPBANK.RMD.Services.IFRS9_Conf.DataTransferObjects.Wfs;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Data.IFRS9_Conf.Views.BCL;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Apr
{
    public class ILLPCashflowAdjustController : QueryController<IFRS9_DataContext, ViewIfrsILLPCashflow, long>
    {
        private readonly IRequestsFileService _requestsFileService;
        private readonly IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> _genTaskRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;
        private readonly IRawILLPCfService _rawILLPCfService;
        private readonly IIfrsCashflowValidateResultRepository _ifrsCashflowValidateResultRepository;
        private readonly ICustomerResultRepository _customerResultRepository;
        private readonly IPLLPCustomerRepository _pllpCustomerRepository;
        //View_MP_Account_Business_Unit
        private readonly IGenericRepository<IFRS9_ConfContext, ViewMpAccountBusinessUnit, int> _genViewMpAccountBusinessUnitRepository;
        private readonly IViewIfrsILLPCashflowRepository _viewIfrsILLPCashflowRepository;

        public ILLPCashflowAdjustController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_DataContext> unitOfWork,
            ITrackableRepository<IFRS9_DataContext, ViewIfrsILLPCashflow, long> trackableRepository,
            IGenericRepository<IFRS9_DataContext, ViewIfrsILLPCashflow, long> genericRepository,

            IRequestsFileService requestsFileService,
            IGenericRepository<IFRS9_ConfContext, RMD.Data.IFRS9_Conf.Entities.WF.Task, int> genTaskRepository,
            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,
            IRawILLPCfService rawILLPCfService,
            IIfrsCashflowValidateResultRepository ifrsCashflowValidateResultRepository,
            ICustomerResultRepository customerResultRepository,
            IPLLPCustomerRepository pllpCustomerRepository,

            IGenericRepository<IFRS9_ConfContext, ViewMpAccountBusinessUnit, int> genViewMpAccountBusinessUnitRepository,
            IViewIfrsILLPCashflowRepository viewIfrsILLPCashflowRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _requestsFileService = requestsFileService;
            _genTaskRepository = genTaskRepository;
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;
            _rawILLPCfService = rawILLPCfService;
            _ifrsCashflowValidateResultRepository = ifrsCashflowValidateResultRepository;
            _customerResultRepository = customerResultRepository;
            _pllpCustomerRepository = pllpCustomerRepository;

            _genViewMpAccountBusinessUnitRepository = genViewMpAccountBusinessUnitRepository;
            _viewIfrsILLPCashflowRepository = viewIfrsILLPCashflowRepository;
        }

        /// <summary>
        /// Get customer_info from Cust_data
        /// </summary>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{customer_Id}")]
        public virtual IActionResult FindCustomerInfo([FromRoute] string customer_Id)
        {
            try
            {
                if (!ModelState.IsValid || string.IsNullOrEmpty(customer_Id))
                    return BadRequest();

                var customer = _customerResultRepository.FindByCustomerId(customer_Id);

                return Ok(customer);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Post list all ILLP Cashflows records with filter, sort, paging.
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="paginatedParams"></param>
        /// <returns>Paginated dynamic</returns>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public async virtual Task<ActionResult<PaginatedContentResults<ViewIfrsILLPCashflow>>> FindAllCashflowsByBusinessDate([FromRoute] int fk_Task_Execution_Id, [Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                // check user query
                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);
                if (user == null)
                    throw new NullReferenceException();

                // grant business unit
                var grantBusinessUnits = _genViewMpAccountBusinessUnitRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(x => x.Username.Equals(user.Username, StringComparison.CurrentCultureIgnoreCase))
                    .SingleOrDefault();

                var grantFkBusinessUnitIds = grantBusinessUnits != null && !string.IsNullOrEmpty(grantBusinessUnits.Fk_Business_Unit_Id)
                        ? grantBusinessUnits.Fk_Business_Unit_Id.Split(";").ToArray().Select(x => int.Parse(x.Trim())).ToList() 
                        : new List<int>();

                var grantBusinessUnitNames = grantBusinessUnits != null && !string.IsNullOrEmpty(grantBusinessUnits.Business_Unit_Names)
                        ? grantBusinessUnits.Business_Unit_Names.Split(";").ToArray().Select(x => x.Trim()).ToList()
                        : new List<string>();

                // check flow
                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                var flowExecution = _genFlowExecutionRepository.Find(flowStepExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null)
                    return NotFound();

                // get data paging
                // build data roles filter
                var engineDataRoles = new List<string>();
                var entityDataRoles = new List<string>();
                // business_unit
                var businessUnitRoles = new List<int>();

                var hasEngineCol = false;
                var hasEntityCol = false;
                var hasBuCol = false;
                var hasBu1Col = false;
                var hasBu2Col = false;
                var hasBu3Col = false;

                var isNormalUser = !string.IsNullOrEmpty(user.Super_Role) && !user.Super_Role.Equals(UserPermissionConstant.SUPPER_ADMIN, StringComparison.CurrentCultureIgnoreCase);

                var isRicMagOrOffice = 
                    grantBusinessUnitNames.Where(x => x.Equals("RIC_Manager", StringComparison.CurrentCultureIgnoreCase)).Any() || 
                    grantBusinessUnitNames.Where(x => x.Equals("RIC_Officer", StringComparison.CurrentCultureIgnoreCase)).Any();

                // check data roles
                if (isNormalUser && !isRicMagOrOffice)
                {
                    // build data roles filter
                    engineDataRoles = GetEngineDataRolesFromHeader();
                    entityDataRoles = GetEntityDataRolesFromHeader();

                    // check this table generic has engine_code, entity_code
                    var entityCodeProperty = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.ENTITY_CODE);
                    var engineCodeProperty = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.ENGINE_CODE);
                    hasEngineCol = engineCodeProperty != null && !string.IsNullOrEmpty(engineCodeProperty.Name);
                    hasEntityCol = entityCodeProperty != null && !string.IsNullOrEmpty(entityCodeProperty.Name);

                    // business_unit
                    businessUnitRoles = GetBusinessUnitDataRolesFromHeader();

                    var businessUnitProperty = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.Business_Unit_Code);
                    var businessUnit1Property = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.Business_Unit_Code1);
                    var businessUnit2Property = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.Business_Unit_Code2);
                    var businessUnit3Property = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.Business_Unit_Code3);
                    hasBuCol = businessUnitProperty != null && !string.IsNullOrEmpty(businessUnitProperty.Name);
                    hasBu1Col = businessUnit1Property != null && !string.IsNullOrEmpty(businessUnit1Property.Name);
                    hasBu2Col = businessUnit2Property != null && !string.IsNullOrEmpty(businessUnit2Property.Name);
                    hasBu3Col = businessUnit3Property != null && !string.IsNullOrEmpty(businessUnit3Property.Name);
                }

                #region for all field common

                // "[Is_Deleted] = 0"
                var entityIsDeleted = typeof(ViewIfrsILLPCashflow).GetProperty(COLUMNS_NAME.IS_DELETED);
                var haIsDeletedCol = entityIsDeleted != null && !string.IsNullOrEmpty(entityIsDeleted.Name);
                if (haIsDeletedCol)
                    paginatedParams.FilterExpression = string.IsNullOrEmpty(paginatedParams.FilterExpression)
                        ? $"[{COLUMNS_NAME.IS_DELETED}] = 0"
                        : $"{ paginatedParams.FilterExpression} AND [{COLUMNS_NAME.IS_DELETED}] = 0";

                #endregion

                // Query data
                var total = _genericRepository.CountDataPaginated(paginatedParams, hasEngineCol, engineDataRoles, hasEntityCol, entityDataRoles,
                    hasBuCol, hasBu1Col, hasBu2Col, hasBu3Col, businessUnitRoles);
                var data = _genericRepository.QueryDataPaginated(paginatedParams, hasEngineCol, engineDataRoles, hasEntityCol, entityDataRoles,
                    hasBuCol, hasBu1Col, hasBu2Col, hasBu3Col, businessUnitRoles);

                // results
                dynamic result = await GenericQueryDataAsync(total, data, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Check result PLLP by customer_id, business_date (th by filename when upload)
        /// </summary>
        /// <param name="cashflowAdjustFile"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<bool> CheckPLLPCustomerByFilename([NotNull][FromBody] CashflowAdjustFileDto cashflowAdjustFile)
        {
            try
            {
                if (!ModelState.IsValid || cashflowAdjustFile == null || string.IsNullOrEmpty(cashflowAdjustFile.Filename))
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

                var fileNames = cashflowAdjustFile.Filename.Split(SpecificCharacteristics.UNDERSCORE);
                if (fileNames == null || fileNames.Count() < 2)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

                var _customerId = fileNames.First();
                var _businessDate = fileNames.Last();

                if (string.IsNullOrEmpty(_customerId) || string.IsNullOrEmpty(_businessDate))
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

                var businessDate = DateTime.ParseExact(_businessDate, DefFormats.DATE_YYYYMMDD, CultureInfo.InvariantCulture);
                if (businessDate == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

                var result = _pllpCustomerRepository.FindPLLPCustomerByCustomerId(_customerId, businessDate);
                if (result == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM032);

                return Ok(true);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Read data file import and save to adjust tables
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="fileUploads">List file upload</param>
        /// <returns></returns>
        /// <response code="201">Returns OK</response>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public async virtual Task<ActionResult<Requests>> Import([FromRoute] int fk_Task_Execution_Id, [FromBody] List<FileUploadReq> fileUploads)
        {
            if (!ModelState.IsValid || fileUploads == null || fk_Task_Execution_Id == 0 || !fileUploads.Any() || fileUploads.Count != 1)
                return BadRequest();

            var setting = FtpInfoSetting.GetFtpSetting(_configuration);
            var remote = new FtpRemoteFileSystem(setting);
            remote.Connect();
            remote.SetRootAsWorkingDirectory();

            try
            {
                // insert new data
                var fileUpload = fileUploads.First();
                if (fileUpload != null)
                {
                    var localPath = $"{Constants.WWWROOT}\\{fileUpload.Path}\\{fileUpload.Filename}";
                    var remotePath = $"{fileUpload.Path}\\{fileUpload.Filename}";
                    remote.DownloadFile(localPath, remotePath);

                    var data = ExcelHelper.ReadDataSheetFromExcelPath(localPath);

                    var results = await _requestsFileService.ImportAsync(localPath, fk_Task_Execution_Id);

                    return Ok(data);
                }

                return StatusCode(StatusCodes.Status201Created);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                bool isConnected = remote.IsConnected();
                Log.Information($"FTP connect status: {isConnected}");
                remote.Disconnect();
                remote.Dispose();
            }
        }

        private readonly string _fileExt = "xlsx";
        private readonly string _fileError = "_ERROR";
        private readonly string _sheet = "Sheet";
        private readonly string _cell = "Cell";
        private readonly string _errorMessage = "Error Message";
        private readonly string _rptReport = "ILLP_CF";
        private readonly string _approach_SBV = "SBV";
        private readonly Dictionary<string, string> _errors = new Dictionary<string, string>
        {
            { "EM001", ErrorMessagesIfrs.EM0011 },
            { "EM002", ErrorMessagesIfrs.EM0021 },
            { "EM021", ErrorMessagesIfrs.EM021 },
            { "EM022", ErrorMessagesIfrs.EM022 },
            { "EM050", ErrorMessagesIfrs.EM050 },
            { "EM051", ErrorMessagesIfrs.EM051 },
            { "EM053", ErrorMessagesIfrs.EM053 },
            { "EM054", ErrorMessagesIfrs.EM054 }
        };

        /// <summary>
        /// Data file import by binary Excel(.xlsx, .xls)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="customer_Id"></param>
        /// <param name="fileContent">file input: excel stream</param>
        /// <returns></returns>
        [HttpPost(template: "{fk_Task_Execution_Id}/customers/{customer_Id}")]
        [Consumes(MediaTypeNames.Application.Octet)]
        public async virtual Task<ActionResult<byte[]>> ImportFile([FromRoute] int fk_Task_Execution_Id, string customer_Id, [FromBody] byte[] fileContent)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(customer_Id) || fileContent == null)
                    return BadRequest();

                var msgError = string.Empty;

                // prepare data
                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);
                var user = FindByUsernameAndIsActiveAndIsDeleted(GetUserPayloadFromHeader().Username, UserStatusConstant.ACTIVE, false);

                // check status
                if (!taskExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM037);

                // validate filename
                var filename = GetHeader(ApiKeys.X_FILE_NAME);
                //filename = "4096109_TECHPAL_JOINT_STOCK_COMPANY_20201231.xlsx";
                Log.Information("Import CF filename: " + filename);
                var msgValiFilename = _rawILLPCfService.ValidateImportIllpCashflow(customer_Id, flowExecution.Business_Date, fk_Task_Execution_Id, filename);
                if (!string.IsNullOrEmpty(msgValiFilename))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msgValiFilename);
                var extFilename = string.IsNullOrEmpty(filename) ? _fileExt : filename.Split(SpecificSystems.DOT).Last();

                // get customer (rebuild filename)
                filename = BuildFilename(customer_Id, flowExecution);

                // insert to raw table
                var jsonDatas = ExcelHelper.ReadDataSheetFromStream(fileContent, customer_Id, flowExecution.Business_Date, user.Username);

                // check error
                msgError = jsonDatas.Item1;
                if (!string.IsNullOrEmpty(msgError))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msgError);

                // check #VALUE! cell
                var errorCells = jsonDatas.Item2;
                if (errorCells != null && errorCells.Any())
                {
                    var errDataTable = new DataTable();
                    errDataTable.Columns.Add(_sheet, typeof(string));
                    errDataTable.Columns.Add(_cell, typeof(string));
                    errDataTable.Columns.Add(_errorMessage, typeof(string));
                    foreach (dynamic error in errorCells)
                        errDataTable.Rows.Add(error.Sheet_Name, error.Address, error.Value);

                    // fill errors and file
                    var fileContentError = ExcelHelper.FillErrorToCellFromStream(fileContent, errDataTable);

                    HttpContext.Response.ContentType = MediaTypeExts.Application.OfficeDocument;
                    HttpContext.Response.Headers.Add(ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE, ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE_VAL);
                    var filenameError = $"{filename}{_fileError}.{extFilename}";
                    HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, filenameError);

                    var fileContentResult = new FileContentResult(fileContentError, MediaTypeExts.Application.OfficeDocument) { FileDownloadName = filenameError };
                    return fileContentResult;
                }
                
                // data raw valid
                var rawData = jsonDatas.Item3;
                _rawILLPCfService.SaveAsync(rawData, fk_Task_Execution_Id, customer_Id, user.Username);

                // call sp validate
                var cashflowErrors = _ifrsCashflowValidateResultRepository.ExecPopulateIllpCashflow(customer_Id, fk_Task_Execution_Id);
                if (cashflowErrors != null && cashflowErrors.Any())
                {
                    var errDataTable = new DataTable();
                    errDataTable.Columns.Add(_sheet, typeof(string));
                    errDataTable.Columns.Add(_cell, typeof(string));
                    errDataTable.Columns.Add(_errorMessage, typeof(string));
                    foreach (var cashflowError in cashflowErrors)
                        errDataTable.Rows.Add(cashflowError.Sheet_Name, $"{cashflowError.Col_Address}{cashflowError.Col_Row_Number}", _errors[cashflowError.Error_Code]);

                    // fill errors and file
                    var fileContentError = ExcelHelper.FillErrorToCellFromStream(fileContent, errDataTable);

                    HttpContext.Response.ContentType = MediaTypeExts.Application.OfficeDocument;
                    HttpContext.Response.Headers.Add(ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE, ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE_VAL);
                    var filenameError = $"{filename}{_fileError}.{extFilename}";
                    HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, filenameError);

                    var fileContentResult = new FileContentResult(fileContentError, MediaTypeExts.Application.OfficeDocument) { FileDownloadName = filenameError };
                    return fileContentResult;
                }

                // save file request & histories file
                var results = await _requestsFileService.ImportStreamAsync(fileContent, flowExecution, taskExecution, customer_Id, user.Username, $"{filename}.{extFilename}");
                Log.Information(JsonConvert.SerializeObject(results, Formatting.Indented));
                return CreatedAtAction(nameof(ImportFile), null);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Download lastest Excel file import(.xlsx, .xls)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{fk_Task_Execution_Id}/customers/{customer_Id}")]
        public virtual ActionResult<byte[]> DownloadFileLastest([FromRoute] int fk_Task_Execution_Id, string customer_Id)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(customer_Id))
                    return BadRequest();

                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);

                var requestsFile = _requestsFileService.FindReqFileByCashflowUploadLastest(customer_Id, flowExecution.Business_Date);
                if (requestsFile == null || requestsFile.File_Content == null || string.IsNullOrEmpty(requestsFile.File_Name))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM055);

                // Set the HTTP MIME type of the output stream
                HttpContext.Response.ContentType = MediaTypeExts.Application.OfficeDocument;
                HttpContext.Response.Headers.Add(ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE, ApiKeys.HEADER_ACCESS_CONTROL_EXPOSE_VAL);
                HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, requestsFile.File_Name);

                var fileContentResult = new FileContentResult(requestsFile.File_Content, MediaTypeExts.Application.OfficeDocument) { FileDownloadName = requestsFile.File_Name };
                return fileContentResult;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Download file Contractual Cashflow by Excel(.xlsx, .xls)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{fk_Task_Execution_Id}/customers/{customer_Id}")]
        public async virtual Task<IActionResult> DownloadContractualCashflow([FromRoute] int fk_Task_Execution_Id, string customer_Id)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(customer_Id))
                    return BadRequest();

                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                var flowExecution = _genFlowExecutionRepository.Find(taskExecution.Fk_Flow_Execution_Id);
                var task = await _genTaskRepository.FindAsync(taskExecution.Fk_Current_Task_Step_Id);

                var sbvExcelReport = new SbvExcelReport
                {
                    rptReport = _rptReport,
                    businessDate = flowExecution.Business_Date,
                    entityCode = task.Entity_Code,
                    approach = _approach_SBV,
                    scenarioId = task.Scenario_Id,
                    versionId = task.Version_Id,
                    additionalParams = $"customer_id^\"{customer_Id}\""
                };

                var api_1_report = $"{_configuration["Properties:API1"]}{RequestSegment.END_POINT_SBV_REPORT}";
                Log.Information($"Call API1_adjust Batch, Job: {api_1_report}");
                Log.Information($"Batch_Engine_Execution adjust: {JsonConvert.SerializeObject(sbvExcelReport, Formatting.Indented)}");
                var results = APIHelper.PostAsString(api_1_report, GetToken(), JsonConvert.SerializeObject(sbvExcelReport), MediaTypeNames.Application.Json, API_METHODS.POST);
                Dictionary<string, List<dynamic>> data = JsonConvert.DeserializeObject<Dictionary<string, List<dynamic>>>(results);

                // get customer (rebuild filename)
                var filename = BuildFilename(customer_Id, flowExecution);
                HttpContext.Response.Headers.Add(ApiKeys.X_FILE_NAME_EXPORT, $"{filename}.xlsx");

                return Ok(data);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Validate flow & task execution
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <returns></returns>
        [HttpGet("{fk_Task_Execution_Id}")]
        public virtual IActionResult Validate([FromRoute] int fk_Task_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // check task completed
                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (taskExecution == null || taskExecution.Task_Status.Equals(Workflow_Status_Code.COMPELTED, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // results
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        private string BuildFilename(string customer_Id, FlowExecution flowExecution)
        {
            // get customer (rebuild filename)
            var customer = _customerResultRepository.FindByCustomerId(customer_Id);
            var filename = string.IsNullOrEmpty(customer.Customer_Name)
                ? $"{customer_Id}{SpecificSystems.UNDERSCORE}{flowExecution.Business_Date.ToString(DefFormats.DATE_FORMAT).Replace(SpecificSystems.DASH, string.Empty)}"
                : $"{customer_Id}{SpecificSystems.UNDERSCORE}{customer.Customer_Name.Replace(SpecificSystems.WHITE_SPACE, SpecificSystems.UNDERSCORE)}{SpecificSystems.UNDERSCORE}{flowExecution.Business_Date.ToString(DefFormats.DATE_FORMAT).Replace(SpecificSystems.DASH, string.Empty)}";
            return filename;
        }
    }
}

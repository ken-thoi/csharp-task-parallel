﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.PhoenixConf.Functions
{
    public class AvaiableDateResult : QueryObjectResult
    {
        public DateTime Business_Date { get; set; }
    }
}

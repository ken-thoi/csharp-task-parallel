﻿namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public class CallbackObjectRes
    {
        public string controlId { get; set; }
        public string value { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.WF
{
    [Table("View_Flow_Configuration", Schema = "WF")]
    public class ViewFlowConfiguration : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public string Fk_Business_Unit_Id { get; set; }

        public string Flow_Name { get; set; }

        public string Flow_Desc { get; set; }

        public bool Is_Actived { get; set; }

        public bool Is_Deleted { get; set; }

        public string Created_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Created_Time { get; set; }

        public string Updated_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Updated_Time { get; set; }
    }
}

﻿using EmailService.Entites;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EmailService.Controller
{
    public static class IMAPController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void RunIMAP()
        {
            var listConfig = GetIMAPConfig;
            List<Task> listConfigRunning = new List<Task>();
            foreach(var item in listConfig)
            {
                listConfigRunning.Add(Task.Factory.StartNew(() =>
                {
                    RunIMAPService(item);
                }));
            }
            Task.WaitAll(listConfigRunning.ToArray());
        }

        private static void RunIMAPService(IMAP_Config item)
        {
            while (true)
            {
                string processID = Guid.NewGuid().ToString();
                logger.Info(processID + $"|Start run imap config id: { item.Id}. Username: {item.Username } on Server: {item.IMAPServer} over Port: {item.Port}");

                try
                {
                    var listRule = GetIMAPRule(item.Id);
                    var listRuleHeader = listRule.Where(x => x.RuleType.Equals("HEADER")).ToList();
                    var listRuleBody = listRule.Where(x => x.RuleType.Equals("BODY")).ToList();
                    var listRuleAttachment = listRule.Where(x => x.RuleType.Equals("ATTACHMENT")).ToList();
                    logger.Info(processID + $"|config id: { item.Id}. Username: {item.Username } Has: {listRule.Count} rule(s) in total, with {listRuleBody.Count} rule(s) get body and {listRuleAttachment.Count} get attachment(s)");
                    GetHeader(processID, item, listRuleHeader);
                    GetBody(processID, item, listRuleBody);
                    GetAttachments(processID, item, listRuleAttachment);
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                }

                Thread.Sleep(item.TimeLoop);
            }
        }

        private static void GetAttachments(string processID, IMAP_Config config, List<IMAP_Rule> listRuleAttachment)
        {
            logger.Info(processID + $"|Start run get attachment config id: { config.Id}. Username: {config.Username}");
            using (var client = new ImapClient())
            {
                client.Connect(config.IMAPServer, config.Port, (SecureSocketOptions)config.SecureSocketOptions);
                client.Authenticate(config.Username, config.Password);
                foreach (var rule in listRuleAttachment)
                {
                    if (string.IsNullOrEmpty(rule.Folder))
                    {
                        logger.Info(processID + $"|- Run get attachment with RuleId: {rule.Id} on {config.Username} is STOP because Folder is null or empty");
                    }
                    else
                    {
                        logger.Info(processID + $"|- Run get attachment with RuleId: {rule.Id} on {config.Username} is START with Folder: '{rule.Folder}'");
                        IMailFolder folder = null;
                        if ("INBOX".Equals(rule.Folder.ToUpper()))
                            folder = client.Inbox;
                        else
                            folder = FindFolder(client.GetFolder(client.PersonalNamespaces[0]), rule.Folder);
                        folder.Open(FolderAccess.ReadOnly);
                        IList<UniqueId> uids = folder.Search(SearchQuery.SentSince(LastedEmailDeliveryTime(rule.Id).AddHours(+7)));
                        uids = GetUidsToProcess(uids, rule.Id);
                        foreach (var uid in uids)
                        {
                            try
                            {
                                Email tmpEmail = new Email();
                                tmpEmail.uid = uid.Id;
                                tmpEmail.FK_IMAP_Rule_Id = rule.Id;
                                Subject_Data subject = new Subject_Data();
                                var body = new Body_Data();
                                var message = folder.GetMessage(uid);
                                List<Header_Data> lstHeader = new List<Header_Data>();
                                string MessageID = string.Empty;
                                foreach (var header in message.Headers)
                                {
                                    Header_Data tmp = new Header_Data();
                                    tmp.FK_Header_Type_Id = HeaderTypeController.GetHeaderId(header.Field);
                                    tmp.HeaderValue = header.Value;
                                    switch (header.Field.ToLower())
                                    {
                                        case "from":
                                            subject.From = header.Value;
                                            break;
                                        case "to":
                                            subject.To = header.Value;
                                            break;
                                        case "subject":
                                            subject.Subject = header.Value;
                                            break;
                                        case "date":
                                            var dateString = !header.Value.Contains('(') ? header.Value : header.Value.Substring(0, header.Value.IndexOf('('));
                                            subject.DateUTC = Convert.ToDateTime(dateString).ToUniversalTime();
                                            break;
                                        case "message-id":
                                            MessageID = header.Value;
                                            break;
                                    }
                                    lstHeader.Add(tmp);
                                }

                                if (string.IsNullOrEmpty(MessageID))
                                    throw new Exception("Message-Id is null on email from: " + subject.From + " at:" + subject.DateUTC);

                                subject.MessageID = GetFKMessageID(MessageID);
                                foreach (var item in lstHeader)
                                    item.MessageID = GetFKMessageID(MessageID);
                                tmpEmail.MessageID = GetFKMessageID(MessageID);
                                Header_DataController.DeleteHeaderData(subject.MessageID);
                                DataTable dtResult = Utils.UtilFunction.ToDataTable(lstHeader);
                                dtResult.TableName = "[dbo].[Header_Data]";
                                Utils.SqlHelper.ExcuteBulkInsert(dtResult);
                                if (string.IsNullOrEmpty(subject.To))
                                    subject.To = config.Username;
                                Subject_DataController.InsertOrUpdateSubjectData(subject);

                                List<Attachment_Data> lstAttachment = new List<Attachment_Data>();
                                var attachments = message.Attachments.ToList();
                                foreach (var attachment in attachments)
                                {
                                    using (var memory = new MemoryStream())
                                    {
                                        Attachment_Data tmp = new Attachment_Data();
                                        tmp.MessageID = GetFKMessageID(MessageID);

                                        if (attachment is MimePart)
                                            ((MimePart)attachment).Content.DecodeTo(memory);
                                        else
                                            ((MessagePart)attachment).Message.WriteTo(memory);
                                        tmp.FileData = memory.ToArray();
                                        if (attachment is MimePart)
                                            tmp.Filename = (attachment as MimePart).FileName;
                                        lstAttachment.Add(tmp);
                                    }
                                }
                                Attachment_DataController.DeleteAttachment(GetFKMessageID(MessageID));
                                Attachment_DataController.InsertOrUpdateAttachment(lstAttachment);
                                EmailController.InsertOrUpdateEmail(tmpEmail);
                            }
                            catch (Exception ex)
                            {
                                logger.Error(ex);
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(rule.AfterFeedStore))
                    {
                        logger.Info(processID + $"|- Discover after feed store RuleId: {rule.Id} on {config.Username} is : '{rule.AfterFeedStore}'");
                        Utils.SqlHelper.ExecuteNonQuery(rule.AfterFeedStore);
                        logger.Info(processID + $"|- Excuted after feed store RuleId: {rule.Id} on {config.Username} successful");
                    }
                }
                client.Disconnect(true);
            }
        }

        private static void GetBody(string processID, IMAP_Config config, List<IMAP_Rule> listRuleBody)
        {
            logger.Info(processID + $"|Start run get body config id: { config.Id}. Username: {config.Username}");
            using (var client = new ImapClient())
            {
                client.Connect(config.IMAPServer, config.Port, (SecureSocketOptions)config.SecureSocketOptions);
                client.Authenticate(config.Username, config.Password);
                foreach (var rule in listRuleBody)
                {
                    if (string.IsNullOrEmpty(rule.Folder))
                    {
                        logger.Info(processID + $"|- Run get body with RuleId: {rule.Id} on {config.Username} is STOP because Folder is null or empty");
                    }
                    else
                    {
                        logger.Info(processID + $"|- Run get body with RuleId: {rule.Id} on {config.Username} is START with Folder: '{rule.Folder}'");
                        IMailFolder folder = null;
                        if ("INBOX".Equals(rule.Folder.ToUpper()))
                            folder = client.Inbox;
                        else
                            folder = FindFolder(client.GetFolder(client.PersonalNamespaces[0]), rule.Folder);
                        folder.Open(FolderAccess.ReadOnly);
                        IList<UniqueId> uids = folder.Search(SearchQuery.SentSince(LastedEmailDeliveryTime(rule.Id).AddHours(+7)));
                        uids = GetUidsToProcess(uids, rule.Id);
                        foreach (var uid in uids)
                        {
                            try
                            {
                                Email tmpEmail = new Email();
                                tmpEmail.uid = uid.Id;
                                tmpEmail.FK_IMAP_Rule_Id = rule.Id;
                                Subject_Data subject = new Subject_Data();
                                var body = new Body_Data();
                                var message = folder.GetMessage(uid);
                                List<Header_Data> lstHeader = new List<Header_Data>();
                                string MessageID = string.Empty;
                                foreach (var header in message.Headers)
                                {
                                    Header_Data tmp = new Header_Data();
                                    tmp.FK_Header_Type_Id = HeaderTypeController.GetHeaderId(header.Field);
                                    tmp.HeaderValue = header.Value;
                                    switch (header.Field.ToLower())
                                    {
                                        case "from":
                                            subject.From = header.Value;
                                            break;
                                        case "to":
                                            subject.To = header.Value;
                                            break;
                                        case "subject":
                                            subject.Subject = header.Value;
                                            break;
                                        case "date":
                                            var dateString = !header.Value.Contains('(') ? header.Value : header.Value.Substring(0, header.Value.IndexOf('('));
                                            subject.DateUTC = Convert.ToDateTime(dateString).ToUniversalTime();
                                            break;
                                        case "message-id":
                                            MessageID = header.Value;
                                            break;
                                    }
                                    lstHeader.Add(tmp);
                                }

                                if (string.IsNullOrEmpty(MessageID))
                                    throw new Exception("Message-Id is null on email from: " + subject.From + " at:" + subject.DateUTC);
                                subject.MessageID = GetFKMessageID(MessageID);
                                foreach (var item in lstHeader)
                                    item.MessageID = GetFKMessageID(MessageID);
                                tmpEmail.MessageID = GetFKMessageID(MessageID);
                                Header_DataController.DeleteHeaderData(subject.MessageID);
                                DataTable dtResult = Utils.UtilFunction.ToDataTable(lstHeader);
                                dtResult.TableName = "[dbo].[Header_Data]";
                                Utils.SqlHelper.ExcuteBulkInsert(dtResult);

                                if (string.IsNullOrEmpty(subject.To))
                                    subject.To = config.Username;

                                Subject_DataController.InsertOrUpdateSubjectData(subject);

                                if (!string.IsNullOrEmpty(message.HtmlBody))
                                    body.Body = message.HtmlBody;
                                else
                                    body.Body = message.TextBody;
                                body.MessageID = GetFKMessageID(MessageID);
                                Body_DataController.InsertOrUpdateBodyData(body);
                                EmailController.InsertOrUpdateEmail(tmpEmail);
                            }
                            catch (Exception ex)
                            {
                                logger.Error(ex);
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(rule.AfterFeedStore))
                    {
                        logger.Info(processID + $"|- Discover after feed store RuleId: {rule.Id} on {config.Username} is : '{rule.AfterFeedStore}'");
                        Utils.SqlHelper.ExecuteNonQuery(rule.AfterFeedStore);
                        logger.Info(processID + $"|- Excuted after feed store RuleId: {rule.Id} on {config.Username} successful");
                    }
                }
                client.Disconnect(true);
            }
        }

        public static void GetHeader(string processID, IMAP_Config config, List<IMAP_Rule> listRule)
        {
            logger.Info(processID + $"|Start run GetHeader config id: { config.Id}. Username: {config.Username}");
            using (var client = new ImapClient())
            {
                client.Connect(config.IMAPServer, config.Port, (SecureSocketOptions) config.SecureSocketOptions);
                client.Authenticate(config.Username, config.Password);
                foreach (var rule in listRule)
                {
                    if (string.IsNullOrEmpty(rule.Folder))
                    {
                        logger.Info(processID + $"|- Run GetHeader with RuleId: {rule.Id} on {config.Username} is STOP because Folder is null or empty");
                    }
                    else
                    {
                        logger.Info(processID + $"|- Run GetHeader with RuleId: {rule.Id} on {config.Username} is START with Folder: '{rule.Folder}'");
                        IMailFolder folder = null;
                        if ("INBOX".Equals(rule.Folder.ToUpper()))
                            folder = client.Inbox;
                        else
                            folder = FindFolder(client.GetFolder(client.PersonalNamespaces[0]), rule.Folder);
                        folder.Open(FolderAccess.ReadOnly);
                        IList<UniqueId> uids = folder.Search(SearchQuery.SentSince(LastedEmailDeliveryTime(rule.Id).AddHours(+7)));
                        uids = GetUidsToProcess(uids, rule.Id);
                        foreach (var uid in uids)
                        {
                            try
                            {
                                Email tmpEmail = new Email();
                                tmpEmail.uid = uid.Id;
                                tmpEmail.FK_IMAP_Rule_Id = rule.Id;

                                Subject_Data subject = new Subject_Data();
                                var headers = folder.GetHeaders(uid);
                                List<Header_Data> lstHeader = new List<Header_Data>();
                                string MessageID = string.Empty;
                                foreach (var header in headers)
                                {
                                    Header_Data tmp = new Header_Data();
                                    tmp.FK_Header_Type_Id = HeaderTypeController.GetHeaderId(header.Field);
                                    tmp.HeaderValue = header.Value;
                                    switch (header.Field.ToLower())
                                    {
                                        case "from":
                                            subject.From = header.Value;
                                            break;
                                        case "to":
                                            subject.To = header.Value;
                                            break;
                                        case "subject":
                                            subject.Subject = header.Value;
                                            break;
                                        case "date":
                                            var dateString = !header.Value.Contains('(') ? header.Value: header.Value.Substring(0, header.Value.IndexOf('('));
                                            subject.DateUTC = Convert.ToDateTime(dateString).ToUniversalTime();
                                            break;
                                        case "message-id":
                                            MessageID = header.Value;
                                            break;
                                    }
                                    lstHeader.Add(tmp);
                                }

                                if (string.IsNullOrEmpty(MessageID))
                                    throw new Exception("Message-Id is null on email from: " + subject.From + " at:" + subject.DateUTC);

                                subject.MessageID = GetFKMessageID(MessageID);
                                foreach (var item in lstHeader)
                                    item.MessageID = GetFKMessageID(MessageID);
                                tmpEmail.MessageID = GetFKMessageID(MessageID);
                                if (string.IsNullOrEmpty(subject.To))
                                    subject.To = config.Username;

                                Header_DataController.DeleteHeaderData(subject.MessageID);
                                DataTable dtResult = Utils.UtilFunction.ToDataTable(lstHeader);
                                dtResult.TableName = "[dbo].[Header_Data]";
                                Utils.SqlHelper.ExcuteBulkInsert(dtResult);

                                Subject_DataController.InsertOrUpdateSubjectData(subject);
                                EmailController.InsertOrUpdateEmail(tmpEmail);
                            }
                            catch (Exception ex)
                            {
                                logger.Error(ex);
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(rule.AfterFeedStore))
                    {
                        logger.Info(processID + $"|- Discover after feed store RuleId: {rule.Id} on {config.Username} is : '{rule.AfterFeedStore}'");
                        Utils.SqlHelper.ExecuteNonQuery(rule.AfterFeedStore);
                        logger.Info(processID + $"|- Excuted after feed store RuleId: {rule.Id} on {config.Username} successful");
                    }
                }
                client.Disconnect(true);
            }
        }

        static IMailFolder FindFolder(IMailFolder toplevel, string name)
        {
            var subfolders = toplevel.GetSubfolders().ToList();

            foreach (var subfolder in subfolders)
            {
                if (subfolder.Name == name)
                    return subfolder;
            }

            foreach (var subfolder in subfolders)
            {
                var folder = FindFolder(subfolder, name);

                if (folder != null)
                    return folder;
            }

            return null;
        }

        private static List<IMAP_Config> GetIMAPConfig
        {
            get
            {
                var lst = new List<IMAP_Config>();
                DataTable dt = new DataTable();
                Utils.SqlHelper.Fill(dt, "[dbo].[IMAP_Config_SEL]");
                foreach (DataRow dr in dt.Rows)
                    lst.Add(Utils.UtilFunction.CreateItemFromRow<IMAP_Config>(dr));
                return lst;
            }
        }

        private static List<IMAP_Rule> GetIMAPRule(int FK_IMAP_Config_Id)
        {
            var lst = new List<IMAP_Rule>();
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, "[dbo].[IMAP_Rule_SEL]", new SqlParameter[] { new SqlParameter("@pv_FK_IMAP_Config_Id", FK_IMAP_Config_Id) });
            foreach (DataRow dr in dt.Rows)
                lst.Add(Utils.UtilFunction.CreateItemFromRow<IMAP_Rule>(dr));
            return lst;
        }

        private static UniqueIdSet GetKnownUids(int FK_IMAP_Rule_Id)
        {
            var knownUids = new UniqueIdSet();
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, "[dbo].[Email_Get_Knows_Uid]", new SqlParameter[] { new SqlParameter("@pv_FK_IMAP_Rule_Id", FK_IMAP_Rule_Id) });
            foreach (DataRow dr in dt.Rows)
            {
                knownUids.Add(new UniqueId(Convert.ToUInt32(dr[0])));
            }
            return knownUids;
        }

        private static UniqueIdSet GetUidsToProcess(IList<UniqueId> uids, int FK_IMAP_Rule_Id)
        {
            var knownUids = new UniqueIdSet();
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, "[dbo].[Email_Get_UidToProcess]", 
                new SqlParameter[] {
                    new SqlParameter("@pv_FK_IMAP_Rule_Id", FK_IMAP_Rule_Id),
                    new SqlParameter("@pv_ListUid", string.Join(";", uids.Select(x => x.Id)))

                });
            foreach (DataRow dr in dt.Rows)
            {
                knownUids.Add(new UniqueId(Convert.ToUInt32(dr[0])));
            }
            return knownUids;
        }

        private static DateTime LastedEmailDeliveryTime(int FK_IMAP_Rule_Id)
        {
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, "[dbo].[Get_Email_Lastest_DeliveryTime]", new SqlParameter[] { new SqlParameter("@pv_FK_IMAP_Rule_Id", FK_IMAP_Rule_Id) });
            var lastDateUTC = Convert.ToDateTime(dt.Rows[0][0]);
            return lastDateUTC;
        }

        private static int GetFKMessageID(string messageID)
        {
            var knownUids = new UniqueIdSet();
            DataTable dt = new DataTable();
            Utils.SqlHelper.Fill(dt, "[dbo].[MessageID_SEL_FK_ID]", new SqlParameter[] { new SqlParameter("@pv_MessageID", messageID) });
            return Convert.ToInt32(dt.Rows[0][0]);
        }
    }
}

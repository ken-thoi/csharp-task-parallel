﻿namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public interface IElasticLog
    {
    }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using Serilog;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;
using System.Net.Mime;
using System.ComponentModel.DataAnnotations;
using TrackableEntities.Common.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.App;
using VPBANK.RMD.Services.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Extensions;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Helpers;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Utils.Common.Helpers;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Services.Auth.Interfaces;
using System.Dynamic;

namespace VPBANK.RMD.API.Common.Controllers
{
    public abstract class ProcessController<TContext, TEntity, TKey> : TrackingController<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IRequestable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        private readonly IRequestObjectRepository _reqRepository;
        private readonly IRequestObjectService _reqService;
        private readonly IApproveStatusService _reqStatusService;
        private readonly IApproveStatusRepository _reqStatusRepository;

        public ProcessController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<TContext> unitOfWork,
            ITrackableRepository<TContext, TEntity, TKey> trackableRepository,
            IGenericRepository<TContext, TEntity, TKey> genericRepository,

            IRequestObjectRepository reqRepository,
            IRequestObjectService requestService,
            IApproveStatusService appStaService,
            IApproveStatusRepository reqStatusRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _reqRepository = reqRepository;
            _reqService = requestService;
            _reqStatusService = appStaService;
            _reqStatusRepository = reqStatusRepository;
        }

        /// <summary>
        /// Create new or update request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly created or updated request</returns>
        [HttpPost, HttpPut]
        public async virtual Task<ActionResult<RequestObject>> Req([Required][NotNull][FromBody] DataReq<TEntity> req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || !req.Entity.Any())
                    return BadRequest(ModelState);

                // Logs payload info
                Log.Information($"Request_Id received: {req.Id}");
                Log.Information($"Comment req: {req.Comment}");
                Log.Information($"Data req: {JsonConvert.SerializeObject(req.Entity, Formatting.Indented)}");

                _unitOfWork.BeginTransaction();

                // insert data
                var currentDate = DateTime.Now;
                var data = new RequestObject
                {
                    Pk_Id = req.Id,
                    Username = GetUserPayload().Username,
                    Payload = req.Entity.JsonSerialize(),
                    Payload_Clazz = typeof(TEntity).ToString(),
                    Comment = req.Comment,
                    Params = null,
                    Type = RequestEvents.DB_SAVE,
                    End_Point = GetFullUri().Replace(RequestSegment.SEGMENT_LAST_SEND_REQ, string.Empty),
                    Created_Dt = currentDate,
                    Approve_Uri_Api = _configuration.GetSection($"{nameof(AppSettings.Properties)}:{nameof(Properties.API_BASE)}").Value
                };
                var result = await _reqService.InsertOrUpdateAsync(data, RequestStatus.PENDING, RequestStep.PENDING, GetUserPayload().Username, currentDate);

                // save changed & commit
                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.Commit();

                // send noti
                var routerKey = Request.Path.Value.Replace(RequestSegment.SEGMENT_LAST_SEND_REQ, string.Empty);
                // get subscribers
                var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                dynamic other = new ExpandoObject();
                other.Data = string.Empty;
                SendNotifications(ActionTypes.REQUEST, typeof(TEntity).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.PENDING, routerKey, subscribers, other);

                // results
                return CreatedAtAction(nameof(Req), result);
            }
            catch (Exception ex)
            {
                _unitOfWork.Rollback();
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);

                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Approve existed request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqId"></param>
        /// <param name="approveStatusReq"></param>
        /// <returns>A newly approved request</returns>
        [HttpPost(template: "{reqId}")]
        public async virtual Task<ActionResult<RequestObject>> Apr([Required][NotNull][FromRoute] int reqId, [Required][NotNull][FromBody] ApproveStatusReq approveStatusReq)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || reqId == 0 || approveStatusReq == null)
                    return BadRequest(ModelState);

                var req = await _reqRepository.FindAsync(reqId);
                var entities = req.Payload.JsonDeSerialize<List<TEntity>>();
                if (entities == null || entities.Count == 0)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.EM204);

                // Logs payload info
                Log.Information(JsonConvert.SerializeObject(entities, Formatting.Indented));

                switch (req.Type.ToLower())
                {
                    case "manual_file":
                        var endPoint = $"{req.End_Point}/apr/{reqId}";
                        APIHelper.Post(endPoint, GetToken(), JsonConvert.SerializeObject(approveStatusReq), MediaTypeNames.Application.Json, API_METHODS.POST);
                        return CreatedAtAction(nameof(Apr), req);
                    case "db_save":
                        try
                        {
                            _unitOfWork.BeginTransaction();

                            var adds = new List<object>();
                            var updates = new List<object>();
                            var deletes = new List<object>();
                            foreach (TEntity item in entities)
                            {
                                if (item.ReqActionType.Equals(ActionTypes.INSERT.ToDescription(), StringComparison.CurrentCultureIgnoreCase))
                                    adds.Add(item);
                                if (item.ReqActionType.Equals(ActionTypes.UPDATE.ToDescription(), StringComparison.CurrentCultureIgnoreCase) && item.ReqObjectType.Equals(ReqObjectTypes.NEW, StringComparison.CurrentCultureIgnoreCase))
                                    updates.Add(item);
                                if (item.ReqActionType.Equals(ActionTypes.DELETE.ToDescription(), StringComparison.CurrentCultureIgnoreCase))
                                    deletes.Add(item);
                            }

                            // save data to sql server
                            if (adds.Any()) _genericRepository.BulkInsert(adds);
                            if (updates.Any()) _genericRepository.BulkUpdate(updates);
                            if (deletes.Any()) _genericRepository.BulkDelete(deletes);

                            // req object & req status
                            req.Comment = approveStatusReq.Comment;
                            await _reqService.InsertOrUpdateAsync(req, RequestStatus.APPROVED, RequestStep.APPROVED, GetUserPayload().Username, DateTime.Now);

                            // save changed & commit
                            await _unitOfWork.SaveChangesAsync();
                            _unitOfWork.Commit();

                            // send noti
                            var routerKey = req.End_Point.Replace(GetBaseUri(), string.Empty);
                            // get subscribers
                            var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                            SendNotifications(ActionTypes.APPROVAL, typeof(TEntity).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.APPROVED, routerKey, subscribers, new ExpandoObject());

                            // results
                            return CreatedAtAction(nameof(Apr), req);
                        }
                        catch (Exception ex)
                        {
                            _unitOfWork.Rollback();
                            Log.Error(ex.Message);
                            Log.Error(ex.StackTrace);

                            if (ex is HttpErrorException)
                                throw;
                            else
                                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
                        }
                    case "db_save_extention":
                    case "endpoint":
                    case "assumption_file":
                    case "cf_assumption_details":
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                if (!string.IsNullOrEmpty(ex.InnerException?.Message))
                {
                    Log.Error($"InnerException: {ex.InnerException?.Message}");
                    _memoryCache.Set(string.Format(CacheKeys.SqlExceptionCache, GetUserPayload().Username), ex.InnerException?.Message);
                }
                throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

﻿using System;

namespace VPBANK.RMD.EFCore.Entities.Commons
{
    public class IfrsRequestsProcess
    {
        public int? Pk_Id { get; set; }
        public int Fk_Request_Id { get; set; }
        public string Processor { get; set; }
        public string Request_Status { get; set; }
        public string Comments { get; set; }
        public DateTime Process_Date { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Views.WF
{
    [Table("View_Task_Monitoring", Schema = "WF")]
    public class ViewTaskMonitoring : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }

        public decimal? Fk_Engine_Batch_Log_Id { get; set; }

        public int Fk_Flow_Execution_Id { get; set; }

        public string Fk_Business_Unit_Id { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Business_Date { get; set; }

        public string Flow_Name { get; set; }

        public string Task_Name { get; set; }

        public string Task_Screen_Code { get; set; }

        public string Entity_Code { get; set; }

        public string Task_Status { get; set; }

        public int Task_Level { get; set; }

        public string Updated_By { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? Start_Date { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? End_Date { get; set; }

        public string Executor_By { get; set; }
    }
}

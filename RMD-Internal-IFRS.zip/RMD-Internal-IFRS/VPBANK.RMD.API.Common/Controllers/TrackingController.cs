﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using Serilog;
using Newtonsoft.Json;
using Microsoft.Extensions.Hosting;
using TrackableEntities.Common.Core;
using VPBANK.RMD.EFCore.Entities;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.API.Common.Controllers
{
    public abstract class TrackingController<TContext, TEntity, TKey> : QueryController<TContext, TEntity, TKey>
        where TContext : DbContext
        where TEntity : class, ITrackable, IEntityBase<TKey>
        where TKey : IEquatable<TKey>
    {
        public TrackingController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<TContext> unitOfWork,
            ITrackableRepository<TContext, TEntity, TKey> trackableRepository,
            IGenericRepository<TContext, TEntity, TKey> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// Create new record.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="entity"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public virtual async Task<ActionResult<TEntity>> Create([Required][NotNull][FromBody] TEntity entity)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                // null for classes
                // null(empty) for Nullable<TKey>
                // zero / false / etc for other structs
                if (!EqualityComparer<TKey>.Default.Equals(entity.Pk_Id, default))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessages.EM002);

                // log Body_Data
                Log.Information($"Body_data: {JsonConvert.SerializeObject(entity, _env.IsDevelopment() ? Formatting.Indented : Formatting.None)}");

                // insert data
                entity.TrackingState = TrackingState.Added;
                _genericRepository.Insert(entity);
                if (await _unitOfWork.SaveChangesAsync() == 0)
                    return BadRequest(ModelState);

                // results
                return CreatedAtAction(nameof(Create), new { pk_Id = entity.Pk_Id }, entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Create new records bulk insert.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="entities"></param>
        /// <returns>A newly created object</returns>
        /// <response code="201">Returns the newly created entity</response>
        /// <response code="400">If the entity is null</response>
        [HttpPost]
        public virtual async Task<ActionResult<IEnumerable<TEntity>>> BatchCreate([Required][NotNull][FromBody] List<TEntity> entities)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || entities == null || !entities.Any())
                    return BadRequest(ModelState);

                // log Body_Data
                Log.Information($"Body_data: {JsonConvert.SerializeObject(entities, _env.IsDevelopment() ? Formatting.Indented : Formatting.None)}");

                // insert data
                foreach (var entity in entities)
                    entity.TrackingState = TrackingState.Added;
                var data = new List<object>();
                data.AddRange(entities);
                await _genericRepository.BulkInsertAsync(data);

                // results
                return CreatedAtAction(nameof(BatchCreate), entities);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Update exists record.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="pk_Id"></param>
        /// <param name="entity"></param>
        /// <returns>A newly updated object</returns>
        /// <response code="200">Returns OK</response>
        /// <response code="400">If the item is null</response>
        /// <response code="404">The item is not found</response>
        [HttpPut(template: "{pk_Id}")]
        public virtual async Task<ActionResult<TEntity>> Update([Required][NotNull][FromRoute] TKey pk_Id, [Required][NotNull][FromBody] TEntity entity)
        {
            try
            {
                if (!ModelState.IsValid || entity == null)
                    return BadRequest(ModelState);

                if (EqualityComparer<TKey>.Default.Equals(entity.Pk_Id, default))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessages.EM002);

                if (!await _genericRepository.ExistsAsync(pk_Id))
                    return NotFound();

                // log Body_Data
                Log.Information($"Body_data: {JsonConvert.SerializeObject(entity, _env.IsDevelopment() ? Formatting.Indented : Formatting.None)}");

                entity.TrackingState = TrackingState.Modified;
                _genericRepository.Update(entity);
                if (await _unitOfWork.SaveChangesAsync() == 0)
                    return BadRequest();

                return Ok(entity);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Update exists records bulk update.
        /// </summary>
        /// <remarks></remarks>
        /// <param name="entities"></param>
        /// <returns>A newly updated object</returns>
        /// <response code="200">Returns OK</response>
        /// <response code="400">If the item is null</response>
        /// <response code="404">The item is not found</response>
        [HttpPut]
        public virtual async Task<ActionResult<IEnumerable<TEntity>>> BatchUpdate([Required][NotNull][FromBody] List<TEntity> entities)
        {
            try
            {
                if (!ModelState.IsValid || entities == null || !entities.Any())
                    return BadRequest(ModelState);

                // log Body_Data
                Log.Information($"Body_data: {JsonConvert.SerializeObject(entities, _env.IsDevelopment() ? Formatting.Indented : Formatting.None)}");

                foreach (var entity in entities)
                    entity.TrackingState = TrackingState.Added;
                var data = new List<object>();
                data.AddRange(entities);
                await _genericRepository.BulkUpdateAsync(data);

                return Ok(entities);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Delete record.
        /// </summary>
        /// <param name="pk_Id"></param>
        /// <returns></returns>
        [HttpDelete(template: "{pk_Id}")]
        public virtual async Task<IActionResult> Delete([Required][NotNull][FromRoute] TKey pk_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (!await _genericRepository.ExistsAsync(pk_Id))
                    return NotFound();

                if (!await _genericRepository.DeleteAsync(pk_Id))
                    return BadRequest();

                // log Body_Data
                Log.Information($"Body_data pk_Id: {JsonConvert.SerializeObject(pk_Id, _env.IsDevelopment() ? Formatting.Indented : Formatting.None)}");

                var result = await _unitOfWork.SaveChangesAsync();
                if (result == 0)
                    return BadRequest();

                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Delete records bulk delete.
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [HttpDelete]
        public virtual async Task<IActionResult> BatchDelete([Required][NotNull][FromBody] List<TKey> ids)
        {
            try
            {
                if (!ModelState.IsValid || ids == null || !ids.Any())
                    return BadRequest(ModelState);

                var entities = new List<object>();
                foreach (var pk_Id in ids)
                {
                    var entity = await _genericRepository.FindAsync(pk_Id);
                    if (entity != null)
                    {
                        entity.TrackingState = TrackingState.Deleted;
                        entities.Add(entity);
                    }
                }

                await _genericRepository.BulkDeleteAsync(entities);
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

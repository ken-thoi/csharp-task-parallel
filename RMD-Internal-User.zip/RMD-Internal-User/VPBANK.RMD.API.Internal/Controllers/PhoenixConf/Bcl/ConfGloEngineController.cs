﻿using VPBANK.RMD.API.Common.Middlewares;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Net;
using AutoMapper;
using System.Net.Http;
using System.Linq;
using VPBANK.RMD.Data.PhoenixConf.Entities.POCOs.Tech;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.Bcl
{
    public class ConfGloEngineController : QueryController<PhoenixConfContext, ConfGloEngine, decimal>
    {
        public ConfGloEngineController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, ConfGloEngine, decimal> trackableRepository,
            IGenericRepository<PhoenixConfContext, ConfGloEngine, decimal> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// Get all data by param val.
        /// </summary>
        /// <remarks>
        /// Get all data by param val.
        /// </remarks>
        /// <param name="paramVal"></param>
        /// <returns></returns>
        [HttpGet("{paramVal}")]
        public virtual ActionResult<bool> FindByParamVal([FromRoute] string paramVal)
        {
            try
            {
                if (string.IsNullOrEmpty(paramVal))
                    return Ok(false);

                var entity = _genericRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => paramVal.Equals(c.Param_Val, StringComparison.CurrentCultureIgnoreCase))
                    .SingleOrDefault();

                return Ok(entity != null && entity.Pk_Id > 0);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}

﻿using EmailService.Entites;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService.Controller
{
    public static class Attachment_DataController
    {
        public static void InsertOrUpdateAttachment(List<Attachment_Data> lstAttachment)
        {
            DataTable data = Utils.UtilFunction.ToDataTable(lstAttachment);
            data.TableName = "[dbo].Attachment_Data";
            Utils.SqlHelper.ExcuteBulkInsert(data);
        }

        public static void DeleteAttachment(int uid)
        {
            string command = "[dbo].[Attachment_Data_DEL]";
            List<SqlParameter> lstParma = new List<SqlParameter>();
            lstParma.Add(new SqlParameter("@pv_MessageID", uid));
            Utils.SqlHelper.ExecuteNonQuery(command, lstParma.ToArray());
        }
    }
}

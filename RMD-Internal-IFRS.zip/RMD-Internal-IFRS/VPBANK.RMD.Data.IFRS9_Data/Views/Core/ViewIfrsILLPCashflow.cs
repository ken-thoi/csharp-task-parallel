﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Data.Views.Core
{
    [Table("view_ILLP_CF", Schema = "Core")]
    public class ViewIfrsILLPCashflow : EntityBase<long>
    {
        [Key]
        public override long Pk_Id { get; set; }
        public int? Fk_Business_Unit_Id { get; set; }

        public DateTime? Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Qtrr_Segment { get; set; }
        public string Stage { get; set; }
        public string Downgrade_Flag { get; set; }
        public decimal? Eir { get; set; }
        public decimal? Pd { get; set; }
        public decimal? Lgd { get; set; }
        public string Rst_Flag { get; set; }
        public int? No_Ovd_Days { get; set; }

        public decimal? Total_Outstanding_Exposure { get; set; }
        public decimal? Total_Outstanding_Loan { get; set; }
        public decimal? Total_off_balance_Ccf { get; set; }
        public decimal? Total_Unused_Limit { get; set; }
        public decimal? Unused_Limit_Ccf { get; set; }
        public decimal? Off_Balance_Amt { get; set; }
        public decimal? Off_Balance_Amt_Ccf { get; set; }
        public decimal? Dcf_Of_Loan { get; set; }
        public decimal? Repay_Of_Ofbal { get; set; }
        public decimal? Repay_Of_Unlimit { get; set; }
        public decimal? Provision_Fund { get; set; }
        public decimal? Provision_Rate { get; set; }
        public decimal? Last_Provision_Fund { get; set; }
        public decimal? Last_Provision_Rate { get; set; }
        public decimal? Cost { get; set; }

        public string Cf_Flag { get; set; }
        public string Cf_Inputer { get; set; }
        public DateTime? Upload_Time { get; set; }
    }
}

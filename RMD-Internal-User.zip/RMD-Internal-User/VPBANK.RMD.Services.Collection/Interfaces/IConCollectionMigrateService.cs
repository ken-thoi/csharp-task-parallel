﻿namespace VPBANK.RMD.Services.Collection.Interfaces
{
    public interface IConCollectionMigrateService
    {
    }
}
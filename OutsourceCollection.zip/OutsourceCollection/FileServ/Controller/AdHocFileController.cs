﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class AdHocFileController
    {
        private static object _lockRunning = new object();
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void AdHocFileProcess()
        {
            logger.Info("------ START: Loading Document Type ------");
            GenerateUPloadFolder();
            Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    DoCheckCustomFile();
                    System.Threading.Thread.Sleep(10000);
                }
            });
        }

        private static void GenerateUPloadFolder()
        {
            var listChildFolder = CurrentChildUploadFolder.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();
            if(listChildFolder.Where( x => x.IndexOfAny(Path.GetInvalidFileNameChars()) > 0).Count() > 0)
            {
                string ex = "Please check table [Collection].[FileServ].[SysVar] where [GName] = 'BASE_FOLDER' AND [VarName] = 'UPLOAD_CHILD_DOCUMENT', there is invalid filename in value";
                logger.Error(ex);
                throw new Exception(ex);
            }

            foreach(var item in listChildFolder)
            {
                var destPath = Path.Combine(CurrentAddHocFolder, item);
                if (!Directory.Exists(destPath))
                    Directory.CreateDirectory(destPath);
            }
        }

        private static void DoCheckCustomFile()
        {
            string filePkgLocal = FilePackageController.GetPackageFolder;
            var listChildFolder = CurrentChildUploadFolder.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();
            foreach (var userFolder in listChildFolder)
            {
                var sourcePath = Path.Combine(CurrentAddHocFolder, userFolder);
                if (Directory.Exists(sourcePath))
                {
                    var listFile = Directory.GetFiles(sourcePath, "*.zip").ToList();
                    foreach (var item in listFile)
                    {
                        try
                        {
                            string fileName = item.Split('\\').LastOrDefault().Split('.').FirstOrDefault().ToUpper();
                            if (!fileName.Contains("_ERROR_"))
                            {
                                FilePackage fpkg = new FilePackage();
                                //validate File
                                fpkg.FK_Customer = CheckCustomerName(fileName);

                                if (fpkg.FK_Customer == -1)
                                {
                                    File.Move(item, item.Replace("\\" + fileName, "\\" + fileName + "_ERROR_001"));
                                    throw new Exception("Documnet name is not exist in DB");
                                }

                                fpkg.Destination = fileName + ".zip";
                                fpkg.MD5Checksum = Utils.UtilFunction.CalculateMD5FromFile(item);
                                fpkg.Size = (new FileInfo(item)).Length;

                                //Process file
                                int countFailCopy = 10;
                                while (countFailCopy > 0)
                                {
                                    string destPathFile = Path.Combine(filePkgLocal, fileName + ".zip");
                                    if (File.Exists(destPathFile))
                                        File.Delete(destPathFile);
                                    File.Copy(item, destPathFile);

                                    var newCheckSum = Utils.UtilFunction.CalculateMD5FromFile(destPathFile);
                                    if (!fpkg.MD5Checksum.Equals(newCheckSum))
                                    {
                                        fpkg.Status = FilePackageStatus.VerifiedFailed;
                                        countFailCopy--;
                                        if (countFailCopy <= 0)
                                        {
                                            File.Move(item, item.Replace("\\" + fileName, "\\" + fileName + "_ERROR_002"));
                                            throw new Exception("Can not verifie file from source to destination");
                                        }
                                    }
                                    else
                                        break;
                                }

                                fpkg.Status = FilePackageStatus.FileUploadCustom;
                                FilePackageController.UpdateFilePackage(fpkg);

                                CustomerDocument custDoc = new CustomerDocument();
                                custDoc.Id = fpkg.FK_Customer;
                                custDoc.Priority = 0;
                                custDoc.Status = CustomerDocumentStatus.Downloaded;
                                custDoc.UpdatedBy = userFolder;
                                custDoc.UpdatedDatetime = File.GetLastWriteTime(item);
                                CustDocController.UpdateCustDocStatus(custDoc);

                                //Backup
                                var historyName = fileName + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".zip";
                                var historyPath = Path.Combine(CurrentHistoryFolder, userFolder, historyName);
                                Directory.CreateDirectory(Path.Combine(CurrentHistoryFolder, userFolder ));
                                countFailCopy = 10;
                                while (countFailCopy > 0)
                                {
                                    if (File.Exists(historyPath))
                                        File.Delete(historyPath);
                                    File.Copy(item, historyPath);

                                    var newCheckSum = Utils.UtilFunction.CalculateMD5FromFile(historyPath);
                                    if (!fpkg.MD5Checksum.Equals(newCheckSum))
                                    {
                                        fpkg.Status = FilePackageStatus.VerifiedFailed;
                                        countFailCopy--;
                                        if (countFailCopy <= 0)
                                        {
                                            File.Move(item, item.Replace("\\" + fileName, "\\" + fileName + "_ERROR_003"));
                                            throw new Exception("Can not backup File from destination");
                                        }
                                    }
                                    else
                                    {
                                        if (File.Exists(item))
                                            File.Delete(item);
                                        break;
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.Error(ex);
                        }
                    }
                }
            }
        }

        private static int CheckCustomerName(string fileName)
        {
            string command = "[FileServ].[CustomerDocument_CheckCustomerName]";
            var result = Utils.SqlHelper.ExecuteScalar(command, new SqlParameter[] { new SqlParameter("@pv_FilePackageName", fileName) });
            return Convert.ToInt32(Convert.ToString(result));
        }

        public static string CurrentAddHocFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "ADDHOC_FOLDER");
            }
        }

        public static string CurrentChildUploadFolder
        {
            get
            {
                return SysVarController.GetSystemValue("BASE_FOLDER", "UPLOAD_CHILD_DOCUMENT");
            }
        }

        public static string CurrentHistoryFolder
        {
            get
            {
                return Path.Combine(SysVarController.GetSystemValue("BASE_FOLDER", "HISTORY"), "1.ManualUpload");
            }
        }

    }
}

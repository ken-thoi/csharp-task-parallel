﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using Serilog;
using System.Net;
using AutoMapper;
using Newtonsoft.Json;
using Microsoft.Data.SqlClient;
using System.Data;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Services.PhoenixConf.Email;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.API.Controllers
{
    [Authorize]
    public class EmailNotiController : BaseController
    {
        private readonly IUnitOfWork<PhoenixConfContext> _unitOfWork;

        public EmailNotiController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<PhoenixConfContext> unitOfWork) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Collection send email.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="reqEmail"></param>
        [HttpPost]
        public virtual async Task<IActionResult> CollectionSend([Required][NotNull][FromBody] CollectionSendEmailReq reqEmail)
        {
            try
            {
                // Check object valid
                if (!ModelState.IsValid)
                    throw new HttpErrorException(HttpStatusCode.NoContent, nameof(HttpStatusCode.NoContent), ErrorMessages.SE011);

                var businessDate = new SqlParameter("@Business_Date", SqlDbType.Date) { Value = reqEmail.businessDate };
                var inSegment = new SqlParameter("@in_Segment", SqlDbType.VarChar) { Value = reqEmail.segment };
                var inOsCompany = new SqlParameter("@in_Os_Company", SqlDbType.VarChar) { Value = string.IsNullOrEmpty(reqEmail.osCompany) ? DataSystems.Select_Item_All : reqEmail.osCompany };

                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();
                await Task.Factory.StartNew(() => _unitOfWork.ExecuteSqlRaw(PhoenixConf_SqlQuery_Define.EXEC_Collection_Send_Email, businessDate, inSegment, inOsCompany));
                stopwatch.Stop();
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
                Log.Information("Send email collection done");
            }
        }
    }
}
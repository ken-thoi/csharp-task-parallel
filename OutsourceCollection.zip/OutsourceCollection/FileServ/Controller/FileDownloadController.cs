﻿using Entities;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace FileServ.Controller
{
    public static class FileDownloadController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        public static void UpdateFileDownload(FileDownload file)
        {
            string procedureName = "[FileServ].[FileDownload_INS]";
            List<SqlParameter> listParam = new List<SqlParameter>();
            listParam.Add(new SqlParameter("@FK_CustomerDocument", file.FK_CustomerDocument));
            listParam.Add(new SqlParameter("@FK_DocumentType", file.FK_DocumentType));
            listParam.Add(new SqlParameter("@OriginalFileName", Utils.UtilFunction.CheckDBValueNull(file.OriginalFileName)));
            listParam.Add(new SqlParameter("@Destination", Utils.UtilFunction.CheckDBValueNull(file.Destination)));
            listParam.Add(new SqlParameter("@ProcessTime", file.ProcessTime));
            listParam.Add(new SqlParameter("@exID", Utils.UtilFunction.CheckDBValueNull(file.exID)));
            listParam.Add(new SqlParameter("@MD5Checksum", Utils.UtilFunction.CheckDBValueNull(file.MD5Checksum)));
            listParam.Add(new SqlParameter("@Status", Utils.UtilFunction.CheckDBValueNull(file.Status)));
            Utils.SqlHelper.ExecuteNonQuery(procedureName, listParam.ToArray());
        }

        public static void VerifiedAfterDownload(string processID, FileDownload file, string path, string fileEXT)
        {
            switch (fileEXT)
            {
                case "pdf":
                    {
                        Utils.UtilFunction.isValidatePDF(path);
                        break;
                    }
                case "doc":
                case "docm":
                case "dotx":
                case "dot":
                case "dotm":
                case "docx":
                case "rtf":
                case "htm":
                case "html":
                case "mht":
                case "xml":
                case "flatopc":
                case "epub":
                    {
                        Utils.UtilFunction.isValidateWord(path);
                        break;
                    }
                case "xlsx":
                case "xlsm":
                case "xlsb":
                case "xls":
                case "xltx":
                case "xltm":
                case "xlt":
                case "csv":
                    {
                        Utils.UtilFunction.isValidateExcel(path);
                        break;
                    }
                case "pptx":
                case "pptm":
                case "potx":
                case "potm":
                case "ppam":
                case "ppsx":
                case "ppsm":
                case "sldx":
                case "sldm":
                case "thmx":
                    {
                        Utils.UtilFunction.isValidatePowerPoint(path);
                        break;
                    }
                case "zip":
                    {
                        Utils.UtilFunction.isValidateZip(path);
                        break;
                    }
                case "bmp":
                case "gif":
                case "jpeg":
                case "png":
                case "tiff":
                case "jpg":
                    {
                        Utils.UtilFunction.isValidGDIPlusImage(path);
                        break;
                    }
                default:
                    {
                        logger.Info(processID + "|File: " + file.OriginalFileName + " can not verified, consider file in good quality");
                        break;
                    }
            }
        }

        public static List<FileDownload> GetListFileDownloadedByCustId(int customerID)
        {
            string procedureName = "[FileServ].[FileDownload_GetFileDownloadedByCust]";
            List<SqlParameter> listParam = new List<SqlParameter>();
            DataTable dt = new DataTable();
            listParam.Add(new SqlParameter("@FK_CustomerDocument", customerID));
            Utils.SqlHelper.Fill(dt, procedureName, listParam.ToArray());
            List<FileDownload> lstFileDownload = new List<FileDownload>();
            foreach (DataRow dr in dt.Rows)
                lstFileDownload.Add(Utils.UtilFunction.CreateItemFromRow<FileDownload>(dr));
            return lstFileDownload;
        }
    }
}

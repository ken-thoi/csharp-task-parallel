﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.Data.Auth;
using VPBANK.RMD.Data.Auth.Entities.POCOs;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.Auth.Interfaces;
using VPBANK.RMD.Services.Auth.Interfaces;

namespace VPBANK.RMD.Services.Auth.Implements
{
    public class UserService : IUserService
    {
        private readonly IUnitOfWork<AuthContext> _unitOfWork;
        private readonly IUserRepository _userRepository;

        private readonly IGenericRepository<AuthContext, DataRole, int> _dataRoleRepository;

        private readonly IGenericRepository<AuthContext, DataUserRole, int> _dataUserRoleRepository;
        private readonly IGenericRepository<AuthContext, FunctionUserRole, int> _funcUserRoleRepository;
        private readonly IGenericRepository<AuthContext, ComponentUserRole, int> _compUserRoleRepository;

        public UserService(IUnitOfWork<AuthContext> unitOfWork, IUserRepository userRepository,
            IGenericRepository<AuthContext, DataRole, int> dataRoleRepository,

            IGenericRepository<AuthContext, DataUserRole, int> dataUserRoleRepository,
            IGenericRepository<AuthContext, FunctionUserRole, int> funcUserRoleRepository,
            IGenericRepository<AuthContext, ComponentUserRole, int> compUserRoleRepository)
        {
            _unitOfWork = unitOfWork;
            _userRepository = userRepository;
            _dataRoleRepository = dataRoleRepository;

            _dataUserRoleRepository = dataUserRoleRepository;
            _funcUserRoleRepository = funcUserRoleRepository;
            _compUserRoleRepository = compUserRoleRepository;
        }

        public User FindByUsername(string username)
        {
            try
            {
                return _userRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => c.Username.Equals(username, StringComparison.CurrentCultureIgnoreCase))
                    .FirstOrDefault();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<string> FindBySupperAdmin()
        {
            try
            {
                return _userRepository
                    .Queryable()
                    .AsEnumerable()
                    .Where(c => !string.IsNullOrEmpty(c.Super_Role) && c.Super_Role.Equals("SuperAdmin", StringComparison.CurrentCultureIgnoreCase))
                    .Select(c => c.Username)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<string> FindEmailsByUsernames(List<string> usernames)
        {
            try
            {
                var results = new List<string>();
                foreach (var username in usernames)
                {
                    var entity = _userRepository
                        .Queryable()
                        .AsEnumerable()
                        .Where(c => c.Username.Equals(username, System.StringComparison.CurrentCultureIgnoreCase))
                        .FirstOrDefault();
                    if (entity != null && !string.IsNullOrEmpty(entity.Email))
                        results.Add(entity.Email);
                }
                return results;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void DeleteUserById(int pk_Id)
        {
            _unitOfWork.BeginTransaction();
            var user = _userRepository.FindByIdAndIsDeleted(pk_Id, 0.ToString());

            if (user == null)
                throw new System.NotImplementedException();
            var dataUserRoles = _dataUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(user.Username, StringComparison.CurrentCultureIgnoreCase))
                .ToList();
            var data1 = new List<object>();
            data1.AddRange(dataUserRoles);
            _dataUserRoleRepository.BulkDelete(data1);

            var funcUserRoles = _funcUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(user.Username, StringComparison.CurrentCultureIgnoreCase))
                .ToList();
            var data2 = new List<object>();
            data2.AddRange(funcUserRoles);
            _funcUserRoleRepository.BulkDelete(data2);

            var compUserRoles = _compUserRoleRepository
                .Queryable()
                .AsEnumerable()
                .Where(c => c.Username.Equals(user.Username, StringComparison.CurrentCultureIgnoreCase))
                .ToList();
            var data3 = new List<object>();
            data3.AddRange(compUserRoles);
            _compUserRoleRepository.BulkDelete(data3);

            user.Is_Deleted = "1";
            _userRepository.Update(user);

            _unitOfWork.SaveChanges();
            _unitOfWork.Commit();
        }

        public async Task<List<SelectedItem>> FindUsernames()
        {
            try
            {
                var entities = await _userRepository.FindAllAsync();

                var results = entities.AsEnumerable()
                    .Select(c => new SelectedItem
                    {
                        Key = c.Username,
                        Val = c.Username
                    })
                    .ToList();

                return results;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<SelectedItem> FindByUserNonRole()
        {
            try
            {
                return _userRepository
                    .FindAllNonRole()
                    .Select(c => new SelectedItem
                    {
                        Key = c.Username,
                        Val = c.Username
                    })
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

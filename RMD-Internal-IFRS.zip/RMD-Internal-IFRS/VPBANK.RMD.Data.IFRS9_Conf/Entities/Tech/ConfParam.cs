﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Tech
{
    [Table("Conf_Param", Schema = "Tech")]
    public class ConfParam : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public string Approach { get; set; }
        public string Entity_Code { get; set; }
        public string Scenario_Id { get; set; }
        public string Version_Id { get; set; }
        public string Param_Name { get; set; }
        public string Param_Value { get; set; }
        public string Description { get; set; }
        public string Impact { get; set; }
    }
}

﻿using System;
using System.Threading.Tasks;

namespace FileServ.Controller
{
    public static class CollectionController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        public static void StartCollectionSystem()
        {
            try
            {
                logger.Info("====== START Collection Componenet ======");
                SysVarController.LoadSysVar();
                SourceController.LoadSource();
                DocumentTypeController.LoadDocumentType();
                CustDocController.CleanCurrentTempFolder();

                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "RunIDLECustDocCollection")))
                {                    
                    Task.Factory.StartNew(() => { CustDocController.RunIDLECustDocCollection(); });
                }

                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "ProcessRequest")))
                    Task.Factory.StartNew(() => { FileRequestController.ProcessRequest(); });

                //if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "ProcessRequestDetail")))
                //    Task.Factory.StartNew(() => { FileRequestController.ProcessRequestDetail(); });

                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "ProcessResponeRequest")))
                    Task.Factory.StartNew(() => { FileRequestController.ProcessResponeRequest(); });

                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "FilePackageProcess")))
                {
                    FilePackageController.CheckCurrentRunning();
                    Task.Factory.StartNew(() => { FilePackageController.FilePackageProcess(); });
                }

                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "AdHocFileProcess")))
                {
                    Task.Factory.StartNew(() => { AdHocFileController.AdHocFileProcess(); });
                }

                if (Convert.ToBoolean(SysVarController.GetSystemValue("RUN", "MGLFileProcess")))
                {
                    Task.Factory.StartNew(() => { MGLController.MGLFileProcess(); });
                }
                
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                throw;
            }

            //Task.WaitAll(task3, task2, task1);
        }
    }
}

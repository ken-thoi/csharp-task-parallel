﻿using System;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core
{
    public class IfrsStagingResult : QueryObjectResult
    {
        public DateTime? Business_Date { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Contract_Id { get; set; }
        public string Statement_Type { get; set; }
        public decimal? Amount_Lcy { get; set; }
        public string Gl_Accrual { get; set; }
        public decimal? Accural_Lcy { get; set; }
        public decimal? Total_Unused_Limit { get; set; }
        public int? No_Ovd_Day { get; set; }
        public string Qtrr_Segment { get; set; }
        public string Product_Group { get; set; }
        public string Default_Status { get; set; }
        public decimal? Eir { get; set; }
        public string Model_Segment { get; set; }
        public string Rating_Ini { get; set; }
        public string Rating { get; set; }
        public string Rst_Flag { get; set; }
        public string Good_Rst_Flag { get; set; }
        public int? Notch_Level_Ini { get; set; }
        public int? Notch_Level { get; set; }
        public string Downgrade_Notch_Ini { get; set; }
        public string Downgrade_Notch { get; set; }
        public int? Notch { get; set; }
        public string Downgrade_Flag { get; set; }
        public string Stage { get; set; }
        public string Stage_Adjust { get; set; }
        public string Ar_Nbr { get; set; }
    }
}

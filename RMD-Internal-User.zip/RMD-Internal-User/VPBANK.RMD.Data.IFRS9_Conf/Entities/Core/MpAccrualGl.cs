﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.Core
{
    [Table("MP_Accrual_GL", Schema = "Core")]
    public class MpAccrualGl : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public decimal Gl_Accruals { get; set; }
        public decimal Gl_Principal { get; set; }
        public int? Local_Loan_Group { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime End_Date { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using VPBANK.RMD.EFCore.Entities;

namespace VPBANK.RMD.Data.IFRS9_Conf.Entities.BCL
{
    [Table("Conf_MP_Cashflow_Right", Schema = "BCL")]
    public class ConfMpCashflowRight : EntityBase<int>
    {
        [Key]
        public override int Pk_Id { get; set; }
        public string Customer_Id { get; set; }
        public int Fk_Business_Unit_Id { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }

    public class ConfMpCashflowRightRequestable : Requestable
    {
        public int? Pk_Id { get; set; }
        public string Customer_Id { get; set; }
        public int Fk_Business_Unit_Id { get; set; }
        public DateTime Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
    }
}

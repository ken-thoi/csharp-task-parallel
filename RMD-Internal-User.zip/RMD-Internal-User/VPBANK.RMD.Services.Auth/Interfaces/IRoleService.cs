﻿using System.Collections.Generic;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Services.Auth.DataTransferObjects;

namespace VPBANK.RMD.Services.Auth.Interfaces
{
    public interface IRoleService
    {
        IList<SelectedItem> GuiDataRoles();
        IList<SelectedItem> GuiDataBusinessUnitRoles();
        UserRoleMappingDto Save(UserRoleMappingDto userRoleMapping);
        void DeleteRoleByUsername(string username);
        void DeleteFunctionRole(string funcRole);
        void DeleteComponentRole(string compRole);
    }
}

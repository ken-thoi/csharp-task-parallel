﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Serilog;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using System;
using AutoMapper;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Data.PhoenixConf.Views.WebCore;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Data.PhoenixConf;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Utils.Common.Shared;

namespace VPBANK.RMD.API.Internal.Controllers.PhoenixConf.WebCore
{
    public class ConfTableMappingController : QueryController<PhoenixConfContext, ViewConfTableMapping, int>
    {
        public ConfTableMappingController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,

            IUnitOfWork<PhoenixConfContext> unitOfWork,
            ITrackableRepository<PhoenixConfContext, ViewConfTableMapping, int> trackableRepository,
            IGenericRepository<PhoenixConfContext, ViewConfTableMapping, int> genericRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository,
                unitOfWork, trackableRepository, genericRepository)
        {
        }

        /// <summary>
        /// Get all conf tables by engine core.
        /// </summary>
        /// <param name="paginatedParams"></param>
        /// <param name="engineCode"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual async Task<ActionResult<PaginatedContentResults<ViewConfTableMapping>>> QueryConfMapping([Required][NotNull][FromBody] PaginatedInputModel paginatedParams, [FromQuery(Name = "engineCode")] string engineCode)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                if (!string.IsNullOrEmpty(paginatedParams.FilterExpression)) 
                    paginatedParams.FilterExpression += Operations.AND;
                paginatedParams.FilterExpression += string.Format(QueryConditions.SQL_STR_CONDITION, engineCode, COLUMNS_NAME.ENGINE_CODE);

                // All data
                var total = _genericRepository.CountDataPaginated(paginatedParams);
                var data = _genericRepository.QueryDataPaginated(paginatedParams);
                dynamic result = await SqlQueryDataAsync(total, data, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        [HttpPost]
        [Route("{engineCode}")]
        public virtual async Task<ActionResult<PaginatedContentResults<ViewConfTableMapping>>> QueryConfMappingTable([Required][NotNull][FromBody] PaginatedInputModel paginatedParams, [FromRoute(Name = "engineCode")] string engineCode)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                if (!string.IsNullOrEmpty(paginatedParams.FilterExpression))
                    paginatedParams.FilterExpression += Operations.AND;
                paginatedParams.FilterExpression += string.Format(QueryConditions.SQL_STR_CONDITION, engineCode, COLUMNS_NAME.ENGINE_CODE);

                // All data
                var total = _genericRepository.CountDataPaginated(paginatedParams);
                var data = _genericRepository.QueryDataPaginated(paginatedParams);
                dynamic result = await SqlQueryDataAsync(total, data, paginatedParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
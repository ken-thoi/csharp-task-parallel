﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System.Dynamic;
using System;
using Serilog;
using System.Net;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Common.Helpers.Paging;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Apr;
using VPBANK.RMD.EFCore.Entities.Commons;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.Utils.Common.Datas;
using VPBANK.RMD.Utils.Common.Shared;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.Services.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Services.IFRS9_Conf.DataTransferObjects.Wfs;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Data.Core
{
    public class ILLPAdjustController : QueryController<IFRS9_DataContext, ILLPAdjust, int>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;
        private readonly IILLPAdjustService _illpAdjustService;
        private readonly IIfrsILLPResultRepository _ifrsILLPResultRepository;
        private readonly IViewIfrsInitContractRepository _viewIfrsInitContractRepository;
        private readonly ICustomerResultRepository _customerResultRepository;
        private readonly ICustomerInitContractResultRepository _customerInitContractResultRepository;

        public ILLPAdjustController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_DataContext> unitOfWork,
            ITrackableRepository<IFRS9_DataContext, ILLPAdjust, int> trackableRepository,
            IGenericRepository<IFRS9_DataContext, ILLPAdjust, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,

            IILLPAdjustService illpAdjustService,
            IIfrsILLPResultRepository ifrsILLPResultRepository,
            IViewIfrsInitContractRepository viewIfrsInitContractRepository,
            ICustomerResultRepository customerResultRepository,
            ICustomerInitContractResultRepository customerInitContractResultRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;

            _illpAdjustService = illpAdjustService;
            _ifrsILLPResultRepository = ifrsILLPResultRepository;
            _viewIfrsInitContractRepository = viewIfrsInitContractRepository;
            _customerResultRepository = customerResultRepository;
            _customerInitContractResultRepository = customerInitContractResultRepository;
        }

        /// <summary>
        /// Find all ILLPs results by Fk_Task_Execution_Id
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="paginatedParams"></param>
        /// <returns></returns>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public virtual async Task<ActionResult<PaginatedContentResults<IfrsILLPResult>>> FindAllILLPsByBusinessDate([FromRoute] int fk_Task_Execution_Id, [Required][NotNull][FromBody] PaginatedInputModel paginatedParams)
        {
            try
            {
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0)
                    return BadRequest();

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                var flowExecution = _genFlowExecutionRepository.Find(flowStepExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null)
                    return NotFound();

                var results = _ifrsILLPResultRepository.FindAllILLPsByCustomerIdAndBusinessDate(null, flowExecution.Business_Date);
                var total = results.Count();
                var data = results.ToList();

                // result
                dynamic result = await GenericQueryResultAsync(total, data, paginatedParams, false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find customer by customer_id
        /// </summary>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{customer_Id}")]
        public virtual ActionResult<IEnumerable<IfrsILLPResult>> FindByCustomerId([FromRoute] string customer_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();
                if (string.IsNullOrEmpty(customer_Id))
                    return NotFound();

                var result = _customerResultRepository.FindByCustomerId(customer_Id);

                // result
                return Ok(result);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find customer_name by customer_id for add/remove in ILLP customer_list (Callback)
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet("{fk_Task_Execution_Id}/customers/{customer_Id}")]
        public virtual ActionResult<IEnumerable<CallbackObjectRes>> FindCustomerForAddOrRemoveCustomerList([FromRoute] int fk_Task_Execution_Id, [NotNull][FromRoute] string customer_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || string.IsNullOrEmpty(customer_Id))
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM042);

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM042);

                var flowExecution = _genFlowExecutionRepository.Find(flowStepExecution.Fk_Flow_Execution_Id);
                if (flowExecution == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM042);

                var customer = _customerInitContractResultRepository.FindCustomerInitContractResultByCustomerId(customer_Id, flowExecution.Business_Date);
                if (customer == null)
                    throw new HttpErrorException(HttpStatusCode.BadRequest, nameof(HttpStatusCode.BadRequest), ErrorMessagesIfrs.EM042);

                return Ok(new List<CallbackObjectRes> { new CallbackObjectRes { controlId = "customer_Name", value = customer.Customer_Name } });
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Create new for add customer ILLP.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly created for add customer_id</returns>
        [HttpPost]
        public async virtual Task<ActionResult<Requests>> Add([NotNull][FromBody] IfrsDataReq<ILLPAdjust> req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null)
                    return BadRequest(ModelState);

                req.Request_Action = (int)ActionTypes.REQUEST;
                var results = await _illpAdjustService.SaveAsync(req, Constants.YES, GetUserPayloadFromHeader().Username);
                var msg = results.Item1;
                var request = results.Item2;

                // error, invalid
                if (!string.IsNullOrEmpty(msg) || request == null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                try
                {
                    // send noti
                    var routerKey = "/api/vbp-rmd/v1.0/illpadjust";
                    dynamic other = new ExpandoObject();
                    other.Customer_Id = request.Customer_Id;
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.IFRS_ILLP_CUST_LIST, typeof(StagingAdjust).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.PENDING, routerKey, subscribers, other);
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    Log.Error(ex.StackTrace);
                    Log.Error(ex.InnerException?.Message);
                }

                // results
                return CreatedAtAction(nameof(Add), request);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Create new for delete customer ILLP.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly created for delete customer_id</returns>
        [HttpPost]
        public async virtual Task<ActionResult<Requests>> Del([NotNull][FromBody] IfrsDataReq<ILLPAdjust> req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null)
                    return BadRequest(ModelState);

                req.Request_Action = (int)ActionTypes.REQUEST;
                var results = await _illpAdjustService.SaveAsync(req, Constants.NO, GetUserPayloadFromHeader().Username);
                var msg = results.Item1;
                var request = results.Item2;

                // error, invalid
                if (!string.IsNullOrEmpty(msg) || request == null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                try
                {
                    // send noti
                    var routerKey = "/api/vbp-rmd/v1.0/illpadjust";
                    dynamic other = new ExpandoObject();
                    other.Customer_Id = request.Customer_Id;
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.IFRS_ILLP_CUST_LIST, typeof(StagingAdjust).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.PENDING, routerKey, subscribers, other);
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    Log.Error(ex.StackTrace);
                    Log.Error(ex.InnerException?.Message);
                }

                // results
                return CreatedAtAction(nameof(Del), request);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Approve/Reject existed request.
        /// Approve (Request_action = 7)
        /// Reject (Request_action = 9)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="req"></param>
        /// <returns>A newly approved/rejected request</returns>
        [HttpPost]
        public async virtual Task<ActionResult<Requests>> Apr([NotNull][FromBody] IfrsDataApr req)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || req == null || req.Request_Id == 0)
                    return BadRequest(ModelState);

                var data = new IfrsDataReq<ILLPAdjust>
                {
                    Request_Id = req.Request_Id,
                    Fk_Flow_Execution_Id = req.Fk_Flow_Execution_Id,
                    Fk_Task_Execution_Id = req.Fk_Task_Execution_Id,
                    Business_Date = req.Business_Date,
                    Customer_Id = req.Customer_Id,
                    Request_Action = req.Request_Status.Equals(IfrsRequestStatus.APPROVED, StringComparison.CurrentCultureIgnoreCase) ? (int)ActionTypes.APPROVAL : (int)ActionTypes.REJECT,
                    Comments = req.Note_Approval,
                    Entities = null
                };

                var results = await _illpAdjustService.SaveAsync(data, Constants.YES, GetUserPayloadFromHeader().Username);
                var msg = results.Item1;
                var request = results.Item2;

                // error, invalid
                if (!string.IsNullOrEmpty(msg) || request == null)
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), msg);

                try
                {
                    // send noti
                    var routerKey = "/api/vbp-rmd/v1.0/illpadjust";
                    dynamic other = new ExpandoObject();
                    other.Customer_Id = request.Customer_Id;
                    // get subscribers
                    var subscribers = _subscriberRepository.FindAllSubscriberByRoutingKey(routerKey).Select(c => c.Username).Distinct().ToList();
                    SendNotifications(ActionTypes.IFRS_ILLP_CUST_LIST, typeof(StagingAdjust).Name.Split(SpecificSystems.DOT).Last(), RequestStatus.APPROVED, routerKey, subscribers, other);
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    Log.Error(ex.StackTrace);
                    Log.Error(ex.InnerException?.Message);
                }

                // results
                return CreatedAtAction(nameof(Apr), request);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Validate
        /// </summary>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <returns></returns>
        [HttpGet("{fk_Task_Execution_Id}")]
        public virtual IActionResult Validate([FromRoute] int fk_Task_Execution_Id)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                // check task completed
                var taskExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (taskExecution == null || taskExecution.Task_Status.Equals(Workflow_Status_Code.COMPELTED, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // results
                return Ok();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }

        /// <summary>
        /// Consolidate Adjust for add customer ILLP list.
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="fk_Task_Execution_Id"></param>
        /// <param name="consolidateAdjust"></param>
        /// <returns></returns>
        [HttpPost(template: "{fk_Task_Execution_Id}")]
        public async virtual Task<ActionResult<int>> IllpConsolidateAdjust([FromRoute] int fk_Task_Execution_Id, [NotNull][FromBody] ConsolidateAdjustDto consolidateAdjust)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid || fk_Task_Execution_Id == 0 || consolidateAdjust == null)
                    return BadRequest(ModelState);

                var flowStepExecution = _genFlowStepExecutionRepository.Find(fk_Task_Execution_Id);
                if (flowStepExecution == null)
                    return NotFound();

                if (!flowStepExecution.Task_Status.Equals(Workflow_Status_Code.READY_TO_EXECUTE, StringComparison.CurrentCultureIgnoreCase))
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), ErrorMessagesIfrs.EM043);

                // results
                return Ok(await _ifrsILLPResultRepository.ConsolidateAdjustByBusinessDate(consolidateAdjust.Business_Date));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}

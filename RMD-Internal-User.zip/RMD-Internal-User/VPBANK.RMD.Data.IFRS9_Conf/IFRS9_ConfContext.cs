﻿using Microsoft.EntityFrameworkCore;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.Core;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Entities.SchemaInfos;

namespace VPBANK.RMD.Data.IFRS9_Conf
{
    public partial class IFRS9_ConfContext : DbContext
    {
        public IFRS9_ConfContext(DbContextOptions<IFRS9_ConfContext> options) : base(options)
        {
        }

        #region DbQuery<T> is for Stored Procedure

        public DbQuery<TableInfo> TableInfos { get; set; }
        public DbQuery<ColumnInfo> ColumnInfos { get; set; }

        #endregion

        #region WF

        public virtual DbSet<DefWorkFlow> DefWorkFlows { get; set; }
        public virtual DbSet<DefWorkFlowStep> DefWorkFlowSteps { get; set; }
        public virtual DbSet<Task> Tasks { get; set; }
        public virtual DbSet<TaskParameter> TaskParameters { get; set; }
        public virtual DbSet<TaskStep> TaskSteps { get; set; }
        public virtual DbSet<WorkFlowStepMapping> WorkFlowStepMappings { get; set; }
        #endregion

        #region #Core
        public virtual DbSet<MpGlIfrs9> MpGlIFRS9s { get; set; }
        public virtual DbSet<MpDefaultFlag> MpDefaultFlags { get; set; }
        public virtual DbSet<MpGroupSegment> MpGroupSegments { get; set; }
        public virtual DbSet<MpModelSegmentGroup> MpModelSegmentGroups { get; set; }
        public virtual DbSet<MpQtrrSegment> MpQtrrSegments { get; set; }
        public virtual DbSet<MpSectorGroup> MpSectorGroups { get; set; }
        public virtual DbSet<MpAccrualGl> MpAccrualGls { get; set; }
        #endregion

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region APP

            modelBuilder.Entity<DefWorkFlow>().ToTable("DefWorkFlow", "WF");
            modelBuilder.Entity<DefWorkFlow>().HasKey(item => new { item.Pk_Id });

            //DefWorkFlowStep
            modelBuilder.Entity<DefWorkFlowStep>().ToTable("DefWorkFlowStep", "WF");
            modelBuilder.Entity<DefWorkFlowStep>().HasKey(item => new { item.Pk_Id });

            //Task
            modelBuilder.Entity<Task>().ToTable("Task", "WF");
            modelBuilder.Entity<Task>().HasKey(item => new { item.Pk_Id });

            //TaskParameter
            modelBuilder.Entity<TaskParameter>().ToTable("TaskParameter", "WF");
            modelBuilder.Entity<TaskParameter>().HasKey(item => new { item.Pk_Id });

            //TaskStep
            modelBuilder.Entity<TaskStep>().ToTable("TaskStep", "WF");
            modelBuilder.Entity<TaskStep>().HasKey(item => new { item.Pk_Id });

            //WorkFlowStepMapping
            modelBuilder.Entity<WorkFlowStepMapping>().ToTable("WorkFlowStepMapping", "WF");
            modelBuilder.Entity<WorkFlowStepMapping>().HasKey(item => new { item.Pk_Id });
            #endregion

            #region #Core
            //Mp_Gl_Ifrs9
            modelBuilder.Entity<MpGlIfrs9>().ToTable("Mp_Gl_Ifrs9", "Core");
            modelBuilder.Entity<MpGlIfrs9>().HasKey(item => new { item.Pk_Id });

            //Mp_Default_Flag
            modelBuilder.Entity<MpDefaultFlag>().ToTable("Mp_Default_Flag", "Core");
            modelBuilder.Entity<MpDefaultFlag>().HasKey(item => new { item.Pk_Id });

            //Mp_Group_Segment
            modelBuilder.Entity<MpGroupSegment>().ToTable("Mp_Group_Segment", "Core");
            modelBuilder.Entity<MpGroupSegment>().HasKey(item => new { item.Pk_Id });

            //MP_Model_Segment_Group
            modelBuilder.Entity<MpModelSegmentGroup>().ToTable("MP_Model_Segment_Group", "Core");
            modelBuilder.Entity<MpModelSegmentGroup>().HasKey(item => new { item.Pk_Id });

            //Mp_Qtrr_Segment
            modelBuilder.Entity<MpQtrrSegment>().ToTable("Mp_Qtrr_Segment", "Core");
            modelBuilder.Entity<MpQtrrSegment>().HasKey(item => new { item.Pk_Id });

            //Mp_Qtrr_Segment
            modelBuilder.Entity<MpSectorGroup>().ToTable("Mp_Sector_group", "Core");
            modelBuilder.Entity<MpSectorGroup>().HasKey(item => new { item.Pk_Id });

            //MP_Accrual_GL
            modelBuilder.Entity<MpAccrualGl>().ToTable("MP_Accrual_GL", "Core");
            modelBuilder.Entity<MpAccrualGl>().HasKey(item => new { item.Pk_Id });
            #endregion

            base.OnModelCreating(modelBuilder);
        }
    }
}

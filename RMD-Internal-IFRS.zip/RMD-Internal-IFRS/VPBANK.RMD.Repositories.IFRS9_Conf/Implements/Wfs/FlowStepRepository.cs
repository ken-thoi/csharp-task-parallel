﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Implements;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Wfs;

namespace VPBANK.RMD.Repositories.IFRS9_Conf.Implements.Wfs
{
    public class FlowStepRepository : Repository<IFRS9_ConfContext, FlowStep, int>, IFlowStepRepository
    {
        protected readonly IDistributedCache _distributedCache;
        protected readonly IFRS9_ConfContext _context;

        public FlowStepRepository(IDistributedCache distributedCache, ITrackableRepository<IFRS9_ConfContext, FlowStep, int> trackableRepository,
            IFRS9_ConfContext context) : base(trackableRepository)
        {
            _distributedCache = distributedCache;
            _context = context;
        }

        public List<FlowStep> FindAllByFlowId(int flowId)
        {
            try
            {
                return Queryable().Where(c => c.Fk_Flow_Id == flowId).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> DeleteFlowStepByFlowId(int flowId)
        {
            try
            {
                return await _context.Database.ExecuteSqlCommandAsync($"DELETE WF.Flow_Step WHERE Fk_Flow_Id = {flowId}");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

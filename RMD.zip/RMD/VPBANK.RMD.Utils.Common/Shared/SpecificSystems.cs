﻿namespace VPBANK.RMD.Utils.Common.Shared
{
    public static class SpecificSystems
    {
        public const string DOT = ".";
        public const string COMMA = ",";
        public const string COL_JOIN_COMMA = ", ";
        public const string SEMICOLON = ";";
        public const string EXCLAMATION = "!";
        public const string BULLET = "*";
        public const string PILE = "|";
        public const string NEXTLINE = "\r\n";
        public const string QUOTE_SIGNLE = "'";
        public const string QUOTE_DOUBLE = "\"";
        public const string SLASH = "/";
        public const string BACK_SLASH = "\\";
        public const string DASH = "-";
        public const string UNDERSCORE = "_";
        public const string WHITE_SPACE = " ";
        public const string POUND = "#";
        public const string PERCENT = "%";
        public const string COPY_RIGHT = "©";
        public const string REGISTERED = "®";
        public const string TRADEMARK = "™";

        public const string BRACKET_FIRST = "[";
        public const string BRACKET_LAST = "]";
        public const string PARENTHESES_FIRST = "(";
        public const string PARENTHESES_LAST = ")";
    }
}

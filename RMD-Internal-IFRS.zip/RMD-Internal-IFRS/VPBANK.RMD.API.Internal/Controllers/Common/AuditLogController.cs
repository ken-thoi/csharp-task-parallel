﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using Serilog;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using VPBANK.RMD.Utils.AuditLog;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.Utils.AuditLog.Models;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.EFCore.Entities.Commons;

namespace VPBANK.RMD.API.Internal.Controllers.Common
{
    [Authorize]
    public class AuditLogController : BaseController
    {
        private readonly IAuditElasticProvider<ElasticLog> _elasticProvider;

        public AuditLogController(
            IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IAuditElasticProvider<ElasticLog> elasticProvider) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService)
        {
            _elasticProvider = elasticProvider;
        }

        /// <summary>
        /// Add new audit logs
        /// </summary>
        /// <param name="elasticLog"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual async Task<ActionResult<IElasticLog>> Create([FromBody] ElasticLog elasticLog)
        {
            try
            {
                // check object valid
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                await _elasticProvider.AddLogAsync(elasticLog);

                // results
                return CreatedAtAction(nameof(Create), new { id = elasticLog.timestamp }, elasticLog);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
                // out method
            }
        }
    }
}
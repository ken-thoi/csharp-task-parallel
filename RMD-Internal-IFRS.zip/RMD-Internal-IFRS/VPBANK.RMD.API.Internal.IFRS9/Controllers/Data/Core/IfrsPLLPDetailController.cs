﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using AutoMapper;
using System;
using Serilog;
using System.Net;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using VPBANK.RMD.Utils.Common;
using VPBANK.RMD.Utils.Notification.Publisher;
using VPBANK.RMD.API.Common.Middlewares;
using VPBANK.RMD.API.Common.Controllers;
using VPBANK.RMD.API.Settings;
using VPBANK.RMD.EFCore;
using VPBANK.RMD.EFCore.Abstractions;
using VPBANK.RMD.EFCore.Generics;
using VPBANK.RMD.Repositories.PhoenixConf.Interfaces.App;
using VPBANK.RMD.Services.Auth.Interfaces;
using VPBANK.RMD.Data.IFRS9_Data;
using VPBANK.RMD.Data.IFRS9_Data.Entities.POCOs.Core;
using VPBANK.RMD.Services.IFRS9_Data.DataTransferObjects;
using VPBANK.RMD.Repositories.IFRS9_Conf.Interfaces.Core;
using VPBANK.RMD.Data.IFRS9_Conf.StoreProcedures.Core;
using VPBANK.RMD.Repositories.IFRS9_Data.Interfaces;
using VPBANK.RMD.Data.IFRS9_Conf;
using VPBANK.RMD.Data.IFRS9_Conf.Entities.WF;

namespace VPBANK.RMD.API.Internal.IFRS9.Controllers.Conf.Apr
{
    public class IfrsPLLPDetailController : QueryController<IFRS9_DataContext, ILLPAdjust, int>
    {
        private readonly IGenericRepository<IFRS9_ConfContext, FlowExecution, int> _genFlowExecutionRepository;
        private readonly IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> _genFlowStepExecutionRepository;

        private readonly IIfrsPLLPResultRepository _ifrsPllpResultRepository;
        private readonly IPLLPCustomerRepository _pllpCustomerRepository;
        private readonly ICustomerResultRepository _customerResultRepository;

        public IfrsPLLPDetailController(IMemoryCache memoryCache,
            IConfiguration configuration,
            IWebHostEnvironment env,
            IAppSettingsReader appSettings,
            IHttpClientFactory httpClientFactory,
            IMapper mapper,
            IRabbitMqPublisher rabbitManager,
            ISubscriberInfoRepository subscriberRepository,
            IUserService userService,

            IUnitOfWork<IFRS9_DataContext> unitOfWork,
            ITrackableRepository<IFRS9_DataContext, ILLPAdjust, int> trackableRepository,
            IGenericRepository<IFRS9_DataContext, ILLPAdjust, int> genericRepository,

            IGenericRepository<IFRS9_ConfContext, FlowExecution, int> genFlowExecutionRepository,
            IGenericRepository<IFRS9_ConfContext, FlowStepExecution, int> genFlowStepExecutionRepository,

            IIfrsPLLPResultRepository ifrsPllpResultRepository,
            IPLLPCustomerRepository pllpCustomerRepository,
            ICustomerResultRepository customerResultRepository) : base(memoryCache, configuration, env, appSettings, httpClientFactory, mapper, rabbitManager, subscriberRepository, userService,
                unitOfWork, trackableRepository, genericRepository)
        {
            _genFlowExecutionRepository = genFlowExecutionRepository;
            _genFlowStepExecutionRepository = genFlowStepExecutionRepository;

            _ifrsPllpResultRepository = ifrsPllpResultRepository;
            _pllpCustomerRepository = pllpCustomerRepository;
            _customerResultRepository = customerResultRepository;
        }

        /// <summary>
        /// Get customer_info from Cust_data
        /// </summary>
        /// <param name="customer_Id"></param>
        /// <returns></returns>
        [HttpGet(template: "{customer_Id}")]
        public IActionResult FindCustomerInfo([FromRoute] string customer_Id)
        {
            try
            {
                if (!ModelState.IsValid || string.IsNullOrEmpty(customer_Id))
                    return BadRequest();

                var customer = _customerResultRepository.FindByCustomerId(customer_Id);

                return Ok(customer);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Find all PLLPs by customer_id, business_date
        /// </summary>
        /// <param name="pllpResultDto"></param>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult<IEnumerable<IfrsPLLPResult>> FindAllContractPLLPsByCustomerId([NotNull][FromBody] PLLPResultDto pllpResultDto)
        {
            try
            {
                if (!ModelState.IsValid || pllpResultDto == null || string.IsNullOrEmpty(pllpResultDto.Customer_Id) || pllpResultDto.Business_Date == null)
                    return BadRequest();

                var results = _ifrsPllpResultRepository.FindAllContractByCustomerId(pllpResultDto.Customer_Id, pllpResultDto.Business_Date);

                return Ok(results);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                Log.Error(ex.StackTrace);
                Log.Error(ex.InnerException?.Message);
                if (ex is HttpErrorException)
                    throw;
                else
                    throw new HttpErrorException(HttpStatusCode.InternalServerError, nameof(HttpStatusCode.InternalServerError), string.Format(ErrorMessages.SE000, ex.Message));
            }
            finally
            {
            }
        }
    }
}
